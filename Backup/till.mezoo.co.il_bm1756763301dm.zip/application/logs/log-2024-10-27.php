<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-27 03:03:05 --> Config Class Initialized
INFO - 2024-10-27 03:03:05 --> Hooks Class Initialized
DEBUG - 2024-10-27 03:03:05 --> UTF-8 Support Enabled
INFO - 2024-10-27 03:03:05 --> Utf8 Class Initialized
INFO - 2024-10-27 03:03:05 --> URI Class Initialized
DEBUG - 2024-10-27 03:03:05 --> No URI present. Default controller set.
INFO - 2024-10-27 03:03:05 --> Router Class Initialized
INFO - 2024-10-27 03:03:05 --> Output Class Initialized
INFO - 2024-10-27 03:03:05 --> Security Class Initialized
DEBUG - 2024-10-27 03:03:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 03:03:05 --> Input Class Initialized
INFO - 2024-10-27 03:03:05 --> Language Class Initialized
ERROR - 2024-10-27 03:03:05 --> TEST ERROR MESSAGE - 2024-10-27 03:03:05
INFO - 2024-10-27 03:03:05 --> Loader Class Initialized
INFO - 2024-10-27 03:03:05 --> Controller Class Initialized
INFO - 2024-10-27 03:03:05 --> Database Driver Class Initialized
INFO - 2024-10-27 03:03:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 03:03:05 --> Helper loaded: form_helper
INFO - 2024-10-27 03:03:05 --> Helper loaded: url_helper
INFO - 2024-10-27 03:03:05 --> Model Class Initialized
INFO - 2024-10-27 03:03:05 --> Helper loaded: inflector_helper
INFO - 2024-10-27 03:03:05 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 03:03:05 --> Helper loaded: email_helper
INFO - 2024-10-27 03:03:05 --> Model Class Initialized
INFO - 2024-10-27 03:03:05 --> Model Class Initialized
INFO - 2024-10-27 03:03:05 --> Model Class Initialized
INFO - 2024-10-27 03:03:05 --> Model Class Initialized
INFO - 2024-10-27 03:03:05 --> Model Class Initialized
INFO - 2024-10-27 03:03:05 --> Model Class Initialized
INFO - 2024-10-27 03:03:05 --> Model Class Initialized
DEBUG - 2024-10-27 03:03:05 --> plural called with: company
DEBUG - 2024-10-27 03:03:05 --> is_countable called with!!!!: company
INFO - 2024-10-27 03:03:05 --> Model Class Initialized
INFO - 2024-10-27 03:03:05 --> Model Class Initialized
INFO - 2024-10-27 03:03:05 --> Model Class Initialized
INFO - 2024-10-27 03:03:05 --> Final output sent to browser
DEBUG - 2024-10-27 03:03:05 --> Total execution time: 0.0283
INFO - 2024-10-27 05:50:19 --> Config Class Initialized
INFO - 2024-10-27 05:50:19 --> Hooks Class Initialized
DEBUG - 2024-10-27 05:50:19 --> UTF-8 Support Enabled
INFO - 2024-10-27 05:50:19 --> Utf8 Class Initialized
INFO - 2024-10-27 05:50:19 --> URI Class Initialized
INFO - 2024-10-27 05:50:19 --> Router Class Initialized
INFO - 2024-10-27 05:50:19 --> Output Class Initialized
INFO - 2024-10-27 05:50:19 --> Security Class Initialized
DEBUG - 2024-10-27 05:50:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 05:50:19 --> Input Class Initialized
INFO - 2024-10-27 05:50:19 --> Language Class Initialized
ERROR - 2024-10-27 05:50:19 --> TEST ERROR MESSAGE - 2024-10-27 05:50:19
INFO - 2024-10-27 05:50:19 --> Loader Class Initialized
INFO - 2024-10-27 05:50:19 --> Controller Class Initialized
INFO - 2024-10-27 05:50:19 --> Database Driver Class Initialized
INFO - 2024-10-27 05:50:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 05:50:19 --> Helper loaded: form_helper
INFO - 2024-10-27 05:50:19 --> Helper loaded: url_helper
INFO - 2024-10-27 05:50:19 --> Model Class Initialized
INFO - 2024-10-27 05:50:19 --> Helper loaded: inflector_helper
INFO - 2024-10-27 05:50:19 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 05:50:19 --> Helper loaded: email_helper
INFO - 2024-10-27 05:50:19 --> Model Class Initialized
INFO - 2024-10-27 05:50:19 --> Model Class Initialized
INFO - 2024-10-27 05:50:19 --> Model Class Initialized
INFO - 2024-10-27 05:50:19 --> Model Class Initialized
INFO - 2024-10-27 05:50:19 --> Model Class Initialized
INFO - 2024-10-27 05:50:19 --> Model Class Initialized
INFO - 2024-10-27 05:50:19 --> Model Class Initialized
DEBUG - 2024-10-27 05:50:19 --> plural called with: company
DEBUG - 2024-10-27 05:50:19 --> is_countable called with!!!!: company
INFO - 2024-10-27 05:50:19 --> Model Class Initialized
INFO - 2024-10-27 05:50:19 --> Model Class Initialized
INFO - 2024-10-27 05:50:19 --> Model Class Initialized
INFO - 2024-10-27 05:50:20 --> Config Class Initialized
INFO - 2024-10-27 05:50:20 --> Hooks Class Initialized
DEBUG - 2024-10-27 05:50:20 --> UTF-8 Support Enabled
INFO - 2024-10-27 05:50:20 --> Utf8 Class Initialized
INFO - 2024-10-27 05:50:20 --> URI Class Initialized
INFO - 2024-10-27 05:50:20 --> Router Class Initialized
INFO - 2024-10-27 05:50:20 --> Output Class Initialized
INFO - 2024-10-27 05:50:20 --> Security Class Initialized
DEBUG - 2024-10-27 05:50:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 05:50:20 --> Input Class Initialized
INFO - 2024-10-27 05:50:20 --> Language Class Initialized
ERROR - 2024-10-27 05:50:20 --> TEST ERROR MESSAGE - 2024-10-27 05:50:20
INFO - 2024-10-27 05:50:20 --> Loader Class Initialized
INFO - 2024-10-27 05:50:20 --> Controller Class Initialized
INFO - 2024-10-27 05:50:20 --> Database Driver Class Initialized
INFO - 2024-10-27 05:50:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 05:50:20 --> Helper loaded: form_helper
INFO - 2024-10-27 05:50:20 --> Helper loaded: url_helper
INFO - 2024-10-27 05:50:20 --> Model Class Initialized
INFO - 2024-10-27 05:50:20 --> Helper loaded: inflector_helper
INFO - 2024-10-27 05:50:20 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 05:50:20 --> Helper loaded: email_helper
INFO - 2024-10-27 05:50:20 --> Model Class Initialized
INFO - 2024-10-27 05:50:20 --> Model Class Initialized
INFO - 2024-10-27 05:50:20 --> Model Class Initialized
INFO - 2024-10-27 05:50:20 --> Model Class Initialized
INFO - 2024-10-27 05:50:20 --> Model Class Initialized
INFO - 2024-10-27 05:50:20 --> Model Class Initialized
INFO - 2024-10-27 05:50:20 --> Model Class Initialized
DEBUG - 2024-10-27 05:50:20 --> plural called with: company
DEBUG - 2024-10-27 05:50:20 --> is_countable called with!!!!: company
INFO - 2024-10-27 05:50:20 --> Model Class Initialized
INFO - 2024-10-27 05:50:20 --> Model Class Initialized
INFO - 2024-10-27 05:50:20 --> Model Class Initialized
INFO - 2024-10-27 05:50:20 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-27 05:50:20 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 05:50:20 --> Final output sent to browser
DEBUG - 2024-10-27 05:50:20 --> Total execution time: 0.0265
INFO - 2024-10-27 06:37:00 --> Config Class Initialized
INFO - 2024-10-27 06:37:00 --> Hooks Class Initialized
DEBUG - 2024-10-27 06:37:00 --> UTF-8 Support Enabled
INFO - 2024-10-27 06:37:00 --> Utf8 Class Initialized
INFO - 2024-10-27 06:37:00 --> URI Class Initialized
INFO - 2024-10-27 06:37:00 --> Router Class Initialized
INFO - 2024-10-27 06:37:00 --> Output Class Initialized
INFO - 2024-10-27 06:37:00 --> Security Class Initialized
DEBUG - 2024-10-27 06:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 06:37:00 --> Input Class Initialized
INFO - 2024-10-27 06:37:00 --> Language Class Initialized
ERROR - 2024-10-27 06:37:00 --> TEST ERROR MESSAGE - 2024-10-27 06:37:00
INFO - 2024-10-27 06:37:00 --> Loader Class Initialized
INFO - 2024-10-27 06:37:00 --> Controller Class Initialized
INFO - 2024-10-27 06:37:00 --> Database Driver Class Initialized
INFO - 2024-10-27 06:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 06:37:00 --> Helper loaded: form_helper
INFO - 2024-10-27 06:37:00 --> Helper loaded: url_helper
INFO - 2024-10-27 06:37:00 --> Model Class Initialized
INFO - 2024-10-27 06:37:00 --> Helper loaded: inflector_helper
INFO - 2024-10-27 06:37:00 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 06:37:00 --> Helper loaded: email_helper
INFO - 2024-10-27 06:37:00 --> Model Class Initialized
INFO - 2024-10-27 06:37:00 --> Model Class Initialized
INFO - 2024-10-27 06:37:00 --> Model Class Initialized
INFO - 2024-10-27 06:37:00 --> Model Class Initialized
INFO - 2024-10-27 06:37:00 --> Model Class Initialized
INFO - 2024-10-27 06:37:00 --> Model Class Initialized
INFO - 2024-10-27 06:37:00 --> Model Class Initialized
DEBUG - 2024-10-27 06:37:00 --> plural called with: company
DEBUG - 2024-10-27 06:37:00 --> is_countable called with!!!!: company
INFO - 2024-10-27 06:37:00 --> Model Class Initialized
INFO - 2024-10-27 06:37:00 --> Model Class Initialized
INFO - 2024-10-27 06:37:00 --> Model Class Initialized
INFO - 2024-10-27 06:37:00 --> Config Class Initialized
INFO - 2024-10-27 06:37:00 --> Hooks Class Initialized
DEBUG - 2024-10-27 06:37:00 --> UTF-8 Support Enabled
INFO - 2024-10-27 06:37:00 --> Utf8 Class Initialized
INFO - 2024-10-27 06:37:00 --> URI Class Initialized
INFO - 2024-10-27 06:37:00 --> Router Class Initialized
INFO - 2024-10-27 06:37:00 --> Output Class Initialized
INFO - 2024-10-27 06:37:00 --> Security Class Initialized
DEBUG - 2024-10-27 06:37:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 06:37:00 --> Input Class Initialized
INFO - 2024-10-27 06:37:00 --> Language Class Initialized
ERROR - 2024-10-27 06:37:00 --> TEST ERROR MESSAGE - 2024-10-27 06:37:00
INFO - 2024-10-27 06:37:00 --> Loader Class Initialized
INFO - 2024-10-27 06:37:00 --> Controller Class Initialized
INFO - 2024-10-27 06:37:00 --> Database Driver Class Initialized
INFO - 2024-10-27 06:37:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 06:37:00 --> Helper loaded: form_helper
INFO - 2024-10-27 06:37:00 --> Helper loaded: url_helper
INFO - 2024-10-27 06:37:00 --> Model Class Initialized
INFO - 2024-10-27 06:37:00 --> Helper loaded: inflector_helper
INFO - 2024-10-27 06:37:00 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 06:37:00 --> Helper loaded: email_helper
INFO - 2024-10-27 06:37:00 --> Model Class Initialized
INFO - 2024-10-27 06:37:00 --> Model Class Initialized
INFO - 2024-10-27 06:37:00 --> Model Class Initialized
INFO - 2024-10-27 06:37:00 --> Model Class Initialized
INFO - 2024-10-27 06:37:00 --> Model Class Initialized
INFO - 2024-10-27 06:37:00 --> Model Class Initialized
INFO - 2024-10-27 06:37:00 --> Model Class Initialized
DEBUG - 2024-10-27 06:37:00 --> plural called with: company
DEBUG - 2024-10-27 06:37:00 --> is_countable called with!!!!: company
INFO - 2024-10-27 06:37:00 --> Model Class Initialized
INFO - 2024-10-27 06:37:00 --> Model Class Initialized
INFO - 2024-10-27 06:37:00 --> Model Class Initialized
ERROR - 2024-10-27 06:37:02 --> Severity: Notice --> Undefined index: freetext /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-27 06:37:02 --> Severity: Notice --> Undefined index: socialDes /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-27 06:37:02 --> Severity: Notice --> Undefined index: company /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-27 06:37:02 --> Severity: Notice --> Undefined index: division /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-27 06:37:02 --> Severity: Notice --> Undefined index: dataGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-27 06:37:02 --> Severity: Notice --> Undefined index: finalGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
INFO - 2024-10-27 06:37:02 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 06:37:02 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 06:37:02 --> Final output sent to browser
DEBUG - 2024-10-27 06:37:02 --> Total execution time: 2.5188
INFO - 2024-10-27 06:37:12 --> Config Class Initialized
INFO - 2024-10-27 06:37:12 --> Hooks Class Initialized
DEBUG - 2024-10-27 06:37:12 --> UTF-8 Support Enabled
INFO - 2024-10-27 06:37:12 --> Utf8 Class Initialized
INFO - 2024-10-27 06:37:12 --> URI Class Initialized
INFO - 2024-10-27 06:37:12 --> Router Class Initialized
INFO - 2024-10-27 06:37:12 --> Output Class Initialized
INFO - 2024-10-27 06:37:12 --> Security Class Initialized
DEBUG - 2024-10-27 06:37:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 06:37:12 --> Input Class Initialized
INFO - 2024-10-27 06:37:12 --> Language Class Initialized
ERROR - 2024-10-27 06:37:12 --> TEST ERROR MESSAGE - 2024-10-27 06:37:12
INFO - 2024-10-27 06:37:12 --> Loader Class Initialized
INFO - 2024-10-27 06:37:12 --> Controller Class Initialized
INFO - 2024-10-27 06:37:12 --> Database Driver Class Initialized
INFO - 2024-10-27 06:37:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 06:37:12 --> Helper loaded: form_helper
INFO - 2024-10-27 06:37:12 --> Helper loaded: url_helper
INFO - 2024-10-27 06:37:12 --> Model Class Initialized
INFO - 2024-10-27 06:37:12 --> Helper loaded: inflector_helper
INFO - 2024-10-27 06:37:12 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 06:37:12 --> Helper loaded: email_helper
INFO - 2024-10-27 06:37:12 --> Model Class Initialized
INFO - 2024-10-27 06:37:12 --> Model Class Initialized
INFO - 2024-10-27 06:37:12 --> Model Class Initialized
INFO - 2024-10-27 06:37:12 --> Model Class Initialized
INFO - 2024-10-27 06:37:12 --> Model Class Initialized
INFO - 2024-10-27 06:37:12 --> Model Class Initialized
INFO - 2024-10-27 06:37:12 --> Model Class Initialized
DEBUG - 2024-10-27 06:37:12 --> plural called with: company
DEBUG - 2024-10-27 06:37:12 --> is_countable called with!!!!: company
INFO - 2024-10-27 06:37:12 --> Model Class Initialized
INFO - 2024-10-27 06:37:12 --> Model Class Initialized
INFO - 2024-10-27 06:37:12 --> Model Class Initialized
INFO - 2024-10-27 06:37:12 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 06:37:12 --> Final output sent to browser
DEBUG - 2024-10-27 06:37:12 --> Total execution time: 0.0275
INFO - 2024-10-27 06:37:18 --> Config Class Initialized
INFO - 2024-10-27 06:37:18 --> Hooks Class Initialized
DEBUG - 2024-10-27 06:37:18 --> UTF-8 Support Enabled
INFO - 2024-10-27 06:37:18 --> Utf8 Class Initialized
INFO - 2024-10-27 06:37:18 --> URI Class Initialized
INFO - 2024-10-27 06:37:18 --> Router Class Initialized
INFO - 2024-10-27 06:37:18 --> Output Class Initialized
INFO - 2024-10-27 06:37:18 --> Security Class Initialized
DEBUG - 2024-10-27 06:37:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 06:37:18 --> Input Class Initialized
INFO - 2024-10-27 06:37:18 --> Language Class Initialized
ERROR - 2024-10-27 06:37:18 --> TEST ERROR MESSAGE - 2024-10-27 06:37:18
INFO - 2024-10-27 06:37:18 --> Loader Class Initialized
INFO - 2024-10-27 06:37:18 --> Controller Class Initialized
INFO - 2024-10-27 06:37:18 --> Database Driver Class Initialized
INFO - 2024-10-27 06:37:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 06:37:18 --> Helper loaded: form_helper
INFO - 2024-10-27 06:37:18 --> Helper loaded: url_helper
INFO - 2024-10-27 06:37:18 --> Model Class Initialized
INFO - 2024-10-27 06:37:18 --> Helper loaded: inflector_helper
INFO - 2024-10-27 06:37:18 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 06:37:18 --> Helper loaded: email_helper
INFO - 2024-10-27 06:37:18 --> Model Class Initialized
INFO - 2024-10-27 06:37:18 --> Model Class Initialized
INFO - 2024-10-27 06:37:18 --> Model Class Initialized
INFO - 2024-10-27 06:37:18 --> Model Class Initialized
INFO - 2024-10-27 06:37:18 --> Model Class Initialized
INFO - 2024-10-27 06:37:18 --> Model Class Initialized
INFO - 2024-10-27 06:37:18 --> Model Class Initialized
DEBUG - 2024-10-27 06:37:18 --> plural called with: company
DEBUG - 2024-10-27 06:37:18 --> is_countable called with!!!!: company
INFO - 2024-10-27 06:37:18 --> Model Class Initialized
INFO - 2024-10-27 06:37:18 --> Model Class Initialized
INFO - 2024-10-27 06:37:18 --> Model Class Initialized
INFO - 2024-10-27 06:37:18 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 06:37:18 --> Final output sent to browser
DEBUG - 2024-10-27 06:37:18 --> Total execution time: 0.0251
INFO - 2024-10-27 06:37:22 --> Config Class Initialized
INFO - 2024-10-27 06:37:22 --> Hooks Class Initialized
DEBUG - 2024-10-27 06:37:22 --> UTF-8 Support Enabled
INFO - 2024-10-27 06:37:22 --> Utf8 Class Initialized
INFO - 2024-10-27 06:37:22 --> URI Class Initialized
INFO - 2024-10-27 06:37:22 --> Router Class Initialized
INFO - 2024-10-27 06:37:22 --> Output Class Initialized
INFO - 2024-10-27 06:37:22 --> Security Class Initialized
DEBUG - 2024-10-27 06:37:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 06:37:22 --> Input Class Initialized
INFO - 2024-10-27 06:37:22 --> Language Class Initialized
ERROR - 2024-10-27 06:37:22 --> TEST ERROR MESSAGE - 2024-10-27 06:37:22
INFO - 2024-10-27 06:37:22 --> Loader Class Initialized
INFO - 2024-10-27 06:37:22 --> Controller Class Initialized
INFO - 2024-10-27 06:37:22 --> Database Driver Class Initialized
INFO - 2024-10-27 06:37:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 06:37:22 --> Helper loaded: form_helper
INFO - 2024-10-27 06:37:22 --> Helper loaded: url_helper
INFO - 2024-10-27 06:37:22 --> Model Class Initialized
INFO - 2024-10-27 06:37:22 --> Helper loaded: inflector_helper
INFO - 2024-10-27 06:37:22 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 06:37:22 --> Helper loaded: email_helper
INFO - 2024-10-27 06:37:22 --> Model Class Initialized
INFO - 2024-10-27 06:37:22 --> Model Class Initialized
INFO - 2024-10-27 06:37:22 --> Model Class Initialized
INFO - 2024-10-27 06:37:22 --> Model Class Initialized
INFO - 2024-10-27 06:37:22 --> Model Class Initialized
INFO - 2024-10-27 06:37:22 --> Model Class Initialized
INFO - 2024-10-27 06:37:22 --> Model Class Initialized
DEBUG - 2024-10-27 06:37:22 --> plural called with: company
DEBUG - 2024-10-27 06:37:22 --> is_countable called with!!!!: company
INFO - 2024-10-27 06:37:22 --> Model Class Initialized
INFO - 2024-10-27 06:37:22 --> Model Class Initialized
INFO - 2024-10-27 06:37:22 --> Model Class Initialized
INFO - 2024-10-27 06:37:22 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 06:37:22 --> Final output sent to browser
DEBUG - 2024-10-27 06:37:22 --> Total execution time: 0.0268
INFO - 2024-10-27 06:37:25 --> Config Class Initialized
INFO - 2024-10-27 06:37:25 --> Hooks Class Initialized
DEBUG - 2024-10-27 06:37:25 --> UTF-8 Support Enabled
INFO - 2024-10-27 06:37:25 --> Utf8 Class Initialized
INFO - 2024-10-27 06:37:25 --> URI Class Initialized
INFO - 2024-10-27 06:37:25 --> Router Class Initialized
INFO - 2024-10-27 06:37:25 --> Output Class Initialized
INFO - 2024-10-27 06:37:25 --> Security Class Initialized
DEBUG - 2024-10-27 06:37:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 06:37:25 --> Input Class Initialized
INFO - 2024-10-27 06:37:25 --> Language Class Initialized
ERROR - 2024-10-27 06:37:25 --> TEST ERROR MESSAGE - 2024-10-27 06:37:25
INFO - 2024-10-27 06:37:25 --> Loader Class Initialized
INFO - 2024-10-27 06:37:25 --> Controller Class Initialized
INFO - 2024-10-27 06:37:25 --> Database Driver Class Initialized
INFO - 2024-10-27 06:37:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 06:37:25 --> Helper loaded: form_helper
INFO - 2024-10-27 06:37:25 --> Helper loaded: url_helper
INFO - 2024-10-27 06:37:25 --> Model Class Initialized
INFO - 2024-10-27 06:37:25 --> Helper loaded: inflector_helper
INFO - 2024-10-27 06:37:25 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 06:37:25 --> Helper loaded: email_helper
INFO - 2024-10-27 06:37:25 --> Model Class Initialized
INFO - 2024-10-27 06:37:25 --> Model Class Initialized
INFO - 2024-10-27 06:37:25 --> Model Class Initialized
INFO - 2024-10-27 06:37:25 --> Model Class Initialized
INFO - 2024-10-27 06:37:25 --> Model Class Initialized
INFO - 2024-10-27 06:37:25 --> Model Class Initialized
INFO - 2024-10-27 06:37:25 --> Model Class Initialized
DEBUG - 2024-10-27 06:37:25 --> plural called with: company
DEBUG - 2024-10-27 06:37:25 --> is_countable called with!!!!: company
INFO - 2024-10-27 06:37:25 --> Model Class Initialized
INFO - 2024-10-27 06:37:25 --> Model Class Initialized
INFO - 2024-10-27 06:37:25 --> Model Class Initialized
INFO - 2024-10-27 06:37:25 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 06:37:25 --> Final output sent to browser
DEBUG - 2024-10-27 06:37:25 --> Total execution time: 0.0308
INFO - 2024-10-27 07:06:10 --> Config Class Initialized
INFO - 2024-10-27 07:06:10 --> Hooks Class Initialized
DEBUG - 2024-10-27 07:06:10 --> UTF-8 Support Enabled
INFO - 2024-10-27 07:06:10 --> Utf8 Class Initialized
INFO - 2024-10-27 07:06:10 --> URI Class Initialized
INFO - 2024-10-27 07:06:10 --> Router Class Initialized
INFO - 2024-10-27 07:06:10 --> Output Class Initialized
INFO - 2024-10-27 07:06:10 --> Security Class Initialized
DEBUG - 2024-10-27 07:06:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 07:06:10 --> Input Class Initialized
INFO - 2024-10-27 07:06:10 --> Language Class Initialized
ERROR - 2024-10-27 07:06:10 --> TEST ERROR MESSAGE - 2024-10-27 07:06:10
INFO - 2024-10-27 07:06:10 --> Loader Class Initialized
INFO - 2024-10-27 07:06:10 --> Controller Class Initialized
INFO - 2024-10-27 07:06:10 --> Database Driver Class Initialized
INFO - 2024-10-27 07:06:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 07:06:10 --> Helper loaded: form_helper
INFO - 2024-10-27 07:06:10 --> Helper loaded: url_helper
INFO - 2024-10-27 07:06:10 --> Model Class Initialized
INFO - 2024-10-27 07:06:10 --> Helper loaded: inflector_helper
INFO - 2024-10-27 07:06:10 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 07:06:10 --> Helper loaded: email_helper
INFO - 2024-10-27 07:06:10 --> Model Class Initialized
INFO - 2024-10-27 07:06:10 --> Model Class Initialized
INFO - 2024-10-27 07:06:10 --> Model Class Initialized
INFO - 2024-10-27 07:06:10 --> Model Class Initialized
INFO - 2024-10-27 07:06:10 --> Model Class Initialized
INFO - 2024-10-27 07:06:10 --> Model Class Initialized
INFO - 2024-10-27 07:06:10 --> Model Class Initialized
DEBUG - 2024-10-27 07:06:10 --> plural called with: company
DEBUG - 2024-10-27 07:06:10 --> is_countable called with!!!!: company
INFO - 2024-10-27 07:06:10 --> Model Class Initialized
INFO - 2024-10-27 07:06:10 --> Model Class Initialized
INFO - 2024-10-27 07:06:10 --> Model Class Initialized
INFO - 2024-10-27 07:06:10 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 07:06:10 --> Final output sent to browser
DEBUG - 2024-10-27 07:06:10 --> Total execution time: 0.0300
INFO - 2024-10-27 07:59:43 --> Config Class Initialized
INFO - 2024-10-27 07:59:43 --> Hooks Class Initialized
DEBUG - 2024-10-27 07:59:43 --> UTF-8 Support Enabled
INFO - 2024-10-27 07:59:43 --> Utf8 Class Initialized
INFO - 2024-10-27 07:59:43 --> URI Class Initialized
INFO - 2024-10-27 07:59:43 --> Router Class Initialized
INFO - 2024-10-27 07:59:43 --> Output Class Initialized
INFO - 2024-10-27 07:59:43 --> Security Class Initialized
DEBUG - 2024-10-27 07:59:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 07:59:43 --> Input Class Initialized
INFO - 2024-10-27 07:59:43 --> Language Class Initialized
ERROR - 2024-10-27 07:59:43 --> TEST ERROR MESSAGE - 2024-10-27 07:59:43
INFO - 2024-10-27 07:59:43 --> Loader Class Initialized
INFO - 2024-10-27 07:59:43 --> Controller Class Initialized
INFO - 2024-10-27 07:59:43 --> Database Driver Class Initialized
INFO - 2024-10-27 07:59:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 07:59:43 --> Helper loaded: form_helper
INFO - 2024-10-27 07:59:43 --> Helper loaded: url_helper
INFO - 2024-10-27 07:59:43 --> Model Class Initialized
INFO - 2024-10-27 07:59:43 --> Helper loaded: inflector_helper
INFO - 2024-10-27 07:59:43 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 07:59:43 --> Helper loaded: email_helper
INFO - 2024-10-27 07:59:43 --> Model Class Initialized
INFO - 2024-10-27 07:59:43 --> Model Class Initialized
INFO - 2024-10-27 07:59:43 --> Model Class Initialized
INFO - 2024-10-27 07:59:43 --> Model Class Initialized
INFO - 2024-10-27 07:59:43 --> Model Class Initialized
INFO - 2024-10-27 07:59:43 --> Model Class Initialized
INFO - 2024-10-27 07:59:43 --> Model Class Initialized
DEBUG - 2024-10-27 07:59:43 --> plural called with: company
DEBUG - 2024-10-27 07:59:43 --> is_countable called with!!!!: company
INFO - 2024-10-27 07:59:43 --> Model Class Initialized
INFO - 2024-10-27 07:59:43 --> Model Class Initialized
INFO - 2024-10-27 07:59:43 --> Model Class Initialized
INFO - 2024-10-27 07:59:43 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-27 07:59:43 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 07:59:43 --> Final output sent to browser
DEBUG - 2024-10-27 07:59:43 --> Total execution time: 0.0220
INFO - 2024-10-27 08:26:32 --> Config Class Initialized
INFO - 2024-10-27 08:26:32 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:26:32 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:26:32 --> Utf8 Class Initialized
INFO - 2024-10-27 08:26:32 --> URI Class Initialized
INFO - 2024-10-27 08:26:32 --> Router Class Initialized
INFO - 2024-10-27 08:26:32 --> Output Class Initialized
INFO - 2024-10-27 08:26:32 --> Security Class Initialized
DEBUG - 2024-10-27 08:26:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:26:32 --> Input Class Initialized
INFO - 2024-10-27 08:26:32 --> Language Class Initialized
ERROR - 2024-10-27 08:26:32 --> TEST ERROR MESSAGE - 2024-10-27 08:26:32
INFO - 2024-10-27 08:26:32 --> Loader Class Initialized
INFO - 2024-10-27 08:26:32 --> Controller Class Initialized
INFO - 2024-10-27 08:26:32 --> Database Driver Class Initialized
INFO - 2024-10-27 08:26:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 08:26:32 --> Helper loaded: form_helper
INFO - 2024-10-27 08:26:32 --> Helper loaded: url_helper
INFO - 2024-10-27 08:26:32 --> Model Class Initialized
INFO - 2024-10-27 08:26:32 --> Helper loaded: inflector_helper
INFO - 2024-10-27 08:26:32 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 08:26:32 --> Helper loaded: email_helper
INFO - 2024-10-27 08:26:32 --> Model Class Initialized
INFO - 2024-10-27 08:26:32 --> Model Class Initialized
INFO - 2024-10-27 08:26:32 --> Model Class Initialized
INFO - 2024-10-27 08:26:32 --> Model Class Initialized
INFO - 2024-10-27 08:26:32 --> Model Class Initialized
INFO - 2024-10-27 08:26:32 --> Model Class Initialized
INFO - 2024-10-27 08:26:32 --> Model Class Initialized
DEBUG - 2024-10-27 08:26:32 --> plural called with: company
DEBUG - 2024-10-27 08:26:32 --> is_countable called with!!!!: company
INFO - 2024-10-27 08:26:32 --> Model Class Initialized
INFO - 2024-10-27 08:26:32 --> Model Class Initialized
INFO - 2024-10-27 08:26:32 --> Model Class Initialized
INFO - 2024-10-27 08:26:32 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 08:26:32 --> Final output sent to browser
DEBUG - 2024-10-27 08:26:32 --> Total execution time: 0.0258
INFO - 2024-10-27 08:26:37 --> Config Class Initialized
INFO - 2024-10-27 08:26:37 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:26:37 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:26:37 --> Utf8 Class Initialized
INFO - 2024-10-27 08:26:37 --> URI Class Initialized
INFO - 2024-10-27 08:26:37 --> Router Class Initialized
INFO - 2024-10-27 08:26:37 --> Output Class Initialized
INFO - 2024-10-27 08:26:37 --> Security Class Initialized
DEBUG - 2024-10-27 08:26:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:26:37 --> Input Class Initialized
INFO - 2024-10-27 08:26:37 --> Language Class Initialized
ERROR - 2024-10-27 08:26:37 --> TEST ERROR MESSAGE - 2024-10-27 08:26:37
INFO - 2024-10-27 08:26:37 --> Loader Class Initialized
INFO - 2024-10-27 08:26:37 --> Controller Class Initialized
INFO - 2024-10-27 08:26:37 --> Database Driver Class Initialized
INFO - 2024-10-27 08:26:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 08:26:37 --> Helper loaded: form_helper
INFO - 2024-10-27 08:26:37 --> Helper loaded: url_helper
INFO - 2024-10-27 08:26:37 --> Model Class Initialized
INFO - 2024-10-27 08:26:37 --> Helper loaded: inflector_helper
INFO - 2024-10-27 08:26:37 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 08:26:37 --> Helper loaded: email_helper
INFO - 2024-10-27 08:26:37 --> Model Class Initialized
INFO - 2024-10-27 08:26:37 --> Model Class Initialized
INFO - 2024-10-27 08:26:37 --> Model Class Initialized
INFO - 2024-10-27 08:26:37 --> Model Class Initialized
INFO - 2024-10-27 08:26:37 --> Model Class Initialized
INFO - 2024-10-27 08:26:37 --> Model Class Initialized
INFO - 2024-10-27 08:26:37 --> Model Class Initialized
DEBUG - 2024-10-27 08:26:37 --> plural called with: company
DEBUG - 2024-10-27 08:26:37 --> is_countable called with!!!!: company
INFO - 2024-10-27 08:26:37 --> Model Class Initialized
INFO - 2024-10-27 08:26:37 --> Model Class Initialized
INFO - 2024-10-27 08:26:37 --> Model Class Initialized
INFO - 2024-10-27 08:26:37 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 08:26:37 --> Final output sent to browser
DEBUG - 2024-10-27 08:26:37 --> Total execution time: 0.0214
INFO - 2024-10-27 08:27:18 --> Config Class Initialized
INFO - 2024-10-27 08:27:18 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:27:18 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:27:18 --> Utf8 Class Initialized
INFO - 2024-10-27 08:27:18 --> URI Class Initialized
INFO - 2024-10-27 08:27:18 --> Router Class Initialized
INFO - 2024-10-27 08:27:18 --> Output Class Initialized
INFO - 2024-10-27 08:27:18 --> Security Class Initialized
DEBUG - 2024-10-27 08:27:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:27:18 --> Input Class Initialized
INFO - 2024-10-27 08:27:18 --> Language Class Initialized
ERROR - 2024-10-27 08:27:18 --> TEST ERROR MESSAGE - 2024-10-27 08:27:18
INFO - 2024-10-27 08:27:18 --> Loader Class Initialized
INFO - 2024-10-27 08:27:18 --> Controller Class Initialized
INFO - 2024-10-27 08:27:18 --> Database Driver Class Initialized
INFO - 2024-10-27 08:27:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 08:27:18 --> Helper loaded: form_helper
INFO - 2024-10-27 08:27:18 --> Helper loaded: url_helper
INFO - 2024-10-27 08:27:18 --> Model Class Initialized
INFO - 2024-10-27 08:27:18 --> Helper loaded: inflector_helper
INFO - 2024-10-27 08:27:18 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 08:27:18 --> Helper loaded: email_helper
INFO - 2024-10-27 08:27:18 --> Model Class Initialized
INFO - 2024-10-27 08:27:18 --> Model Class Initialized
INFO - 2024-10-27 08:27:18 --> Model Class Initialized
INFO - 2024-10-27 08:27:18 --> Model Class Initialized
INFO - 2024-10-27 08:27:18 --> Model Class Initialized
INFO - 2024-10-27 08:27:18 --> Model Class Initialized
INFO - 2024-10-27 08:27:18 --> Model Class Initialized
DEBUG - 2024-10-27 08:27:18 --> plural called with: company
DEBUG - 2024-10-27 08:27:18 --> is_countable called with!!!!: company
INFO - 2024-10-27 08:27:18 --> Model Class Initialized
INFO - 2024-10-27 08:27:18 --> Model Class Initialized
INFO - 2024-10-27 08:27:18 --> Model Class Initialized
INFO - 2024-10-27 08:27:18 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 08:27:18 --> Final output sent to browser
DEBUG - 2024-10-27 08:27:18 --> Total execution time: 0.0271
INFO - 2024-10-27 08:27:59 --> Config Class Initialized
INFO - 2024-10-27 08:27:59 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:27:59 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:27:59 --> Utf8 Class Initialized
INFO - 2024-10-27 08:27:59 --> URI Class Initialized
INFO - 2024-10-27 08:27:59 --> Router Class Initialized
INFO - 2024-10-27 08:27:59 --> Output Class Initialized
INFO - 2024-10-27 08:27:59 --> Security Class Initialized
DEBUG - 2024-10-27 08:27:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:27:59 --> Input Class Initialized
INFO - 2024-10-27 08:27:59 --> Language Class Initialized
ERROR - 2024-10-27 08:27:59 --> TEST ERROR MESSAGE - 2024-10-27 08:27:59
INFO - 2024-10-27 08:27:59 --> Loader Class Initialized
INFO - 2024-10-27 08:27:59 --> Controller Class Initialized
INFO - 2024-10-27 08:27:59 --> Database Driver Class Initialized
INFO - 2024-10-27 08:27:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 08:27:59 --> Helper loaded: form_helper
INFO - 2024-10-27 08:27:59 --> Helper loaded: url_helper
INFO - 2024-10-27 08:27:59 --> Model Class Initialized
INFO - 2024-10-27 08:27:59 --> Helper loaded: inflector_helper
INFO - 2024-10-27 08:27:59 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 08:27:59 --> Helper loaded: email_helper
INFO - 2024-10-27 08:27:59 --> Model Class Initialized
INFO - 2024-10-27 08:27:59 --> Model Class Initialized
INFO - 2024-10-27 08:27:59 --> Model Class Initialized
INFO - 2024-10-27 08:27:59 --> Model Class Initialized
INFO - 2024-10-27 08:27:59 --> Model Class Initialized
INFO - 2024-10-27 08:27:59 --> Model Class Initialized
INFO - 2024-10-27 08:27:59 --> Model Class Initialized
DEBUG - 2024-10-27 08:27:59 --> plural called with: company
DEBUG - 2024-10-27 08:27:59 --> is_countable called with!!!!: company
INFO - 2024-10-27 08:27:59 --> Model Class Initialized
INFO - 2024-10-27 08:27:59 --> Model Class Initialized
INFO - 2024-10-27 08:27:59 --> Model Class Initialized
ERROR - 2024-10-27 08:28:00 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 298
ERROR - 2024-10-27 08:28:00 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 312
ERROR - 2024-10-27 08:28:00 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 317
INFO - 2024-10-27 08:28:00 --> Final output sent to browser
DEBUG - 2024-10-27 08:28:00 --> Total execution time: 0.1331
INFO - 2024-10-27 08:28:03 --> Config Class Initialized
INFO - 2024-10-27 08:28:03 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:28:03 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:28:03 --> Utf8 Class Initialized
INFO - 2024-10-27 08:28:03 --> URI Class Initialized
INFO - 2024-10-27 08:28:03 --> Router Class Initialized
INFO - 2024-10-27 08:28:03 --> Output Class Initialized
INFO - 2024-10-27 08:28:03 --> Security Class Initialized
DEBUG - 2024-10-27 08:28:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:28:03 --> Input Class Initialized
INFO - 2024-10-27 08:28:03 --> Language Class Initialized
ERROR - 2024-10-27 08:28:03 --> TEST ERROR MESSAGE - 2024-10-27 08:28:03
INFO - 2024-10-27 08:28:03 --> Loader Class Initialized
INFO - 2024-10-27 08:28:03 --> Controller Class Initialized
INFO - 2024-10-27 08:28:03 --> Database Driver Class Initialized
INFO - 2024-10-27 08:28:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 08:28:03 --> Helper loaded: form_helper
INFO - 2024-10-27 08:28:03 --> Helper loaded: url_helper
INFO - 2024-10-27 08:28:03 --> Model Class Initialized
INFO - 2024-10-27 08:28:03 --> Helper loaded: inflector_helper
INFO - 2024-10-27 08:28:03 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 08:28:03 --> Helper loaded: email_helper
INFO - 2024-10-27 08:28:03 --> Model Class Initialized
INFO - 2024-10-27 08:28:03 --> Model Class Initialized
INFO - 2024-10-27 08:28:03 --> Model Class Initialized
INFO - 2024-10-27 08:28:03 --> Model Class Initialized
INFO - 2024-10-27 08:28:03 --> Model Class Initialized
INFO - 2024-10-27 08:28:03 --> Model Class Initialized
INFO - 2024-10-27 08:28:03 --> Model Class Initialized
DEBUG - 2024-10-27 08:28:03 --> plural called with: company
DEBUG - 2024-10-27 08:28:03 --> is_countable called with!!!!: company
INFO - 2024-10-27 08:28:03 --> Model Class Initialized
INFO - 2024-10-27 08:28:03 --> Model Class Initialized
INFO - 2024-10-27 08:28:03 --> Model Class Initialized
INFO - 2024-10-27 08:28:05 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 08:28:05 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 08:28:05 --> Final output sent to browser
DEBUG - 2024-10-27 08:28:05 --> Total execution time: 2.7449
INFO - 2024-10-27 08:28:06 --> Config Class Initialized
INFO - 2024-10-27 08:28:06 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:28:06 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:28:06 --> Utf8 Class Initialized
INFO - 2024-10-27 08:28:06 --> URI Class Initialized
INFO - 2024-10-27 08:28:06 --> Router Class Initialized
INFO - 2024-10-27 08:28:06 --> Output Class Initialized
INFO - 2024-10-27 08:28:06 --> Security Class Initialized
DEBUG - 2024-10-27 08:28:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:28:06 --> Input Class Initialized
INFO - 2024-10-27 08:28:06 --> Language Class Initialized
ERROR - 2024-10-27 08:28:06 --> TEST ERROR MESSAGE - 2024-10-27 08:28:06
INFO - 2024-10-27 08:28:06 --> Loader Class Initialized
INFO - 2024-10-27 08:28:06 --> Controller Class Initialized
INFO - 2024-10-27 08:28:06 --> Database Driver Class Initialized
INFO - 2024-10-27 08:28:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 08:28:06 --> Helper loaded: form_helper
INFO - 2024-10-27 08:28:06 --> Helper loaded: url_helper
INFO - 2024-10-27 08:28:06 --> Model Class Initialized
INFO - 2024-10-27 08:28:06 --> Helper loaded: inflector_helper
INFO - 2024-10-27 08:28:06 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 08:28:06 --> Helper loaded: email_helper
INFO - 2024-10-27 08:28:06 --> Model Class Initialized
INFO - 2024-10-27 08:28:06 --> Model Class Initialized
INFO - 2024-10-27 08:28:06 --> Model Class Initialized
INFO - 2024-10-27 08:28:06 --> Model Class Initialized
INFO - 2024-10-27 08:28:06 --> Model Class Initialized
INFO - 2024-10-27 08:28:06 --> Model Class Initialized
INFO - 2024-10-27 08:28:06 --> Model Class Initialized
DEBUG - 2024-10-27 08:28:06 --> plural called with: company
DEBUG - 2024-10-27 08:28:06 --> is_countable called with!!!!: company
INFO - 2024-10-27 08:28:06 --> Model Class Initialized
INFO - 2024-10-27 08:28:06 --> Model Class Initialized
INFO - 2024-10-27 08:28:06 --> Model Class Initialized
INFO - 2024-10-27 08:28:06 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 08:28:06 --> Final output sent to browser
DEBUG - 2024-10-27 08:28:06 --> Total execution time: 0.0274
INFO - 2024-10-27 08:29:48 --> Config Class Initialized
INFO - 2024-10-27 08:29:48 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:29:48 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:29:48 --> Utf8 Class Initialized
INFO - 2024-10-27 08:29:48 --> URI Class Initialized
INFO - 2024-10-27 08:29:48 --> Router Class Initialized
INFO - 2024-10-27 08:29:48 --> Output Class Initialized
INFO - 2024-10-27 08:29:48 --> Security Class Initialized
DEBUG - 2024-10-27 08:29:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:29:48 --> Input Class Initialized
INFO - 2024-10-27 08:29:48 --> Language Class Initialized
ERROR - 2024-10-27 08:29:48 --> TEST ERROR MESSAGE - 2024-10-27 08:29:48
INFO - 2024-10-27 08:29:48 --> Loader Class Initialized
INFO - 2024-10-27 08:29:48 --> Controller Class Initialized
INFO - 2024-10-27 08:29:48 --> Database Driver Class Initialized
INFO - 2024-10-27 08:29:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 08:29:48 --> Helper loaded: form_helper
INFO - 2024-10-27 08:29:48 --> Helper loaded: url_helper
INFO - 2024-10-27 08:29:48 --> Model Class Initialized
INFO - 2024-10-27 08:29:48 --> Helper loaded: inflector_helper
INFO - 2024-10-27 08:29:48 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 08:29:48 --> Helper loaded: email_helper
INFO - 2024-10-27 08:29:48 --> Model Class Initialized
INFO - 2024-10-27 08:29:48 --> Model Class Initialized
INFO - 2024-10-27 08:29:48 --> Model Class Initialized
INFO - 2024-10-27 08:29:48 --> Model Class Initialized
INFO - 2024-10-27 08:29:48 --> Model Class Initialized
INFO - 2024-10-27 08:29:48 --> Model Class Initialized
INFO - 2024-10-27 08:29:48 --> Model Class Initialized
DEBUG - 2024-10-27 08:29:48 --> plural called with: company
DEBUG - 2024-10-27 08:29:48 --> is_countable called with!!!!: company
INFO - 2024-10-27 08:29:48 --> Model Class Initialized
INFO - 2024-10-27 08:29:48 --> Model Class Initialized
INFO - 2024-10-27 08:29:48 --> Model Class Initialized
ERROR - 2024-10-27 08:29:48 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 298
ERROR - 2024-10-27 08:29:48 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 312
ERROR - 2024-10-27 08:29:48 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 317
INFO - 2024-10-27 08:29:48 --> Final output sent to browser
DEBUG - 2024-10-27 08:29:48 --> Total execution time: 0.1066
INFO - 2024-10-27 08:29:50 --> Config Class Initialized
INFO - 2024-10-27 08:29:50 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:29:50 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:29:50 --> Utf8 Class Initialized
INFO - 2024-10-27 08:29:50 --> URI Class Initialized
INFO - 2024-10-27 08:29:50 --> Router Class Initialized
INFO - 2024-10-27 08:29:50 --> Output Class Initialized
INFO - 2024-10-27 08:29:50 --> Security Class Initialized
DEBUG - 2024-10-27 08:29:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:29:50 --> Input Class Initialized
INFO - 2024-10-27 08:29:50 --> Language Class Initialized
ERROR - 2024-10-27 08:29:50 --> TEST ERROR MESSAGE - 2024-10-27 08:29:50
INFO - 2024-10-27 08:29:50 --> Loader Class Initialized
INFO - 2024-10-27 08:29:50 --> Controller Class Initialized
INFO - 2024-10-27 08:29:50 --> Database Driver Class Initialized
INFO - 2024-10-27 08:29:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 08:29:50 --> Helper loaded: form_helper
INFO - 2024-10-27 08:29:50 --> Helper loaded: url_helper
INFO - 2024-10-27 08:29:50 --> Model Class Initialized
INFO - 2024-10-27 08:29:50 --> Helper loaded: inflector_helper
INFO - 2024-10-27 08:29:50 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 08:29:50 --> Helper loaded: email_helper
INFO - 2024-10-27 08:29:50 --> Model Class Initialized
INFO - 2024-10-27 08:29:50 --> Model Class Initialized
INFO - 2024-10-27 08:29:50 --> Model Class Initialized
INFO - 2024-10-27 08:29:50 --> Model Class Initialized
INFO - 2024-10-27 08:29:50 --> Model Class Initialized
INFO - 2024-10-27 08:29:50 --> Model Class Initialized
INFO - 2024-10-27 08:29:50 --> Model Class Initialized
DEBUG - 2024-10-27 08:29:50 --> plural called with: company
DEBUG - 2024-10-27 08:29:50 --> is_countable called with!!!!: company
INFO - 2024-10-27 08:29:50 --> Model Class Initialized
INFO - 2024-10-27 08:29:50 --> Model Class Initialized
INFO - 2024-10-27 08:29:50 --> Model Class Initialized
INFO - 2024-10-27 08:29:53 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 08:29:53 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 08:29:53 --> Final output sent to browser
DEBUG - 2024-10-27 08:29:53 --> Total execution time: 2.4995
INFO - 2024-10-27 08:29:54 --> Config Class Initialized
INFO - 2024-10-27 08:29:54 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:29:54 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:29:54 --> Utf8 Class Initialized
INFO - 2024-10-27 08:29:54 --> URI Class Initialized
INFO - 2024-10-27 08:29:54 --> Router Class Initialized
INFO - 2024-10-27 08:29:54 --> Output Class Initialized
INFO - 2024-10-27 08:29:54 --> Security Class Initialized
DEBUG - 2024-10-27 08:29:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:29:54 --> Input Class Initialized
INFO - 2024-10-27 08:29:54 --> Language Class Initialized
ERROR - 2024-10-27 08:29:54 --> TEST ERROR MESSAGE - 2024-10-27 08:29:54
INFO - 2024-10-27 08:29:54 --> Loader Class Initialized
INFO - 2024-10-27 08:29:54 --> Controller Class Initialized
INFO - 2024-10-27 08:29:54 --> Database Driver Class Initialized
INFO - 2024-10-27 08:29:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 08:29:54 --> Helper loaded: form_helper
INFO - 2024-10-27 08:29:54 --> Helper loaded: url_helper
INFO - 2024-10-27 08:29:54 --> Model Class Initialized
INFO - 2024-10-27 08:29:54 --> Helper loaded: inflector_helper
INFO - 2024-10-27 08:29:54 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 08:29:54 --> Helper loaded: email_helper
INFO - 2024-10-27 08:29:54 --> Model Class Initialized
INFO - 2024-10-27 08:29:54 --> Model Class Initialized
INFO - 2024-10-27 08:29:54 --> Model Class Initialized
INFO - 2024-10-27 08:29:54 --> Model Class Initialized
INFO - 2024-10-27 08:29:54 --> Model Class Initialized
INFO - 2024-10-27 08:29:54 --> Model Class Initialized
INFO - 2024-10-27 08:29:54 --> Model Class Initialized
DEBUG - 2024-10-27 08:29:54 --> plural called with: company
DEBUG - 2024-10-27 08:29:54 --> is_countable called with!!!!: company
INFO - 2024-10-27 08:29:54 --> Model Class Initialized
INFO - 2024-10-27 08:29:54 --> Model Class Initialized
INFO - 2024-10-27 08:29:54 --> Model Class Initialized
INFO - 2024-10-27 08:29:54 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 08:29:54 --> Final output sent to browser
DEBUG - 2024-10-27 08:29:54 --> Total execution time: 0.0206
INFO - 2024-10-27 08:29:57 --> Config Class Initialized
INFO - 2024-10-27 08:29:57 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:29:57 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:29:57 --> Utf8 Class Initialized
INFO - 2024-10-27 08:29:57 --> URI Class Initialized
INFO - 2024-10-27 08:29:57 --> Router Class Initialized
INFO - 2024-10-27 08:29:57 --> Output Class Initialized
INFO - 2024-10-27 08:29:57 --> Security Class Initialized
DEBUG - 2024-10-27 08:29:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:29:57 --> Input Class Initialized
INFO - 2024-10-27 08:29:57 --> Language Class Initialized
ERROR - 2024-10-27 08:29:57 --> TEST ERROR MESSAGE - 2024-10-27 08:29:57
INFO - 2024-10-27 08:29:57 --> Loader Class Initialized
INFO - 2024-10-27 08:29:57 --> Controller Class Initialized
INFO - 2024-10-27 08:29:57 --> Database Driver Class Initialized
INFO - 2024-10-27 08:29:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 08:29:57 --> Helper loaded: form_helper
INFO - 2024-10-27 08:29:57 --> Helper loaded: url_helper
INFO - 2024-10-27 08:29:57 --> Model Class Initialized
INFO - 2024-10-27 08:29:57 --> Helper loaded: inflector_helper
INFO - 2024-10-27 08:29:58 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 08:29:58 --> Helper loaded: email_helper
INFO - 2024-10-27 08:29:58 --> Model Class Initialized
INFO - 2024-10-27 08:29:58 --> Model Class Initialized
INFO - 2024-10-27 08:29:58 --> Model Class Initialized
INFO - 2024-10-27 08:29:58 --> Model Class Initialized
INFO - 2024-10-27 08:29:58 --> Model Class Initialized
INFO - 2024-10-27 08:29:58 --> Model Class Initialized
INFO - 2024-10-27 08:29:58 --> Model Class Initialized
DEBUG - 2024-10-27 08:29:58 --> plural called with: company
DEBUG - 2024-10-27 08:29:58 --> is_countable called with!!!!: company
INFO - 2024-10-27 08:29:58 --> Model Class Initialized
INFO - 2024-10-27 08:29:58 --> Model Class Initialized
INFO - 2024-10-27 08:29:58 --> Model Class Initialized
INFO - 2024-10-27 08:29:58 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 08:29:58 --> Final output sent to browser
DEBUG - 2024-10-27 08:29:58 --> Total execution time: 0.0320
INFO - 2024-10-27 08:30:01 --> Config Class Initialized
INFO - 2024-10-27 08:30:01 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:30:01 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:30:01 --> Utf8 Class Initialized
INFO - 2024-10-27 08:30:01 --> URI Class Initialized
INFO - 2024-10-27 08:30:01 --> Router Class Initialized
INFO - 2024-10-27 08:30:01 --> Output Class Initialized
INFO - 2024-10-27 08:30:01 --> Security Class Initialized
DEBUG - 2024-10-27 08:30:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:30:01 --> Input Class Initialized
INFO - 2024-10-27 08:30:01 --> Language Class Initialized
ERROR - 2024-10-27 08:30:01 --> TEST ERROR MESSAGE - 2024-10-27 08:30:01
INFO - 2024-10-27 08:30:01 --> Loader Class Initialized
INFO - 2024-10-27 08:30:01 --> Controller Class Initialized
INFO - 2024-10-27 08:30:01 --> Database Driver Class Initialized
INFO - 2024-10-27 08:30:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 08:30:01 --> Helper loaded: form_helper
INFO - 2024-10-27 08:30:01 --> Helper loaded: url_helper
INFO - 2024-10-27 08:30:01 --> Model Class Initialized
INFO - 2024-10-27 08:30:01 --> Helper loaded: inflector_helper
INFO - 2024-10-27 08:30:01 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 08:30:01 --> Helper loaded: email_helper
INFO - 2024-10-27 08:30:01 --> Model Class Initialized
INFO - 2024-10-27 08:30:01 --> Model Class Initialized
INFO - 2024-10-27 08:30:01 --> Model Class Initialized
INFO - 2024-10-27 08:30:01 --> Model Class Initialized
INFO - 2024-10-27 08:30:01 --> Model Class Initialized
INFO - 2024-10-27 08:30:01 --> Model Class Initialized
INFO - 2024-10-27 08:30:01 --> Model Class Initialized
DEBUG - 2024-10-27 08:30:01 --> plural called with: company
DEBUG - 2024-10-27 08:30:01 --> is_countable called with!!!!: company
INFO - 2024-10-27 08:30:01 --> Model Class Initialized
INFO - 2024-10-27 08:30:01 --> Model Class Initialized
INFO - 2024-10-27 08:30:01 --> Model Class Initialized
INFO - 2024-10-27 08:30:01 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 08:30:01 --> Final output sent to browser
DEBUG - 2024-10-27 08:30:01 --> Total execution time: 0.0208
INFO - 2024-10-27 08:32:23 --> Config Class Initialized
INFO - 2024-10-27 08:32:23 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:32:23 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:32:23 --> Utf8 Class Initialized
INFO - 2024-10-27 08:32:23 --> URI Class Initialized
INFO - 2024-10-27 08:32:23 --> Router Class Initialized
INFO - 2024-10-27 08:32:23 --> Output Class Initialized
INFO - 2024-10-27 08:32:23 --> Security Class Initialized
DEBUG - 2024-10-27 08:32:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:32:23 --> Input Class Initialized
INFO - 2024-10-27 08:32:23 --> Language Class Initialized
ERROR - 2024-10-27 08:32:23 --> TEST ERROR MESSAGE - 2024-10-27 08:32:23
INFO - 2024-10-27 08:32:23 --> Loader Class Initialized
INFO - 2024-10-27 08:32:23 --> Controller Class Initialized
INFO - 2024-10-27 08:32:23 --> Database Driver Class Initialized
INFO - 2024-10-27 08:32:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 08:32:23 --> Helper loaded: form_helper
INFO - 2024-10-27 08:32:23 --> Helper loaded: url_helper
INFO - 2024-10-27 08:32:23 --> Model Class Initialized
INFO - 2024-10-27 08:32:23 --> Helper loaded: inflector_helper
INFO - 2024-10-27 08:32:23 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 08:32:23 --> Helper loaded: email_helper
INFO - 2024-10-27 08:32:23 --> Model Class Initialized
INFO - 2024-10-27 08:32:23 --> Model Class Initialized
INFO - 2024-10-27 08:32:23 --> Model Class Initialized
INFO - 2024-10-27 08:32:23 --> Model Class Initialized
INFO - 2024-10-27 08:32:23 --> Model Class Initialized
INFO - 2024-10-27 08:32:23 --> Model Class Initialized
INFO - 2024-10-27 08:32:23 --> Model Class Initialized
DEBUG - 2024-10-27 08:32:23 --> plural called with: company
DEBUG - 2024-10-27 08:32:23 --> is_countable called with!!!!: company
INFO - 2024-10-27 08:32:23 --> Model Class Initialized
INFO - 2024-10-27 08:32:23 --> Model Class Initialized
INFO - 2024-10-27 08:32:23 --> Model Class Initialized
INFO - 2024-10-27 08:32:40 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 08:32:40 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 08:32:40 --> Final output sent to browser
DEBUG - 2024-10-27 08:32:40 --> Total execution time: 17.1913
INFO - 2024-10-27 08:32:42 --> Config Class Initialized
INFO - 2024-10-27 08:32:42 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:32:42 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:32:42 --> Utf8 Class Initialized
INFO - 2024-10-27 08:32:42 --> URI Class Initialized
INFO - 2024-10-27 08:32:42 --> Router Class Initialized
INFO - 2024-10-27 08:32:42 --> Output Class Initialized
INFO - 2024-10-27 08:32:42 --> Security Class Initialized
DEBUG - 2024-10-27 08:32:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:32:42 --> Input Class Initialized
INFO - 2024-10-27 08:32:42 --> Language Class Initialized
ERROR - 2024-10-27 08:32:42 --> TEST ERROR MESSAGE - 2024-10-27 08:32:42
INFO - 2024-10-27 08:32:42 --> Loader Class Initialized
INFO - 2024-10-27 08:32:42 --> Controller Class Initialized
INFO - 2024-10-27 08:32:42 --> Database Driver Class Initialized
INFO - 2024-10-27 08:32:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 08:32:42 --> Helper loaded: form_helper
INFO - 2024-10-27 08:32:42 --> Helper loaded: url_helper
INFO - 2024-10-27 08:32:42 --> Model Class Initialized
INFO - 2024-10-27 08:32:42 --> Helper loaded: inflector_helper
INFO - 2024-10-27 08:32:42 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 08:32:42 --> Helper loaded: email_helper
INFO - 2024-10-27 08:32:42 --> Model Class Initialized
INFO - 2024-10-27 08:32:42 --> Model Class Initialized
INFO - 2024-10-27 08:32:42 --> Model Class Initialized
INFO - 2024-10-27 08:32:42 --> Model Class Initialized
INFO - 2024-10-27 08:32:42 --> Model Class Initialized
INFO - 2024-10-27 08:32:42 --> Model Class Initialized
INFO - 2024-10-27 08:32:42 --> Model Class Initialized
DEBUG - 2024-10-27 08:32:42 --> plural called with: company
DEBUG - 2024-10-27 08:32:42 --> is_countable called with!!!!: company
INFO - 2024-10-27 08:32:42 --> Model Class Initialized
INFO - 2024-10-27 08:32:42 --> Model Class Initialized
INFO - 2024-10-27 08:32:42 --> Model Class Initialized
INFO - 2024-10-27 08:32:42 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 08:32:42 --> Final output sent to browser
DEBUG - 2024-10-27 08:32:42 --> Total execution time: 0.0339
INFO - 2024-10-27 08:32:46 --> Config Class Initialized
INFO - 2024-10-27 08:32:46 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:32:46 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:32:46 --> Utf8 Class Initialized
INFO - 2024-10-27 08:32:46 --> URI Class Initialized
INFO - 2024-10-27 08:32:46 --> Router Class Initialized
INFO - 2024-10-27 08:32:46 --> Output Class Initialized
INFO - 2024-10-27 08:32:46 --> Security Class Initialized
DEBUG - 2024-10-27 08:32:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:32:46 --> Input Class Initialized
INFO - 2024-10-27 08:32:46 --> Language Class Initialized
ERROR - 2024-10-27 08:32:46 --> TEST ERROR MESSAGE - 2024-10-27 08:32:46
INFO - 2024-10-27 08:32:46 --> Loader Class Initialized
INFO - 2024-10-27 08:32:46 --> Controller Class Initialized
INFO - 2024-10-27 08:32:46 --> Database Driver Class Initialized
INFO - 2024-10-27 08:32:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 08:32:46 --> Helper loaded: form_helper
INFO - 2024-10-27 08:32:46 --> Helper loaded: url_helper
INFO - 2024-10-27 08:32:46 --> Model Class Initialized
INFO - 2024-10-27 08:32:46 --> Helper loaded: inflector_helper
INFO - 2024-10-27 08:32:46 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 08:32:46 --> Helper loaded: email_helper
INFO - 2024-10-27 08:32:46 --> Model Class Initialized
INFO - 2024-10-27 08:32:46 --> Model Class Initialized
INFO - 2024-10-27 08:32:46 --> Model Class Initialized
INFO - 2024-10-27 08:32:46 --> Model Class Initialized
INFO - 2024-10-27 08:32:46 --> Model Class Initialized
INFO - 2024-10-27 08:32:46 --> Model Class Initialized
INFO - 2024-10-27 08:32:46 --> Model Class Initialized
DEBUG - 2024-10-27 08:32:46 --> plural called with: company
DEBUG - 2024-10-27 08:32:46 --> is_countable called with!!!!: company
INFO - 2024-10-27 08:32:46 --> Model Class Initialized
INFO - 2024-10-27 08:32:46 --> Model Class Initialized
INFO - 2024-10-27 08:32:46 --> Model Class Initialized
INFO - 2024-10-27 08:32:46 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 08:32:46 --> Final output sent to browser
DEBUG - 2024-10-27 08:32:46 --> Total execution time: 0.0324
INFO - 2024-10-27 08:34:07 --> Config Class Initialized
INFO - 2024-10-27 08:34:07 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:34:07 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:34:07 --> Utf8 Class Initialized
INFO - 2024-10-27 08:34:07 --> URI Class Initialized
INFO - 2024-10-27 08:34:07 --> Router Class Initialized
INFO - 2024-10-27 08:34:07 --> Output Class Initialized
INFO - 2024-10-27 08:34:07 --> Security Class Initialized
DEBUG - 2024-10-27 08:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:34:07 --> Input Class Initialized
INFO - 2024-10-27 08:34:07 --> Language Class Initialized
ERROR - 2024-10-27 08:34:07 --> TEST ERROR MESSAGE - 2024-10-27 08:34:07
INFO - 2024-10-27 08:34:07 --> Loader Class Initialized
INFO - 2024-10-27 08:34:07 --> Controller Class Initialized
INFO - 2024-10-27 08:34:07 --> Database Driver Class Initialized
INFO - 2024-10-27 08:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 08:34:07 --> Helper loaded: form_helper
INFO - 2024-10-27 08:34:07 --> Helper loaded: url_helper
INFO - 2024-10-27 08:34:07 --> Model Class Initialized
INFO - 2024-10-27 08:34:07 --> Helper loaded: inflector_helper
INFO - 2024-10-27 08:34:07 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 08:34:07 --> Helper loaded: email_helper
INFO - 2024-10-27 08:34:07 --> Model Class Initialized
INFO - 2024-10-27 08:34:07 --> Model Class Initialized
INFO - 2024-10-27 08:34:07 --> Model Class Initialized
INFO - 2024-10-27 08:34:07 --> Model Class Initialized
INFO - 2024-10-27 08:34:07 --> Model Class Initialized
INFO - 2024-10-27 08:34:07 --> Model Class Initialized
INFO - 2024-10-27 08:34:07 --> Model Class Initialized
DEBUG - 2024-10-27 08:34:07 --> plural called with: company
DEBUG - 2024-10-27 08:34:07 --> is_countable called with!!!!: company
INFO - 2024-10-27 08:34:07 --> Model Class Initialized
INFO - 2024-10-27 08:34:07 --> Model Class Initialized
INFO - 2024-10-27 08:34:07 --> Model Class Initialized
INFO - 2024-10-27 08:34:07 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 08:34:07 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 08:34:07 --> Final output sent to browser
DEBUG - 2024-10-27 08:34:07 --> Total execution time: 0.1638
INFO - 2024-10-27 08:34:08 --> Config Class Initialized
INFO - 2024-10-27 08:34:08 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:34:08 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:34:08 --> Utf8 Class Initialized
INFO - 2024-10-27 08:34:08 --> URI Class Initialized
INFO - 2024-10-27 08:34:08 --> Router Class Initialized
INFO - 2024-10-27 08:34:08 --> Output Class Initialized
INFO - 2024-10-27 08:34:08 --> Security Class Initialized
DEBUG - 2024-10-27 08:34:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:34:08 --> Input Class Initialized
INFO - 2024-10-27 08:34:08 --> Language Class Initialized
ERROR - 2024-10-27 08:34:08 --> TEST ERROR MESSAGE - 2024-10-27 08:34:08
INFO - 2024-10-27 08:34:08 --> Loader Class Initialized
INFO - 2024-10-27 08:34:08 --> Controller Class Initialized
INFO - 2024-10-27 08:34:08 --> Database Driver Class Initialized
INFO - 2024-10-27 08:34:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 08:34:08 --> Helper loaded: form_helper
INFO - 2024-10-27 08:34:08 --> Helper loaded: url_helper
INFO - 2024-10-27 08:34:08 --> Model Class Initialized
INFO - 2024-10-27 08:34:08 --> Helper loaded: inflector_helper
INFO - 2024-10-27 08:34:08 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 08:34:08 --> Helper loaded: email_helper
INFO - 2024-10-27 08:34:08 --> Model Class Initialized
INFO - 2024-10-27 08:34:08 --> Model Class Initialized
INFO - 2024-10-27 08:34:08 --> Model Class Initialized
INFO - 2024-10-27 08:34:08 --> Model Class Initialized
INFO - 2024-10-27 08:34:08 --> Model Class Initialized
INFO - 2024-10-27 08:34:08 --> Model Class Initialized
INFO - 2024-10-27 08:34:08 --> Model Class Initialized
DEBUG - 2024-10-27 08:34:08 --> plural called with: company
DEBUG - 2024-10-27 08:34:08 --> is_countable called with!!!!: company
INFO - 2024-10-27 08:34:08 --> Model Class Initialized
INFO - 2024-10-27 08:34:08 --> Model Class Initialized
INFO - 2024-10-27 08:34:08 --> Model Class Initialized
INFO - 2024-10-27 08:34:08 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 08:34:08 --> Final output sent to browser
DEBUG - 2024-10-27 08:34:08 --> Total execution time: 0.0269
INFO - 2024-10-27 08:34:13 --> Config Class Initialized
INFO - 2024-10-27 08:34:13 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:34:13 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:34:13 --> Utf8 Class Initialized
INFO - 2024-10-27 08:34:13 --> URI Class Initialized
INFO - 2024-10-27 08:34:13 --> Router Class Initialized
INFO - 2024-10-27 08:34:13 --> Output Class Initialized
INFO - 2024-10-27 08:34:13 --> Security Class Initialized
DEBUG - 2024-10-27 08:34:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:34:13 --> Input Class Initialized
INFO - 2024-10-27 08:34:13 --> Language Class Initialized
ERROR - 2024-10-27 08:34:13 --> TEST ERROR MESSAGE - 2024-10-27 08:34:13
INFO - 2024-10-27 08:34:13 --> Loader Class Initialized
INFO - 2024-10-27 08:34:13 --> Controller Class Initialized
INFO - 2024-10-27 08:34:13 --> Database Driver Class Initialized
INFO - 2024-10-27 08:34:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 08:34:13 --> Helper loaded: form_helper
INFO - 2024-10-27 08:34:13 --> Helper loaded: url_helper
INFO - 2024-10-27 08:34:13 --> Model Class Initialized
INFO - 2024-10-27 08:34:13 --> Helper loaded: inflector_helper
INFO - 2024-10-27 08:34:13 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 08:34:13 --> Helper loaded: email_helper
INFO - 2024-10-27 08:34:13 --> Model Class Initialized
INFO - 2024-10-27 08:34:13 --> Model Class Initialized
INFO - 2024-10-27 08:34:13 --> Model Class Initialized
INFO - 2024-10-27 08:34:13 --> Model Class Initialized
INFO - 2024-10-27 08:34:13 --> Model Class Initialized
INFO - 2024-10-27 08:34:13 --> Model Class Initialized
INFO - 2024-10-27 08:34:13 --> Model Class Initialized
DEBUG - 2024-10-27 08:34:13 --> plural called with: company
DEBUG - 2024-10-27 08:34:13 --> is_countable called with!!!!: company
INFO - 2024-10-27 08:34:13 --> Model Class Initialized
INFO - 2024-10-27 08:34:13 --> Model Class Initialized
INFO - 2024-10-27 08:34:13 --> Model Class Initialized
INFO - 2024-10-27 08:34:13 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 08:34:13 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 08:34:13 --> Final output sent to browser
DEBUG - 2024-10-27 08:34:13 --> Total execution time: 0.1565
INFO - 2024-10-27 08:36:34 --> Config Class Initialized
INFO - 2024-10-27 08:36:34 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:36:34 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:36:34 --> Utf8 Class Initialized
INFO - 2024-10-27 08:36:34 --> URI Class Initialized
INFO - 2024-10-27 08:36:34 --> Router Class Initialized
INFO - 2024-10-27 08:36:34 --> Output Class Initialized
INFO - 2024-10-27 08:36:34 --> Security Class Initialized
DEBUG - 2024-10-27 08:36:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:36:34 --> Input Class Initialized
INFO - 2024-10-27 08:36:34 --> Language Class Initialized
ERROR - 2024-10-27 08:36:34 --> TEST ERROR MESSAGE - 2024-10-27 08:36:34
INFO - 2024-10-27 08:36:34 --> Loader Class Initialized
INFO - 2024-10-27 08:36:34 --> Controller Class Initialized
INFO - 2024-10-27 08:36:34 --> Database Driver Class Initialized
INFO - 2024-10-27 08:36:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 08:36:34 --> Helper loaded: form_helper
INFO - 2024-10-27 08:36:34 --> Helper loaded: url_helper
INFO - 2024-10-27 08:36:34 --> Model Class Initialized
INFO - 2024-10-27 08:36:34 --> Helper loaded: inflector_helper
INFO - 2024-10-27 08:36:34 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 08:36:34 --> Helper loaded: email_helper
INFO - 2024-10-27 08:36:34 --> Model Class Initialized
INFO - 2024-10-27 08:36:34 --> Model Class Initialized
INFO - 2024-10-27 08:36:34 --> Model Class Initialized
INFO - 2024-10-27 08:36:34 --> Model Class Initialized
INFO - 2024-10-27 08:36:34 --> Model Class Initialized
INFO - 2024-10-27 08:36:34 --> Model Class Initialized
INFO - 2024-10-27 08:36:34 --> Model Class Initialized
DEBUG - 2024-10-27 08:36:34 --> plural called with: company
DEBUG - 2024-10-27 08:36:34 --> is_countable called with!!!!: company
INFO - 2024-10-27 08:36:34 --> Model Class Initialized
INFO - 2024-10-27 08:36:34 --> Model Class Initialized
INFO - 2024-10-27 08:36:34 --> Model Class Initialized
INFO - 2024-10-27 08:36:34 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-27 08:36:34 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 08:36:34 --> Final output sent to browser
DEBUG - 2024-10-27 08:36:34 --> Total execution time: 0.0224
INFO - 2024-10-27 08:36:56 --> Config Class Initialized
INFO - 2024-10-27 08:36:56 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:36:56 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:36:56 --> Utf8 Class Initialized
INFO - 2024-10-27 08:36:56 --> URI Class Initialized
INFO - 2024-10-27 08:36:56 --> Router Class Initialized
INFO - 2024-10-27 08:36:56 --> Output Class Initialized
INFO - 2024-10-27 08:36:56 --> Security Class Initialized
DEBUG - 2024-10-27 08:36:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:36:56 --> Input Class Initialized
INFO - 2024-10-27 08:36:56 --> Language Class Initialized
ERROR - 2024-10-27 08:36:56 --> TEST ERROR MESSAGE - 2024-10-27 08:36:56
INFO - 2024-10-27 08:36:56 --> Loader Class Initialized
INFO - 2024-10-27 08:36:56 --> Controller Class Initialized
INFO - 2024-10-27 08:36:56 --> Database Driver Class Initialized
INFO - 2024-10-27 08:36:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 08:36:56 --> Helper loaded: form_helper
INFO - 2024-10-27 08:36:56 --> Helper loaded: url_helper
INFO - 2024-10-27 08:36:56 --> Model Class Initialized
INFO - 2024-10-27 08:36:56 --> Helper loaded: inflector_helper
INFO - 2024-10-27 08:36:56 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 08:36:56 --> Helper loaded: email_helper
INFO - 2024-10-27 08:36:56 --> Model Class Initialized
INFO - 2024-10-27 08:36:56 --> Model Class Initialized
INFO - 2024-10-27 08:36:56 --> Model Class Initialized
INFO - 2024-10-27 08:36:56 --> Model Class Initialized
INFO - 2024-10-27 08:36:56 --> Model Class Initialized
INFO - 2024-10-27 08:36:56 --> Model Class Initialized
INFO - 2024-10-27 08:36:56 --> Model Class Initialized
DEBUG - 2024-10-27 08:36:56 --> plural called with: company
DEBUG - 2024-10-27 08:36:56 --> is_countable called with!!!!: company
INFO - 2024-10-27 08:36:56 --> Model Class Initialized
INFO - 2024-10-27 08:36:56 --> Model Class Initialized
INFO - 2024-10-27 08:36:56 --> Model Class Initialized
INFO - 2024-10-27 08:36:56 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 08:36:56 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 08:36:56 --> Final output sent to browser
DEBUG - 2024-10-27 08:36:56 --> Total execution time: 0.2289
INFO - 2024-10-27 08:37:06 --> Config Class Initialized
INFO - 2024-10-27 08:37:06 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:37:06 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:37:06 --> Utf8 Class Initialized
INFO - 2024-10-27 08:37:06 --> URI Class Initialized
INFO - 2024-10-27 08:37:06 --> Router Class Initialized
INFO - 2024-10-27 08:37:06 --> Output Class Initialized
INFO - 2024-10-27 08:37:06 --> Security Class Initialized
DEBUG - 2024-10-27 08:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:37:06 --> Input Class Initialized
INFO - 2024-10-27 08:37:06 --> Language Class Initialized
ERROR - 2024-10-27 08:37:06 --> TEST ERROR MESSAGE - 2024-10-27 08:37:06
INFO - 2024-10-27 08:37:06 --> Loader Class Initialized
INFO - 2024-10-27 08:37:06 --> Controller Class Initialized
INFO - 2024-10-27 08:37:06 --> Database Driver Class Initialized
INFO - 2024-10-27 08:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 08:37:06 --> Helper loaded: form_helper
INFO - 2024-10-27 08:37:06 --> Helper loaded: url_helper
INFO - 2024-10-27 08:37:06 --> Model Class Initialized
INFO - 2024-10-27 08:37:06 --> Helper loaded: inflector_helper
INFO - 2024-10-27 08:37:06 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 08:37:06 --> Helper loaded: email_helper
INFO - 2024-10-27 08:37:06 --> Model Class Initialized
INFO - 2024-10-27 08:37:06 --> Model Class Initialized
INFO - 2024-10-27 08:37:06 --> Model Class Initialized
INFO - 2024-10-27 08:37:06 --> Model Class Initialized
INFO - 2024-10-27 08:37:06 --> Model Class Initialized
INFO - 2024-10-27 08:37:06 --> Model Class Initialized
INFO - 2024-10-27 08:37:06 --> Model Class Initialized
DEBUG - 2024-10-27 08:37:06 --> plural called with: company
DEBUG - 2024-10-27 08:37:06 --> is_countable called with!!!!: company
INFO - 2024-10-27 08:37:06 --> Model Class Initialized
INFO - 2024-10-27 08:37:06 --> Model Class Initialized
INFO - 2024-10-27 08:37:06 --> Model Class Initialized
INFO - 2024-10-27 08:37:06 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 08:37:06 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 08:37:06 --> Final output sent to browser
DEBUG - 2024-10-27 08:37:06 --> Total execution time: 0.1586
INFO - 2024-10-27 08:37:08 --> Config Class Initialized
INFO - 2024-10-27 08:37:08 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:37:08 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:37:08 --> Utf8 Class Initialized
INFO - 2024-10-27 08:37:08 --> URI Class Initialized
INFO - 2024-10-27 08:37:08 --> Router Class Initialized
INFO - 2024-10-27 08:37:08 --> Output Class Initialized
INFO - 2024-10-27 08:37:08 --> Security Class Initialized
DEBUG - 2024-10-27 08:37:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:37:08 --> Input Class Initialized
INFO - 2024-10-27 08:37:08 --> Language Class Initialized
ERROR - 2024-10-27 08:37:08 --> TEST ERROR MESSAGE - 2024-10-27 08:37:08
INFO - 2024-10-27 08:37:08 --> Loader Class Initialized
INFO - 2024-10-27 08:37:08 --> Controller Class Initialized
INFO - 2024-10-27 08:37:08 --> Database Driver Class Initialized
INFO - 2024-10-27 08:37:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 08:37:08 --> Helper loaded: form_helper
INFO - 2024-10-27 08:37:08 --> Helper loaded: url_helper
INFO - 2024-10-27 08:37:08 --> Model Class Initialized
INFO - 2024-10-27 08:37:08 --> Helper loaded: inflector_helper
INFO - 2024-10-27 08:37:08 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 08:37:08 --> Helper loaded: email_helper
INFO - 2024-10-27 08:37:08 --> Model Class Initialized
INFO - 2024-10-27 08:37:08 --> Model Class Initialized
INFO - 2024-10-27 08:37:08 --> Model Class Initialized
INFO - 2024-10-27 08:37:08 --> Model Class Initialized
INFO - 2024-10-27 08:37:08 --> Model Class Initialized
INFO - 2024-10-27 08:37:08 --> Model Class Initialized
INFO - 2024-10-27 08:37:08 --> Model Class Initialized
DEBUG - 2024-10-27 08:37:08 --> plural called with: company
DEBUG - 2024-10-27 08:37:08 --> is_countable called with!!!!: company
INFO - 2024-10-27 08:37:08 --> Model Class Initialized
INFO - 2024-10-27 08:37:08 --> Model Class Initialized
INFO - 2024-10-27 08:37:08 --> Model Class Initialized
INFO - 2024-10-27 08:37:08 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 08:37:08 --> Final output sent to browser
DEBUG - 2024-10-27 08:37:08 --> Total execution time: 0.0262
INFO - 2024-10-27 08:37:11 --> Config Class Initialized
INFO - 2024-10-27 08:37:11 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:37:11 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:37:11 --> Utf8 Class Initialized
INFO - 2024-10-27 08:37:11 --> URI Class Initialized
INFO - 2024-10-27 08:37:11 --> Router Class Initialized
INFO - 2024-10-27 08:37:11 --> Output Class Initialized
INFO - 2024-10-27 08:37:11 --> Security Class Initialized
DEBUG - 2024-10-27 08:37:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:37:11 --> Input Class Initialized
INFO - 2024-10-27 08:37:11 --> Language Class Initialized
ERROR - 2024-10-27 08:37:11 --> TEST ERROR MESSAGE - 2024-10-27 08:37:11
INFO - 2024-10-27 08:37:11 --> Loader Class Initialized
INFO - 2024-10-27 08:37:11 --> Controller Class Initialized
INFO - 2024-10-27 08:37:11 --> Database Driver Class Initialized
INFO - 2024-10-27 08:37:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 08:37:11 --> Helper loaded: form_helper
INFO - 2024-10-27 08:37:11 --> Helper loaded: url_helper
INFO - 2024-10-27 08:37:11 --> Model Class Initialized
INFO - 2024-10-27 08:37:11 --> Helper loaded: inflector_helper
INFO - 2024-10-27 08:37:11 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 08:37:11 --> Helper loaded: email_helper
INFO - 2024-10-27 08:37:11 --> Model Class Initialized
INFO - 2024-10-27 08:37:11 --> Model Class Initialized
INFO - 2024-10-27 08:37:11 --> Model Class Initialized
INFO - 2024-10-27 08:37:11 --> Model Class Initialized
INFO - 2024-10-27 08:37:11 --> Model Class Initialized
INFO - 2024-10-27 08:37:11 --> Model Class Initialized
INFO - 2024-10-27 08:37:11 --> Model Class Initialized
DEBUG - 2024-10-27 08:37:11 --> plural called with: company
DEBUG - 2024-10-27 08:37:11 --> is_countable called with!!!!: company
INFO - 2024-10-27 08:37:11 --> Model Class Initialized
INFO - 2024-10-27 08:37:11 --> Model Class Initialized
INFO - 2024-10-27 08:37:11 --> Model Class Initialized
INFO - 2024-10-27 08:37:11 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 08:37:11 --> Final output sent to browser
DEBUG - 2024-10-27 08:37:11 --> Total execution time: 0.0243
INFO - 2024-10-27 08:53:14 --> Config Class Initialized
INFO - 2024-10-27 08:53:14 --> Hooks Class Initialized
DEBUG - 2024-10-27 08:53:14 --> UTF-8 Support Enabled
INFO - 2024-10-27 08:53:14 --> Utf8 Class Initialized
INFO - 2024-10-27 08:53:14 --> URI Class Initialized
INFO - 2024-10-27 08:53:14 --> Router Class Initialized
INFO - 2024-10-27 08:53:14 --> Output Class Initialized
INFO - 2024-10-27 08:53:14 --> Security Class Initialized
DEBUG - 2024-10-27 08:53:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 08:53:14 --> Input Class Initialized
INFO - 2024-10-27 08:53:14 --> Language Class Initialized
ERROR - 2024-10-27 08:53:14 --> TEST ERROR MESSAGE - 2024-10-27 08:53:14
INFO - 2024-10-27 08:53:14 --> Loader Class Initialized
INFO - 2024-10-27 08:53:14 --> Controller Class Initialized
INFO - 2024-10-27 08:53:14 --> Database Driver Class Initialized
INFO - 2024-10-27 08:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 08:53:14 --> Helper loaded: form_helper
INFO - 2024-10-27 08:53:14 --> Helper loaded: url_helper
INFO - 2024-10-27 08:53:14 --> Model Class Initialized
INFO - 2024-10-27 08:53:14 --> Helper loaded: inflector_helper
INFO - 2024-10-27 08:53:14 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 08:53:14 --> Helper loaded: email_helper
INFO - 2024-10-27 08:53:14 --> Model Class Initialized
INFO - 2024-10-27 08:53:14 --> Model Class Initialized
INFO - 2024-10-27 08:53:14 --> Model Class Initialized
INFO - 2024-10-27 08:53:14 --> Model Class Initialized
INFO - 2024-10-27 08:53:14 --> Model Class Initialized
INFO - 2024-10-27 08:53:14 --> Model Class Initialized
INFO - 2024-10-27 08:53:14 --> Model Class Initialized
DEBUG - 2024-10-27 08:53:14 --> plural called with: company
DEBUG - 2024-10-27 08:53:14 --> is_countable called with!!!!: company
INFO - 2024-10-27 08:53:14 --> Model Class Initialized
INFO - 2024-10-27 08:53:14 --> Model Class Initialized
INFO - 2024-10-27 08:53:14 --> Model Class Initialized
INFO - 2024-10-27 08:53:14 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 08:53:14 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 08:53:14 --> Final output sent to browser
DEBUG - 2024-10-27 08:53:14 --> Total execution time: 0.1888
INFO - 2024-10-27 09:03:58 --> Config Class Initialized
INFO - 2024-10-27 09:03:58 --> Hooks Class Initialized
DEBUG - 2024-10-27 09:03:58 --> UTF-8 Support Enabled
INFO - 2024-10-27 09:03:58 --> Utf8 Class Initialized
INFO - 2024-10-27 09:03:58 --> URI Class Initialized
INFO - 2024-10-27 09:03:58 --> Router Class Initialized
INFO - 2024-10-27 09:03:58 --> Output Class Initialized
INFO - 2024-10-27 09:03:58 --> Security Class Initialized
DEBUG - 2024-10-27 09:03:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 09:03:58 --> Input Class Initialized
INFO - 2024-10-27 09:03:58 --> Language Class Initialized
ERROR - 2024-10-27 09:03:58 --> TEST ERROR MESSAGE - 2024-10-27 09:03:58
INFO - 2024-10-27 09:03:58 --> Loader Class Initialized
INFO - 2024-10-27 09:03:58 --> Controller Class Initialized
INFO - 2024-10-27 09:03:58 --> Database Driver Class Initialized
INFO - 2024-10-27 09:03:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 09:03:58 --> Helper loaded: form_helper
INFO - 2024-10-27 09:03:58 --> Helper loaded: url_helper
INFO - 2024-10-27 09:03:58 --> Model Class Initialized
INFO - 2024-10-27 09:03:58 --> Helper loaded: inflector_helper
INFO - 2024-10-27 09:03:58 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 09:03:58 --> Helper loaded: email_helper
INFO - 2024-10-27 09:03:58 --> Model Class Initialized
INFO - 2024-10-27 09:03:58 --> Model Class Initialized
INFO - 2024-10-27 09:03:58 --> Model Class Initialized
INFO - 2024-10-27 09:03:58 --> Model Class Initialized
INFO - 2024-10-27 09:03:58 --> Model Class Initialized
INFO - 2024-10-27 09:03:58 --> Model Class Initialized
INFO - 2024-10-27 09:03:58 --> Model Class Initialized
DEBUG - 2024-10-27 09:03:58 --> plural called with: company
DEBUG - 2024-10-27 09:03:58 --> is_countable called with!!!!: company
INFO - 2024-10-27 09:03:58 --> Model Class Initialized
INFO - 2024-10-27 09:03:58 --> Model Class Initialized
INFO - 2024-10-27 09:03:58 --> Model Class Initialized
INFO - 2024-10-27 09:03:58 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 09:03:58 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 09:03:58 --> Final output sent to browser
DEBUG - 2024-10-27 09:03:58 --> Total execution time: 0.1597
INFO - 2024-10-27 09:18:40 --> Config Class Initialized
INFO - 2024-10-27 09:18:40 --> Hooks Class Initialized
DEBUG - 2024-10-27 09:18:40 --> UTF-8 Support Enabled
INFO - 2024-10-27 09:18:40 --> Utf8 Class Initialized
INFO - 2024-10-27 09:18:40 --> URI Class Initialized
INFO - 2024-10-27 09:18:40 --> Router Class Initialized
INFO - 2024-10-27 09:18:40 --> Output Class Initialized
INFO - 2024-10-27 09:18:40 --> Security Class Initialized
DEBUG - 2024-10-27 09:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 09:18:40 --> Input Class Initialized
INFO - 2024-10-27 09:18:40 --> Language Class Initialized
ERROR - 2024-10-27 09:18:40 --> TEST ERROR MESSAGE - 2024-10-27 09:18:40
INFO - 2024-10-27 09:18:40 --> Loader Class Initialized
INFO - 2024-10-27 09:18:40 --> Controller Class Initialized
INFO - 2024-10-27 09:18:40 --> Database Driver Class Initialized
INFO - 2024-10-27 09:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 09:18:40 --> Helper loaded: form_helper
INFO - 2024-10-27 09:18:40 --> Helper loaded: url_helper
INFO - 2024-10-27 09:18:40 --> Model Class Initialized
INFO - 2024-10-27 09:18:40 --> Helper loaded: inflector_helper
INFO - 2024-10-27 09:18:40 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 09:18:40 --> Helper loaded: email_helper
INFO - 2024-10-27 09:18:40 --> Model Class Initialized
INFO - 2024-10-27 09:18:40 --> Model Class Initialized
INFO - 2024-10-27 09:18:40 --> Model Class Initialized
INFO - 2024-10-27 09:18:40 --> Model Class Initialized
INFO - 2024-10-27 09:18:40 --> Model Class Initialized
INFO - 2024-10-27 09:18:40 --> Model Class Initialized
INFO - 2024-10-27 09:18:40 --> Model Class Initialized
DEBUG - 2024-10-27 09:18:40 --> plural called with: company
DEBUG - 2024-10-27 09:18:40 --> is_countable called with!!!!: company
INFO - 2024-10-27 09:18:40 --> Model Class Initialized
INFO - 2024-10-27 09:18:40 --> Model Class Initialized
INFO - 2024-10-27 09:18:40 --> Model Class Initialized
INFO - 2024-10-27 09:18:40 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 09:18:40 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 09:18:40 --> Final output sent to browser
DEBUG - 2024-10-27 09:18:40 --> Total execution time: 0.1273
INFO - 2024-10-27 10:19:14 --> Config Class Initialized
INFO - 2024-10-27 10:19:14 --> Hooks Class Initialized
DEBUG - 2024-10-27 10:19:14 --> UTF-8 Support Enabled
INFO - 2024-10-27 10:19:14 --> Utf8 Class Initialized
INFO - 2024-10-27 10:19:14 --> URI Class Initialized
INFO - 2024-10-27 10:19:14 --> Router Class Initialized
INFO - 2024-10-27 10:19:14 --> Output Class Initialized
INFO - 2024-10-27 10:19:14 --> Security Class Initialized
DEBUG - 2024-10-27 10:19:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 10:19:14 --> Input Class Initialized
INFO - 2024-10-27 10:19:14 --> Language Class Initialized
ERROR - 2024-10-27 10:19:14 --> TEST ERROR MESSAGE - 2024-10-27 10:19:14
INFO - 2024-10-27 10:19:14 --> Loader Class Initialized
INFO - 2024-10-27 10:19:14 --> Controller Class Initialized
INFO - 2024-10-27 10:19:14 --> Database Driver Class Initialized
INFO - 2024-10-27 10:19:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 10:19:14 --> Helper loaded: form_helper
INFO - 2024-10-27 10:19:14 --> Helper loaded: url_helper
INFO - 2024-10-27 10:19:14 --> Model Class Initialized
INFO - 2024-10-27 10:19:14 --> Helper loaded: inflector_helper
INFO - 2024-10-27 10:19:14 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 10:19:14 --> Helper loaded: email_helper
INFO - 2024-10-27 10:19:14 --> Model Class Initialized
INFO - 2024-10-27 10:19:14 --> Model Class Initialized
INFO - 2024-10-27 10:19:14 --> Model Class Initialized
INFO - 2024-10-27 10:19:14 --> Model Class Initialized
INFO - 2024-10-27 10:19:14 --> Model Class Initialized
INFO - 2024-10-27 10:19:14 --> Model Class Initialized
INFO - 2024-10-27 10:19:14 --> Model Class Initialized
DEBUG - 2024-10-27 10:19:14 --> plural called with: company
DEBUG - 2024-10-27 10:19:14 --> is_countable called with!!!!: company
INFO - 2024-10-27 10:19:14 --> Model Class Initialized
INFO - 2024-10-27 10:19:14 --> Model Class Initialized
INFO - 2024-10-27 10:19:14 --> Model Class Initialized
ERROR - 2024-10-27 10:19:14 --> Severity: Notice --> Undefined index: CompanyId /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 446
INFO - 2024-10-27 10:19:14 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 10:19:14 --> Final output sent to browser
DEBUG - 2024-10-27 10:19:14 --> Total execution time: 0.0371
INFO - 2024-10-27 10:26:41 --> Config Class Initialized
INFO - 2024-10-27 10:26:41 --> Hooks Class Initialized
DEBUG - 2024-10-27 10:26:41 --> UTF-8 Support Enabled
INFO - 2024-10-27 10:26:41 --> Utf8 Class Initialized
INFO - 2024-10-27 10:26:41 --> URI Class Initialized
INFO - 2024-10-27 10:26:41 --> Router Class Initialized
INFO - 2024-10-27 10:26:41 --> Output Class Initialized
INFO - 2024-10-27 10:26:41 --> Security Class Initialized
DEBUG - 2024-10-27 10:26:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 10:26:41 --> Input Class Initialized
INFO - 2024-10-27 10:26:41 --> Language Class Initialized
ERROR - 2024-10-27 10:26:41 --> TEST ERROR MESSAGE - 2024-10-27 10:26:41
INFO - 2024-10-27 10:26:41 --> Loader Class Initialized
INFO - 2024-10-27 10:26:41 --> Controller Class Initialized
INFO - 2024-10-27 10:26:41 --> Database Driver Class Initialized
INFO - 2024-10-27 10:26:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 10:26:41 --> Helper loaded: form_helper
INFO - 2024-10-27 10:26:41 --> Helper loaded: url_helper
INFO - 2024-10-27 10:26:41 --> Model Class Initialized
INFO - 2024-10-27 10:26:41 --> Helper loaded: inflector_helper
INFO - 2024-10-27 10:26:41 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 10:26:41 --> Helper loaded: email_helper
INFO - 2024-10-27 10:26:41 --> Model Class Initialized
INFO - 2024-10-27 10:26:41 --> Model Class Initialized
INFO - 2024-10-27 10:26:41 --> Model Class Initialized
INFO - 2024-10-27 10:26:41 --> Model Class Initialized
INFO - 2024-10-27 10:26:41 --> Model Class Initialized
INFO - 2024-10-27 10:26:41 --> Model Class Initialized
INFO - 2024-10-27 10:26:41 --> Model Class Initialized
DEBUG - 2024-10-27 10:26:41 --> plural called with: company
DEBUG - 2024-10-27 10:26:41 --> is_countable called with!!!!: company
INFO - 2024-10-27 10:26:41 --> Model Class Initialized
INFO - 2024-10-27 10:26:41 --> Model Class Initialized
INFO - 2024-10-27 10:26:41 --> Model Class Initialized
INFO - 2024-10-27 10:26:41 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 10:26:41 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 10:26:41 --> Final output sent to browser
DEBUG - 2024-10-27 10:26:41 --> Total execution time: 0.1803
INFO - 2024-10-27 10:52:49 --> Config Class Initialized
INFO - 2024-10-27 10:52:49 --> Hooks Class Initialized
DEBUG - 2024-10-27 10:52:49 --> UTF-8 Support Enabled
INFO - 2024-10-27 10:52:49 --> Utf8 Class Initialized
INFO - 2024-10-27 10:52:49 --> URI Class Initialized
INFO - 2024-10-27 10:52:49 --> Router Class Initialized
INFO - 2024-10-27 10:52:49 --> Output Class Initialized
INFO - 2024-10-27 10:52:49 --> Security Class Initialized
DEBUG - 2024-10-27 10:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 10:52:49 --> Input Class Initialized
INFO - 2024-10-27 10:52:49 --> Language Class Initialized
ERROR - 2024-10-27 10:52:49 --> TEST ERROR MESSAGE - 2024-10-27 10:52:49
INFO - 2024-10-27 10:52:49 --> Loader Class Initialized
INFO - 2024-10-27 10:52:49 --> Controller Class Initialized
INFO - 2024-10-27 10:52:49 --> Database Driver Class Initialized
INFO - 2024-10-27 10:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 10:52:49 --> Helper loaded: form_helper
INFO - 2024-10-27 10:52:49 --> Helper loaded: url_helper
INFO - 2024-10-27 10:52:49 --> Model Class Initialized
INFO - 2024-10-27 10:52:49 --> Helper loaded: inflector_helper
INFO - 2024-10-27 10:52:49 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 10:52:49 --> Helper loaded: email_helper
INFO - 2024-10-27 10:52:49 --> Model Class Initialized
INFO - 2024-10-27 10:52:49 --> Model Class Initialized
INFO - 2024-10-27 10:52:49 --> Model Class Initialized
INFO - 2024-10-27 10:52:49 --> Model Class Initialized
INFO - 2024-10-27 10:52:49 --> Model Class Initialized
INFO - 2024-10-27 10:52:49 --> Model Class Initialized
INFO - 2024-10-27 10:52:49 --> Model Class Initialized
DEBUG - 2024-10-27 10:52:49 --> plural called with: company
DEBUG - 2024-10-27 10:52:49 --> is_countable called with!!!!: company
INFO - 2024-10-27 10:52:49 --> Model Class Initialized
INFO - 2024-10-27 10:52:49 --> Model Class Initialized
INFO - 2024-10-27 10:52:49 --> Model Class Initialized
INFO - 2024-10-27 10:52:49 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 10:52:49 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 10:52:49 --> Final output sent to browser
DEBUG - 2024-10-27 10:52:49 --> Total execution time: 0.1725
INFO - 2024-10-27 12:53:17 --> Config Class Initialized
INFO - 2024-10-27 12:53:17 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:53:17 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:53:17 --> Utf8 Class Initialized
INFO - 2024-10-27 12:53:17 --> URI Class Initialized
INFO - 2024-10-27 12:53:17 --> Router Class Initialized
INFO - 2024-10-27 12:53:17 --> Output Class Initialized
INFO - 2024-10-27 12:53:17 --> Security Class Initialized
DEBUG - 2024-10-27 12:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:53:17 --> Input Class Initialized
INFO - 2024-10-27 12:53:17 --> Language Class Initialized
ERROR - 2024-10-27 12:53:17 --> TEST ERROR MESSAGE - 2024-10-27 12:53:17
INFO - 2024-10-27 12:53:17 --> Loader Class Initialized
INFO - 2024-10-27 12:53:17 --> Controller Class Initialized
INFO - 2024-10-27 12:53:17 --> Database Driver Class Initialized
INFO - 2024-10-27 12:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:53:17 --> Helper loaded: form_helper
INFO - 2024-10-27 12:53:17 --> Helper loaded: url_helper
INFO - 2024-10-27 12:53:17 --> Model Class Initialized
INFO - 2024-10-27 12:53:17 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:53:17 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:53:17 --> Helper loaded: email_helper
INFO - 2024-10-27 12:53:17 --> Model Class Initialized
INFO - 2024-10-27 12:53:17 --> Model Class Initialized
INFO - 2024-10-27 12:53:17 --> Model Class Initialized
INFO - 2024-10-27 12:53:17 --> Model Class Initialized
INFO - 2024-10-27 12:53:17 --> Model Class Initialized
INFO - 2024-10-27 12:53:17 --> Model Class Initialized
INFO - 2024-10-27 12:53:17 --> Model Class Initialized
DEBUG - 2024-10-27 12:53:17 --> plural called with: company
DEBUG - 2024-10-27 12:53:17 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:53:17 --> Model Class Initialized
INFO - 2024-10-27 12:53:17 --> Model Class Initialized
INFO - 2024-10-27 12:53:17 --> Model Class Initialized
INFO - 2024-10-27 12:53:17 --> Config Class Initialized
INFO - 2024-10-27 12:53:17 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:53:17 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:53:17 --> Utf8 Class Initialized
INFO - 2024-10-27 12:53:17 --> URI Class Initialized
INFO - 2024-10-27 12:53:17 --> Router Class Initialized
INFO - 2024-10-27 12:53:17 --> Output Class Initialized
INFO - 2024-10-27 12:53:17 --> Security Class Initialized
DEBUG - 2024-10-27 12:53:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:53:17 --> Input Class Initialized
INFO - 2024-10-27 12:53:17 --> Language Class Initialized
ERROR - 2024-10-27 12:53:17 --> TEST ERROR MESSAGE - 2024-10-27 12:53:17
INFO - 2024-10-27 12:53:17 --> Loader Class Initialized
INFO - 2024-10-27 12:53:17 --> Controller Class Initialized
INFO - 2024-10-27 12:53:17 --> Database Driver Class Initialized
INFO - 2024-10-27 12:53:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:53:17 --> Helper loaded: form_helper
INFO - 2024-10-27 12:53:17 --> Helper loaded: url_helper
INFO - 2024-10-27 12:53:17 --> Model Class Initialized
INFO - 2024-10-27 12:53:17 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:53:17 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:53:17 --> Helper loaded: email_helper
INFO - 2024-10-27 12:53:17 --> Model Class Initialized
INFO - 2024-10-27 12:53:17 --> Model Class Initialized
INFO - 2024-10-27 12:53:17 --> Model Class Initialized
INFO - 2024-10-27 12:53:17 --> Model Class Initialized
INFO - 2024-10-27 12:53:17 --> Model Class Initialized
INFO - 2024-10-27 12:53:17 --> Model Class Initialized
INFO - 2024-10-27 12:53:17 --> Model Class Initialized
DEBUG - 2024-10-27 12:53:17 --> plural called with: company
DEBUG - 2024-10-27 12:53:17 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:53:17 --> Model Class Initialized
INFO - 2024-10-27 12:53:17 --> Model Class Initialized
INFO - 2024-10-27 12:53:17 --> Model Class Initialized
INFO - 2024-10-27 12:53:17 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-27 12:53:17 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 12:53:17 --> Final output sent to browser
DEBUG - 2024-10-27 12:53:17 --> Total execution time: 0.0217
INFO - 2024-10-27 12:53:23 --> Config Class Initialized
INFO - 2024-10-27 12:53:23 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:53:23 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:53:23 --> Utf8 Class Initialized
INFO - 2024-10-27 12:53:23 --> URI Class Initialized
INFO - 2024-10-27 12:53:23 --> Router Class Initialized
INFO - 2024-10-27 12:53:23 --> Output Class Initialized
INFO - 2024-10-27 12:53:23 --> Security Class Initialized
DEBUG - 2024-10-27 12:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:53:23 --> Input Class Initialized
INFO - 2024-10-27 12:53:23 --> Language Class Initialized
ERROR - 2024-10-27 12:53:23 --> TEST ERROR MESSAGE - 2024-10-27 12:53:23
INFO - 2024-10-27 12:53:23 --> Loader Class Initialized
INFO - 2024-10-27 12:53:23 --> Controller Class Initialized
INFO - 2024-10-27 12:53:23 --> Database Driver Class Initialized
INFO - 2024-10-27 12:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:53:23 --> Helper loaded: form_helper
INFO - 2024-10-27 12:53:23 --> Helper loaded: url_helper
INFO - 2024-10-27 12:53:23 --> Model Class Initialized
INFO - 2024-10-27 12:53:23 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:53:23 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:53:23 --> Helper loaded: email_helper
INFO - 2024-10-27 12:53:23 --> Model Class Initialized
INFO - 2024-10-27 12:53:23 --> Model Class Initialized
INFO - 2024-10-27 12:53:23 --> Model Class Initialized
INFO - 2024-10-27 12:53:23 --> Model Class Initialized
INFO - 2024-10-27 12:53:23 --> Model Class Initialized
INFO - 2024-10-27 12:53:23 --> Model Class Initialized
INFO - 2024-10-27 12:53:23 --> Model Class Initialized
DEBUG - 2024-10-27 12:53:23 --> plural called with: company
DEBUG - 2024-10-27 12:53:23 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:53:23 --> Model Class Initialized
INFO - 2024-10-27 12:53:23 --> Model Class Initialized
INFO - 2024-10-27 12:53:23 --> Model Class Initialized
INFO - 2024-10-27 12:53:23 --> Config Class Initialized
INFO - 2024-10-27 12:53:23 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:53:23 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:53:23 --> Utf8 Class Initialized
INFO - 2024-10-27 12:53:23 --> URI Class Initialized
INFO - 2024-10-27 12:53:23 --> Router Class Initialized
INFO - 2024-10-27 12:53:23 --> Output Class Initialized
INFO - 2024-10-27 12:53:23 --> Security Class Initialized
DEBUG - 2024-10-27 12:53:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:53:23 --> Input Class Initialized
INFO - 2024-10-27 12:53:23 --> Language Class Initialized
ERROR - 2024-10-27 12:53:23 --> TEST ERROR MESSAGE - 2024-10-27 12:53:23
INFO - 2024-10-27 12:53:23 --> Loader Class Initialized
INFO - 2024-10-27 12:53:23 --> Controller Class Initialized
INFO - 2024-10-27 12:53:23 --> Database Driver Class Initialized
INFO - 2024-10-27 12:53:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:53:23 --> Helper loaded: form_helper
INFO - 2024-10-27 12:53:23 --> Helper loaded: url_helper
INFO - 2024-10-27 12:53:23 --> Model Class Initialized
INFO - 2024-10-27 12:53:23 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:53:23 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:53:23 --> Helper loaded: email_helper
INFO - 2024-10-27 12:53:23 --> Model Class Initialized
INFO - 2024-10-27 12:53:23 --> Model Class Initialized
INFO - 2024-10-27 12:53:23 --> Model Class Initialized
INFO - 2024-10-27 12:53:23 --> Model Class Initialized
INFO - 2024-10-27 12:53:23 --> Model Class Initialized
INFO - 2024-10-27 12:53:23 --> Model Class Initialized
INFO - 2024-10-27 12:53:23 --> Model Class Initialized
DEBUG - 2024-10-27 12:53:23 --> plural called with: company
DEBUG - 2024-10-27 12:53:23 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:53:23 --> Model Class Initialized
INFO - 2024-10-27 12:53:23 --> Model Class Initialized
INFO - 2024-10-27 12:53:23 --> Model Class Initialized
ERROR - 2024-10-27 12:53:25 --> Severity: Notice --> Undefined index: freetext /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-27 12:53:25 --> Severity: Notice --> Undefined index: socialDes /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-27 12:53:25 --> Severity: Notice --> Undefined index: company /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-27 12:53:25 --> Severity: Notice --> Undefined index: division /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-27 12:53:25 --> Severity: Notice --> Undefined index: dataGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-27 12:53:25 --> Severity: Notice --> Undefined index: finalGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
INFO - 2024-10-27 12:53:25 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 12:53:25 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 12:53:25 --> Final output sent to browser
DEBUG - 2024-10-27 12:53:25 --> Total execution time: 2.4562
INFO - 2024-10-27 12:53:39 --> Config Class Initialized
INFO - 2024-10-27 12:53:39 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:53:39 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:53:39 --> Utf8 Class Initialized
INFO - 2024-10-27 12:53:39 --> URI Class Initialized
INFO - 2024-10-27 12:53:39 --> Router Class Initialized
INFO - 2024-10-27 12:53:39 --> Output Class Initialized
INFO - 2024-10-27 12:53:39 --> Security Class Initialized
DEBUG - 2024-10-27 12:53:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:53:39 --> Input Class Initialized
INFO - 2024-10-27 12:53:39 --> Language Class Initialized
ERROR - 2024-10-27 12:53:39 --> TEST ERROR MESSAGE - 2024-10-27 12:53:39
INFO - 2024-10-27 12:53:39 --> Loader Class Initialized
INFO - 2024-10-27 12:53:39 --> Controller Class Initialized
INFO - 2024-10-27 12:53:39 --> Database Driver Class Initialized
INFO - 2024-10-27 12:53:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:53:39 --> Helper loaded: form_helper
INFO - 2024-10-27 12:53:39 --> Helper loaded: url_helper
INFO - 2024-10-27 12:53:39 --> Model Class Initialized
INFO - 2024-10-27 12:53:39 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:53:39 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:53:39 --> Helper loaded: email_helper
INFO - 2024-10-27 12:53:39 --> Model Class Initialized
INFO - 2024-10-27 12:53:39 --> Model Class Initialized
INFO - 2024-10-27 12:53:39 --> Model Class Initialized
INFO - 2024-10-27 12:53:39 --> Model Class Initialized
INFO - 2024-10-27 12:53:39 --> Model Class Initialized
INFO - 2024-10-27 12:53:39 --> Model Class Initialized
INFO - 2024-10-27 12:53:39 --> Model Class Initialized
DEBUG - 2024-10-27 12:53:39 --> plural called with: company
DEBUG - 2024-10-27 12:53:39 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:53:39 --> Model Class Initialized
INFO - 2024-10-27 12:53:39 --> Model Class Initialized
INFO - 2024-10-27 12:53:39 --> Model Class Initialized
INFO - 2024-10-27 12:53:41 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 12:53:41 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 12:53:41 --> Final output sent to browser
DEBUG - 2024-10-27 12:53:41 --> Total execution time: 2.3300
INFO - 2024-10-27 12:53:42 --> Config Class Initialized
INFO - 2024-10-27 12:53:42 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:53:42 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:53:42 --> Utf8 Class Initialized
INFO - 2024-10-27 12:53:42 --> URI Class Initialized
INFO - 2024-10-27 12:53:42 --> Router Class Initialized
INFO - 2024-10-27 12:53:42 --> Output Class Initialized
INFO - 2024-10-27 12:53:42 --> Security Class Initialized
DEBUG - 2024-10-27 12:53:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:53:42 --> Input Class Initialized
INFO - 2024-10-27 12:53:42 --> Language Class Initialized
ERROR - 2024-10-27 12:53:42 --> TEST ERROR MESSAGE - 2024-10-27 12:53:42
INFO - 2024-10-27 12:53:42 --> Loader Class Initialized
INFO - 2024-10-27 12:53:42 --> Controller Class Initialized
INFO - 2024-10-27 12:53:42 --> Database Driver Class Initialized
INFO - 2024-10-27 12:53:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:53:42 --> Helper loaded: form_helper
INFO - 2024-10-27 12:53:42 --> Helper loaded: url_helper
INFO - 2024-10-27 12:53:42 --> Model Class Initialized
INFO - 2024-10-27 12:53:42 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:53:42 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:53:42 --> Helper loaded: email_helper
INFO - 2024-10-27 12:53:42 --> Model Class Initialized
INFO - 2024-10-27 12:53:42 --> Model Class Initialized
INFO - 2024-10-27 12:53:42 --> Model Class Initialized
INFO - 2024-10-27 12:53:42 --> Model Class Initialized
INFO - 2024-10-27 12:53:42 --> Model Class Initialized
INFO - 2024-10-27 12:53:42 --> Model Class Initialized
INFO - 2024-10-27 12:53:42 --> Model Class Initialized
DEBUG - 2024-10-27 12:53:42 --> plural called with: company
DEBUG - 2024-10-27 12:53:42 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:53:42 --> Model Class Initialized
INFO - 2024-10-27 12:53:42 --> Model Class Initialized
INFO - 2024-10-27 12:53:42 --> Model Class Initialized
INFO - 2024-10-27 12:53:42 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 12:53:42 --> Final output sent to browser
DEBUG - 2024-10-27 12:53:42 --> Total execution time: 0.0209
INFO - 2024-10-27 12:54:03 --> Config Class Initialized
INFO - 2024-10-27 12:54:03 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:54:03 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:54:03 --> Utf8 Class Initialized
INFO - 2024-10-27 12:54:03 --> URI Class Initialized
INFO - 2024-10-27 12:54:03 --> Router Class Initialized
INFO - 2024-10-27 12:54:03 --> Output Class Initialized
INFO - 2024-10-27 12:54:03 --> Security Class Initialized
DEBUG - 2024-10-27 12:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:54:03 --> Input Class Initialized
INFO - 2024-10-27 12:54:03 --> Language Class Initialized
ERROR - 2024-10-27 12:54:03 --> TEST ERROR MESSAGE - 2024-10-27 12:54:03
INFO - 2024-10-27 12:54:03 --> Loader Class Initialized
INFO - 2024-10-27 12:54:03 --> Controller Class Initialized
INFO - 2024-10-27 12:54:03 --> Database Driver Class Initialized
INFO - 2024-10-27 12:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:54:03 --> Helper loaded: form_helper
INFO - 2024-10-27 12:54:03 --> Helper loaded: url_helper
INFO - 2024-10-27 12:54:03 --> Model Class Initialized
INFO - 2024-10-27 12:54:03 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:54:03 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:54:03 --> Helper loaded: email_helper
INFO - 2024-10-27 12:54:03 --> Model Class Initialized
INFO - 2024-10-27 12:54:03 --> Model Class Initialized
INFO - 2024-10-27 12:54:03 --> Model Class Initialized
INFO - 2024-10-27 12:54:03 --> Model Class Initialized
INFO - 2024-10-27 12:54:03 --> Model Class Initialized
INFO - 2024-10-27 12:54:03 --> Model Class Initialized
INFO - 2024-10-27 12:54:03 --> Model Class Initialized
DEBUG - 2024-10-27 12:54:03 --> plural called with: company
DEBUG - 2024-10-27 12:54:03 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:54:03 --> Model Class Initialized
INFO - 2024-10-27 12:54:03 --> Model Class Initialized
INFO - 2024-10-27 12:54:03 --> Model Class Initialized
INFO - 2024-10-27 12:54:03 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 12:54:03 --> Final output sent to browser
DEBUG - 2024-10-27 12:54:03 --> Total execution time: 0.0234
INFO - 2024-10-27 12:54:23 --> Config Class Initialized
INFO - 2024-10-27 12:54:23 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:54:23 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:54:23 --> Utf8 Class Initialized
INFO - 2024-10-27 12:54:23 --> URI Class Initialized
INFO - 2024-10-27 12:54:23 --> Router Class Initialized
INFO - 2024-10-27 12:54:23 --> Output Class Initialized
INFO - 2024-10-27 12:54:23 --> Security Class Initialized
DEBUG - 2024-10-27 12:54:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:54:23 --> Input Class Initialized
INFO - 2024-10-27 12:54:23 --> Language Class Initialized
ERROR - 2024-10-27 12:54:23 --> TEST ERROR MESSAGE - 2024-10-27 12:54:23
INFO - 2024-10-27 12:54:23 --> Loader Class Initialized
INFO - 2024-10-27 12:54:23 --> Controller Class Initialized
INFO - 2024-10-27 12:54:23 --> Database Driver Class Initialized
INFO - 2024-10-27 12:54:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:54:23 --> Helper loaded: form_helper
INFO - 2024-10-27 12:54:23 --> Helper loaded: url_helper
INFO - 2024-10-27 12:54:23 --> Model Class Initialized
INFO - 2024-10-27 12:54:23 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:54:23 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:54:23 --> Helper loaded: email_helper
INFO - 2024-10-27 12:54:23 --> Model Class Initialized
INFO - 2024-10-27 12:54:23 --> Model Class Initialized
INFO - 2024-10-27 12:54:23 --> Model Class Initialized
INFO - 2024-10-27 12:54:23 --> Model Class Initialized
INFO - 2024-10-27 12:54:23 --> Model Class Initialized
INFO - 2024-10-27 12:54:23 --> Model Class Initialized
INFO - 2024-10-27 12:54:23 --> Model Class Initialized
DEBUG - 2024-10-27 12:54:23 --> plural called with: company
DEBUG - 2024-10-27 12:54:23 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:54:23 --> Model Class Initialized
INFO - 2024-10-27 12:54:23 --> Model Class Initialized
INFO - 2024-10-27 12:54:23 --> Model Class Initialized
INFO - 2024-10-27 12:54:24 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 12:54:24 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 12:54:24 --> Final output sent to browser
DEBUG - 2024-10-27 12:54:24 --> Total execution time: 1.9515
INFO - 2024-10-27 12:54:26 --> Config Class Initialized
INFO - 2024-10-27 12:54:26 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:54:26 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:54:26 --> Utf8 Class Initialized
INFO - 2024-10-27 12:54:26 --> URI Class Initialized
INFO - 2024-10-27 12:54:26 --> Router Class Initialized
INFO - 2024-10-27 12:54:26 --> Output Class Initialized
INFO - 2024-10-27 12:54:26 --> Security Class Initialized
DEBUG - 2024-10-27 12:54:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:54:26 --> Input Class Initialized
INFO - 2024-10-27 12:54:26 --> Language Class Initialized
ERROR - 2024-10-27 12:54:26 --> TEST ERROR MESSAGE - 2024-10-27 12:54:26
INFO - 2024-10-27 12:54:26 --> Loader Class Initialized
INFO - 2024-10-27 12:54:26 --> Controller Class Initialized
INFO - 2024-10-27 12:54:26 --> Database Driver Class Initialized
INFO - 2024-10-27 12:54:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:54:26 --> Helper loaded: form_helper
INFO - 2024-10-27 12:54:26 --> Helper loaded: url_helper
INFO - 2024-10-27 12:54:26 --> Model Class Initialized
INFO - 2024-10-27 12:54:26 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:54:26 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:54:26 --> Helper loaded: email_helper
INFO - 2024-10-27 12:54:26 --> Model Class Initialized
INFO - 2024-10-27 12:54:26 --> Model Class Initialized
INFO - 2024-10-27 12:54:26 --> Model Class Initialized
INFO - 2024-10-27 12:54:26 --> Model Class Initialized
INFO - 2024-10-27 12:54:26 --> Model Class Initialized
INFO - 2024-10-27 12:54:26 --> Model Class Initialized
INFO - 2024-10-27 12:54:26 --> Model Class Initialized
DEBUG - 2024-10-27 12:54:26 --> plural called with: company
DEBUG - 2024-10-27 12:54:26 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:54:26 --> Model Class Initialized
INFO - 2024-10-27 12:54:26 --> Model Class Initialized
INFO - 2024-10-27 12:54:26 --> Model Class Initialized
INFO - 2024-10-27 12:54:26 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 12:54:26 --> Final output sent to browser
DEBUG - 2024-10-27 12:54:26 --> Total execution time: 0.0328
INFO - 2024-10-27 12:54:42 --> Config Class Initialized
INFO - 2024-10-27 12:54:42 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:54:42 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:54:42 --> Utf8 Class Initialized
INFO - 2024-10-27 12:54:42 --> URI Class Initialized
INFO - 2024-10-27 12:54:42 --> Router Class Initialized
INFO - 2024-10-27 12:54:42 --> Output Class Initialized
INFO - 2024-10-27 12:54:42 --> Security Class Initialized
DEBUG - 2024-10-27 12:54:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:54:42 --> Input Class Initialized
INFO - 2024-10-27 12:54:42 --> Language Class Initialized
ERROR - 2024-10-27 12:54:42 --> TEST ERROR MESSAGE - 2024-10-27 12:54:42
INFO - 2024-10-27 12:54:42 --> Loader Class Initialized
INFO - 2024-10-27 12:54:42 --> Controller Class Initialized
INFO - 2024-10-27 12:54:42 --> Database Driver Class Initialized
INFO - 2024-10-27 12:54:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:54:42 --> Helper loaded: form_helper
INFO - 2024-10-27 12:54:42 --> Helper loaded: url_helper
INFO - 2024-10-27 12:54:42 --> Model Class Initialized
INFO - 2024-10-27 12:54:42 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:54:42 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:54:42 --> Helper loaded: email_helper
INFO - 2024-10-27 12:54:42 --> Model Class Initialized
INFO - 2024-10-27 12:54:42 --> Model Class Initialized
INFO - 2024-10-27 12:54:42 --> Model Class Initialized
INFO - 2024-10-27 12:54:42 --> Model Class Initialized
INFO - 2024-10-27 12:54:42 --> Model Class Initialized
INFO - 2024-10-27 12:54:42 --> Model Class Initialized
INFO - 2024-10-27 12:54:42 --> Model Class Initialized
DEBUG - 2024-10-27 12:54:42 --> plural called with: company
DEBUG - 2024-10-27 12:54:42 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:54:42 --> Model Class Initialized
INFO - 2024-10-27 12:54:42 --> Model Class Initialized
INFO - 2024-10-27 12:54:42 --> Model Class Initialized
INFO - 2024-10-27 12:54:43 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 12:54:43 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 12:54:43 --> Final output sent to browser
DEBUG - 2024-10-27 12:54:43 --> Total execution time: 1.7679
INFO - 2024-10-27 12:54:59 --> Config Class Initialized
INFO - 2024-10-27 12:54:59 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:54:59 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:54:59 --> Utf8 Class Initialized
INFO - 2024-10-27 12:54:59 --> URI Class Initialized
INFO - 2024-10-27 12:54:59 --> Router Class Initialized
INFO - 2024-10-27 12:54:59 --> Output Class Initialized
INFO - 2024-10-27 12:54:59 --> Security Class Initialized
DEBUG - 2024-10-27 12:54:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:54:59 --> Input Class Initialized
INFO - 2024-10-27 12:54:59 --> Language Class Initialized
ERROR - 2024-10-27 12:54:59 --> TEST ERROR MESSAGE - 2024-10-27 12:54:59
INFO - 2024-10-27 12:54:59 --> Loader Class Initialized
INFO - 2024-10-27 12:54:59 --> Controller Class Initialized
INFO - 2024-10-27 12:54:59 --> Database Driver Class Initialized
INFO - 2024-10-27 12:54:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:54:59 --> Helper loaded: form_helper
INFO - 2024-10-27 12:54:59 --> Helper loaded: url_helper
INFO - 2024-10-27 12:54:59 --> Model Class Initialized
INFO - 2024-10-27 12:54:59 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:54:59 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:54:59 --> Helper loaded: email_helper
INFO - 2024-10-27 12:54:59 --> Model Class Initialized
INFO - 2024-10-27 12:54:59 --> Model Class Initialized
INFO - 2024-10-27 12:54:59 --> Model Class Initialized
INFO - 2024-10-27 12:54:59 --> Model Class Initialized
INFO - 2024-10-27 12:54:59 --> Model Class Initialized
INFO - 2024-10-27 12:54:59 --> Model Class Initialized
INFO - 2024-10-27 12:54:59 --> Model Class Initialized
DEBUG - 2024-10-27 12:54:59 --> plural called with: company
DEBUG - 2024-10-27 12:54:59 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:54:59 --> Model Class Initialized
INFO - 2024-10-27 12:54:59 --> Model Class Initialized
INFO - 2024-10-27 12:54:59 --> Model Class Initialized
INFO - 2024-10-27 12:55:02 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 12:55:02 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 12:55:02 --> Final output sent to browser
DEBUG - 2024-10-27 12:55:02 --> Total execution time: 2.7471
INFO - 2024-10-27 12:55:04 --> Config Class Initialized
INFO - 2024-10-27 12:55:04 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:55:04 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:55:04 --> Utf8 Class Initialized
INFO - 2024-10-27 12:55:04 --> URI Class Initialized
INFO - 2024-10-27 12:55:04 --> Router Class Initialized
INFO - 2024-10-27 12:55:04 --> Output Class Initialized
INFO - 2024-10-27 12:55:04 --> Security Class Initialized
DEBUG - 2024-10-27 12:55:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:55:04 --> Input Class Initialized
INFO - 2024-10-27 12:55:04 --> Language Class Initialized
ERROR - 2024-10-27 12:55:04 --> TEST ERROR MESSAGE - 2024-10-27 12:55:04
INFO - 2024-10-27 12:55:04 --> Loader Class Initialized
INFO - 2024-10-27 12:55:04 --> Controller Class Initialized
INFO - 2024-10-27 12:55:04 --> Database Driver Class Initialized
INFO - 2024-10-27 12:55:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:55:04 --> Helper loaded: form_helper
INFO - 2024-10-27 12:55:04 --> Helper loaded: url_helper
INFO - 2024-10-27 12:55:04 --> Model Class Initialized
INFO - 2024-10-27 12:55:04 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:55:04 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:55:04 --> Helper loaded: email_helper
INFO - 2024-10-27 12:55:04 --> Model Class Initialized
INFO - 2024-10-27 12:55:04 --> Model Class Initialized
INFO - 2024-10-27 12:55:04 --> Model Class Initialized
INFO - 2024-10-27 12:55:04 --> Model Class Initialized
INFO - 2024-10-27 12:55:04 --> Model Class Initialized
INFO - 2024-10-27 12:55:04 --> Model Class Initialized
INFO - 2024-10-27 12:55:04 --> Model Class Initialized
DEBUG - 2024-10-27 12:55:04 --> plural called with: company
DEBUG - 2024-10-27 12:55:04 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:55:04 --> Model Class Initialized
INFO - 2024-10-27 12:55:04 --> Model Class Initialized
INFO - 2024-10-27 12:55:04 --> Model Class Initialized
INFO - 2024-10-27 12:55:07 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 12:55:07 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 12:55:07 --> Final output sent to browser
DEBUG - 2024-10-27 12:55:07 --> Total execution time: 2.7906
INFO - 2024-10-27 12:55:11 --> Config Class Initialized
INFO - 2024-10-27 12:55:11 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:55:11 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:55:11 --> Utf8 Class Initialized
INFO - 2024-10-27 12:55:11 --> URI Class Initialized
INFO - 2024-10-27 12:55:11 --> Router Class Initialized
INFO - 2024-10-27 12:55:11 --> Output Class Initialized
INFO - 2024-10-27 12:55:11 --> Security Class Initialized
DEBUG - 2024-10-27 12:55:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:55:11 --> Input Class Initialized
INFO - 2024-10-27 12:55:11 --> Language Class Initialized
ERROR - 2024-10-27 12:55:11 --> TEST ERROR MESSAGE - 2024-10-27 12:55:11
INFO - 2024-10-27 12:55:11 --> Loader Class Initialized
INFO - 2024-10-27 12:55:11 --> Controller Class Initialized
INFO - 2024-10-27 12:55:11 --> Database Driver Class Initialized
INFO - 2024-10-27 12:55:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:55:11 --> Helper loaded: form_helper
INFO - 2024-10-27 12:55:11 --> Helper loaded: url_helper
INFO - 2024-10-27 12:55:11 --> Model Class Initialized
INFO - 2024-10-27 12:55:11 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:55:11 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:55:11 --> Helper loaded: email_helper
INFO - 2024-10-27 12:55:11 --> Model Class Initialized
INFO - 2024-10-27 12:55:11 --> Model Class Initialized
INFO - 2024-10-27 12:55:11 --> Model Class Initialized
INFO - 2024-10-27 12:55:11 --> Model Class Initialized
INFO - 2024-10-27 12:55:11 --> Model Class Initialized
INFO - 2024-10-27 12:55:11 --> Model Class Initialized
INFO - 2024-10-27 12:55:11 --> Model Class Initialized
DEBUG - 2024-10-27 12:55:11 --> plural called with: company
DEBUG - 2024-10-27 12:55:11 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:55:11 --> Model Class Initialized
INFO - 2024-10-27 12:55:11 --> Model Class Initialized
INFO - 2024-10-27 12:55:11 --> Model Class Initialized
ERROR - 2024-10-27 12:55:11 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 298
INFO - 2024-10-27 12:55:11 --> Final output sent to browser
DEBUG - 2024-10-27 12:55:11 --> Total execution time: 0.0724
INFO - 2024-10-27 12:55:14 --> Config Class Initialized
INFO - 2024-10-27 12:55:14 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:55:14 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:55:14 --> Utf8 Class Initialized
INFO - 2024-10-27 12:55:14 --> URI Class Initialized
INFO - 2024-10-27 12:55:14 --> Router Class Initialized
INFO - 2024-10-27 12:55:14 --> Output Class Initialized
INFO - 2024-10-27 12:55:14 --> Security Class Initialized
DEBUG - 2024-10-27 12:55:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:55:14 --> Input Class Initialized
INFO - 2024-10-27 12:55:14 --> Language Class Initialized
ERROR - 2024-10-27 12:55:14 --> TEST ERROR MESSAGE - 2024-10-27 12:55:14
INFO - 2024-10-27 12:55:14 --> Loader Class Initialized
INFO - 2024-10-27 12:55:14 --> Controller Class Initialized
INFO - 2024-10-27 12:55:14 --> Database Driver Class Initialized
INFO - 2024-10-27 12:55:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:55:14 --> Helper loaded: form_helper
INFO - 2024-10-27 12:55:14 --> Helper loaded: url_helper
INFO - 2024-10-27 12:55:14 --> Model Class Initialized
INFO - 2024-10-27 12:55:14 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:55:14 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:55:14 --> Helper loaded: email_helper
INFO - 2024-10-27 12:55:14 --> Model Class Initialized
INFO - 2024-10-27 12:55:14 --> Model Class Initialized
INFO - 2024-10-27 12:55:14 --> Model Class Initialized
INFO - 2024-10-27 12:55:14 --> Model Class Initialized
INFO - 2024-10-27 12:55:14 --> Model Class Initialized
INFO - 2024-10-27 12:55:14 --> Model Class Initialized
INFO - 2024-10-27 12:55:14 --> Model Class Initialized
DEBUG - 2024-10-27 12:55:14 --> plural called with: company
DEBUG - 2024-10-27 12:55:14 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:55:14 --> Model Class Initialized
INFO - 2024-10-27 12:55:14 --> Model Class Initialized
INFO - 2024-10-27 12:55:14 --> Model Class Initialized
INFO - 2024-10-27 12:55:16 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 12:55:16 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 12:55:16 --> Final output sent to browser
DEBUG - 2024-10-27 12:55:16 --> Total execution time: 2.4623
INFO - 2024-10-27 12:55:18 --> Config Class Initialized
INFO - 2024-10-27 12:55:18 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:55:18 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:55:18 --> Utf8 Class Initialized
INFO - 2024-10-27 12:55:18 --> URI Class Initialized
INFO - 2024-10-27 12:55:18 --> Router Class Initialized
INFO - 2024-10-27 12:55:18 --> Output Class Initialized
INFO - 2024-10-27 12:55:18 --> Security Class Initialized
DEBUG - 2024-10-27 12:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:55:18 --> Input Class Initialized
INFO - 2024-10-27 12:55:18 --> Language Class Initialized
ERROR - 2024-10-27 12:55:18 --> TEST ERROR MESSAGE - 2024-10-27 12:55:18
INFO - 2024-10-27 12:55:18 --> Loader Class Initialized
INFO - 2024-10-27 12:55:18 --> Controller Class Initialized
INFO - 2024-10-27 12:55:18 --> Database Driver Class Initialized
INFO - 2024-10-27 12:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:55:18 --> Helper loaded: form_helper
INFO - 2024-10-27 12:55:18 --> Helper loaded: url_helper
INFO - 2024-10-27 12:55:18 --> Model Class Initialized
INFO - 2024-10-27 12:55:18 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:55:18 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:55:18 --> Helper loaded: email_helper
INFO - 2024-10-27 12:55:18 --> Model Class Initialized
INFO - 2024-10-27 12:55:18 --> Model Class Initialized
INFO - 2024-10-27 12:55:18 --> Model Class Initialized
INFO - 2024-10-27 12:55:18 --> Model Class Initialized
INFO - 2024-10-27 12:55:18 --> Model Class Initialized
INFO - 2024-10-27 12:55:18 --> Model Class Initialized
INFO - 2024-10-27 12:55:18 --> Model Class Initialized
DEBUG - 2024-10-27 12:55:18 --> plural called with: company
DEBUG - 2024-10-27 12:55:18 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:55:18 --> Model Class Initialized
INFO - 2024-10-27 12:55:18 --> Model Class Initialized
INFO - 2024-10-27 12:55:18 --> Model Class Initialized
INFO - 2024-10-27 12:55:18 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 12:55:18 --> Final output sent to browser
DEBUG - 2024-10-27 12:55:18 --> Total execution time: 0.0278
INFO - 2024-10-27 12:55:32 --> Config Class Initialized
INFO - 2024-10-27 12:55:32 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:55:32 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:55:32 --> Utf8 Class Initialized
INFO - 2024-10-27 12:55:32 --> URI Class Initialized
INFO - 2024-10-27 12:55:32 --> Router Class Initialized
INFO - 2024-10-27 12:55:32 --> Output Class Initialized
INFO - 2024-10-27 12:55:32 --> Security Class Initialized
DEBUG - 2024-10-27 12:55:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:55:32 --> Input Class Initialized
INFO - 2024-10-27 12:55:32 --> Language Class Initialized
ERROR - 2024-10-27 12:55:32 --> TEST ERROR MESSAGE - 2024-10-27 12:55:32
INFO - 2024-10-27 12:55:32 --> Loader Class Initialized
INFO - 2024-10-27 12:55:32 --> Controller Class Initialized
INFO - 2024-10-27 12:55:32 --> Database Driver Class Initialized
INFO - 2024-10-27 12:55:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:55:32 --> Helper loaded: form_helper
INFO - 2024-10-27 12:55:32 --> Helper loaded: url_helper
INFO - 2024-10-27 12:55:32 --> Model Class Initialized
INFO - 2024-10-27 12:55:32 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:55:32 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:55:32 --> Helper loaded: email_helper
INFO - 2024-10-27 12:55:32 --> Model Class Initialized
INFO - 2024-10-27 12:55:32 --> Model Class Initialized
INFO - 2024-10-27 12:55:32 --> Model Class Initialized
INFO - 2024-10-27 12:55:32 --> Model Class Initialized
INFO - 2024-10-27 12:55:32 --> Model Class Initialized
INFO - 2024-10-27 12:55:32 --> Model Class Initialized
INFO - 2024-10-27 12:55:32 --> Model Class Initialized
DEBUG - 2024-10-27 12:55:32 --> plural called with: company
DEBUG - 2024-10-27 12:55:32 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:55:32 --> Model Class Initialized
INFO - 2024-10-27 12:55:32 --> Model Class Initialized
INFO - 2024-10-27 12:55:32 --> Model Class Initialized
INFO - 2024-10-27 12:55:35 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 12:55:35 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 12:55:35 --> Final output sent to browser
DEBUG - 2024-10-27 12:55:35 --> Total execution time: 2.8354
INFO - 2024-10-27 12:55:44 --> Config Class Initialized
INFO - 2024-10-27 12:55:44 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:55:44 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:55:44 --> Utf8 Class Initialized
INFO - 2024-10-27 12:55:44 --> URI Class Initialized
INFO - 2024-10-27 12:55:44 --> Router Class Initialized
INFO - 2024-10-27 12:55:44 --> Output Class Initialized
INFO - 2024-10-27 12:55:44 --> Security Class Initialized
DEBUG - 2024-10-27 12:55:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:55:44 --> Input Class Initialized
INFO - 2024-10-27 12:55:44 --> Language Class Initialized
ERROR - 2024-10-27 12:55:44 --> TEST ERROR MESSAGE - 2024-10-27 12:55:44
INFO - 2024-10-27 12:55:44 --> Loader Class Initialized
INFO - 2024-10-27 12:55:44 --> Controller Class Initialized
INFO - 2024-10-27 12:55:44 --> Database Driver Class Initialized
INFO - 2024-10-27 12:55:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:55:44 --> Helper loaded: form_helper
INFO - 2024-10-27 12:55:44 --> Helper loaded: url_helper
INFO - 2024-10-27 12:55:44 --> Model Class Initialized
INFO - 2024-10-27 12:55:44 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:55:44 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:55:44 --> Helper loaded: email_helper
INFO - 2024-10-27 12:55:44 --> Model Class Initialized
INFO - 2024-10-27 12:55:44 --> Model Class Initialized
INFO - 2024-10-27 12:55:44 --> Model Class Initialized
INFO - 2024-10-27 12:55:44 --> Model Class Initialized
INFO - 2024-10-27 12:55:44 --> Model Class Initialized
INFO - 2024-10-27 12:55:44 --> Model Class Initialized
INFO - 2024-10-27 12:55:44 --> Model Class Initialized
DEBUG - 2024-10-27 12:55:44 --> plural called with: company
DEBUG - 2024-10-27 12:55:44 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:55:44 --> Model Class Initialized
INFO - 2024-10-27 12:55:44 --> Model Class Initialized
INFO - 2024-10-27 12:55:44 --> Model Class Initialized
ERROR - 2024-10-27 12:55:44 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 298
INFO - 2024-10-27 12:55:44 --> Final output sent to browser
DEBUG - 2024-10-27 12:55:44 --> Total execution time: 0.0596
INFO - 2024-10-27 12:55:45 --> Config Class Initialized
INFO - 2024-10-27 12:55:45 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:55:45 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:55:45 --> Utf8 Class Initialized
INFO - 2024-10-27 12:55:45 --> URI Class Initialized
INFO - 2024-10-27 12:55:45 --> Router Class Initialized
INFO - 2024-10-27 12:55:45 --> Output Class Initialized
INFO - 2024-10-27 12:55:45 --> Security Class Initialized
DEBUG - 2024-10-27 12:55:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:55:45 --> Input Class Initialized
INFO - 2024-10-27 12:55:45 --> Language Class Initialized
ERROR - 2024-10-27 12:55:45 --> TEST ERROR MESSAGE - 2024-10-27 12:55:45
INFO - 2024-10-27 12:55:45 --> Loader Class Initialized
INFO - 2024-10-27 12:55:45 --> Controller Class Initialized
INFO - 2024-10-27 12:55:45 --> Database Driver Class Initialized
INFO - 2024-10-27 12:55:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:55:45 --> Helper loaded: form_helper
INFO - 2024-10-27 12:55:45 --> Helper loaded: url_helper
INFO - 2024-10-27 12:55:45 --> Model Class Initialized
INFO - 2024-10-27 12:55:45 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:55:45 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:55:45 --> Helper loaded: email_helper
INFO - 2024-10-27 12:55:45 --> Model Class Initialized
INFO - 2024-10-27 12:55:45 --> Model Class Initialized
INFO - 2024-10-27 12:55:45 --> Model Class Initialized
INFO - 2024-10-27 12:55:45 --> Model Class Initialized
INFO - 2024-10-27 12:55:45 --> Model Class Initialized
INFO - 2024-10-27 12:55:45 --> Model Class Initialized
INFO - 2024-10-27 12:55:45 --> Model Class Initialized
DEBUG - 2024-10-27 12:55:45 --> plural called with: company
DEBUG - 2024-10-27 12:55:45 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:55:45 --> Model Class Initialized
INFO - 2024-10-27 12:55:45 --> Model Class Initialized
INFO - 2024-10-27 12:55:45 --> Model Class Initialized
INFO - 2024-10-27 12:55:48 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 12:55:48 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 12:55:48 --> Final output sent to browser
DEBUG - 2024-10-27 12:55:48 --> Total execution time: 2.6424
INFO - 2024-10-27 12:55:49 --> Config Class Initialized
INFO - 2024-10-27 12:55:49 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:55:49 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:55:49 --> Utf8 Class Initialized
INFO - 2024-10-27 12:55:49 --> URI Class Initialized
INFO - 2024-10-27 12:55:49 --> Router Class Initialized
INFO - 2024-10-27 12:55:49 --> Output Class Initialized
INFO - 2024-10-27 12:55:49 --> Security Class Initialized
DEBUG - 2024-10-27 12:55:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:55:49 --> Input Class Initialized
INFO - 2024-10-27 12:55:49 --> Language Class Initialized
ERROR - 2024-10-27 12:55:49 --> TEST ERROR MESSAGE - 2024-10-27 12:55:49
INFO - 2024-10-27 12:55:49 --> Loader Class Initialized
INFO - 2024-10-27 12:55:49 --> Controller Class Initialized
INFO - 2024-10-27 12:55:49 --> Database Driver Class Initialized
INFO - 2024-10-27 12:55:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:55:49 --> Helper loaded: form_helper
INFO - 2024-10-27 12:55:49 --> Helper loaded: url_helper
INFO - 2024-10-27 12:55:49 --> Model Class Initialized
INFO - 2024-10-27 12:55:49 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:55:49 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:55:49 --> Helper loaded: email_helper
INFO - 2024-10-27 12:55:49 --> Model Class Initialized
INFO - 2024-10-27 12:55:49 --> Model Class Initialized
INFO - 2024-10-27 12:55:49 --> Model Class Initialized
INFO - 2024-10-27 12:55:49 --> Model Class Initialized
INFO - 2024-10-27 12:55:49 --> Model Class Initialized
INFO - 2024-10-27 12:55:49 --> Model Class Initialized
INFO - 2024-10-27 12:55:49 --> Model Class Initialized
DEBUG - 2024-10-27 12:55:49 --> plural called with: company
DEBUG - 2024-10-27 12:55:49 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:55:49 --> Model Class Initialized
INFO - 2024-10-27 12:55:49 --> Model Class Initialized
INFO - 2024-10-27 12:55:49 --> Model Class Initialized
INFO - 2024-10-27 12:55:49 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 12:55:49 --> Final output sent to browser
DEBUG - 2024-10-27 12:55:49 --> Total execution time: 0.0233
INFO - 2024-10-27 12:56:02 --> Config Class Initialized
INFO - 2024-10-27 12:56:02 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:56:02 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:56:02 --> Utf8 Class Initialized
INFO - 2024-10-27 12:56:02 --> URI Class Initialized
INFO - 2024-10-27 12:56:02 --> Router Class Initialized
INFO - 2024-10-27 12:56:02 --> Output Class Initialized
INFO - 2024-10-27 12:56:02 --> Security Class Initialized
DEBUG - 2024-10-27 12:56:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:56:02 --> Input Class Initialized
INFO - 2024-10-27 12:56:02 --> Language Class Initialized
ERROR - 2024-10-27 12:56:02 --> TEST ERROR MESSAGE - 2024-10-27 12:56:02
INFO - 2024-10-27 12:56:02 --> Loader Class Initialized
INFO - 2024-10-27 12:56:02 --> Controller Class Initialized
INFO - 2024-10-27 12:56:02 --> Database Driver Class Initialized
INFO - 2024-10-27 12:56:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:56:02 --> Helper loaded: form_helper
INFO - 2024-10-27 12:56:02 --> Helper loaded: url_helper
INFO - 2024-10-27 12:56:02 --> Model Class Initialized
INFO - 2024-10-27 12:56:02 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:56:02 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:56:02 --> Helper loaded: email_helper
INFO - 2024-10-27 12:56:02 --> Model Class Initialized
INFO - 2024-10-27 12:56:02 --> Model Class Initialized
INFO - 2024-10-27 12:56:02 --> Model Class Initialized
INFO - 2024-10-27 12:56:02 --> Model Class Initialized
INFO - 2024-10-27 12:56:02 --> Model Class Initialized
INFO - 2024-10-27 12:56:02 --> Model Class Initialized
INFO - 2024-10-27 12:56:02 --> Model Class Initialized
DEBUG - 2024-10-27 12:56:02 --> plural called with: company
DEBUG - 2024-10-27 12:56:02 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:56:02 --> Model Class Initialized
INFO - 2024-10-27 12:56:02 --> Model Class Initialized
INFO - 2024-10-27 12:56:02 --> Model Class Initialized
INFO - 2024-10-27 12:56:05 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 12:56:05 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 12:56:05 --> Final output sent to browser
DEBUG - 2024-10-27 12:56:05 --> Total execution time: 2.8057
INFO - 2024-10-27 12:56:15 --> Config Class Initialized
INFO - 2024-10-27 12:56:15 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:56:15 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:56:15 --> Utf8 Class Initialized
INFO - 2024-10-27 12:56:15 --> URI Class Initialized
INFO - 2024-10-27 12:56:15 --> Router Class Initialized
INFO - 2024-10-27 12:56:15 --> Output Class Initialized
INFO - 2024-10-27 12:56:15 --> Security Class Initialized
DEBUG - 2024-10-27 12:56:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:56:15 --> Input Class Initialized
INFO - 2024-10-27 12:56:15 --> Language Class Initialized
ERROR - 2024-10-27 12:56:15 --> TEST ERROR MESSAGE - 2024-10-27 12:56:15
INFO - 2024-10-27 12:56:15 --> Loader Class Initialized
INFO - 2024-10-27 12:56:15 --> Controller Class Initialized
INFO - 2024-10-27 12:56:15 --> Database Driver Class Initialized
INFO - 2024-10-27 12:56:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:56:15 --> Helper loaded: form_helper
INFO - 2024-10-27 12:56:15 --> Helper loaded: url_helper
INFO - 2024-10-27 12:56:15 --> Model Class Initialized
INFO - 2024-10-27 12:56:15 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:56:15 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:56:15 --> Helper loaded: email_helper
INFO - 2024-10-27 12:56:15 --> Model Class Initialized
INFO - 2024-10-27 12:56:15 --> Model Class Initialized
INFO - 2024-10-27 12:56:15 --> Model Class Initialized
INFO - 2024-10-27 12:56:15 --> Model Class Initialized
INFO - 2024-10-27 12:56:15 --> Model Class Initialized
INFO - 2024-10-27 12:56:15 --> Model Class Initialized
INFO - 2024-10-27 12:56:15 --> Model Class Initialized
DEBUG - 2024-10-27 12:56:15 --> plural called with: company
DEBUG - 2024-10-27 12:56:15 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:56:15 --> Model Class Initialized
INFO - 2024-10-27 12:56:15 --> Model Class Initialized
INFO - 2024-10-27 12:56:15 --> Model Class Initialized
ERROR - 2024-10-27 12:56:15 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 298
INFO - 2024-10-27 12:56:15 --> Final output sent to browser
DEBUG - 2024-10-27 12:56:15 --> Total execution time: 0.0856
INFO - 2024-10-27 12:56:17 --> Config Class Initialized
INFO - 2024-10-27 12:56:17 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:56:17 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:56:17 --> Utf8 Class Initialized
INFO - 2024-10-27 12:56:17 --> URI Class Initialized
INFO - 2024-10-27 12:56:17 --> Router Class Initialized
INFO - 2024-10-27 12:56:17 --> Output Class Initialized
INFO - 2024-10-27 12:56:17 --> Security Class Initialized
DEBUG - 2024-10-27 12:56:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:56:17 --> Input Class Initialized
INFO - 2024-10-27 12:56:17 --> Language Class Initialized
ERROR - 2024-10-27 12:56:17 --> TEST ERROR MESSAGE - 2024-10-27 12:56:17
INFO - 2024-10-27 12:56:17 --> Loader Class Initialized
INFO - 2024-10-27 12:56:17 --> Controller Class Initialized
INFO - 2024-10-27 12:56:17 --> Database Driver Class Initialized
INFO - 2024-10-27 12:56:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:56:17 --> Helper loaded: form_helper
INFO - 2024-10-27 12:56:17 --> Helper loaded: url_helper
INFO - 2024-10-27 12:56:17 --> Model Class Initialized
INFO - 2024-10-27 12:56:17 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:56:17 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:56:17 --> Helper loaded: email_helper
INFO - 2024-10-27 12:56:17 --> Model Class Initialized
INFO - 2024-10-27 12:56:17 --> Model Class Initialized
INFO - 2024-10-27 12:56:17 --> Model Class Initialized
INFO - 2024-10-27 12:56:17 --> Model Class Initialized
INFO - 2024-10-27 12:56:17 --> Model Class Initialized
INFO - 2024-10-27 12:56:17 --> Model Class Initialized
INFO - 2024-10-27 12:56:17 --> Model Class Initialized
DEBUG - 2024-10-27 12:56:17 --> plural called with: company
DEBUG - 2024-10-27 12:56:17 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:56:17 --> Model Class Initialized
INFO - 2024-10-27 12:56:17 --> Model Class Initialized
INFO - 2024-10-27 12:56:17 --> Model Class Initialized
INFO - 2024-10-27 12:56:19 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 12:56:19 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 12:56:19 --> Final output sent to browser
DEBUG - 2024-10-27 12:56:19 --> Total execution time: 2.4243
INFO - 2024-10-27 12:56:24 --> Config Class Initialized
INFO - 2024-10-27 12:56:24 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:56:24 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:56:24 --> Utf8 Class Initialized
INFO - 2024-10-27 12:56:24 --> URI Class Initialized
INFO - 2024-10-27 12:56:24 --> Router Class Initialized
INFO - 2024-10-27 12:56:24 --> Output Class Initialized
INFO - 2024-10-27 12:56:24 --> Security Class Initialized
DEBUG - 2024-10-27 12:56:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:56:24 --> Input Class Initialized
INFO - 2024-10-27 12:56:24 --> Language Class Initialized
ERROR - 2024-10-27 12:56:24 --> TEST ERROR MESSAGE - 2024-10-27 12:56:24
INFO - 2024-10-27 12:56:24 --> Loader Class Initialized
INFO - 2024-10-27 12:56:24 --> Controller Class Initialized
INFO - 2024-10-27 12:56:24 --> Database Driver Class Initialized
INFO - 2024-10-27 12:56:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:56:24 --> Helper loaded: form_helper
INFO - 2024-10-27 12:56:24 --> Helper loaded: url_helper
INFO - 2024-10-27 12:56:24 --> Model Class Initialized
INFO - 2024-10-27 12:56:24 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:56:24 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:56:24 --> Helper loaded: email_helper
INFO - 2024-10-27 12:56:24 --> Model Class Initialized
INFO - 2024-10-27 12:56:24 --> Model Class Initialized
INFO - 2024-10-27 12:56:24 --> Model Class Initialized
INFO - 2024-10-27 12:56:24 --> Model Class Initialized
INFO - 2024-10-27 12:56:24 --> Model Class Initialized
INFO - 2024-10-27 12:56:24 --> Model Class Initialized
INFO - 2024-10-27 12:56:24 --> Model Class Initialized
DEBUG - 2024-10-27 12:56:24 --> plural called with: company
DEBUG - 2024-10-27 12:56:24 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:56:24 --> Model Class Initialized
INFO - 2024-10-27 12:56:24 --> Model Class Initialized
INFO - 2024-10-27 12:56:24 --> Model Class Initialized
INFO - 2024-10-27 12:56:24 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 12:56:24 --> Final output sent to browser
DEBUG - 2024-10-27 12:56:24 --> Total execution time: 0.0221
INFO - 2024-10-27 12:56:36 --> Config Class Initialized
INFO - 2024-10-27 12:56:36 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:56:36 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:56:36 --> Utf8 Class Initialized
INFO - 2024-10-27 12:56:36 --> URI Class Initialized
INFO - 2024-10-27 12:56:36 --> Router Class Initialized
INFO - 2024-10-27 12:56:36 --> Output Class Initialized
INFO - 2024-10-27 12:56:36 --> Security Class Initialized
DEBUG - 2024-10-27 12:56:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:56:36 --> Input Class Initialized
INFO - 2024-10-27 12:56:36 --> Language Class Initialized
ERROR - 2024-10-27 12:56:36 --> TEST ERROR MESSAGE - 2024-10-27 12:56:36
INFO - 2024-10-27 12:56:36 --> Loader Class Initialized
INFO - 2024-10-27 12:56:36 --> Controller Class Initialized
INFO - 2024-10-27 12:56:36 --> Database Driver Class Initialized
INFO - 2024-10-27 12:56:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:56:36 --> Helper loaded: form_helper
INFO - 2024-10-27 12:56:36 --> Helper loaded: url_helper
INFO - 2024-10-27 12:56:36 --> Model Class Initialized
INFO - 2024-10-27 12:56:36 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:56:36 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:56:36 --> Helper loaded: email_helper
INFO - 2024-10-27 12:56:36 --> Model Class Initialized
INFO - 2024-10-27 12:56:36 --> Model Class Initialized
INFO - 2024-10-27 12:56:36 --> Model Class Initialized
INFO - 2024-10-27 12:56:36 --> Model Class Initialized
INFO - 2024-10-27 12:56:36 --> Model Class Initialized
INFO - 2024-10-27 12:56:36 --> Model Class Initialized
INFO - 2024-10-27 12:56:36 --> Model Class Initialized
DEBUG - 2024-10-27 12:56:36 --> plural called with: company
DEBUG - 2024-10-27 12:56:36 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:56:36 --> Model Class Initialized
INFO - 2024-10-27 12:56:36 --> Model Class Initialized
INFO - 2024-10-27 12:56:36 --> Model Class Initialized
INFO - 2024-10-27 12:56:39 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 12:56:39 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 12:56:39 --> Final output sent to browser
DEBUG - 2024-10-27 12:56:39 --> Total execution time: 2.7268
INFO - 2024-10-27 12:56:43 --> Config Class Initialized
INFO - 2024-10-27 12:56:43 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:56:43 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:56:43 --> Utf8 Class Initialized
INFO - 2024-10-27 12:56:43 --> URI Class Initialized
INFO - 2024-10-27 12:56:43 --> Router Class Initialized
INFO - 2024-10-27 12:56:43 --> Output Class Initialized
INFO - 2024-10-27 12:56:43 --> Security Class Initialized
DEBUG - 2024-10-27 12:56:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:56:43 --> Input Class Initialized
INFO - 2024-10-27 12:56:43 --> Language Class Initialized
ERROR - 2024-10-27 12:56:43 --> TEST ERROR MESSAGE - 2024-10-27 12:56:43
INFO - 2024-10-27 12:56:43 --> Loader Class Initialized
INFO - 2024-10-27 12:56:43 --> Controller Class Initialized
INFO - 2024-10-27 12:56:43 --> Database Driver Class Initialized
INFO - 2024-10-27 12:56:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:56:43 --> Helper loaded: form_helper
INFO - 2024-10-27 12:56:43 --> Helper loaded: url_helper
INFO - 2024-10-27 12:56:43 --> Model Class Initialized
INFO - 2024-10-27 12:56:43 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:56:43 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:56:43 --> Helper loaded: email_helper
INFO - 2024-10-27 12:56:43 --> Model Class Initialized
INFO - 2024-10-27 12:56:43 --> Model Class Initialized
INFO - 2024-10-27 12:56:43 --> Model Class Initialized
INFO - 2024-10-27 12:56:43 --> Model Class Initialized
INFO - 2024-10-27 12:56:43 --> Model Class Initialized
INFO - 2024-10-27 12:56:43 --> Model Class Initialized
INFO - 2024-10-27 12:56:43 --> Model Class Initialized
DEBUG - 2024-10-27 12:56:43 --> plural called with: company
DEBUG - 2024-10-27 12:56:43 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:56:43 --> Model Class Initialized
INFO - 2024-10-27 12:56:43 --> Model Class Initialized
INFO - 2024-10-27 12:56:43 --> Model Class Initialized
INFO - 2024-10-27 12:56:43 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 12:56:43 --> Final output sent to browser
DEBUG - 2024-10-27 12:56:43 --> Total execution time: 0.0254
INFO - 2024-10-27 12:56:58 --> Config Class Initialized
INFO - 2024-10-27 12:56:58 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:56:58 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:56:58 --> Utf8 Class Initialized
INFO - 2024-10-27 12:56:58 --> URI Class Initialized
INFO - 2024-10-27 12:56:58 --> Router Class Initialized
INFO - 2024-10-27 12:56:58 --> Output Class Initialized
INFO - 2024-10-27 12:56:58 --> Security Class Initialized
DEBUG - 2024-10-27 12:56:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:56:58 --> Input Class Initialized
INFO - 2024-10-27 12:56:58 --> Language Class Initialized
ERROR - 2024-10-27 12:56:58 --> TEST ERROR MESSAGE - 2024-10-27 12:56:58
INFO - 2024-10-27 12:56:58 --> Loader Class Initialized
INFO - 2024-10-27 12:56:58 --> Controller Class Initialized
INFO - 2024-10-27 12:56:58 --> Database Driver Class Initialized
INFO - 2024-10-27 12:56:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:56:58 --> Helper loaded: form_helper
INFO - 2024-10-27 12:56:58 --> Helper loaded: url_helper
INFO - 2024-10-27 12:56:58 --> Model Class Initialized
INFO - 2024-10-27 12:56:58 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:56:58 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:56:58 --> Helper loaded: email_helper
INFO - 2024-10-27 12:56:58 --> Model Class Initialized
INFO - 2024-10-27 12:56:58 --> Model Class Initialized
INFO - 2024-10-27 12:56:58 --> Model Class Initialized
INFO - 2024-10-27 12:56:58 --> Model Class Initialized
INFO - 2024-10-27 12:56:58 --> Model Class Initialized
INFO - 2024-10-27 12:56:58 --> Model Class Initialized
INFO - 2024-10-27 12:56:58 --> Model Class Initialized
DEBUG - 2024-10-27 12:56:58 --> plural called with: company
DEBUG - 2024-10-27 12:56:58 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:56:58 --> Model Class Initialized
INFO - 2024-10-27 12:56:58 --> Model Class Initialized
INFO - 2024-10-27 12:56:58 --> Model Class Initialized
INFO - 2024-10-27 12:57:00 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 12:57:00 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 12:57:00 --> Final output sent to browser
DEBUG - 2024-10-27 12:57:00 --> Total execution time: 2.5137
INFO - 2024-10-27 12:57:08 --> Config Class Initialized
INFO - 2024-10-27 12:57:08 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:57:08 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:57:08 --> Utf8 Class Initialized
INFO - 2024-10-27 12:57:08 --> URI Class Initialized
INFO - 2024-10-27 12:57:08 --> Router Class Initialized
INFO - 2024-10-27 12:57:08 --> Output Class Initialized
INFO - 2024-10-27 12:57:08 --> Security Class Initialized
DEBUG - 2024-10-27 12:57:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:57:08 --> Input Class Initialized
INFO - 2024-10-27 12:57:08 --> Language Class Initialized
ERROR - 2024-10-27 12:57:08 --> TEST ERROR MESSAGE - 2024-10-27 12:57:08
INFO - 2024-10-27 12:57:08 --> Loader Class Initialized
INFO - 2024-10-27 12:57:08 --> Controller Class Initialized
INFO - 2024-10-27 12:57:08 --> Database Driver Class Initialized
INFO - 2024-10-27 12:57:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:57:08 --> Helper loaded: form_helper
INFO - 2024-10-27 12:57:08 --> Helper loaded: url_helper
INFO - 2024-10-27 12:57:08 --> Model Class Initialized
INFO - 2024-10-27 12:57:08 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:57:08 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:57:08 --> Helper loaded: email_helper
INFO - 2024-10-27 12:57:08 --> Model Class Initialized
INFO - 2024-10-27 12:57:08 --> Model Class Initialized
INFO - 2024-10-27 12:57:08 --> Model Class Initialized
INFO - 2024-10-27 12:57:08 --> Model Class Initialized
INFO - 2024-10-27 12:57:08 --> Model Class Initialized
INFO - 2024-10-27 12:57:08 --> Model Class Initialized
INFO - 2024-10-27 12:57:08 --> Model Class Initialized
DEBUG - 2024-10-27 12:57:08 --> plural called with: company
DEBUG - 2024-10-27 12:57:08 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:57:08 --> Model Class Initialized
INFO - 2024-10-27 12:57:08 --> Model Class Initialized
INFO - 2024-10-27 12:57:08 --> Model Class Initialized
ERROR - 2024-10-27 12:57:08 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 298
INFO - 2024-10-27 12:57:08 --> Final output sent to browser
DEBUG - 2024-10-27 12:57:08 --> Total execution time: 0.0820
INFO - 2024-10-27 12:57:09 --> Config Class Initialized
INFO - 2024-10-27 12:57:09 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:57:09 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:57:09 --> Utf8 Class Initialized
INFO - 2024-10-27 12:57:09 --> URI Class Initialized
INFO - 2024-10-27 12:57:09 --> Router Class Initialized
INFO - 2024-10-27 12:57:09 --> Output Class Initialized
INFO - 2024-10-27 12:57:09 --> Security Class Initialized
DEBUG - 2024-10-27 12:57:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:57:09 --> Input Class Initialized
INFO - 2024-10-27 12:57:09 --> Language Class Initialized
ERROR - 2024-10-27 12:57:09 --> TEST ERROR MESSAGE - 2024-10-27 12:57:09
INFO - 2024-10-27 12:57:09 --> Loader Class Initialized
INFO - 2024-10-27 12:57:09 --> Controller Class Initialized
INFO - 2024-10-27 12:57:09 --> Database Driver Class Initialized
INFO - 2024-10-27 12:57:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:57:09 --> Helper loaded: form_helper
INFO - 2024-10-27 12:57:09 --> Helper loaded: url_helper
INFO - 2024-10-27 12:57:09 --> Model Class Initialized
INFO - 2024-10-27 12:57:09 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:57:09 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:57:09 --> Helper loaded: email_helper
INFO - 2024-10-27 12:57:09 --> Model Class Initialized
INFO - 2024-10-27 12:57:09 --> Model Class Initialized
INFO - 2024-10-27 12:57:09 --> Model Class Initialized
INFO - 2024-10-27 12:57:09 --> Model Class Initialized
INFO - 2024-10-27 12:57:09 --> Model Class Initialized
INFO - 2024-10-27 12:57:09 --> Model Class Initialized
INFO - 2024-10-27 12:57:09 --> Model Class Initialized
DEBUG - 2024-10-27 12:57:09 --> plural called with: company
DEBUG - 2024-10-27 12:57:09 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:57:09 --> Model Class Initialized
INFO - 2024-10-27 12:57:09 --> Model Class Initialized
INFO - 2024-10-27 12:57:09 --> Model Class Initialized
INFO - 2024-10-27 12:57:11 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 12:57:11 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 12:57:11 --> Final output sent to browser
DEBUG - 2024-10-27 12:57:11 --> Total execution time: 2.4385
INFO - 2024-10-27 12:57:15 --> Config Class Initialized
INFO - 2024-10-27 12:57:15 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:57:15 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:57:15 --> Utf8 Class Initialized
INFO - 2024-10-27 12:57:15 --> URI Class Initialized
INFO - 2024-10-27 12:57:15 --> Router Class Initialized
INFO - 2024-10-27 12:57:15 --> Output Class Initialized
INFO - 2024-10-27 12:57:15 --> Security Class Initialized
DEBUG - 2024-10-27 12:57:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:57:15 --> Input Class Initialized
INFO - 2024-10-27 12:57:15 --> Language Class Initialized
ERROR - 2024-10-27 12:57:15 --> TEST ERROR MESSAGE - 2024-10-27 12:57:15
INFO - 2024-10-27 12:57:15 --> Loader Class Initialized
INFO - 2024-10-27 12:57:15 --> Controller Class Initialized
INFO - 2024-10-27 12:57:15 --> Database Driver Class Initialized
INFO - 2024-10-27 12:57:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:57:15 --> Helper loaded: form_helper
INFO - 2024-10-27 12:57:15 --> Helper loaded: url_helper
INFO - 2024-10-27 12:57:15 --> Model Class Initialized
INFO - 2024-10-27 12:57:15 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:57:15 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:57:15 --> Helper loaded: email_helper
INFO - 2024-10-27 12:57:15 --> Model Class Initialized
INFO - 2024-10-27 12:57:15 --> Model Class Initialized
INFO - 2024-10-27 12:57:15 --> Model Class Initialized
INFO - 2024-10-27 12:57:15 --> Model Class Initialized
INFO - 2024-10-27 12:57:15 --> Model Class Initialized
INFO - 2024-10-27 12:57:15 --> Model Class Initialized
INFO - 2024-10-27 12:57:15 --> Model Class Initialized
DEBUG - 2024-10-27 12:57:15 --> plural called with: company
DEBUG - 2024-10-27 12:57:15 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:57:15 --> Model Class Initialized
INFO - 2024-10-27 12:57:15 --> Model Class Initialized
INFO - 2024-10-27 12:57:15 --> Model Class Initialized
INFO - 2024-10-27 12:57:15 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 12:57:15 --> Final output sent to browser
DEBUG - 2024-10-27 12:57:15 --> Total execution time: 0.0383
INFO - 2024-10-27 12:57:29 --> Config Class Initialized
INFO - 2024-10-27 12:57:29 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:57:29 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:57:29 --> Utf8 Class Initialized
INFO - 2024-10-27 12:57:29 --> URI Class Initialized
INFO - 2024-10-27 12:57:29 --> Router Class Initialized
INFO - 2024-10-27 12:57:29 --> Output Class Initialized
INFO - 2024-10-27 12:57:29 --> Security Class Initialized
DEBUG - 2024-10-27 12:57:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:57:29 --> Input Class Initialized
INFO - 2024-10-27 12:57:29 --> Language Class Initialized
ERROR - 2024-10-27 12:57:29 --> TEST ERROR MESSAGE - 2024-10-27 12:57:29
INFO - 2024-10-27 12:57:29 --> Loader Class Initialized
INFO - 2024-10-27 12:57:29 --> Controller Class Initialized
INFO - 2024-10-27 12:57:29 --> Database Driver Class Initialized
INFO - 2024-10-27 12:57:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:57:29 --> Helper loaded: form_helper
INFO - 2024-10-27 12:57:29 --> Helper loaded: url_helper
INFO - 2024-10-27 12:57:29 --> Model Class Initialized
INFO - 2024-10-27 12:57:29 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:57:29 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:57:29 --> Helper loaded: email_helper
INFO - 2024-10-27 12:57:29 --> Model Class Initialized
INFO - 2024-10-27 12:57:29 --> Model Class Initialized
INFO - 2024-10-27 12:57:29 --> Model Class Initialized
INFO - 2024-10-27 12:57:29 --> Model Class Initialized
INFO - 2024-10-27 12:57:29 --> Model Class Initialized
INFO - 2024-10-27 12:57:29 --> Model Class Initialized
INFO - 2024-10-27 12:57:29 --> Model Class Initialized
DEBUG - 2024-10-27 12:57:29 --> plural called with: company
DEBUG - 2024-10-27 12:57:29 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:57:29 --> Model Class Initialized
INFO - 2024-10-27 12:57:29 --> Model Class Initialized
INFO - 2024-10-27 12:57:29 --> Model Class Initialized
INFO - 2024-10-27 12:57:31 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 12:57:31 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 12:57:31 --> Final output sent to browser
DEBUG - 2024-10-27 12:57:31 --> Total execution time: 2.2693
INFO - 2024-10-27 12:57:37 --> Config Class Initialized
INFO - 2024-10-27 12:57:37 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:57:37 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:57:37 --> Utf8 Class Initialized
INFO - 2024-10-27 12:57:37 --> URI Class Initialized
INFO - 2024-10-27 12:57:37 --> Router Class Initialized
INFO - 2024-10-27 12:57:37 --> Output Class Initialized
INFO - 2024-10-27 12:57:37 --> Security Class Initialized
DEBUG - 2024-10-27 12:57:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:57:37 --> Input Class Initialized
INFO - 2024-10-27 12:57:37 --> Language Class Initialized
ERROR - 2024-10-27 12:57:37 --> TEST ERROR MESSAGE - 2024-10-27 12:57:37
INFO - 2024-10-27 12:57:37 --> Loader Class Initialized
INFO - 2024-10-27 12:57:37 --> Controller Class Initialized
INFO - 2024-10-27 12:57:37 --> Database Driver Class Initialized
INFO - 2024-10-27 12:57:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:57:37 --> Helper loaded: form_helper
INFO - 2024-10-27 12:57:37 --> Helper loaded: url_helper
INFO - 2024-10-27 12:57:37 --> Model Class Initialized
INFO - 2024-10-27 12:57:37 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:57:37 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:57:37 --> Helper loaded: email_helper
INFO - 2024-10-27 12:57:37 --> Model Class Initialized
INFO - 2024-10-27 12:57:37 --> Model Class Initialized
INFO - 2024-10-27 12:57:37 --> Model Class Initialized
INFO - 2024-10-27 12:57:37 --> Model Class Initialized
INFO - 2024-10-27 12:57:37 --> Model Class Initialized
INFO - 2024-10-27 12:57:37 --> Model Class Initialized
INFO - 2024-10-27 12:57:37 --> Model Class Initialized
DEBUG - 2024-10-27 12:57:37 --> plural called with: company
DEBUG - 2024-10-27 12:57:37 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:57:37 --> Model Class Initialized
INFO - 2024-10-27 12:57:37 --> Model Class Initialized
INFO - 2024-10-27 12:57:37 --> Model Class Initialized
INFO - 2024-10-27 12:57:37 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 12:57:37 --> Final output sent to browser
DEBUG - 2024-10-27 12:57:37 --> Total execution time: 0.0244
INFO - 2024-10-27 12:57:53 --> Config Class Initialized
INFO - 2024-10-27 12:57:53 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:57:53 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:57:53 --> Utf8 Class Initialized
INFO - 2024-10-27 12:57:53 --> URI Class Initialized
INFO - 2024-10-27 12:57:53 --> Router Class Initialized
INFO - 2024-10-27 12:57:53 --> Output Class Initialized
INFO - 2024-10-27 12:57:53 --> Security Class Initialized
DEBUG - 2024-10-27 12:57:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:57:53 --> Input Class Initialized
INFO - 2024-10-27 12:57:53 --> Language Class Initialized
ERROR - 2024-10-27 12:57:53 --> TEST ERROR MESSAGE - 2024-10-27 12:57:53
INFO - 2024-10-27 12:57:53 --> Loader Class Initialized
INFO - 2024-10-27 12:57:53 --> Controller Class Initialized
INFO - 2024-10-27 12:57:53 --> Database Driver Class Initialized
INFO - 2024-10-27 12:57:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:57:53 --> Helper loaded: form_helper
INFO - 2024-10-27 12:57:53 --> Helper loaded: url_helper
INFO - 2024-10-27 12:57:53 --> Model Class Initialized
INFO - 2024-10-27 12:57:53 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:57:53 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:57:53 --> Helper loaded: email_helper
INFO - 2024-10-27 12:57:53 --> Model Class Initialized
INFO - 2024-10-27 12:57:53 --> Model Class Initialized
INFO - 2024-10-27 12:57:53 --> Model Class Initialized
INFO - 2024-10-27 12:57:53 --> Model Class Initialized
INFO - 2024-10-27 12:57:53 --> Model Class Initialized
INFO - 2024-10-27 12:57:53 --> Model Class Initialized
INFO - 2024-10-27 12:57:53 --> Model Class Initialized
DEBUG - 2024-10-27 12:57:53 --> plural called with: company
DEBUG - 2024-10-27 12:57:53 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:57:53 --> Model Class Initialized
INFO - 2024-10-27 12:57:53 --> Model Class Initialized
INFO - 2024-10-27 12:57:53 --> Model Class Initialized
INFO - 2024-10-27 12:57:55 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 12:57:55 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 12:57:55 --> Final output sent to browser
DEBUG - 2024-10-27 12:57:55 --> Total execution time: 2.8129
INFO - 2024-10-27 12:57:59 --> Config Class Initialized
INFO - 2024-10-27 12:57:59 --> Hooks Class Initialized
DEBUG - 2024-10-27 12:57:59 --> UTF-8 Support Enabled
INFO - 2024-10-27 12:57:59 --> Utf8 Class Initialized
INFO - 2024-10-27 12:57:59 --> URI Class Initialized
INFO - 2024-10-27 12:57:59 --> Router Class Initialized
INFO - 2024-10-27 12:57:59 --> Output Class Initialized
INFO - 2024-10-27 12:57:59 --> Security Class Initialized
DEBUG - 2024-10-27 12:57:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 12:57:59 --> Input Class Initialized
INFO - 2024-10-27 12:57:59 --> Language Class Initialized
ERROR - 2024-10-27 12:57:59 --> TEST ERROR MESSAGE - 2024-10-27 12:57:59
INFO - 2024-10-27 12:57:59 --> Loader Class Initialized
INFO - 2024-10-27 12:57:59 --> Controller Class Initialized
INFO - 2024-10-27 12:57:59 --> Database Driver Class Initialized
INFO - 2024-10-27 12:57:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 12:57:59 --> Helper loaded: form_helper
INFO - 2024-10-27 12:57:59 --> Helper loaded: url_helper
INFO - 2024-10-27 12:57:59 --> Model Class Initialized
INFO - 2024-10-27 12:57:59 --> Helper loaded: inflector_helper
INFO - 2024-10-27 12:57:59 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 12:57:59 --> Helper loaded: email_helper
INFO - 2024-10-27 12:57:59 --> Model Class Initialized
INFO - 2024-10-27 12:57:59 --> Model Class Initialized
INFO - 2024-10-27 12:57:59 --> Model Class Initialized
INFO - 2024-10-27 12:57:59 --> Model Class Initialized
INFO - 2024-10-27 12:57:59 --> Model Class Initialized
INFO - 2024-10-27 12:57:59 --> Model Class Initialized
INFO - 2024-10-27 12:57:59 --> Model Class Initialized
DEBUG - 2024-10-27 12:57:59 --> plural called with: company
DEBUG - 2024-10-27 12:57:59 --> is_countable called with!!!!: company
INFO - 2024-10-27 12:57:59 --> Model Class Initialized
INFO - 2024-10-27 12:57:59 --> Model Class Initialized
INFO - 2024-10-27 12:57:59 --> Model Class Initialized
INFO - 2024-10-27 12:57:59 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 12:57:59 --> Final output sent to browser
DEBUG - 2024-10-27 12:57:59 --> Total execution time: 0.0252
INFO - 2024-10-27 13:05:08 --> Config Class Initialized
INFO - 2024-10-27 13:05:08 --> Hooks Class Initialized
DEBUG - 2024-10-27 13:05:08 --> UTF-8 Support Enabled
INFO - 2024-10-27 13:05:08 --> Utf8 Class Initialized
INFO - 2024-10-27 13:05:08 --> URI Class Initialized
INFO - 2024-10-27 13:05:08 --> Router Class Initialized
INFO - 2024-10-27 13:05:08 --> Output Class Initialized
INFO - 2024-10-27 13:05:08 --> Security Class Initialized
DEBUG - 2024-10-27 13:05:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 13:05:08 --> Input Class Initialized
INFO - 2024-10-27 13:05:08 --> Language Class Initialized
ERROR - 2024-10-27 13:05:08 --> TEST ERROR MESSAGE - 2024-10-27 13:05:08
INFO - 2024-10-27 13:05:08 --> Loader Class Initialized
INFO - 2024-10-27 13:05:08 --> Controller Class Initialized
INFO - 2024-10-27 13:05:08 --> Database Driver Class Initialized
INFO - 2024-10-27 13:05:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 13:05:08 --> Helper loaded: form_helper
INFO - 2024-10-27 13:05:08 --> Helper loaded: url_helper
INFO - 2024-10-27 13:05:08 --> Model Class Initialized
INFO - 2024-10-27 13:05:08 --> Helper loaded: inflector_helper
INFO - 2024-10-27 13:05:08 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 13:05:08 --> Helper loaded: email_helper
INFO - 2024-10-27 13:05:08 --> Model Class Initialized
INFO - 2024-10-27 13:05:08 --> Model Class Initialized
INFO - 2024-10-27 13:05:08 --> Model Class Initialized
INFO - 2024-10-27 13:05:08 --> Model Class Initialized
INFO - 2024-10-27 13:05:08 --> Model Class Initialized
INFO - 2024-10-27 13:05:08 --> Model Class Initialized
INFO - 2024-10-27 13:05:08 --> Model Class Initialized
DEBUG - 2024-10-27 13:05:08 --> plural called with: company
DEBUG - 2024-10-27 13:05:08 --> is_countable called with!!!!: company
INFO - 2024-10-27 13:05:08 --> Model Class Initialized
INFO - 2024-10-27 13:05:08 --> Model Class Initialized
INFO - 2024-10-27 13:05:08 --> Model Class Initialized
ERROR - 2024-10-27 13:05:08 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 298
INFO - 2024-10-27 13:05:08 --> Final output sent to browser
DEBUG - 2024-10-27 13:05:08 --> Total execution time: 0.0679
INFO - 2024-10-27 13:05:17 --> Config Class Initialized
INFO - 2024-10-27 13:05:17 --> Hooks Class Initialized
DEBUG - 2024-10-27 13:05:17 --> UTF-8 Support Enabled
INFO - 2024-10-27 13:05:17 --> Utf8 Class Initialized
INFO - 2024-10-27 13:05:17 --> URI Class Initialized
INFO - 2024-10-27 13:05:17 --> Router Class Initialized
INFO - 2024-10-27 13:05:17 --> Output Class Initialized
INFO - 2024-10-27 13:05:17 --> Security Class Initialized
DEBUG - 2024-10-27 13:05:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 13:05:17 --> Input Class Initialized
INFO - 2024-10-27 13:05:17 --> Language Class Initialized
ERROR - 2024-10-27 13:05:17 --> TEST ERROR MESSAGE - 2024-10-27 13:05:17
INFO - 2024-10-27 13:05:17 --> Loader Class Initialized
INFO - 2024-10-27 13:05:17 --> Controller Class Initialized
INFO - 2024-10-27 13:05:17 --> Database Driver Class Initialized
INFO - 2024-10-27 13:05:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 13:05:17 --> Helper loaded: form_helper
INFO - 2024-10-27 13:05:17 --> Helper loaded: url_helper
INFO - 2024-10-27 13:05:17 --> Model Class Initialized
INFO - 2024-10-27 13:05:17 --> Helper loaded: inflector_helper
INFO - 2024-10-27 13:05:17 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 13:05:17 --> Helper loaded: email_helper
INFO - 2024-10-27 13:05:17 --> Model Class Initialized
INFO - 2024-10-27 13:05:17 --> Model Class Initialized
INFO - 2024-10-27 13:05:17 --> Model Class Initialized
INFO - 2024-10-27 13:05:17 --> Model Class Initialized
INFO - 2024-10-27 13:05:17 --> Model Class Initialized
INFO - 2024-10-27 13:05:17 --> Model Class Initialized
INFO - 2024-10-27 13:05:17 --> Model Class Initialized
DEBUG - 2024-10-27 13:05:17 --> plural called with: company
DEBUG - 2024-10-27 13:05:17 --> is_countable called with!!!!: company
INFO - 2024-10-27 13:05:17 --> Model Class Initialized
INFO - 2024-10-27 13:05:17 --> Model Class Initialized
INFO - 2024-10-27 13:05:17 --> Model Class Initialized
ERROR - 2024-10-27 13:05:17 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 298
INFO - 2024-10-27 13:05:17 --> Final output sent to browser
DEBUG - 2024-10-27 13:05:17 --> Total execution time: 0.0735
INFO - 2024-10-27 13:23:45 --> Config Class Initialized
INFO - 2024-10-27 13:23:45 --> Hooks Class Initialized
DEBUG - 2024-10-27 13:23:45 --> UTF-8 Support Enabled
INFO - 2024-10-27 13:23:45 --> Utf8 Class Initialized
INFO - 2024-10-27 13:23:45 --> URI Class Initialized
INFO - 2024-10-27 13:23:45 --> Router Class Initialized
INFO - 2024-10-27 13:23:45 --> Output Class Initialized
INFO - 2024-10-27 13:23:45 --> Security Class Initialized
DEBUG - 2024-10-27 13:23:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 13:23:45 --> Input Class Initialized
INFO - 2024-10-27 13:23:45 --> Language Class Initialized
ERROR - 2024-10-27 13:23:45 --> TEST ERROR MESSAGE - 2024-10-27 13:23:45
INFO - 2024-10-27 13:23:45 --> Loader Class Initialized
INFO - 2024-10-27 13:23:45 --> Controller Class Initialized
INFO - 2024-10-27 13:23:45 --> Database Driver Class Initialized
INFO - 2024-10-27 13:23:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 13:23:45 --> Helper loaded: form_helper
INFO - 2024-10-27 13:23:45 --> Helper loaded: url_helper
INFO - 2024-10-27 13:23:45 --> Model Class Initialized
INFO - 2024-10-27 13:23:45 --> Helper loaded: inflector_helper
INFO - 2024-10-27 13:23:45 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 13:23:45 --> Helper loaded: email_helper
INFO - 2024-10-27 13:23:45 --> Model Class Initialized
INFO - 2024-10-27 13:23:45 --> Model Class Initialized
INFO - 2024-10-27 13:23:45 --> Model Class Initialized
INFO - 2024-10-27 13:23:45 --> Model Class Initialized
INFO - 2024-10-27 13:23:45 --> Model Class Initialized
INFO - 2024-10-27 13:23:45 --> Model Class Initialized
INFO - 2024-10-27 13:23:45 --> Model Class Initialized
DEBUG - 2024-10-27 13:23:45 --> plural called with: company
DEBUG - 2024-10-27 13:23:45 --> is_countable called with!!!!: company
INFO - 2024-10-27 13:23:45 --> Model Class Initialized
INFO - 2024-10-27 13:23:45 --> Model Class Initialized
INFO - 2024-10-27 13:23:45 --> Model Class Initialized
ERROR - 2024-10-27 13:23:45 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 298
INFO - 2024-10-27 13:23:45 --> Final output sent to browser
DEBUG - 2024-10-27 13:23:45 --> Total execution time: 0.1007
INFO - 2024-10-27 13:55:18 --> Config Class Initialized
INFO - 2024-10-27 13:55:18 --> Hooks Class Initialized
DEBUG - 2024-10-27 13:55:18 --> UTF-8 Support Enabled
INFO - 2024-10-27 13:55:18 --> Utf8 Class Initialized
INFO - 2024-10-27 13:55:18 --> URI Class Initialized
INFO - 2024-10-27 13:55:18 --> Router Class Initialized
INFO - 2024-10-27 13:55:18 --> Output Class Initialized
INFO - 2024-10-27 13:55:18 --> Security Class Initialized
DEBUG - 2024-10-27 13:55:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 13:55:18 --> Input Class Initialized
INFO - 2024-10-27 13:55:18 --> Language Class Initialized
ERROR - 2024-10-27 13:55:18 --> TEST ERROR MESSAGE - 2024-10-27 13:55:18
INFO - 2024-10-27 13:55:18 --> Loader Class Initialized
INFO - 2024-10-27 13:55:18 --> Controller Class Initialized
INFO - 2024-10-27 13:55:18 --> Database Driver Class Initialized
INFO - 2024-10-27 13:55:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 13:55:18 --> Helper loaded: form_helper
INFO - 2024-10-27 13:55:18 --> Helper loaded: url_helper
INFO - 2024-10-27 13:55:18 --> Model Class Initialized
INFO - 2024-10-27 13:55:18 --> Helper loaded: inflector_helper
INFO - 2024-10-27 13:55:18 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 13:55:18 --> Helper loaded: email_helper
INFO - 2024-10-27 13:55:18 --> Model Class Initialized
INFO - 2024-10-27 13:55:18 --> Model Class Initialized
INFO - 2024-10-27 13:55:18 --> Model Class Initialized
INFO - 2024-10-27 13:55:18 --> Model Class Initialized
INFO - 2024-10-27 13:55:18 --> Model Class Initialized
INFO - 2024-10-27 13:55:18 --> Model Class Initialized
INFO - 2024-10-27 13:55:18 --> Model Class Initialized
DEBUG - 2024-10-27 13:55:18 --> plural called with: company
DEBUG - 2024-10-27 13:55:18 --> is_countable called with!!!!: company
INFO - 2024-10-27 13:55:18 --> Model Class Initialized
INFO - 2024-10-27 13:55:18 --> Model Class Initialized
INFO - 2024-10-27 13:55:18 --> Model Class Initialized
INFO - 2024-10-27 13:55:21 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 13:55:21 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 13:55:21 --> Final output sent to browser
DEBUG - 2024-10-27 13:55:21 --> Total execution time: 2.9549
INFO - 2024-10-27 13:55:26 --> Config Class Initialized
INFO - 2024-10-27 13:55:26 --> Hooks Class Initialized
DEBUG - 2024-10-27 13:55:26 --> UTF-8 Support Enabled
INFO - 2024-10-27 13:55:26 --> Utf8 Class Initialized
INFO - 2024-10-27 13:55:26 --> URI Class Initialized
INFO - 2024-10-27 13:55:26 --> Router Class Initialized
INFO - 2024-10-27 13:55:26 --> Output Class Initialized
INFO - 2024-10-27 13:55:26 --> Security Class Initialized
DEBUG - 2024-10-27 13:55:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 13:55:26 --> Input Class Initialized
INFO - 2024-10-27 13:55:26 --> Language Class Initialized
ERROR - 2024-10-27 13:55:26 --> TEST ERROR MESSAGE - 2024-10-27 13:55:26
INFO - 2024-10-27 13:55:26 --> Loader Class Initialized
INFO - 2024-10-27 13:55:26 --> Controller Class Initialized
INFO - 2024-10-27 13:55:26 --> Database Driver Class Initialized
INFO - 2024-10-27 13:55:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 13:55:26 --> Helper loaded: form_helper
INFO - 2024-10-27 13:55:26 --> Helper loaded: url_helper
INFO - 2024-10-27 13:55:26 --> Model Class Initialized
INFO - 2024-10-27 13:55:26 --> Helper loaded: inflector_helper
INFO - 2024-10-27 13:55:26 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 13:55:26 --> Helper loaded: email_helper
INFO - 2024-10-27 13:55:26 --> Model Class Initialized
INFO - 2024-10-27 13:55:26 --> Model Class Initialized
INFO - 2024-10-27 13:55:26 --> Model Class Initialized
INFO - 2024-10-27 13:55:26 --> Model Class Initialized
INFO - 2024-10-27 13:55:26 --> Model Class Initialized
INFO - 2024-10-27 13:55:26 --> Model Class Initialized
INFO - 2024-10-27 13:55:26 --> Model Class Initialized
DEBUG - 2024-10-27 13:55:26 --> plural called with: company
DEBUG - 2024-10-27 13:55:26 --> is_countable called with!!!!: company
INFO - 2024-10-27 13:55:26 --> Model Class Initialized
INFO - 2024-10-27 13:55:26 --> Model Class Initialized
INFO - 2024-10-27 13:55:26 --> Model Class Initialized
INFO - 2024-10-27 13:55:30 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 13:55:30 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 13:55:30 --> Final output sent to browser
DEBUG - 2024-10-27 13:55:30 --> Total execution time: 3.2936
INFO - 2024-10-27 13:57:23 --> Config Class Initialized
INFO - 2024-10-27 13:57:23 --> Hooks Class Initialized
DEBUG - 2024-10-27 13:57:23 --> UTF-8 Support Enabled
INFO - 2024-10-27 13:57:23 --> Utf8 Class Initialized
INFO - 2024-10-27 13:57:23 --> URI Class Initialized
INFO - 2024-10-27 13:57:23 --> Router Class Initialized
INFO - 2024-10-27 13:57:23 --> Output Class Initialized
INFO - 2024-10-27 13:57:23 --> Security Class Initialized
DEBUG - 2024-10-27 13:57:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 13:57:23 --> Input Class Initialized
INFO - 2024-10-27 13:57:23 --> Language Class Initialized
ERROR - 2024-10-27 13:57:23 --> TEST ERROR MESSAGE - 2024-10-27 13:57:23
INFO - 2024-10-27 13:57:23 --> Loader Class Initialized
INFO - 2024-10-27 13:57:23 --> Controller Class Initialized
INFO - 2024-10-27 13:57:23 --> Database Driver Class Initialized
INFO - 2024-10-27 13:57:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 13:57:23 --> Helper loaded: form_helper
INFO - 2024-10-27 13:57:23 --> Helper loaded: url_helper
INFO - 2024-10-27 13:57:23 --> Model Class Initialized
INFO - 2024-10-27 13:57:23 --> Helper loaded: inflector_helper
INFO - 2024-10-27 13:57:23 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 13:57:23 --> Helper loaded: email_helper
INFO - 2024-10-27 13:57:23 --> Model Class Initialized
INFO - 2024-10-27 13:57:23 --> Model Class Initialized
INFO - 2024-10-27 13:57:23 --> Model Class Initialized
INFO - 2024-10-27 13:57:23 --> Model Class Initialized
INFO - 2024-10-27 13:57:23 --> Model Class Initialized
INFO - 2024-10-27 13:57:23 --> Model Class Initialized
INFO - 2024-10-27 13:57:23 --> Model Class Initialized
DEBUG - 2024-10-27 13:57:23 --> plural called with: company
DEBUG - 2024-10-27 13:57:23 --> is_countable called with!!!!: company
INFO - 2024-10-27 13:57:23 --> Model Class Initialized
INFO - 2024-10-27 13:57:23 --> Model Class Initialized
INFO - 2024-10-27 13:57:23 --> Model Class Initialized
ERROR - 2024-10-27 13:57:23 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 298
INFO - 2024-10-27 13:57:23 --> Final output sent to browser
DEBUG - 2024-10-27 13:57:23 --> Total execution time: 0.0857
INFO - 2024-10-27 14:01:29 --> Config Class Initialized
INFO - 2024-10-27 14:01:29 --> Hooks Class Initialized
DEBUG - 2024-10-27 14:01:29 --> UTF-8 Support Enabled
INFO - 2024-10-27 14:01:29 --> Utf8 Class Initialized
INFO - 2024-10-27 14:01:29 --> URI Class Initialized
INFO - 2024-10-27 14:01:29 --> Router Class Initialized
INFO - 2024-10-27 14:01:29 --> Output Class Initialized
INFO - 2024-10-27 14:01:29 --> Security Class Initialized
DEBUG - 2024-10-27 14:01:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 14:01:29 --> Input Class Initialized
INFO - 2024-10-27 14:01:29 --> Language Class Initialized
ERROR - 2024-10-27 14:01:29 --> TEST ERROR MESSAGE - 2024-10-27 14:01:29
INFO - 2024-10-27 14:01:29 --> Loader Class Initialized
INFO - 2024-10-27 14:01:29 --> Controller Class Initialized
INFO - 2024-10-27 14:01:29 --> Database Driver Class Initialized
INFO - 2024-10-27 14:01:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 14:01:29 --> Helper loaded: form_helper
INFO - 2024-10-27 14:01:29 --> Helper loaded: url_helper
INFO - 2024-10-27 14:01:29 --> Model Class Initialized
INFO - 2024-10-27 14:01:29 --> Helper loaded: inflector_helper
INFO - 2024-10-27 14:01:29 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 14:01:29 --> Helper loaded: email_helper
INFO - 2024-10-27 14:01:29 --> Model Class Initialized
INFO - 2024-10-27 14:01:29 --> Model Class Initialized
INFO - 2024-10-27 14:01:29 --> Model Class Initialized
INFO - 2024-10-27 14:01:29 --> Model Class Initialized
INFO - 2024-10-27 14:01:29 --> Model Class Initialized
INFO - 2024-10-27 14:01:29 --> Model Class Initialized
INFO - 2024-10-27 14:01:29 --> Model Class Initialized
DEBUG - 2024-10-27 14:01:29 --> plural called with: company
DEBUG - 2024-10-27 14:01:29 --> is_countable called with!!!!: company
INFO - 2024-10-27 14:01:29 --> Model Class Initialized
INFO - 2024-10-27 14:01:29 --> Model Class Initialized
INFO - 2024-10-27 14:01:29 --> Model Class Initialized
INFO - 2024-10-27 14:01:33 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 14:01:33 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 14:01:33 --> Final output sent to browser
DEBUG - 2024-10-27 14:01:33 --> Total execution time: 3.7910
INFO - 2024-10-27 14:01:47 --> Config Class Initialized
INFO - 2024-10-27 14:01:47 --> Hooks Class Initialized
DEBUG - 2024-10-27 14:01:47 --> UTF-8 Support Enabled
INFO - 2024-10-27 14:01:47 --> Utf8 Class Initialized
INFO - 2024-10-27 14:01:47 --> URI Class Initialized
INFO - 2024-10-27 14:01:47 --> Router Class Initialized
INFO - 2024-10-27 14:01:47 --> Output Class Initialized
INFO - 2024-10-27 14:01:47 --> Security Class Initialized
DEBUG - 2024-10-27 14:01:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 14:01:47 --> Input Class Initialized
INFO - 2024-10-27 14:01:47 --> Language Class Initialized
ERROR - 2024-10-27 14:01:47 --> TEST ERROR MESSAGE - 2024-10-27 14:01:47
INFO - 2024-10-27 14:01:47 --> Loader Class Initialized
INFO - 2024-10-27 14:01:47 --> Controller Class Initialized
INFO - 2024-10-27 14:01:47 --> Database Driver Class Initialized
INFO - 2024-10-27 14:01:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 14:01:47 --> Helper loaded: form_helper
INFO - 2024-10-27 14:01:47 --> Helper loaded: url_helper
INFO - 2024-10-27 14:01:47 --> Model Class Initialized
INFO - 2024-10-27 14:01:47 --> Helper loaded: inflector_helper
INFO - 2024-10-27 14:01:47 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 14:01:47 --> Helper loaded: email_helper
INFO - 2024-10-27 14:01:47 --> Model Class Initialized
INFO - 2024-10-27 14:01:47 --> Model Class Initialized
INFO - 2024-10-27 14:01:47 --> Model Class Initialized
INFO - 2024-10-27 14:01:47 --> Model Class Initialized
INFO - 2024-10-27 14:01:47 --> Model Class Initialized
INFO - 2024-10-27 14:01:47 --> Model Class Initialized
INFO - 2024-10-27 14:01:47 --> Model Class Initialized
DEBUG - 2024-10-27 14:01:47 --> plural called with: company
DEBUG - 2024-10-27 14:01:47 --> is_countable called with!!!!: company
INFO - 2024-10-27 14:01:47 --> Model Class Initialized
INFO - 2024-10-27 14:01:47 --> Model Class Initialized
INFO - 2024-10-27 14:01:47 --> Model Class Initialized
INFO - 2024-10-27 14:01:47 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 14:01:47 --> Final output sent to browser
DEBUG - 2024-10-27 14:01:47 --> Total execution time: 0.0288
INFO - 2024-10-27 14:01:54 --> Config Class Initialized
INFO - 2024-10-27 14:01:54 --> Hooks Class Initialized
DEBUG - 2024-10-27 14:01:54 --> UTF-8 Support Enabled
INFO - 2024-10-27 14:01:54 --> Utf8 Class Initialized
INFO - 2024-10-27 14:01:54 --> URI Class Initialized
INFO - 2024-10-27 14:01:54 --> Router Class Initialized
INFO - 2024-10-27 14:01:54 --> Output Class Initialized
INFO - 2024-10-27 14:01:54 --> Security Class Initialized
DEBUG - 2024-10-27 14:01:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 14:01:54 --> Input Class Initialized
INFO - 2024-10-27 14:01:54 --> Language Class Initialized
ERROR - 2024-10-27 14:01:54 --> TEST ERROR MESSAGE - 2024-10-27 14:01:54
INFO - 2024-10-27 14:01:54 --> Loader Class Initialized
INFO - 2024-10-27 14:01:54 --> Controller Class Initialized
INFO - 2024-10-27 14:01:54 --> Database Driver Class Initialized
INFO - 2024-10-27 14:01:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 14:01:54 --> Helper loaded: form_helper
INFO - 2024-10-27 14:01:54 --> Helper loaded: url_helper
INFO - 2024-10-27 14:01:54 --> Model Class Initialized
INFO - 2024-10-27 14:01:54 --> Helper loaded: inflector_helper
INFO - 2024-10-27 14:01:54 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 14:01:54 --> Helper loaded: email_helper
INFO - 2024-10-27 14:01:54 --> Model Class Initialized
INFO - 2024-10-27 14:01:54 --> Model Class Initialized
INFO - 2024-10-27 14:01:54 --> Model Class Initialized
INFO - 2024-10-27 14:01:54 --> Model Class Initialized
INFO - 2024-10-27 14:01:54 --> Model Class Initialized
INFO - 2024-10-27 14:01:54 --> Model Class Initialized
INFO - 2024-10-27 14:01:54 --> Model Class Initialized
DEBUG - 2024-10-27 14:01:54 --> plural called with: company
DEBUG - 2024-10-27 14:01:54 --> is_countable called with!!!!: company
INFO - 2024-10-27 14:01:54 --> Model Class Initialized
INFO - 2024-10-27 14:01:54 --> Model Class Initialized
INFO - 2024-10-27 14:01:54 --> Model Class Initialized
INFO - 2024-10-27 14:01:54 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 14:01:54 --> Final output sent to browser
DEBUG - 2024-10-27 14:01:54 --> Total execution time: 0.0321
INFO - 2024-10-27 14:02:10 --> Config Class Initialized
INFO - 2024-10-27 14:02:10 --> Hooks Class Initialized
DEBUG - 2024-10-27 14:02:10 --> UTF-8 Support Enabled
INFO - 2024-10-27 14:02:10 --> Utf8 Class Initialized
INFO - 2024-10-27 14:02:10 --> URI Class Initialized
INFO - 2024-10-27 14:02:10 --> Router Class Initialized
INFO - 2024-10-27 14:02:10 --> Output Class Initialized
INFO - 2024-10-27 14:02:10 --> Security Class Initialized
DEBUG - 2024-10-27 14:02:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 14:02:10 --> Input Class Initialized
INFO - 2024-10-27 14:02:10 --> Language Class Initialized
ERROR - 2024-10-27 14:02:10 --> TEST ERROR MESSAGE - 2024-10-27 14:02:10
INFO - 2024-10-27 14:02:10 --> Loader Class Initialized
INFO - 2024-10-27 14:02:10 --> Controller Class Initialized
INFO - 2024-10-27 14:02:10 --> Database Driver Class Initialized
INFO - 2024-10-27 14:02:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 14:02:10 --> Helper loaded: form_helper
INFO - 2024-10-27 14:02:10 --> Helper loaded: url_helper
INFO - 2024-10-27 14:02:10 --> Model Class Initialized
INFO - 2024-10-27 14:02:10 --> Helper loaded: inflector_helper
INFO - 2024-10-27 14:02:10 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 14:02:10 --> Helper loaded: email_helper
INFO - 2024-10-27 14:02:10 --> Model Class Initialized
INFO - 2024-10-27 14:02:10 --> Model Class Initialized
INFO - 2024-10-27 14:02:10 --> Model Class Initialized
INFO - 2024-10-27 14:02:10 --> Model Class Initialized
INFO - 2024-10-27 14:02:10 --> Model Class Initialized
INFO - 2024-10-27 14:02:10 --> Model Class Initialized
INFO - 2024-10-27 14:02:10 --> Model Class Initialized
DEBUG - 2024-10-27 14:02:10 --> plural called with: company
DEBUG - 2024-10-27 14:02:10 --> is_countable called with!!!!: company
INFO - 2024-10-27 14:02:10 --> Model Class Initialized
INFO - 2024-10-27 14:02:10 --> Model Class Initialized
INFO - 2024-10-27 14:02:10 --> Model Class Initialized
INFO - 2024-10-27 14:02:10 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 14:02:10 --> Final output sent to browser
DEBUG - 2024-10-27 14:02:10 --> Total execution time: 0.0212
INFO - 2024-10-27 14:03:09 --> Config Class Initialized
INFO - 2024-10-27 14:03:09 --> Hooks Class Initialized
DEBUG - 2024-10-27 14:03:09 --> UTF-8 Support Enabled
INFO - 2024-10-27 14:03:09 --> Utf8 Class Initialized
INFO - 2024-10-27 14:03:09 --> URI Class Initialized
INFO - 2024-10-27 14:03:09 --> Router Class Initialized
INFO - 2024-10-27 14:03:09 --> Output Class Initialized
INFO - 2024-10-27 14:03:09 --> Security Class Initialized
DEBUG - 2024-10-27 14:03:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 14:03:09 --> Input Class Initialized
INFO - 2024-10-27 14:03:09 --> Language Class Initialized
ERROR - 2024-10-27 14:03:09 --> TEST ERROR MESSAGE - 2024-10-27 14:03:09
INFO - 2024-10-27 14:03:09 --> Loader Class Initialized
INFO - 2024-10-27 14:03:09 --> Controller Class Initialized
INFO - 2024-10-27 14:03:09 --> Database Driver Class Initialized
INFO - 2024-10-27 14:03:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 14:03:09 --> Helper loaded: form_helper
INFO - 2024-10-27 14:03:09 --> Helper loaded: url_helper
INFO - 2024-10-27 14:03:09 --> Model Class Initialized
INFO - 2024-10-27 14:03:09 --> Helper loaded: inflector_helper
INFO - 2024-10-27 14:03:09 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 14:03:09 --> Helper loaded: email_helper
INFO - 2024-10-27 14:03:09 --> Model Class Initialized
INFO - 2024-10-27 14:03:09 --> Model Class Initialized
INFO - 2024-10-27 14:03:09 --> Model Class Initialized
INFO - 2024-10-27 14:03:09 --> Model Class Initialized
INFO - 2024-10-27 14:03:09 --> Model Class Initialized
INFO - 2024-10-27 14:03:09 --> Model Class Initialized
INFO - 2024-10-27 14:03:09 --> Model Class Initialized
DEBUG - 2024-10-27 14:03:09 --> plural called with: company
DEBUG - 2024-10-27 14:03:09 --> is_countable called with!!!!: company
INFO - 2024-10-27 14:03:09 --> Model Class Initialized
INFO - 2024-10-27 14:03:09 --> Model Class Initialized
INFO - 2024-10-27 14:03:09 --> Model Class Initialized
INFO - 2024-10-27 14:03:09 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 14:03:09 --> Final output sent to browser
DEBUG - 2024-10-27 14:03:09 --> Total execution time: 0.0237
INFO - 2024-10-27 14:03:25 --> Config Class Initialized
INFO - 2024-10-27 14:03:25 --> Hooks Class Initialized
DEBUG - 2024-10-27 14:03:25 --> UTF-8 Support Enabled
INFO - 2024-10-27 14:03:25 --> Utf8 Class Initialized
INFO - 2024-10-27 14:03:25 --> URI Class Initialized
INFO - 2024-10-27 14:03:25 --> Router Class Initialized
INFO - 2024-10-27 14:03:25 --> Output Class Initialized
INFO - 2024-10-27 14:03:25 --> Security Class Initialized
DEBUG - 2024-10-27 14:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 14:03:25 --> Input Class Initialized
INFO - 2024-10-27 14:03:25 --> Language Class Initialized
ERROR - 2024-10-27 14:03:25 --> TEST ERROR MESSAGE - 2024-10-27 14:03:25
INFO - 2024-10-27 14:03:25 --> Loader Class Initialized
INFO - 2024-10-27 14:03:25 --> Controller Class Initialized
INFO - 2024-10-27 14:03:25 --> Database Driver Class Initialized
INFO - 2024-10-27 14:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 14:03:25 --> Helper loaded: form_helper
INFO - 2024-10-27 14:03:25 --> Helper loaded: url_helper
INFO - 2024-10-27 14:03:25 --> Model Class Initialized
INFO - 2024-10-27 14:03:25 --> Helper loaded: inflector_helper
INFO - 2024-10-27 14:03:25 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 14:03:25 --> Helper loaded: email_helper
INFO - 2024-10-27 14:03:25 --> Model Class Initialized
INFO - 2024-10-27 14:03:25 --> Model Class Initialized
INFO - 2024-10-27 14:03:25 --> Model Class Initialized
INFO - 2024-10-27 14:03:25 --> Model Class Initialized
INFO - 2024-10-27 14:03:25 --> Model Class Initialized
INFO - 2024-10-27 14:03:25 --> Model Class Initialized
INFO - 2024-10-27 14:03:25 --> Model Class Initialized
DEBUG - 2024-10-27 14:03:25 --> plural called with: company
DEBUG - 2024-10-27 14:03:25 --> is_countable called with!!!!: company
INFO - 2024-10-27 14:03:25 --> Model Class Initialized
INFO - 2024-10-27 14:03:25 --> Model Class Initialized
INFO - 2024-10-27 14:03:25 --> Model Class Initialized
INFO - 2024-10-27 14:03:25 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 14:03:25 --> Final output sent to browser
DEBUG - 2024-10-27 14:03:25 --> Total execution time: 0.0251
INFO - 2024-10-27 14:03:42 --> Config Class Initialized
INFO - 2024-10-27 14:03:42 --> Hooks Class Initialized
DEBUG - 2024-10-27 14:03:42 --> UTF-8 Support Enabled
INFO - 2024-10-27 14:03:42 --> Utf8 Class Initialized
INFO - 2024-10-27 14:03:42 --> URI Class Initialized
INFO - 2024-10-27 14:03:42 --> Router Class Initialized
INFO - 2024-10-27 14:03:42 --> Output Class Initialized
INFO - 2024-10-27 14:03:42 --> Security Class Initialized
DEBUG - 2024-10-27 14:03:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 14:03:42 --> Input Class Initialized
INFO - 2024-10-27 14:03:42 --> Language Class Initialized
ERROR - 2024-10-27 14:03:42 --> TEST ERROR MESSAGE - 2024-10-27 14:03:42
INFO - 2024-10-27 14:03:42 --> Loader Class Initialized
INFO - 2024-10-27 14:03:42 --> Controller Class Initialized
INFO - 2024-10-27 14:03:42 --> Database Driver Class Initialized
INFO - 2024-10-27 14:03:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 14:03:42 --> Helper loaded: form_helper
INFO - 2024-10-27 14:03:42 --> Helper loaded: url_helper
INFO - 2024-10-27 14:03:42 --> Model Class Initialized
INFO - 2024-10-27 14:03:42 --> Helper loaded: inflector_helper
INFO - 2024-10-27 14:03:42 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 14:03:42 --> Helper loaded: email_helper
INFO - 2024-10-27 14:03:42 --> Model Class Initialized
INFO - 2024-10-27 14:03:42 --> Model Class Initialized
INFO - 2024-10-27 14:03:42 --> Model Class Initialized
INFO - 2024-10-27 14:03:42 --> Model Class Initialized
INFO - 2024-10-27 14:03:42 --> Model Class Initialized
INFO - 2024-10-27 14:03:42 --> Model Class Initialized
INFO - 2024-10-27 14:03:42 --> Model Class Initialized
DEBUG - 2024-10-27 14:03:42 --> plural called with: company
DEBUG - 2024-10-27 14:03:42 --> is_countable called with!!!!: company
INFO - 2024-10-27 14:03:42 --> Model Class Initialized
INFO - 2024-10-27 14:03:42 --> Model Class Initialized
INFO - 2024-10-27 14:03:42 --> Model Class Initialized
INFO - 2024-10-27 14:03:42 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 14:03:42 --> Final output sent to browser
DEBUG - 2024-10-27 14:03:42 --> Total execution time: 0.0266
INFO - 2024-10-27 14:03:52 --> Config Class Initialized
INFO - 2024-10-27 14:03:52 --> Hooks Class Initialized
DEBUG - 2024-10-27 14:03:52 --> UTF-8 Support Enabled
INFO - 2024-10-27 14:03:52 --> Utf8 Class Initialized
INFO - 2024-10-27 14:03:52 --> URI Class Initialized
INFO - 2024-10-27 14:03:52 --> Router Class Initialized
INFO - 2024-10-27 14:03:52 --> Output Class Initialized
INFO - 2024-10-27 14:03:52 --> Security Class Initialized
DEBUG - 2024-10-27 14:03:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 14:03:52 --> Input Class Initialized
INFO - 2024-10-27 14:03:52 --> Language Class Initialized
ERROR - 2024-10-27 14:03:52 --> TEST ERROR MESSAGE - 2024-10-27 14:03:52
INFO - 2024-10-27 14:03:52 --> Loader Class Initialized
INFO - 2024-10-27 14:03:52 --> Controller Class Initialized
INFO - 2024-10-27 14:03:52 --> Database Driver Class Initialized
INFO - 2024-10-27 14:03:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 14:03:52 --> Helper loaded: form_helper
INFO - 2024-10-27 14:03:52 --> Helper loaded: url_helper
INFO - 2024-10-27 14:03:52 --> Model Class Initialized
INFO - 2024-10-27 14:03:52 --> Helper loaded: inflector_helper
INFO - 2024-10-27 14:03:52 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 14:03:52 --> Helper loaded: email_helper
INFO - 2024-10-27 14:03:52 --> Model Class Initialized
INFO - 2024-10-27 14:03:52 --> Model Class Initialized
INFO - 2024-10-27 14:03:52 --> Model Class Initialized
INFO - 2024-10-27 14:03:52 --> Model Class Initialized
INFO - 2024-10-27 14:03:52 --> Model Class Initialized
INFO - 2024-10-27 14:03:52 --> Model Class Initialized
INFO - 2024-10-27 14:03:52 --> Model Class Initialized
DEBUG - 2024-10-27 14:03:52 --> plural called with: company
DEBUG - 2024-10-27 14:03:52 --> is_countable called with!!!!: company
INFO - 2024-10-27 14:03:52 --> Model Class Initialized
INFO - 2024-10-27 14:03:52 --> Model Class Initialized
INFO - 2024-10-27 14:03:52 --> Model Class Initialized
INFO - 2024-10-27 14:03:52 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 14:03:52 --> Final output sent to browser
DEBUG - 2024-10-27 14:03:52 --> Total execution time: 0.0279
INFO - 2024-10-27 14:19:57 --> Config Class Initialized
INFO - 2024-10-27 14:19:57 --> Hooks Class Initialized
DEBUG - 2024-10-27 14:19:57 --> UTF-8 Support Enabled
INFO - 2024-10-27 14:19:57 --> Utf8 Class Initialized
INFO - 2024-10-27 14:19:57 --> URI Class Initialized
INFO - 2024-10-27 14:19:57 --> Router Class Initialized
INFO - 2024-10-27 14:19:57 --> Output Class Initialized
INFO - 2024-10-27 14:19:57 --> Security Class Initialized
DEBUG - 2024-10-27 14:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 14:19:57 --> Input Class Initialized
INFO - 2024-10-27 14:19:57 --> Language Class Initialized
ERROR - 2024-10-27 14:19:57 --> TEST ERROR MESSAGE - 2024-10-27 14:19:57
INFO - 2024-10-27 14:19:57 --> Loader Class Initialized
INFO - 2024-10-27 14:19:57 --> Controller Class Initialized
INFO - 2024-10-27 14:19:57 --> Database Driver Class Initialized
INFO - 2024-10-27 14:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 14:19:57 --> Helper loaded: form_helper
INFO - 2024-10-27 14:19:57 --> Helper loaded: url_helper
INFO - 2024-10-27 14:19:57 --> Model Class Initialized
INFO - 2024-10-27 14:19:57 --> Helper loaded: inflector_helper
INFO - 2024-10-27 14:19:57 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 14:19:57 --> Helper loaded: email_helper
INFO - 2024-10-27 14:19:57 --> Model Class Initialized
INFO - 2024-10-27 14:19:57 --> Model Class Initialized
INFO - 2024-10-27 14:19:57 --> Model Class Initialized
INFO - 2024-10-27 14:19:57 --> Model Class Initialized
INFO - 2024-10-27 14:19:57 --> Model Class Initialized
INFO - 2024-10-27 14:19:57 --> Model Class Initialized
INFO - 2024-10-27 14:19:57 --> Model Class Initialized
DEBUG - 2024-10-27 14:19:57 --> plural called with: company
DEBUG - 2024-10-27 14:19:57 --> is_countable called with!!!!: company
INFO - 2024-10-27 14:19:57 --> Model Class Initialized
INFO - 2024-10-27 14:19:57 --> Model Class Initialized
INFO - 2024-10-27 14:19:57 --> Model Class Initialized
INFO - 2024-10-27 14:19:57 --> Config Class Initialized
INFO - 2024-10-27 14:19:57 --> Hooks Class Initialized
DEBUG - 2024-10-27 14:19:57 --> UTF-8 Support Enabled
INFO - 2024-10-27 14:19:57 --> Utf8 Class Initialized
INFO - 2024-10-27 14:19:57 --> URI Class Initialized
INFO - 2024-10-27 14:19:57 --> Router Class Initialized
INFO - 2024-10-27 14:19:57 --> Output Class Initialized
INFO - 2024-10-27 14:19:57 --> Security Class Initialized
DEBUG - 2024-10-27 14:19:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 14:19:57 --> Input Class Initialized
INFO - 2024-10-27 14:19:57 --> Language Class Initialized
ERROR - 2024-10-27 14:19:57 --> TEST ERROR MESSAGE - 2024-10-27 14:19:57
INFO - 2024-10-27 14:19:57 --> Loader Class Initialized
INFO - 2024-10-27 14:19:57 --> Controller Class Initialized
INFO - 2024-10-27 14:19:57 --> Database Driver Class Initialized
INFO - 2024-10-27 14:19:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 14:19:57 --> Helper loaded: form_helper
INFO - 2024-10-27 14:19:57 --> Helper loaded: url_helper
INFO - 2024-10-27 14:19:57 --> Model Class Initialized
INFO - 2024-10-27 14:19:57 --> Helper loaded: inflector_helper
INFO - 2024-10-27 14:19:57 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 14:19:57 --> Helper loaded: email_helper
INFO - 2024-10-27 14:19:57 --> Model Class Initialized
INFO - 2024-10-27 14:19:57 --> Model Class Initialized
INFO - 2024-10-27 14:19:57 --> Model Class Initialized
INFO - 2024-10-27 14:19:57 --> Model Class Initialized
INFO - 2024-10-27 14:19:57 --> Model Class Initialized
INFO - 2024-10-27 14:19:57 --> Model Class Initialized
INFO - 2024-10-27 14:19:57 --> Model Class Initialized
DEBUG - 2024-10-27 14:19:57 --> plural called with: company
DEBUG - 2024-10-27 14:19:57 --> is_countable called with!!!!: company
INFO - 2024-10-27 14:19:57 --> Model Class Initialized
INFO - 2024-10-27 14:19:57 --> Model Class Initialized
INFO - 2024-10-27 14:19:57 --> Model Class Initialized
INFO - 2024-10-27 14:19:57 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-27 14:19:57 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 14:19:57 --> Final output sent to browser
DEBUG - 2024-10-27 14:19:57 --> Total execution time: 0.0312
INFO - 2024-10-27 14:20:04 --> Config Class Initialized
INFO - 2024-10-27 14:20:04 --> Hooks Class Initialized
DEBUG - 2024-10-27 14:20:04 --> UTF-8 Support Enabled
INFO - 2024-10-27 14:20:04 --> Utf8 Class Initialized
INFO - 2024-10-27 14:20:04 --> URI Class Initialized
INFO - 2024-10-27 14:20:04 --> Router Class Initialized
INFO - 2024-10-27 14:20:04 --> Output Class Initialized
INFO - 2024-10-27 14:20:04 --> Security Class Initialized
DEBUG - 2024-10-27 14:20:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 14:20:04 --> Input Class Initialized
INFO - 2024-10-27 14:20:04 --> Language Class Initialized
ERROR - 2024-10-27 14:20:04 --> TEST ERROR MESSAGE - 2024-10-27 14:20:04
INFO - 2024-10-27 14:20:04 --> Loader Class Initialized
INFO - 2024-10-27 14:20:04 --> Controller Class Initialized
INFO - 2024-10-27 14:20:04 --> Database Driver Class Initialized
INFO - 2024-10-27 14:20:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 14:20:04 --> Helper loaded: form_helper
INFO - 2024-10-27 14:20:04 --> Helper loaded: url_helper
INFO - 2024-10-27 14:20:04 --> Model Class Initialized
INFO - 2024-10-27 14:20:04 --> Helper loaded: inflector_helper
INFO - 2024-10-27 14:20:04 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 14:20:04 --> Helper loaded: email_helper
INFO - 2024-10-27 14:20:04 --> Model Class Initialized
INFO - 2024-10-27 14:20:04 --> Model Class Initialized
INFO - 2024-10-27 14:20:04 --> Model Class Initialized
INFO - 2024-10-27 14:20:04 --> Model Class Initialized
INFO - 2024-10-27 14:20:04 --> Model Class Initialized
INFO - 2024-10-27 14:20:04 --> Model Class Initialized
INFO - 2024-10-27 14:20:04 --> Model Class Initialized
DEBUG - 2024-10-27 14:20:04 --> plural called with: company
DEBUG - 2024-10-27 14:20:04 --> is_countable called with!!!!: company
INFO - 2024-10-27 14:20:04 --> Model Class Initialized
INFO - 2024-10-27 14:20:04 --> Model Class Initialized
INFO - 2024-10-27 14:20:04 --> Model Class Initialized
INFO - 2024-10-27 14:20:04 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-27 14:20:04 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 14:20:04 --> Final output sent to browser
DEBUG - 2024-10-27 14:20:04 --> Total execution time: 0.0238
INFO - 2024-10-27 14:20:10 --> Config Class Initialized
INFO - 2024-10-27 14:20:10 --> Hooks Class Initialized
DEBUG - 2024-10-27 14:20:10 --> UTF-8 Support Enabled
INFO - 2024-10-27 14:20:10 --> Utf8 Class Initialized
INFO - 2024-10-27 14:20:10 --> URI Class Initialized
INFO - 2024-10-27 14:20:10 --> Router Class Initialized
INFO - 2024-10-27 14:20:10 --> Output Class Initialized
INFO - 2024-10-27 14:20:10 --> Security Class Initialized
DEBUG - 2024-10-27 14:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 14:20:10 --> Input Class Initialized
INFO - 2024-10-27 14:20:10 --> Language Class Initialized
ERROR - 2024-10-27 14:20:10 --> TEST ERROR MESSAGE - 2024-10-27 14:20:10
INFO - 2024-10-27 14:20:10 --> Loader Class Initialized
INFO - 2024-10-27 14:20:10 --> Controller Class Initialized
INFO - 2024-10-27 14:20:10 --> Database Driver Class Initialized
INFO - 2024-10-27 14:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 14:20:10 --> Helper loaded: form_helper
INFO - 2024-10-27 14:20:10 --> Helper loaded: url_helper
INFO - 2024-10-27 14:20:10 --> Model Class Initialized
INFO - 2024-10-27 14:20:10 --> Helper loaded: inflector_helper
INFO - 2024-10-27 14:20:10 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 14:20:10 --> Helper loaded: email_helper
INFO - 2024-10-27 14:20:10 --> Model Class Initialized
INFO - 2024-10-27 14:20:10 --> Model Class Initialized
INFO - 2024-10-27 14:20:10 --> Model Class Initialized
INFO - 2024-10-27 14:20:10 --> Model Class Initialized
INFO - 2024-10-27 14:20:10 --> Model Class Initialized
INFO - 2024-10-27 14:20:10 --> Model Class Initialized
INFO - 2024-10-27 14:20:10 --> Model Class Initialized
DEBUG - 2024-10-27 14:20:10 --> plural called with: company
DEBUG - 2024-10-27 14:20:10 --> is_countable called with!!!!: company
INFO - 2024-10-27 14:20:10 --> Model Class Initialized
INFO - 2024-10-27 14:20:10 --> Model Class Initialized
INFO - 2024-10-27 14:20:10 --> Model Class Initialized
INFO - 2024-10-27 14:20:10 --> Config Class Initialized
INFO - 2024-10-27 14:20:10 --> Hooks Class Initialized
DEBUG - 2024-10-27 14:20:10 --> UTF-8 Support Enabled
INFO - 2024-10-27 14:20:10 --> Utf8 Class Initialized
INFO - 2024-10-27 14:20:10 --> URI Class Initialized
INFO - 2024-10-27 14:20:10 --> Router Class Initialized
INFO - 2024-10-27 14:20:10 --> Output Class Initialized
INFO - 2024-10-27 14:20:10 --> Security Class Initialized
DEBUG - 2024-10-27 14:20:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 14:20:10 --> Input Class Initialized
INFO - 2024-10-27 14:20:10 --> Language Class Initialized
ERROR - 2024-10-27 14:20:10 --> TEST ERROR MESSAGE - 2024-10-27 14:20:10
INFO - 2024-10-27 14:20:10 --> Loader Class Initialized
INFO - 2024-10-27 14:20:10 --> Controller Class Initialized
INFO - 2024-10-27 14:20:10 --> Database Driver Class Initialized
INFO - 2024-10-27 14:20:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 14:20:10 --> Helper loaded: form_helper
INFO - 2024-10-27 14:20:10 --> Helper loaded: url_helper
INFO - 2024-10-27 14:20:10 --> Model Class Initialized
INFO - 2024-10-27 14:20:10 --> Helper loaded: inflector_helper
INFO - 2024-10-27 14:20:10 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 14:20:10 --> Helper loaded: email_helper
INFO - 2024-10-27 14:20:10 --> Model Class Initialized
INFO - 2024-10-27 14:20:10 --> Model Class Initialized
INFO - 2024-10-27 14:20:10 --> Model Class Initialized
INFO - 2024-10-27 14:20:10 --> Model Class Initialized
INFO - 2024-10-27 14:20:10 --> Model Class Initialized
INFO - 2024-10-27 14:20:10 --> Model Class Initialized
INFO - 2024-10-27 14:20:10 --> Model Class Initialized
DEBUG - 2024-10-27 14:20:10 --> plural called with: company
DEBUG - 2024-10-27 14:20:10 --> is_countable called with!!!!: company
INFO - 2024-10-27 14:20:10 --> Model Class Initialized
INFO - 2024-10-27 14:20:10 --> Model Class Initialized
INFO - 2024-10-27 14:20:10 --> Model Class Initialized
ERROR - 2024-10-27 14:20:13 --> Severity: Notice --> Undefined index: freetext /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-27 14:20:13 --> Severity: Notice --> Undefined index: socialDes /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-27 14:20:13 --> Severity: Notice --> Undefined index: company /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-27 14:20:13 --> Severity: Notice --> Undefined index: division /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-27 14:20:13 --> Severity: Notice --> Undefined index: dataGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-27 14:20:13 --> Severity: Notice --> Undefined index: finalGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
INFO - 2024-10-27 14:20:13 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 14:20:13 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 14:20:13 --> Final output sent to browser
DEBUG - 2024-10-27 14:20:13 --> Total execution time: 2.6014
INFO - 2024-10-27 14:20:24 --> Config Class Initialized
INFO - 2024-10-27 14:20:24 --> Hooks Class Initialized
DEBUG - 2024-10-27 14:20:24 --> UTF-8 Support Enabled
INFO - 2024-10-27 14:20:24 --> Utf8 Class Initialized
INFO - 2024-10-27 14:20:24 --> URI Class Initialized
INFO - 2024-10-27 14:20:24 --> Router Class Initialized
INFO - 2024-10-27 14:20:24 --> Output Class Initialized
INFO - 2024-10-27 14:20:24 --> Security Class Initialized
DEBUG - 2024-10-27 14:20:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 14:20:24 --> Input Class Initialized
INFO - 2024-10-27 14:20:24 --> Language Class Initialized
ERROR - 2024-10-27 14:20:24 --> TEST ERROR MESSAGE - 2024-10-27 14:20:24
INFO - 2024-10-27 14:20:24 --> Loader Class Initialized
INFO - 2024-10-27 14:20:24 --> Controller Class Initialized
INFO - 2024-10-27 14:20:24 --> Database Driver Class Initialized
INFO - 2024-10-27 14:20:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 14:20:24 --> Helper loaded: form_helper
INFO - 2024-10-27 14:20:24 --> Helper loaded: url_helper
INFO - 2024-10-27 14:20:24 --> Model Class Initialized
INFO - 2024-10-27 14:20:24 --> Helper loaded: inflector_helper
INFO - 2024-10-27 14:20:24 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 14:20:24 --> Helper loaded: email_helper
INFO - 2024-10-27 14:20:24 --> Model Class Initialized
INFO - 2024-10-27 14:20:24 --> Model Class Initialized
INFO - 2024-10-27 14:20:24 --> Model Class Initialized
INFO - 2024-10-27 14:20:24 --> Model Class Initialized
INFO - 2024-10-27 14:20:24 --> Model Class Initialized
INFO - 2024-10-27 14:20:24 --> Model Class Initialized
INFO - 2024-10-27 14:20:24 --> Model Class Initialized
DEBUG - 2024-10-27 14:20:24 --> plural called with: company
DEBUG - 2024-10-27 14:20:24 --> is_countable called with!!!!: company
INFO - 2024-10-27 14:20:24 --> Model Class Initialized
INFO - 2024-10-27 14:20:24 --> Model Class Initialized
INFO - 2024-10-27 14:20:24 --> Model Class Initialized
INFO - 2024-10-27 14:21:01 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 14:21:01 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 14:21:01 --> Final output sent to browser
DEBUG - 2024-10-27 14:21:01 --> Total execution time: 36.7426
INFO - 2024-10-27 14:21:11 --> Config Class Initialized
INFO - 2024-10-27 14:21:11 --> Hooks Class Initialized
DEBUG - 2024-10-27 14:21:11 --> UTF-8 Support Enabled
INFO - 2024-10-27 14:21:11 --> Utf8 Class Initialized
INFO - 2024-10-27 14:21:11 --> URI Class Initialized
INFO - 2024-10-27 14:21:11 --> Router Class Initialized
INFO - 2024-10-27 14:21:11 --> Output Class Initialized
INFO - 2024-10-27 14:21:11 --> Security Class Initialized
DEBUG - 2024-10-27 14:21:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 14:21:11 --> Input Class Initialized
INFO - 2024-10-27 14:21:11 --> Language Class Initialized
ERROR - 2024-10-27 14:21:11 --> TEST ERROR MESSAGE - 2024-10-27 14:21:11
INFO - 2024-10-27 14:21:11 --> Loader Class Initialized
INFO - 2024-10-27 14:21:11 --> Controller Class Initialized
INFO - 2024-10-27 14:21:11 --> Database Driver Class Initialized
INFO - 2024-10-27 14:21:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 14:21:11 --> Helper loaded: form_helper
INFO - 2024-10-27 14:21:11 --> Helper loaded: url_helper
INFO - 2024-10-27 14:21:11 --> Model Class Initialized
INFO - 2024-10-27 14:21:11 --> Helper loaded: inflector_helper
INFO - 2024-10-27 14:21:11 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 14:21:11 --> Helper loaded: email_helper
INFO - 2024-10-27 14:21:11 --> Model Class Initialized
INFO - 2024-10-27 14:21:11 --> Model Class Initialized
INFO - 2024-10-27 14:21:11 --> Model Class Initialized
INFO - 2024-10-27 14:21:11 --> Model Class Initialized
INFO - 2024-10-27 14:21:11 --> Model Class Initialized
INFO - 2024-10-27 14:21:11 --> Model Class Initialized
INFO - 2024-10-27 14:21:11 --> Model Class Initialized
DEBUG - 2024-10-27 14:21:11 --> plural called with: company
DEBUG - 2024-10-27 14:21:11 --> is_countable called with!!!!: company
INFO - 2024-10-27 14:21:11 --> Model Class Initialized
INFO - 2024-10-27 14:21:11 --> Model Class Initialized
INFO - 2024-10-27 14:21:11 --> Model Class Initialized
INFO - 2024-10-27 14:21:11 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 14:21:11 --> Final output sent to browser
DEBUG - 2024-10-27 14:21:11 --> Total execution time: 0.0318
INFO - 2024-10-27 14:21:55 --> Config Class Initialized
INFO - 2024-10-27 14:21:55 --> Hooks Class Initialized
DEBUG - 2024-10-27 14:21:55 --> UTF-8 Support Enabled
INFO - 2024-10-27 14:21:55 --> Utf8 Class Initialized
INFO - 2024-10-27 14:21:55 --> URI Class Initialized
INFO - 2024-10-27 14:21:55 --> Router Class Initialized
INFO - 2024-10-27 14:21:55 --> Output Class Initialized
INFO - 2024-10-27 14:21:55 --> Security Class Initialized
DEBUG - 2024-10-27 14:21:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 14:21:55 --> Input Class Initialized
INFO - 2024-10-27 14:21:55 --> Language Class Initialized
ERROR - 2024-10-27 14:21:55 --> TEST ERROR MESSAGE - 2024-10-27 14:21:55
INFO - 2024-10-27 14:21:55 --> Loader Class Initialized
INFO - 2024-10-27 14:21:55 --> Controller Class Initialized
INFO - 2024-10-27 14:21:55 --> Database Driver Class Initialized
INFO - 2024-10-27 14:21:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 14:21:55 --> Helper loaded: form_helper
INFO - 2024-10-27 14:21:55 --> Helper loaded: url_helper
INFO - 2024-10-27 14:21:55 --> Model Class Initialized
INFO - 2024-10-27 14:21:55 --> Helper loaded: inflector_helper
INFO - 2024-10-27 14:21:55 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 14:21:55 --> Helper loaded: email_helper
INFO - 2024-10-27 14:21:55 --> Model Class Initialized
INFO - 2024-10-27 14:21:55 --> Model Class Initialized
INFO - 2024-10-27 14:21:55 --> Model Class Initialized
INFO - 2024-10-27 14:21:55 --> Model Class Initialized
INFO - 2024-10-27 14:21:55 --> Model Class Initialized
INFO - 2024-10-27 14:21:55 --> Model Class Initialized
INFO - 2024-10-27 14:21:55 --> Model Class Initialized
DEBUG - 2024-10-27 14:21:55 --> plural called with: company
DEBUG - 2024-10-27 14:21:55 --> is_countable called with!!!!: company
INFO - 2024-10-27 14:21:55 --> Model Class Initialized
INFO - 2024-10-27 14:21:55 --> Model Class Initialized
INFO - 2024-10-27 14:21:55 --> Model Class Initialized
INFO - 2024-10-27 14:21:55 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 14:21:55 --> Final output sent to browser
DEBUG - 2024-10-27 14:21:55 --> Total execution time: 0.0252
INFO - 2024-10-27 14:22:27 --> Config Class Initialized
INFO - 2024-10-27 14:22:27 --> Hooks Class Initialized
DEBUG - 2024-10-27 14:22:27 --> UTF-8 Support Enabled
INFO - 2024-10-27 14:22:27 --> Utf8 Class Initialized
INFO - 2024-10-27 14:22:27 --> URI Class Initialized
INFO - 2024-10-27 14:22:27 --> Router Class Initialized
INFO - 2024-10-27 14:22:27 --> Output Class Initialized
INFO - 2024-10-27 14:22:27 --> Security Class Initialized
DEBUG - 2024-10-27 14:22:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 14:22:27 --> Input Class Initialized
INFO - 2024-10-27 14:22:27 --> Language Class Initialized
ERROR - 2024-10-27 14:22:27 --> TEST ERROR MESSAGE - 2024-10-27 14:22:27
INFO - 2024-10-27 14:22:27 --> Loader Class Initialized
INFO - 2024-10-27 14:22:27 --> Controller Class Initialized
INFO - 2024-10-27 14:22:27 --> Database Driver Class Initialized
INFO - 2024-10-27 14:22:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 14:22:27 --> Helper loaded: form_helper
INFO - 2024-10-27 14:22:27 --> Helper loaded: url_helper
INFO - 2024-10-27 14:22:27 --> Model Class Initialized
INFO - 2024-10-27 14:22:27 --> Helper loaded: inflector_helper
INFO - 2024-10-27 14:22:27 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 14:22:27 --> Helper loaded: email_helper
INFO - 2024-10-27 14:22:27 --> Model Class Initialized
INFO - 2024-10-27 14:22:27 --> Model Class Initialized
INFO - 2024-10-27 14:22:27 --> Model Class Initialized
INFO - 2024-10-27 14:22:27 --> Model Class Initialized
INFO - 2024-10-27 14:22:27 --> Model Class Initialized
INFO - 2024-10-27 14:22:27 --> Model Class Initialized
INFO - 2024-10-27 14:22:27 --> Model Class Initialized
DEBUG - 2024-10-27 14:22:27 --> plural called with: company
DEBUG - 2024-10-27 14:22:27 --> is_countable called with!!!!: company
INFO - 2024-10-27 14:22:27 --> Model Class Initialized
INFO - 2024-10-27 14:22:27 --> Model Class Initialized
INFO - 2024-10-27 14:22:27 --> Model Class Initialized
INFO - 2024-10-27 14:22:27 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 14:22:27 --> Final output sent to browser
DEBUG - 2024-10-27 14:22:27 --> Total execution time: 0.0304
INFO - 2024-10-27 14:25:33 --> Config Class Initialized
INFO - 2024-10-27 14:25:33 --> Hooks Class Initialized
DEBUG - 2024-10-27 14:25:33 --> UTF-8 Support Enabled
INFO - 2024-10-27 14:25:33 --> Utf8 Class Initialized
INFO - 2024-10-27 14:25:33 --> URI Class Initialized
INFO - 2024-10-27 14:25:33 --> Router Class Initialized
INFO - 2024-10-27 14:25:33 --> Output Class Initialized
INFO - 2024-10-27 14:25:33 --> Security Class Initialized
DEBUG - 2024-10-27 14:25:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 14:25:33 --> Input Class Initialized
INFO - 2024-10-27 14:25:33 --> Language Class Initialized
ERROR - 2024-10-27 14:25:33 --> TEST ERROR MESSAGE - 2024-10-27 14:25:33
INFO - 2024-10-27 14:25:33 --> Loader Class Initialized
INFO - 2024-10-27 14:25:33 --> Controller Class Initialized
INFO - 2024-10-27 14:25:33 --> Database Driver Class Initialized
INFO - 2024-10-27 14:25:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 14:25:33 --> Helper loaded: form_helper
INFO - 2024-10-27 14:25:33 --> Helper loaded: url_helper
INFO - 2024-10-27 14:25:33 --> Model Class Initialized
INFO - 2024-10-27 14:25:33 --> Helper loaded: inflector_helper
INFO - 2024-10-27 14:25:33 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 14:25:33 --> Helper loaded: email_helper
INFO - 2024-10-27 14:25:33 --> Model Class Initialized
INFO - 2024-10-27 14:25:33 --> Model Class Initialized
INFO - 2024-10-27 14:25:33 --> Model Class Initialized
INFO - 2024-10-27 14:25:33 --> Model Class Initialized
INFO - 2024-10-27 14:25:33 --> Model Class Initialized
INFO - 2024-10-27 14:25:33 --> Model Class Initialized
INFO - 2024-10-27 14:25:33 --> Model Class Initialized
DEBUG - 2024-10-27 14:25:33 --> plural called with: company
DEBUG - 2024-10-27 14:25:33 --> is_countable called with!!!!: company
INFO - 2024-10-27 14:25:33 --> Model Class Initialized
INFO - 2024-10-27 14:25:33 --> Model Class Initialized
INFO - 2024-10-27 14:25:33 --> Model Class Initialized
INFO - 2024-10-27 14:25:33 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 14:25:33 --> Final output sent to browser
DEBUG - 2024-10-27 14:25:33 --> Total execution time: 0.0433
INFO - 2024-10-27 14:26:06 --> Config Class Initialized
INFO - 2024-10-27 14:26:06 --> Hooks Class Initialized
DEBUG - 2024-10-27 14:26:06 --> UTF-8 Support Enabled
INFO - 2024-10-27 14:26:06 --> Utf8 Class Initialized
INFO - 2024-10-27 14:26:06 --> URI Class Initialized
INFO - 2024-10-27 14:26:06 --> Router Class Initialized
INFO - 2024-10-27 14:26:06 --> Output Class Initialized
INFO - 2024-10-27 14:26:06 --> Security Class Initialized
DEBUG - 2024-10-27 14:26:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 14:26:06 --> Input Class Initialized
INFO - 2024-10-27 14:26:06 --> Language Class Initialized
ERROR - 2024-10-27 14:26:06 --> TEST ERROR MESSAGE - 2024-10-27 14:26:06
INFO - 2024-10-27 14:26:06 --> Loader Class Initialized
INFO - 2024-10-27 14:26:06 --> Controller Class Initialized
INFO - 2024-10-27 14:26:06 --> Database Driver Class Initialized
INFO - 2024-10-27 14:26:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 14:26:06 --> Helper loaded: form_helper
INFO - 2024-10-27 14:26:06 --> Helper loaded: url_helper
INFO - 2024-10-27 14:26:06 --> Model Class Initialized
INFO - 2024-10-27 14:26:06 --> Helper loaded: inflector_helper
INFO - 2024-10-27 14:26:06 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 14:26:06 --> Helper loaded: email_helper
INFO - 2024-10-27 14:26:06 --> Model Class Initialized
INFO - 2024-10-27 14:26:06 --> Model Class Initialized
INFO - 2024-10-27 14:26:06 --> Model Class Initialized
INFO - 2024-10-27 14:26:06 --> Model Class Initialized
INFO - 2024-10-27 14:26:06 --> Model Class Initialized
INFO - 2024-10-27 14:26:06 --> Model Class Initialized
INFO - 2024-10-27 14:26:06 --> Model Class Initialized
DEBUG - 2024-10-27 14:26:06 --> plural called with: company
DEBUG - 2024-10-27 14:26:06 --> is_countable called with!!!!: company
INFO - 2024-10-27 14:26:06 --> Model Class Initialized
INFO - 2024-10-27 14:26:06 --> Model Class Initialized
INFO - 2024-10-27 14:26:06 --> Model Class Initialized
INFO - 2024-10-27 14:26:12 --> Config Class Initialized
INFO - 2024-10-27 14:26:12 --> Hooks Class Initialized
DEBUG - 2024-10-27 14:26:12 --> UTF-8 Support Enabled
INFO - 2024-10-27 14:26:12 --> Utf8 Class Initialized
INFO - 2024-10-27 14:26:12 --> URI Class Initialized
INFO - 2024-10-27 14:26:12 --> Router Class Initialized
INFO - 2024-10-27 14:26:12 --> Output Class Initialized
INFO - 2024-10-27 14:26:12 --> Security Class Initialized
DEBUG - 2024-10-27 14:26:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 14:26:12 --> Input Class Initialized
INFO - 2024-10-27 14:26:12 --> Language Class Initialized
ERROR - 2024-10-27 14:26:12 --> TEST ERROR MESSAGE - 2024-10-27 14:26:12
INFO - 2024-10-27 14:26:12 --> Loader Class Initialized
INFO - 2024-10-27 14:26:12 --> Controller Class Initialized
INFO - 2024-10-27 14:26:12 --> Database Driver Class Initialized
INFO - 2024-10-27 14:26:46 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 14:26:46 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 14:26:46 --> Final output sent to browser
DEBUG - 2024-10-27 14:26:46 --> Total execution time: 39.8957
INFO - 2024-10-27 14:26:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 14:26:46 --> Helper loaded: form_helper
INFO - 2024-10-27 14:26:46 --> Helper loaded: url_helper
INFO - 2024-10-27 14:26:46 --> Model Class Initialized
INFO - 2024-10-27 14:26:46 --> Helper loaded: inflector_helper
INFO - 2024-10-27 14:26:46 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 14:26:46 --> Helper loaded: email_helper
INFO - 2024-10-27 14:26:46 --> Model Class Initialized
INFO - 2024-10-27 14:26:46 --> Model Class Initialized
INFO - 2024-10-27 14:26:46 --> Model Class Initialized
INFO - 2024-10-27 14:26:46 --> Model Class Initialized
INFO - 2024-10-27 14:26:46 --> Model Class Initialized
INFO - 2024-10-27 14:26:46 --> Model Class Initialized
INFO - 2024-10-27 14:26:46 --> Model Class Initialized
DEBUG - 2024-10-27 14:26:46 --> plural called with: company
DEBUG - 2024-10-27 14:26:46 --> is_countable called with!!!!: company
INFO - 2024-10-27 14:26:46 --> Model Class Initialized
INFO - 2024-10-27 14:26:46 --> Model Class Initialized
INFO - 2024-10-27 14:26:46 --> Model Class Initialized
INFO - 2024-10-27 14:26:46 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 14:26:46 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 14:26:46 --> Final output sent to browser
DEBUG - 2024-10-27 14:26:46 --> Total execution time: 33.6136
INFO - 2024-10-27 14:27:08 --> Config Class Initialized
INFO - 2024-10-27 14:27:08 --> Hooks Class Initialized
DEBUG - 2024-10-27 14:27:08 --> UTF-8 Support Enabled
INFO - 2024-10-27 14:27:08 --> Utf8 Class Initialized
INFO - 2024-10-27 14:27:08 --> URI Class Initialized
INFO - 2024-10-27 14:27:08 --> Router Class Initialized
INFO - 2024-10-27 14:27:08 --> Output Class Initialized
INFO - 2024-10-27 14:27:08 --> Security Class Initialized
DEBUG - 2024-10-27 14:27:08 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 14:27:08 --> Input Class Initialized
INFO - 2024-10-27 14:27:08 --> Language Class Initialized
ERROR - 2024-10-27 14:27:08 --> TEST ERROR MESSAGE - 2024-10-27 14:27:08
INFO - 2024-10-27 14:27:08 --> Loader Class Initialized
INFO - 2024-10-27 14:27:08 --> Controller Class Initialized
INFO - 2024-10-27 14:27:08 --> Database Driver Class Initialized
INFO - 2024-10-27 14:27:08 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 14:27:08 --> Helper loaded: form_helper
INFO - 2024-10-27 14:27:08 --> Helper loaded: url_helper
INFO - 2024-10-27 14:27:08 --> Model Class Initialized
INFO - 2024-10-27 14:27:08 --> Helper loaded: inflector_helper
INFO - 2024-10-27 14:27:08 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 14:27:08 --> Helper loaded: email_helper
INFO - 2024-10-27 14:27:08 --> Model Class Initialized
INFO - 2024-10-27 14:27:08 --> Model Class Initialized
INFO - 2024-10-27 14:27:08 --> Model Class Initialized
INFO - 2024-10-27 14:27:08 --> Model Class Initialized
INFO - 2024-10-27 14:27:08 --> Model Class Initialized
INFO - 2024-10-27 14:27:08 --> Model Class Initialized
INFO - 2024-10-27 14:27:08 --> Model Class Initialized
DEBUG - 2024-10-27 14:27:08 --> plural called with: company
DEBUG - 2024-10-27 14:27:08 --> is_countable called with!!!!: company
INFO - 2024-10-27 14:27:08 --> Model Class Initialized
INFO - 2024-10-27 14:27:08 --> Model Class Initialized
INFO - 2024-10-27 14:27:08 --> Model Class Initialized
INFO - 2024-10-27 14:27:08 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-27 14:27:08 --> Final output sent to browser
DEBUG - 2024-10-27 14:27:08 --> Total execution time: 0.0348
INFO - 2024-10-27 15:05:52 --> Config Class Initialized
INFO - 2024-10-27 15:05:52 --> Hooks Class Initialized
DEBUG - 2024-10-27 15:05:52 --> UTF-8 Support Enabled
INFO - 2024-10-27 15:05:52 --> Utf8 Class Initialized
INFO - 2024-10-27 15:05:52 --> URI Class Initialized
INFO - 2024-10-27 15:05:52 --> Router Class Initialized
INFO - 2024-10-27 15:05:52 --> Output Class Initialized
INFO - 2024-10-27 15:05:52 --> Security Class Initialized
DEBUG - 2024-10-27 15:05:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 15:05:52 --> Input Class Initialized
INFO - 2024-10-27 15:05:52 --> Language Class Initialized
ERROR - 2024-10-27 15:05:52 --> TEST ERROR MESSAGE - 2024-10-27 15:05:52
INFO - 2024-10-27 15:05:52 --> Loader Class Initialized
INFO - 2024-10-27 15:05:52 --> Controller Class Initialized
INFO - 2024-10-27 15:05:52 --> Database Driver Class Initialized
INFO - 2024-10-27 15:05:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 15:05:52 --> Helper loaded: form_helper
INFO - 2024-10-27 15:05:52 --> Helper loaded: url_helper
INFO - 2024-10-27 15:05:52 --> Model Class Initialized
INFO - 2024-10-27 15:05:52 --> Helper loaded: inflector_helper
INFO - 2024-10-27 15:05:52 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 15:05:52 --> Helper loaded: email_helper
INFO - 2024-10-27 15:05:52 --> Model Class Initialized
INFO - 2024-10-27 15:05:52 --> Model Class Initialized
INFO - 2024-10-27 15:05:52 --> Model Class Initialized
INFO - 2024-10-27 15:05:52 --> Model Class Initialized
INFO - 2024-10-27 15:05:52 --> Model Class Initialized
INFO - 2024-10-27 15:05:52 --> Model Class Initialized
INFO - 2024-10-27 15:05:52 --> Model Class Initialized
DEBUG - 2024-10-27 15:05:52 --> plural called with: company
DEBUG - 2024-10-27 15:05:52 --> is_countable called with!!!!: company
INFO - 2024-10-27 15:05:52 --> Model Class Initialized
INFO - 2024-10-27 15:05:52 --> Model Class Initialized
INFO - 2024-10-27 15:05:52 --> Model Class Initialized
INFO - 2024-10-27 15:05:55 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-27 15:05:55 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-27 15:05:55 --> Final output sent to browser
DEBUG - 2024-10-27 15:05:55 --> Total execution time: 3.3006
INFO - 2024-10-27 16:16:22 --> Config Class Initialized
INFO - 2024-10-27 16:16:22 --> Hooks Class Initialized
DEBUG - 2024-10-27 16:16:22 --> UTF-8 Support Enabled
INFO - 2024-10-27 16:16:22 --> Utf8 Class Initialized
INFO - 2024-10-27 16:16:22 --> URI Class Initialized
INFO - 2024-10-27 16:16:22 --> Router Class Initialized
INFO - 2024-10-27 16:16:22 --> Output Class Initialized
INFO - 2024-10-27 16:16:22 --> Security Class Initialized
DEBUG - 2024-10-27 16:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-27 16:16:22 --> Input Class Initialized
INFO - 2024-10-27 16:16:22 --> Language Class Initialized
ERROR - 2024-10-27 16:16:22 --> TEST ERROR MESSAGE - 2024-10-27 16:16:22
INFO - 2024-10-27 16:16:22 --> Loader Class Initialized
INFO - 2024-10-27 16:16:22 --> Controller Class Initialized
INFO - 2024-10-27 16:16:22 --> Database Driver Class Initialized
INFO - 2024-10-27 16:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-27 16:16:22 --> Helper loaded: form_helper
INFO - 2024-10-27 16:16:22 --> Helper loaded: url_helper
INFO - 2024-10-27 16:16:22 --> Model Class Initialized
INFO - 2024-10-27 16:16:22 --> Helper loaded: inflector_helper
INFO - 2024-10-27 16:16:22 --> Helper loaded: mezoo_helper
INFO - 2024-10-27 16:16:22 --> Helper loaded: email_helper
INFO - 2024-10-27 16:16:22 --> Model Class Initialized
INFO - 2024-10-27 16:16:22 --> Model Class Initialized
INFO - 2024-10-27 16:16:22 --> Model Class Initialized
INFO - 2024-10-27 16:16:22 --> Model Class Initialized
INFO - 2024-10-27 16:16:22 --> Model Class Initialized
INFO - 2024-10-27 16:16:22 --> Model Class Initialized
INFO - 2024-10-27 16:16:22 --> Model Class Initialized
DEBUG - 2024-10-27 16:16:22 --> plural called with: company
DEBUG - 2024-10-27 16:16:22 --> is_countable called with!!!!: company
INFO - 2024-10-27 16:16:22 --> Model Class Initialized
INFO - 2024-10-27 16:16:22 --> Model Class Initialized
INFO - 2024-10-27 16:16:22 --> Model Class Initialized
ERROR - 2024-10-27 16:16:23 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 298
INFO - 2024-10-27 16:16:23 --> Final output sent to browser
DEBUG - 2024-10-27 16:16:23 --> Total execution time: 0.1322

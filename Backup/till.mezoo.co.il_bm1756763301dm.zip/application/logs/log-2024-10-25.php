<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-25 00:33:22 --> Config Class Initialized
INFO - 2024-10-25 00:33:22 --> Hooks Class Initialized
DEBUG - 2024-10-25 00:33:22 --> UTF-8 Support Enabled
INFO - 2024-10-25 00:33:22 --> Utf8 Class Initialized
INFO - 2024-10-25 00:33:22 --> URI Class Initialized
INFO - 2024-10-25 00:33:22 --> Router Class Initialized
INFO - 2024-10-25 00:33:22 --> Output Class Initialized
INFO - 2024-10-25 00:33:22 --> Security Class Initialized
DEBUG - 2024-10-25 00:33:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 00:33:22 --> Input Class Initialized
INFO - 2024-10-25 00:33:22 --> Language Class Initialized
ERROR - 2024-10-25 00:33:22 --> TEST ERROR MESSAGE - 2024-10-25 00:33:22
INFO - 2024-10-25 00:33:22 --> Loader Class Initialized
INFO - 2024-10-25 00:33:22 --> Controller Class Initialized
INFO - 2024-10-25 00:33:22 --> Database Driver Class Initialized
INFO - 2024-10-25 00:33:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 00:33:22 --> Helper loaded: form_helper
INFO - 2024-10-25 00:33:22 --> Helper loaded: url_helper
INFO - 2024-10-25 00:33:22 --> Model Class Initialized
INFO - 2024-10-25 00:33:22 --> Helper loaded: inflector_helper
INFO - 2024-10-25 00:33:22 --> Helper loaded: mezoo_helper
INFO - 2024-10-25 00:33:22 --> Helper loaded: email_helper
INFO - 2024-10-25 00:33:22 --> Model Class Initialized
INFO - 2024-10-25 00:33:22 --> Model Class Initialized
INFO - 2024-10-25 00:33:22 --> Model Class Initialized
INFO - 2024-10-25 00:33:22 --> Model Class Initialized
INFO - 2024-10-25 00:33:22 --> Model Class Initialized
INFO - 2024-10-25 00:33:22 --> Model Class Initialized
INFO - 2024-10-25 00:33:22 --> Model Class Initialized
DEBUG - 2024-10-25 00:33:22 --> plural called with: company
DEBUG - 2024-10-25 00:33:22 --> is_countable called with!!!!: company
INFO - 2024-10-25 00:33:22 --> Model Class Initialized
INFO - 2024-10-25 00:33:22 --> Model Class Initialized
INFO - 2024-10-25 00:33:22 --> Model Class Initialized
INFO - 2024-10-25 00:33:58 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-25 00:33:58 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-25 00:33:58 --> Final output sent to browser
DEBUG - 2024-10-25 00:33:58 --> Total execution time: 35.8163
INFO - 2024-10-25 00:34:02 --> Config Class Initialized
INFO - 2024-10-25 00:34:02 --> Hooks Class Initialized
DEBUG - 2024-10-25 00:34:02 --> UTF-8 Support Enabled
INFO - 2024-10-25 00:34:02 --> Utf8 Class Initialized
INFO - 2024-10-25 00:34:02 --> URI Class Initialized
INFO - 2024-10-25 00:34:02 --> Router Class Initialized
INFO - 2024-10-25 00:34:02 --> Output Class Initialized
INFO - 2024-10-25 00:34:02 --> Security Class Initialized
DEBUG - 2024-10-25 00:34:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 00:34:02 --> Input Class Initialized
INFO - 2024-10-25 00:34:02 --> Language Class Initialized
ERROR - 2024-10-25 00:34:02 --> TEST ERROR MESSAGE - 2024-10-25 00:34:02
INFO - 2024-10-25 00:34:02 --> Loader Class Initialized
INFO - 2024-10-25 00:34:02 --> Controller Class Initialized
INFO - 2024-10-25 00:34:02 --> Database Driver Class Initialized
INFO - 2024-10-25 00:34:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 00:34:02 --> Helper loaded: form_helper
INFO - 2024-10-25 00:34:02 --> Helper loaded: url_helper
INFO - 2024-10-25 00:34:02 --> Model Class Initialized
INFO - 2024-10-25 00:34:02 --> Helper loaded: inflector_helper
INFO - 2024-10-25 00:34:02 --> Helper loaded: mezoo_helper
INFO - 2024-10-25 00:34:02 --> Helper loaded: email_helper
INFO - 2024-10-25 00:34:02 --> Model Class Initialized
INFO - 2024-10-25 00:34:02 --> Model Class Initialized
INFO - 2024-10-25 00:34:02 --> Model Class Initialized
INFO - 2024-10-25 00:34:02 --> Model Class Initialized
INFO - 2024-10-25 00:34:02 --> Model Class Initialized
INFO - 2024-10-25 00:34:02 --> Model Class Initialized
INFO - 2024-10-25 00:34:02 --> Model Class Initialized
DEBUG - 2024-10-25 00:34:02 --> plural called with: company
DEBUG - 2024-10-25 00:34:02 --> is_countable called with!!!!: company
INFO - 2024-10-25 00:34:02 --> Model Class Initialized
INFO - 2024-10-25 00:34:02 --> Model Class Initialized
INFO - 2024-10-25 00:34:02 --> Model Class Initialized
INFO - 2024-10-25 00:34:02 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-25 00:34:02 --> Final output sent to browser
DEBUG - 2024-10-25 00:34:02 --> Total execution time: 0.0310
INFO - 2024-10-25 00:53:37 --> Config Class Initialized
INFO - 2024-10-25 00:53:37 --> Hooks Class Initialized
DEBUG - 2024-10-25 00:53:37 --> UTF-8 Support Enabled
INFO - 2024-10-25 00:53:37 --> Utf8 Class Initialized
INFO - 2024-10-25 00:53:37 --> URI Class Initialized
INFO - 2024-10-25 00:53:37 --> Router Class Initialized
INFO - 2024-10-25 00:53:37 --> Output Class Initialized
INFO - 2024-10-25 00:53:37 --> Security Class Initialized
DEBUG - 2024-10-25 00:53:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 00:53:37 --> Input Class Initialized
INFO - 2024-10-25 00:53:37 --> Language Class Initialized
ERROR - 2024-10-25 00:53:37 --> TEST ERROR MESSAGE - 2024-10-25 00:53:37
INFO - 2024-10-25 00:53:37 --> Loader Class Initialized
INFO - 2024-10-25 00:53:37 --> Controller Class Initialized
INFO - 2024-10-25 00:53:37 --> Database Driver Class Initialized
INFO - 2024-10-25 00:53:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 00:53:37 --> Helper loaded: form_helper
INFO - 2024-10-25 00:53:37 --> Helper loaded: url_helper
INFO - 2024-10-25 00:53:37 --> Model Class Initialized
INFO - 2024-10-25 00:53:37 --> Helper loaded: inflector_helper
INFO - 2024-10-25 00:53:37 --> Helper loaded: mezoo_helper
INFO - 2024-10-25 00:53:37 --> Helper loaded: email_helper
INFO - 2024-10-25 00:53:37 --> Model Class Initialized
INFO - 2024-10-25 00:53:37 --> Model Class Initialized
INFO - 2024-10-25 00:53:37 --> Model Class Initialized
INFO - 2024-10-25 00:53:37 --> Model Class Initialized
INFO - 2024-10-25 00:53:37 --> Model Class Initialized
INFO - 2024-10-25 00:53:37 --> Model Class Initialized
INFO - 2024-10-25 00:53:37 --> Model Class Initialized
DEBUG - 2024-10-25 00:53:37 --> plural called with: company
DEBUG - 2024-10-25 00:53:37 --> is_countable called with!!!!: company
INFO - 2024-10-25 00:53:37 --> Model Class Initialized
INFO - 2024-10-25 00:53:37 --> Model Class Initialized
INFO - 2024-10-25 00:53:37 --> Model Class Initialized
INFO - 2024-10-25 00:54:11 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-25 00:54:11 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-25 00:54:11 --> Final output sent to browser
DEBUG - 2024-10-25 00:54:11 --> Total execution time: 33.8214
INFO - 2024-10-25 00:54:16 --> Config Class Initialized
INFO - 2024-10-25 00:54:16 --> Hooks Class Initialized
DEBUG - 2024-10-25 00:54:16 --> UTF-8 Support Enabled
INFO - 2024-10-25 00:54:16 --> Utf8 Class Initialized
INFO - 2024-10-25 00:54:16 --> URI Class Initialized
INFO - 2024-10-25 00:54:16 --> Router Class Initialized
INFO - 2024-10-25 00:54:16 --> Output Class Initialized
INFO - 2024-10-25 00:54:16 --> Security Class Initialized
DEBUG - 2024-10-25 00:54:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 00:54:16 --> Input Class Initialized
INFO - 2024-10-25 00:54:16 --> Language Class Initialized
ERROR - 2024-10-25 00:54:16 --> TEST ERROR MESSAGE - 2024-10-25 00:54:16
INFO - 2024-10-25 00:54:16 --> Loader Class Initialized
INFO - 2024-10-25 00:54:16 --> Controller Class Initialized
INFO - 2024-10-25 00:54:16 --> Database Driver Class Initialized
INFO - 2024-10-25 00:54:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 00:54:16 --> Helper loaded: form_helper
INFO - 2024-10-25 00:54:16 --> Helper loaded: url_helper
INFO - 2024-10-25 00:54:16 --> Model Class Initialized
INFO - 2024-10-25 00:54:16 --> Helper loaded: inflector_helper
INFO - 2024-10-25 00:54:16 --> Helper loaded: mezoo_helper
INFO - 2024-10-25 00:54:16 --> Helper loaded: email_helper
INFO - 2024-10-25 00:54:16 --> Model Class Initialized
INFO - 2024-10-25 00:54:16 --> Model Class Initialized
INFO - 2024-10-25 00:54:16 --> Model Class Initialized
INFO - 2024-10-25 00:54:16 --> Model Class Initialized
INFO - 2024-10-25 00:54:16 --> Model Class Initialized
INFO - 2024-10-25 00:54:16 --> Model Class Initialized
INFO - 2024-10-25 00:54:16 --> Model Class Initialized
DEBUG - 2024-10-25 00:54:16 --> plural called with: company
DEBUG - 2024-10-25 00:54:16 --> is_countable called with!!!!: company
INFO - 2024-10-25 00:54:16 --> Model Class Initialized
INFO - 2024-10-25 00:54:16 --> Model Class Initialized
INFO - 2024-10-25 00:54:16 --> Model Class Initialized
INFO - 2024-10-25 00:54:16 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-25 00:54:16 --> Final output sent to browser
DEBUG - 2024-10-25 00:54:16 --> Total execution time: 0.0253
INFO - 2024-10-25 00:59:18 --> Config Class Initialized
INFO - 2024-10-25 00:59:18 --> Hooks Class Initialized
DEBUG - 2024-10-25 00:59:18 --> UTF-8 Support Enabled
INFO - 2024-10-25 00:59:18 --> Utf8 Class Initialized
INFO - 2024-10-25 00:59:18 --> URI Class Initialized
INFO - 2024-10-25 00:59:18 --> Router Class Initialized
INFO - 2024-10-25 00:59:18 --> Output Class Initialized
INFO - 2024-10-25 00:59:18 --> Security Class Initialized
DEBUG - 2024-10-25 00:59:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 00:59:18 --> Input Class Initialized
INFO - 2024-10-25 00:59:18 --> Language Class Initialized
ERROR - 2024-10-25 00:59:18 --> TEST ERROR MESSAGE - 2024-10-25 00:59:18
INFO - 2024-10-25 00:59:18 --> Loader Class Initialized
INFO - 2024-10-25 00:59:18 --> Controller Class Initialized
INFO - 2024-10-25 00:59:18 --> Database Driver Class Initialized
INFO - 2024-10-25 00:59:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 00:59:18 --> Helper loaded: form_helper
INFO - 2024-10-25 00:59:18 --> Helper loaded: url_helper
INFO - 2024-10-25 00:59:18 --> Model Class Initialized
INFO - 2024-10-25 00:59:18 --> Helper loaded: inflector_helper
INFO - 2024-10-25 00:59:18 --> Helper loaded: mezoo_helper
INFO - 2024-10-25 00:59:18 --> Helper loaded: email_helper
INFO - 2024-10-25 00:59:18 --> Model Class Initialized
INFO - 2024-10-25 00:59:18 --> Model Class Initialized
INFO - 2024-10-25 00:59:18 --> Model Class Initialized
INFO - 2024-10-25 00:59:18 --> Model Class Initialized
INFO - 2024-10-25 00:59:18 --> Model Class Initialized
INFO - 2024-10-25 00:59:18 --> Model Class Initialized
INFO - 2024-10-25 00:59:18 --> Model Class Initialized
DEBUG - 2024-10-25 00:59:18 --> plural called with: company
DEBUG - 2024-10-25 00:59:18 --> is_countable called with!!!!: company
INFO - 2024-10-25 00:59:18 --> Model Class Initialized
INFO - 2024-10-25 00:59:18 --> Model Class Initialized
INFO - 2024-10-25 00:59:18 --> Model Class Initialized
INFO - 2024-10-25 00:59:51 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-25 00:59:51 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-25 00:59:51 --> Final output sent to browser
DEBUG - 2024-10-25 00:59:51 --> Total execution time: 32.8995
INFO - 2024-10-25 01:00:03 --> Config Class Initialized
INFO - 2024-10-25 01:00:03 --> Hooks Class Initialized
DEBUG - 2024-10-25 01:00:03 --> UTF-8 Support Enabled
INFO - 2024-10-25 01:00:03 --> Utf8 Class Initialized
INFO - 2024-10-25 01:00:03 --> URI Class Initialized
INFO - 2024-10-25 01:00:03 --> Router Class Initialized
INFO - 2024-10-25 01:00:03 --> Output Class Initialized
INFO - 2024-10-25 01:00:03 --> Security Class Initialized
DEBUG - 2024-10-25 01:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 01:00:03 --> Input Class Initialized
INFO - 2024-10-25 01:00:03 --> Language Class Initialized
ERROR - 2024-10-25 01:00:03 --> TEST ERROR MESSAGE - 2024-10-25 01:00:03
INFO - 2024-10-25 01:00:03 --> Loader Class Initialized
INFO - 2024-10-25 01:00:03 --> Controller Class Initialized
INFO - 2024-10-25 01:00:03 --> Database Driver Class Initialized
INFO - 2024-10-25 01:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 01:00:03 --> Helper loaded: form_helper
INFO - 2024-10-25 01:00:03 --> Helper loaded: url_helper
INFO - 2024-10-25 01:00:03 --> Model Class Initialized
INFO - 2024-10-25 01:00:03 --> Helper loaded: inflector_helper
INFO - 2024-10-25 01:00:03 --> Helper loaded: mezoo_helper
INFO - 2024-10-25 01:00:03 --> Helper loaded: email_helper
INFO - 2024-10-25 01:00:03 --> Model Class Initialized
INFO - 2024-10-25 01:00:03 --> Model Class Initialized
INFO - 2024-10-25 01:00:03 --> Model Class Initialized
INFO - 2024-10-25 01:00:03 --> Model Class Initialized
INFO - 2024-10-25 01:00:03 --> Model Class Initialized
INFO - 2024-10-25 01:00:03 --> Model Class Initialized
INFO - 2024-10-25 01:00:03 --> Model Class Initialized
DEBUG - 2024-10-25 01:00:03 --> plural called with: company
DEBUG - 2024-10-25 01:00:03 --> is_countable called with!!!!: company
INFO - 2024-10-25 01:00:03 --> Model Class Initialized
INFO - 2024-10-25 01:00:03 --> Model Class Initialized
INFO - 2024-10-25 01:00:03 --> Model Class Initialized
INFO - 2024-10-25 01:00:03 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-25 01:00:03 --> Final output sent to browser
DEBUG - 2024-10-25 01:00:03 --> Total execution time: 0.0392
INFO - 2024-10-25 01:01:24 --> Config Class Initialized
INFO - 2024-10-25 01:01:24 --> Hooks Class Initialized
DEBUG - 2024-10-25 01:01:24 --> UTF-8 Support Enabled
INFO - 2024-10-25 01:01:24 --> Utf8 Class Initialized
INFO - 2024-10-25 01:01:24 --> URI Class Initialized
INFO - 2024-10-25 01:01:24 --> Router Class Initialized
INFO - 2024-10-25 01:01:24 --> Output Class Initialized
INFO - 2024-10-25 01:01:24 --> Security Class Initialized
DEBUG - 2024-10-25 01:01:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 01:01:24 --> Input Class Initialized
INFO - 2024-10-25 01:01:24 --> Language Class Initialized
ERROR - 2024-10-25 01:01:24 --> TEST ERROR MESSAGE - 2024-10-25 01:01:24
INFO - 2024-10-25 01:01:24 --> Loader Class Initialized
INFO - 2024-10-25 01:01:24 --> Controller Class Initialized
INFO - 2024-10-25 01:01:24 --> Database Driver Class Initialized
INFO - 2024-10-25 01:01:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 01:01:24 --> Helper loaded: form_helper
INFO - 2024-10-25 01:01:24 --> Helper loaded: url_helper
INFO - 2024-10-25 01:01:24 --> Model Class Initialized
INFO - 2024-10-25 01:01:24 --> Helper loaded: inflector_helper
INFO - 2024-10-25 01:01:24 --> Helper loaded: mezoo_helper
INFO - 2024-10-25 01:01:24 --> Helper loaded: email_helper
INFO - 2024-10-25 01:01:24 --> Model Class Initialized
INFO - 2024-10-25 01:01:24 --> Model Class Initialized
INFO - 2024-10-25 01:01:24 --> Model Class Initialized
INFO - 2024-10-25 01:01:24 --> Model Class Initialized
INFO - 2024-10-25 01:01:24 --> Model Class Initialized
INFO - 2024-10-25 01:01:24 --> Model Class Initialized
INFO - 2024-10-25 01:01:24 --> Model Class Initialized
DEBUG - 2024-10-25 01:01:24 --> plural called with: company
DEBUG - 2024-10-25 01:01:24 --> is_countable called with!!!!: company
INFO - 2024-10-25 01:01:24 --> Model Class Initialized
INFO - 2024-10-25 01:01:24 --> Model Class Initialized
INFO - 2024-10-25 01:01:24 --> Model Class Initialized
INFO - 2024-10-25 01:01:24 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-25 01:01:24 --> Final output sent to browser
DEBUG - 2024-10-25 01:01:24 --> Total execution time: 0.0243
INFO - 2024-10-25 03:03:16 --> Config Class Initialized
INFO - 2024-10-25 03:03:16 --> Hooks Class Initialized
DEBUG - 2024-10-25 03:03:16 --> UTF-8 Support Enabled
INFO - 2024-10-25 03:03:16 --> Utf8 Class Initialized
INFO - 2024-10-25 03:03:16 --> URI Class Initialized
DEBUG - 2024-10-25 03:03:16 --> No URI present. Default controller set.
INFO - 2024-10-25 03:03:16 --> Router Class Initialized
INFO - 2024-10-25 03:03:16 --> Output Class Initialized
INFO - 2024-10-25 03:03:16 --> Security Class Initialized
DEBUG - 2024-10-25 03:03:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 03:03:16 --> Input Class Initialized
INFO - 2024-10-25 03:03:16 --> Language Class Initialized
ERROR - 2024-10-25 03:03:16 --> TEST ERROR MESSAGE - 2024-10-25 03:03:16
INFO - 2024-10-25 03:03:16 --> Loader Class Initialized
INFO - 2024-10-25 03:03:16 --> Controller Class Initialized
INFO - 2024-10-25 03:03:16 --> Database Driver Class Initialized
INFO - 2024-10-25 03:03:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 03:03:16 --> Helper loaded: form_helper
INFO - 2024-10-25 03:03:16 --> Helper loaded: url_helper
INFO - 2024-10-25 03:03:16 --> Model Class Initialized
INFO - 2024-10-25 03:03:16 --> Helper loaded: inflector_helper
INFO - 2024-10-25 03:03:16 --> Helper loaded: mezoo_helper
INFO - 2024-10-25 03:03:16 --> Helper loaded: email_helper
INFO - 2024-10-25 03:03:16 --> Model Class Initialized
INFO - 2024-10-25 03:03:16 --> Model Class Initialized
INFO - 2024-10-25 03:03:16 --> Model Class Initialized
INFO - 2024-10-25 03:03:16 --> Model Class Initialized
INFO - 2024-10-25 03:03:16 --> Model Class Initialized
INFO - 2024-10-25 03:03:16 --> Model Class Initialized
INFO - 2024-10-25 03:03:16 --> Model Class Initialized
DEBUG - 2024-10-25 03:03:16 --> plural called with: company
DEBUG - 2024-10-25 03:03:16 --> is_countable called with!!!!: company
INFO - 2024-10-25 03:03:16 --> Model Class Initialized
INFO - 2024-10-25 03:03:16 --> Model Class Initialized
INFO - 2024-10-25 03:03:16 --> Model Class Initialized
INFO - 2024-10-25 03:03:16 --> Final output sent to browser
DEBUG - 2024-10-25 03:03:16 --> Total execution time: 0.0447
INFO - 2024-10-25 19:34:05 --> Config Class Initialized
INFO - 2024-10-25 19:34:05 --> Hooks Class Initialized
DEBUG - 2024-10-25 19:34:05 --> UTF-8 Support Enabled
INFO - 2024-10-25 19:34:05 --> Utf8 Class Initialized
INFO - 2024-10-25 19:34:05 --> URI Class Initialized
INFO - 2024-10-25 19:34:05 --> Router Class Initialized
INFO - 2024-10-25 19:34:05 --> Output Class Initialized
INFO - 2024-10-25 19:34:05 --> Security Class Initialized
DEBUG - 2024-10-25 19:34:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-25 19:34:05 --> Input Class Initialized
INFO - 2024-10-25 19:34:05 --> Language Class Initialized
ERROR - 2024-10-25 19:34:05 --> TEST ERROR MESSAGE - 2024-10-25 19:34:05
INFO - 2024-10-25 19:34:05 --> Loader Class Initialized
INFO - 2024-10-25 19:34:05 --> Controller Class Initialized
INFO - 2024-10-25 19:34:05 --> Database Driver Class Initialized
INFO - 2024-10-25 19:34:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-25 19:34:05 --> Helper loaded: form_helper
INFO - 2024-10-25 19:34:05 --> Helper loaded: url_helper
INFO - 2024-10-25 19:34:05 --> Model Class Initialized
INFO - 2024-10-25 19:34:05 --> Helper loaded: inflector_helper
INFO - 2024-10-25 19:34:05 --> Helper loaded: mezoo_helper
INFO - 2024-10-25 19:34:05 --> Helper loaded: email_helper
INFO - 2024-10-25 19:34:05 --> Model Class Initialized
INFO - 2024-10-25 19:34:05 --> Model Class Initialized
INFO - 2024-10-25 19:34:05 --> Model Class Initialized
INFO - 2024-10-25 19:34:05 --> Model Class Initialized
INFO - 2024-10-25 19:34:05 --> Model Class Initialized
INFO - 2024-10-25 19:34:05 --> Model Class Initialized
INFO - 2024-10-25 19:34:05 --> Model Class Initialized
DEBUG - 2024-10-25 19:34:05 --> plural called with: company
DEBUG - 2024-10-25 19:34:05 --> is_countable called with!!!!: company
INFO - 2024-10-25 19:34:05 --> Model Class Initialized
INFO - 2024-10-25 19:34:05 --> Model Class Initialized
INFO - 2024-10-25 19:34:05 --> Model Class Initialized
ERROR - 2024-10-25 19:34:06 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 298
INFO - 2024-10-25 19:34:06 --> Final output sent to browser
DEBUG - 2024-10-25 19:34:06 --> Total execution time: 0.1229

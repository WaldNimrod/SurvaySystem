<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-10-29 01:08:00 --> Severity: error --> Exception: syntax error, unexpected 'd' (T_STRING) /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 130
ERROR - 2024-10-29 01:08:08 --> Severity: error --> Exception: syntax error, unexpected 'd' (T_STRING) /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 130
ERROR - 2024-10-29 01:44:26 --> Severity: Warning --> Division by zero /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 214
ERROR - 2024-10-29 01:44:26 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: INSERT INTO `feedbackdims` (`feedbackId`, `dimId`, `result`) VALUES (16395, NULL, NAN)
ERROR - 2024-10-29 01:44:26 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: INSERT INTO `feedbackdims` (`feedbackId`, `dimId`, `result`) VALUES (16395, NULL, NAN)
ERROR - 2024-10-29 01:49:02 --> Severity: Warning --> Cannot use a scalar value as an array /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 438
ERROR - 2024-10-29 01:49:29 --> Severity: Warning --> Cannot use a scalar value as an array /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 438
ERROR - 2024-10-29 01:49:52 --> Severity: Warning --> Cannot use a scalar value as an array /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 438
ERROR - 2024-10-29 06:31:11 --> Severity: Warning --> Cannot use a scalar value as an array /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 438
ERROR - 2024-10-29 08:05:39 --> Severity: Warning --> Cannot use a scalar value as an array /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 438

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-26 18:32:54 --> Config Class Initialized
INFO - 2024-10-26 18:32:54 --> Hooks Class Initialized
DEBUG - 2024-10-26 18:32:54 --> UTF-8 Support Enabled
INFO - 2024-10-26 18:32:54 --> Utf8 Class Initialized
INFO - 2024-10-26 18:32:54 --> URI Class Initialized
INFO - 2024-10-26 18:32:54 --> Router Class Initialized
INFO - 2024-10-26 18:32:54 --> Output Class Initialized
INFO - 2024-10-26 18:32:54 --> Security Class Initialized
DEBUG - 2024-10-26 18:32:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 18:32:54 --> Input Class Initialized
INFO - 2024-10-26 18:32:54 --> Language Class Initialized
ERROR - 2024-10-26 18:32:54 --> TEST ERROR MESSAGE - 2024-10-26 18:32:54
INFO - 2024-10-26 18:32:54 --> Loader Class Initialized
INFO - 2024-10-26 18:32:54 --> Controller Class Initialized
INFO - 2024-10-26 18:32:54 --> Database Driver Class Initialized
INFO - 2024-10-26 18:32:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 18:32:54 --> Helper loaded: form_helper
INFO - 2024-10-26 18:32:54 --> Helper loaded: url_helper
INFO - 2024-10-26 18:32:54 --> Model Class Initialized
INFO - 2024-10-26 18:32:54 --> Helper loaded: inflector_helper
INFO - 2024-10-26 18:32:54 --> Helper loaded: mezoo_helper
INFO - 2024-10-26 18:32:54 --> Helper loaded: email_helper
INFO - 2024-10-26 18:32:54 --> Model Class Initialized
INFO - 2024-10-26 18:32:54 --> Model Class Initialized
INFO - 2024-10-26 18:32:54 --> Model Class Initialized
INFO - 2024-10-26 18:32:54 --> Model Class Initialized
INFO - 2024-10-26 18:32:54 --> Model Class Initialized
INFO - 2024-10-26 18:32:54 --> Model Class Initialized
INFO - 2024-10-26 18:32:54 --> Model Class Initialized
DEBUG - 2024-10-26 18:32:54 --> plural called with: company
DEBUG - 2024-10-26 18:32:54 --> is_countable called with!!!!: company
INFO - 2024-10-26 18:32:54 --> Model Class Initialized
INFO - 2024-10-26 18:32:54 --> Model Class Initialized
INFO - 2024-10-26 18:32:54 --> Model Class Initialized
ERROR - 2024-10-26 18:32:54 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 298
INFO - 2024-10-26 18:32:54 --> Final output sent to browser
DEBUG - 2024-10-26 18:32:54 --> Total execution time: 0.1550
INFO - 2024-10-26 20:23:32 --> Config Class Initialized
INFO - 2024-10-26 20:23:32 --> Hooks Class Initialized
DEBUG - 2024-10-26 20:23:32 --> UTF-8 Support Enabled
INFO - 2024-10-26 20:23:32 --> Utf8 Class Initialized
INFO - 2024-10-26 20:23:32 --> URI Class Initialized
INFO - 2024-10-26 20:23:32 --> Router Class Initialized
INFO - 2024-10-26 20:23:32 --> Output Class Initialized
INFO - 2024-10-26 20:23:32 --> Security Class Initialized
DEBUG - 2024-10-26 20:23:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-26 20:23:32 --> Input Class Initialized
INFO - 2024-10-26 20:23:32 --> Language Class Initialized
ERROR - 2024-10-26 20:23:32 --> TEST ERROR MESSAGE - 2024-10-26 20:23:32
INFO - 2024-10-26 20:23:32 --> Loader Class Initialized
INFO - 2024-10-26 20:23:32 --> Controller Class Initialized
INFO - 2024-10-26 20:23:32 --> Database Driver Class Initialized
INFO - 2024-10-26 20:23:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-26 20:23:32 --> Helper loaded: form_helper
INFO - 2024-10-26 20:23:32 --> Helper loaded: url_helper
INFO - 2024-10-26 20:23:32 --> Model Class Initialized
INFO - 2024-10-26 20:23:32 --> Helper loaded: inflector_helper
INFO - 2024-10-26 20:23:32 --> Helper loaded: mezoo_helper
INFO - 2024-10-26 20:23:32 --> Helper loaded: email_helper
INFO - 2024-10-26 20:23:32 --> Model Class Initialized
INFO - 2024-10-26 20:23:32 --> Model Class Initialized
INFO - 2024-10-26 20:23:32 --> Model Class Initialized
INFO - 2024-10-26 20:23:32 --> Model Class Initialized
INFO - 2024-10-26 20:23:32 --> Model Class Initialized
INFO - 2024-10-26 20:23:32 --> Model Class Initialized
INFO - 2024-10-26 20:23:32 --> Model Class Initialized
DEBUG - 2024-10-26 20:23:32 --> plural called with: company
DEBUG - 2024-10-26 20:23:32 --> is_countable called with!!!!: company
INFO - 2024-10-26 20:23:32 --> Model Class Initialized
INFO - 2024-10-26 20:23:32 --> Model Class Initialized
INFO - 2024-10-26 20:23:32 --> Model Class Initialized
ERROR - 2024-10-26 20:23:32 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 298
ERROR - 2024-10-26 20:23:32 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 312
ERROR - 2024-10-26 20:23:32 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 317
INFO - 2024-10-26 20:23:32 --> Final output sent to browser
DEBUG - 2024-10-26 20:23:32 --> Total execution time: 0.1157

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-05-04 08:13:52 --> Severity: Warning --> mysqli::real_connect(): Error while reading greeting packet. PID=2543951 /home/tillmezo/domains/till.mezoo.co.il/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2025-05-04 08:13:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/2006): MySQL server has gone away /home/tillmezo/domains/till.mezoo.co.il/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2025-05-04 08:13:52 --> Unable to connect to the database
ERROR - 2025-05-04 08:13:52 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home/tillmezo/domains/till.mezoo.co.il/public_html/system/database/drivers/mysqli/mysqli_driver.php 391
ERROR - 2025-05-04 08:13:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home/tillmezo/domains/till.mezoo.co.il/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2025-05-04 08:13:52 --> Unable to connect to the database
ERROR - 2025-05-04 08:13:52 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home/tillmezo/domains/till.mezoo.co.il/public_html/system/database/drivers/mysqli/mysqli_driver.php 391
ERROR - 2025-05-04 08:13:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home/tillmezo/domains/till.mezoo.co.il/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2025-05-04 08:13:52 --> Unable to connect to the database
ERROR - 2025-05-04 08:13:52 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home/tillmezo/domains/till.mezoo.co.il/public_html/system/database/drivers/mysqli/mysqli_driver.php 391
ERROR - 2025-05-04 08:13:52 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home/tillmezo/domains/till.mezoo.co.il/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2025-05-04 08:13:52 --> Unable to connect to the database
ERROR - 2025-05-04 08:13:52 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home/tillmezo/domains/till.mezoo.co.il/public_html/system/database/drivers/mysqli/mysqli_driver.php 391

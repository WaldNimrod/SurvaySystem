<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-04-08 13:19:34 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home/tillmezo/domains/till.mezoo.co.il/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2025-04-08 13:19:34 --> Unable to connect to the database
ERROR - 2025-04-08 13:19:34 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home/tillmezo/domains/till.mezoo.co.il/public_html/system/database/drivers/mysqli/mysqli_driver.php 391
ERROR - 2025-04-08 13:19:37 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home/tillmezo/domains/till.mezoo.co.il/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2025-04-08 13:19:37 --> Unable to connect to the database
ERROR - 2025-04-08 13:19:39 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home/tillmezo/domains/till.mezoo.co.il/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2025-04-08 13:19:39 --> Unable to connect to the database
ERROR - 2025-04-08 13:19:39 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home/tillmezo/domains/till.mezoo.co.il/public_html/system/database/drivers/mysqli/mysqli_driver.php 391
ERROR - 2025-04-08 13:19:42 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home/tillmezo/domains/till.mezoo.co.il/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2025-04-08 13:19:42 --> Unable to connect to the database
ERROR - 2025-04-08 13:19:42 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home/tillmezo/domains/till.mezoo.co.il/public_html/system/database/drivers/mysqli/mysqli_driver.php 391
ERROR - 2025-04-08 13:19:53 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home/tillmezo/domains/till.mezoo.co.il/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2025-04-08 13:19:53 --> Unable to connect to the database
ERROR - 2025-04-08 13:19:53 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home/tillmezo/domains/till.mezoo.co.il/public_html/system/database/drivers/mysqli/mysqli_driver.php 391
ERROR - 2025-04-08 13:20:18 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home/tillmezo/domains/till.mezoo.co.il/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2025-04-08 13:20:18 --> Unable to connect to the database
ERROR - 2025-04-08 13:20:18 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home/tillmezo/domains/till.mezoo.co.il/public_html/system/database/drivers/mysqli/mysqli_driver.php 391
ERROR - 2025-04-08 13:20:20 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home/tillmezo/domains/till.mezoo.co.il/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2025-04-08 13:20:20 --> Unable to connect to the database
ERROR - 2025-04-08 13:20:21 --> Severity: Warning --> mysqli::real_connect(): (HY000/2002): Connection refused /home/tillmezo/domains/till.mezoo.co.il/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2025-04-08 13:20:21 --> Unable to connect to the database
ERROR - 2025-04-08 13:20:21 --> Severity: error --> Exception: Call to a member function real_escape_string() on bool /home/tillmezo/domains/till.mezoo.co.il/public_html/system/database/drivers/mysqli/mysqli_driver.php 391

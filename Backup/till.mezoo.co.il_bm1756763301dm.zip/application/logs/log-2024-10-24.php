<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-24 02:36:10 --> Config Class Initialized
INFO - 2024-10-24 02:36:10 --> Hooks Class Initialized
DEBUG - 2024-10-24 02:36:10 --> UTF-8 Support Enabled
INFO - 2024-10-24 02:36:10 --> Utf8 Class Initialized
INFO - 2024-10-24 02:36:10 --> URI Class Initialized
INFO - 2024-10-24 02:36:10 --> Router Class Initialized
INFO - 2024-10-24 02:36:10 --> Output Class Initialized
INFO - 2024-10-24 02:36:10 --> Security Class Initialized
DEBUG - 2024-10-24 02:36:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 02:36:10 --> Input Class Initialized
INFO - 2024-10-24 02:36:10 --> Language Class Initialized
ERROR - 2024-10-24 02:36:10 --> TEST ERROR MESSAGE - 2024-10-24 02:36:10
INFO - 2024-10-24 02:36:10 --> Loader Class Initialized
INFO - 2024-10-24 02:36:10 --> Controller Class Initialized
INFO - 2024-10-24 02:36:10 --> Database Driver Class Initialized
INFO - 2024-10-24 02:36:10 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 02:36:10 --> Helper loaded: form_helper
INFO - 2024-10-24 02:36:10 --> Helper loaded: url_helper
INFO - 2024-10-24 02:36:10 --> Model Class Initialized
INFO - 2024-10-24 02:36:10 --> Helper loaded: inflector_helper
INFO - 2024-10-24 02:36:10 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 02:36:10 --> Helper loaded: email_helper
INFO - 2024-10-24 02:36:10 --> Model Class Initialized
INFO - 2024-10-24 02:36:10 --> Model Class Initialized
INFO - 2024-10-24 02:36:10 --> Model Class Initialized
INFO - 2024-10-24 02:36:10 --> Model Class Initialized
INFO - 2024-10-24 02:36:10 --> Model Class Initialized
INFO - 2024-10-24 02:36:10 --> Model Class Initialized
INFO - 2024-10-24 02:36:10 --> Model Class Initialized
INFO - 2024-10-24 02:36:10 --> Model Class Initialized
INFO - 2024-10-24 02:36:10 --> Model Class Initialized
INFO - 2024-10-24 02:36:10 --> Model Class Initialized
INFO - 2024-10-24 02:36:10 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-24 02:36:10 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 02:36:10 --> Final output sent to browser
DEBUG - 2024-10-24 02:36:10 --> Total execution time: 0.0248
INFO - 2024-10-24 02:36:15 --> Config Class Initialized
INFO - 2024-10-24 02:36:15 --> Hooks Class Initialized
DEBUG - 2024-10-24 02:36:15 --> UTF-8 Support Enabled
INFO - 2024-10-24 02:36:15 --> Utf8 Class Initialized
INFO - 2024-10-24 02:36:15 --> URI Class Initialized
INFO - 2024-10-24 02:36:15 --> Router Class Initialized
INFO - 2024-10-24 02:36:15 --> Output Class Initialized
INFO - 2024-10-24 02:36:15 --> Security Class Initialized
DEBUG - 2024-10-24 02:36:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 02:36:15 --> Input Class Initialized
INFO - 2024-10-24 02:36:15 --> Language Class Initialized
ERROR - 2024-10-24 02:36:15 --> TEST ERROR MESSAGE - 2024-10-24 02:36:15
INFO - 2024-10-24 02:36:15 --> Loader Class Initialized
INFO - 2024-10-24 02:36:15 --> Controller Class Initialized
INFO - 2024-10-24 02:36:15 --> Database Driver Class Initialized
INFO - 2024-10-24 02:36:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 02:36:15 --> Helper loaded: form_helper
INFO - 2024-10-24 02:36:15 --> Helper loaded: url_helper
INFO - 2024-10-24 02:36:15 --> Model Class Initialized
INFO - 2024-10-24 02:36:15 --> Helper loaded: inflector_helper
INFO - 2024-10-24 02:36:15 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 02:36:15 --> Helper loaded: email_helper
INFO - 2024-10-24 02:36:15 --> Model Class Initialized
INFO - 2024-10-24 02:36:15 --> Model Class Initialized
INFO - 2024-10-24 02:36:15 --> Model Class Initialized
INFO - 2024-10-24 02:36:15 --> Model Class Initialized
INFO - 2024-10-24 02:36:15 --> Model Class Initialized
INFO - 2024-10-24 02:36:15 --> Model Class Initialized
INFO - 2024-10-24 02:36:15 --> Model Class Initialized
INFO - 2024-10-24 02:36:15 --> Model Class Initialized
INFO - 2024-10-24 02:36:15 --> Model Class Initialized
INFO - 2024-10-24 02:36:15 --> Model Class Initialized
ERROR - 2024-10-24 02:36:15 --> Query error: Table 'tillmezo_a.company' doesn't exist - Invalid query: SELECT *
FROM `company`
WHERE `login` = 'admin2'
AND `password` = 'til794613'
INFO - 2024-10-24 02:36:15 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-24 02:37:01 --> Config Class Initialized
INFO - 2024-10-24 02:37:01 --> Hooks Class Initialized
DEBUG - 2024-10-24 02:37:01 --> UTF-8 Support Enabled
INFO - 2024-10-24 02:37:01 --> Utf8 Class Initialized
INFO - 2024-10-24 02:37:01 --> URI Class Initialized
INFO - 2024-10-24 02:37:01 --> Router Class Initialized
INFO - 2024-10-24 02:37:01 --> Output Class Initialized
INFO - 2024-10-24 02:37:01 --> Security Class Initialized
DEBUG - 2024-10-24 02:37:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 02:37:01 --> Input Class Initialized
INFO - 2024-10-24 02:37:01 --> Language Class Initialized
ERROR - 2024-10-24 02:37:01 --> TEST ERROR MESSAGE - 2024-10-24 02:37:01
INFO - 2024-10-24 02:37:01 --> Loader Class Initialized
INFO - 2024-10-24 02:37:01 --> Controller Class Initialized
INFO - 2024-10-24 02:37:01 --> Database Driver Class Initialized
INFO - 2024-10-24 02:37:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 02:37:01 --> Helper loaded: form_helper
INFO - 2024-10-24 02:37:01 --> Helper loaded: url_helper
INFO - 2024-10-24 02:37:01 --> Model Class Initialized
INFO - 2024-10-24 02:37:01 --> Helper loaded: inflector_helper
INFO - 2024-10-24 02:37:01 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 02:37:01 --> Helper loaded: email_helper
INFO - 2024-10-24 02:37:01 --> Model Class Initialized
INFO - 2024-10-24 02:37:01 --> Model Class Initialized
INFO - 2024-10-24 02:37:01 --> Model Class Initialized
INFO - 2024-10-24 02:37:01 --> Model Class Initialized
INFO - 2024-10-24 02:37:01 --> Model Class Initialized
INFO - 2024-10-24 02:37:01 --> Model Class Initialized
INFO - 2024-10-24 02:37:01 --> Model Class Initialized
INFO - 2024-10-24 02:37:01 --> Model Class Initialized
INFO - 2024-10-24 02:37:01 --> Model Class Initialized
INFO - 2024-10-24 02:37:01 --> Model Class Initialized
INFO - 2024-10-24 02:37:01 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-24 02:37:01 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 02:37:01 --> Final output sent to browser
DEBUG - 2024-10-24 02:37:01 --> Total execution time: 0.0228
INFO - 2024-10-24 02:37:03 --> Config Class Initialized
INFO - 2024-10-24 02:37:03 --> Hooks Class Initialized
DEBUG - 2024-10-24 02:37:03 --> UTF-8 Support Enabled
INFO - 2024-10-24 02:37:03 --> Utf8 Class Initialized
INFO - 2024-10-24 02:37:03 --> URI Class Initialized
INFO - 2024-10-24 02:37:03 --> Router Class Initialized
INFO - 2024-10-24 02:37:03 --> Output Class Initialized
INFO - 2024-10-24 02:37:03 --> Security Class Initialized
DEBUG - 2024-10-24 02:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 02:37:03 --> Input Class Initialized
INFO - 2024-10-24 02:37:03 --> Language Class Initialized
ERROR - 2024-10-24 02:37:03 --> TEST ERROR MESSAGE - 2024-10-24 02:37:03
INFO - 2024-10-24 02:37:03 --> Loader Class Initialized
INFO - 2024-10-24 02:37:03 --> Controller Class Initialized
INFO - 2024-10-24 02:37:03 --> Database Driver Class Initialized
INFO - 2024-10-24 02:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 02:37:03 --> Helper loaded: form_helper
INFO - 2024-10-24 02:37:03 --> Helper loaded: url_helper
INFO - 2024-10-24 02:37:03 --> Model Class Initialized
INFO - 2024-10-24 02:37:03 --> Helper loaded: inflector_helper
INFO - 2024-10-24 02:37:03 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 02:37:03 --> Helper loaded: email_helper
INFO - 2024-10-24 02:37:03 --> Model Class Initialized
INFO - 2024-10-24 02:37:03 --> Model Class Initialized
INFO - 2024-10-24 02:37:03 --> Model Class Initialized
INFO - 2024-10-24 02:37:03 --> Model Class Initialized
INFO - 2024-10-24 02:37:03 --> Model Class Initialized
INFO - 2024-10-24 02:37:03 --> Model Class Initialized
INFO - 2024-10-24 02:37:03 --> Model Class Initialized
INFO - 2024-10-24 02:37:03 --> Model Class Initialized
INFO - 2024-10-24 02:37:03 --> Model Class Initialized
INFO - 2024-10-24 02:37:03 --> Model Class Initialized
INFO - 2024-10-24 02:37:03 --> Config Class Initialized
INFO - 2024-10-24 02:37:03 --> Hooks Class Initialized
DEBUG - 2024-10-24 02:37:03 --> UTF-8 Support Enabled
INFO - 2024-10-24 02:37:03 --> Utf8 Class Initialized
INFO - 2024-10-24 02:37:03 --> URI Class Initialized
INFO - 2024-10-24 02:37:03 --> Router Class Initialized
INFO - 2024-10-24 02:37:03 --> Output Class Initialized
INFO - 2024-10-24 02:37:03 --> Security Class Initialized
DEBUG - 2024-10-24 02:37:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 02:37:03 --> Input Class Initialized
INFO - 2024-10-24 02:37:03 --> Language Class Initialized
ERROR - 2024-10-24 02:37:03 --> TEST ERROR MESSAGE - 2024-10-24 02:37:03
INFO - 2024-10-24 02:37:03 --> Loader Class Initialized
INFO - 2024-10-24 02:37:03 --> Controller Class Initialized
INFO - 2024-10-24 02:37:03 --> Database Driver Class Initialized
INFO - 2024-10-24 02:37:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 02:37:03 --> Helper loaded: form_helper
INFO - 2024-10-24 02:37:03 --> Helper loaded: url_helper
INFO - 2024-10-24 02:37:03 --> Model Class Initialized
INFO - 2024-10-24 02:37:03 --> Helper loaded: inflector_helper
INFO - 2024-10-24 02:37:03 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 02:37:03 --> Helper loaded: email_helper
INFO - 2024-10-24 02:37:03 --> Model Class Initialized
INFO - 2024-10-24 02:37:03 --> Model Class Initialized
INFO - 2024-10-24 02:37:03 --> Model Class Initialized
INFO - 2024-10-24 02:37:03 --> Model Class Initialized
INFO - 2024-10-24 02:37:03 --> Model Class Initialized
INFO - 2024-10-24 02:37:03 --> Model Class Initialized
INFO - 2024-10-24 02:37:03 --> Model Class Initialized
INFO - 2024-10-24 02:37:03 --> Model Class Initialized
INFO - 2024-10-24 02:37:03 --> Model Class Initialized
INFO - 2024-10-24 02:37:03 --> Model Class Initialized
ERROR - 2024-10-24 02:37:05 --> Severity: Notice --> Undefined index: freetext /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 02:37:05 --> Severity: Notice --> Undefined index: socialDes /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 02:37:05 --> Severity: Notice --> Undefined index: company /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 02:37:05 --> Severity: Notice --> Undefined index: division /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 02:37:05 --> Severity: Notice --> Undefined index: dataGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 02:37:05 --> Severity: Notice --> Undefined index: finalGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
INFO - 2024-10-24 02:37:05 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 02:37:05 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 02:37:06 --> Final output sent to browser
DEBUG - 2024-10-24 02:37:06 --> Total execution time: 2.4475
INFO - 2024-10-24 02:37:07 --> Config Class Initialized
INFO - 2024-10-24 02:37:07 --> Hooks Class Initialized
DEBUG - 2024-10-24 02:37:07 --> UTF-8 Support Enabled
INFO - 2024-10-24 02:37:07 --> Utf8 Class Initialized
INFO - 2024-10-24 02:37:07 --> URI Class Initialized
INFO - 2024-10-24 02:37:07 --> Router Class Initialized
INFO - 2024-10-24 02:37:07 --> Output Class Initialized
INFO - 2024-10-24 02:37:07 --> Security Class Initialized
DEBUG - 2024-10-24 02:37:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 02:37:07 --> Input Class Initialized
INFO - 2024-10-24 02:37:07 --> Language Class Initialized
ERROR - 2024-10-24 02:37:07 --> TEST ERROR MESSAGE - 2024-10-24 02:37:07
INFO - 2024-10-24 02:37:07 --> Loader Class Initialized
INFO - 2024-10-24 02:37:07 --> Controller Class Initialized
INFO - 2024-10-24 02:37:07 --> Database Driver Class Initialized
INFO - 2024-10-24 02:37:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 02:37:07 --> Helper loaded: form_helper
INFO - 2024-10-24 02:37:07 --> Helper loaded: url_helper
INFO - 2024-10-24 02:37:07 --> Model Class Initialized
INFO - 2024-10-24 02:37:07 --> Helper loaded: inflector_helper
INFO - 2024-10-24 02:37:07 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 02:37:07 --> Helper loaded: email_helper
INFO - 2024-10-24 02:37:07 --> Model Class Initialized
INFO - 2024-10-24 02:37:07 --> Model Class Initialized
INFO - 2024-10-24 02:37:07 --> Model Class Initialized
INFO - 2024-10-24 02:37:07 --> Model Class Initialized
INFO - 2024-10-24 02:37:07 --> Model Class Initialized
INFO - 2024-10-24 02:37:07 --> Model Class Initialized
INFO - 2024-10-24 02:37:07 --> Model Class Initialized
INFO - 2024-10-24 02:37:07 --> Model Class Initialized
INFO - 2024-10-24 02:37:07 --> Model Class Initialized
INFO - 2024-10-24 02:37:07 --> Model Class Initialized
INFO - 2024-10-24 02:37:07 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 02:37:07 --> Final output sent to browser
DEBUG - 2024-10-24 02:37:07 --> Total execution time: 0.0297
INFO - 2024-10-24 02:58:11 --> Config Class Initialized
INFO - 2024-10-24 02:58:11 --> Hooks Class Initialized
DEBUG - 2024-10-24 02:58:11 --> UTF-8 Support Enabled
INFO - 2024-10-24 02:58:11 --> Utf8 Class Initialized
INFO - 2024-10-24 02:58:11 --> URI Class Initialized
INFO - 2024-10-24 02:58:11 --> Router Class Initialized
INFO - 2024-10-24 02:58:11 --> Output Class Initialized
INFO - 2024-10-24 02:58:11 --> Security Class Initialized
DEBUG - 2024-10-24 02:58:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 02:58:11 --> Input Class Initialized
INFO - 2024-10-24 02:58:11 --> Language Class Initialized
ERROR - 2024-10-24 02:58:11 --> TEST ERROR MESSAGE - 2024-10-24 02:58:11
INFO - 2024-10-24 02:58:11 --> Loader Class Initialized
INFO - 2024-10-24 02:58:11 --> Controller Class Initialized
INFO - 2024-10-24 02:58:11 --> Database Driver Class Initialized
INFO - 2024-10-24 02:58:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 02:58:11 --> Helper loaded: form_helper
INFO - 2024-10-24 02:58:11 --> Helper loaded: url_helper
INFO - 2024-10-24 02:58:11 --> Model Class Initialized
INFO - 2024-10-24 02:58:11 --> Helper loaded: inflector_helper
DEBUG - 2024-10-24 02:58:11 --> _fetch_table() called!!!
INFO - 2024-10-24 02:58:11 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 02:58:11 --> Helper loaded: email_helper
INFO - 2024-10-24 02:58:11 --> Model Class Initialized
DEBUG - 2024-10-24 02:58:11 --> _fetch_table() called!!!
INFO - 2024-10-24 02:58:11 --> Model Class Initialized
DEBUG - 2024-10-24 02:58:11 --> _fetch_table() called!!!
INFO - 2024-10-24 02:58:11 --> Model Class Initialized
DEBUG - 2024-10-24 02:58:11 --> _fetch_table() called!!!
INFO - 2024-10-24 02:58:11 --> Model Class Initialized
DEBUG - 2024-10-24 02:58:11 --> _fetch_table() called!!!
INFO - 2024-10-24 02:58:11 --> Model Class Initialized
DEBUG - 2024-10-24 02:58:11 --> _fetch_table() called!!!
INFO - 2024-10-24 02:58:11 --> Model Class Initialized
DEBUG - 2024-10-24 02:58:11 --> _fetch_table() called!!!
INFO - 2024-10-24 02:58:11 --> Model Class Initialized
DEBUG - 2024-10-24 02:58:11 --> _fetch_table() called!!!
INFO - 2024-10-24 02:58:11 --> Model Class Initialized
DEBUG - 2024-10-24 02:58:11 --> _fetch_table() called!!!
INFO - 2024-10-24 02:58:11 --> Model Class Initialized
DEBUG - 2024-10-24 02:58:11 --> _fetch_table() called!!!
INFO - 2024-10-24 02:58:11 --> Model Class Initialized
DEBUG - 2024-10-24 02:58:11 --> _fetch_table() called!!!
INFO - 2024-10-24 02:58:11 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-24 02:58:11 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 02:58:11 --> Final output sent to browser
DEBUG - 2024-10-24 02:58:11 --> Total execution time: 0.0373
INFO - 2024-10-24 02:58:21 --> Config Class Initialized
INFO - 2024-10-24 02:58:21 --> Hooks Class Initialized
DEBUG - 2024-10-24 02:58:21 --> UTF-8 Support Enabled
INFO - 2024-10-24 02:58:21 --> Utf8 Class Initialized
INFO - 2024-10-24 02:58:21 --> URI Class Initialized
INFO - 2024-10-24 02:58:21 --> Router Class Initialized
INFO - 2024-10-24 02:58:21 --> Output Class Initialized
INFO - 2024-10-24 02:58:21 --> Security Class Initialized
DEBUG - 2024-10-24 02:58:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 02:58:21 --> Input Class Initialized
INFO - 2024-10-24 02:58:21 --> Language Class Initialized
ERROR - 2024-10-24 02:58:21 --> TEST ERROR MESSAGE - 2024-10-24 02:58:21
INFO - 2024-10-24 02:58:21 --> Loader Class Initialized
INFO - 2024-10-24 02:58:21 --> Controller Class Initialized
INFO - 2024-10-24 02:58:21 --> Database Driver Class Initialized
INFO - 2024-10-24 02:58:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 02:58:21 --> Helper loaded: form_helper
INFO - 2024-10-24 02:58:21 --> Helper loaded: url_helper
INFO - 2024-10-24 02:58:21 --> Model Class Initialized
INFO - 2024-10-24 02:58:21 --> Helper loaded: inflector_helper
DEBUG - 2024-10-24 02:58:21 --> _fetch_table() called!!!
INFO - 2024-10-24 02:58:21 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 02:58:21 --> Helper loaded: email_helper
INFO - 2024-10-24 02:58:21 --> Model Class Initialized
DEBUG - 2024-10-24 02:58:21 --> _fetch_table() called!!!
INFO - 2024-10-24 02:58:21 --> Model Class Initialized
DEBUG - 2024-10-24 02:58:21 --> _fetch_table() called!!!
INFO - 2024-10-24 02:58:21 --> Model Class Initialized
DEBUG - 2024-10-24 02:58:21 --> _fetch_table() called!!!
INFO - 2024-10-24 02:58:21 --> Model Class Initialized
DEBUG - 2024-10-24 02:58:21 --> _fetch_table() called!!!
INFO - 2024-10-24 02:58:21 --> Model Class Initialized
DEBUG - 2024-10-24 02:58:21 --> _fetch_table() called!!!
INFO - 2024-10-24 02:58:21 --> Model Class Initialized
DEBUG - 2024-10-24 02:58:21 --> _fetch_table() called!!!
INFO - 2024-10-24 02:58:21 --> Model Class Initialized
DEBUG - 2024-10-24 02:58:21 --> _fetch_table() called!!!
INFO - 2024-10-24 02:58:21 --> Model Class Initialized
DEBUG - 2024-10-24 02:58:21 --> _fetch_table() called!!!
INFO - 2024-10-24 02:58:21 --> Model Class Initialized
DEBUG - 2024-10-24 02:58:21 --> _fetch_table() called!!!
INFO - 2024-10-24 02:58:21 --> Model Class Initialized
DEBUG - 2024-10-24 02:58:21 --> _fetch_table() called!!!
ERROR - 2024-10-24 02:58:21 --> Query error: Table 'tillmezo_a.company' doesn't exist - Invalid query: SELECT *
FROM `company`
WHERE `login` = 'admin2'
AND `password` = 'til794613'
INFO - 2024-10-24 02:58:21 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-24 03:01:51 --> Config Class Initialized
INFO - 2024-10-24 03:01:51 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:01:51 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:01:51 --> Utf8 Class Initialized
INFO - 2024-10-24 03:01:51 --> URI Class Initialized
INFO - 2024-10-24 03:01:51 --> Router Class Initialized
INFO - 2024-10-24 03:01:51 --> Output Class Initialized
INFO - 2024-10-24 03:01:51 --> Security Class Initialized
DEBUG - 2024-10-24 03:01:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:01:51 --> Input Class Initialized
INFO - 2024-10-24 03:01:51 --> Language Class Initialized
ERROR - 2024-10-24 03:01:51 --> TEST ERROR MESSAGE - 2024-10-24 03:01:51
INFO - 2024-10-24 03:01:51 --> Loader Class Initialized
INFO - 2024-10-24 03:01:51 --> Controller Class Initialized
INFO - 2024-10-24 03:01:51 --> Database Driver Class Initialized
INFO - 2024-10-24 03:01:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:01:51 --> Helper loaded: form_helper
INFO - 2024-10-24 03:01:51 --> Helper loaded: url_helper
INFO - 2024-10-24 03:01:51 --> Model Class Initialized
INFO - 2024-10-24 03:01:51 --> Helper loaded: inflector_helper
DEBUG - 2024-10-24 03:01:51 --> _fetch_table() called
INFO - 2024-10-24 03:01:51 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:01:51 --> Helper loaded: email_helper
INFO - 2024-10-24 03:01:51 --> Model Class Initialized
DEBUG - 2024-10-24 03:01:51 --> _fetch_table() called
INFO - 2024-10-24 03:01:51 --> Model Class Initialized
DEBUG - 2024-10-24 03:01:51 --> _fetch_table() called
INFO - 2024-10-24 03:01:51 --> Model Class Initialized
DEBUG - 2024-10-24 03:01:51 --> _fetch_table() called
INFO - 2024-10-24 03:01:51 --> Model Class Initialized
DEBUG - 2024-10-24 03:01:51 --> _fetch_table() called
INFO - 2024-10-24 03:01:51 --> Model Class Initialized
DEBUG - 2024-10-24 03:01:51 --> _fetch_table() called
INFO - 2024-10-24 03:01:51 --> Model Class Initialized
DEBUG - 2024-10-24 03:01:51 --> _fetch_table() called
INFO - 2024-10-24 03:01:51 --> Model Class Initialized
DEBUG - 2024-10-24 03:01:51 --> _fetch_table() called
DEBUG - 2024-10-24 03:01:51 --> $this->_table is NULL, proceeding with name generation
DEBUG - 2024-10-24 03:01:51 --> Class name: Company_m
DEBUG - 2024-10-24 03:01:51 --> Stripped name: company
DEBUG - 2024-10-24 03:01:51 --> plural() function exists
DEBUG - 2024-10-24 03:01:51 --> Pluralized result: company
INFO - 2024-10-24 03:01:51 --> Model Class Initialized
DEBUG - 2024-10-24 03:01:51 --> _fetch_table() called
INFO - 2024-10-24 03:01:51 --> Model Class Initialized
DEBUG - 2024-10-24 03:01:51 --> _fetch_table() called
INFO - 2024-10-24 03:01:51 --> Model Class Initialized
DEBUG - 2024-10-24 03:01:51 --> _fetch_table() called
INFO - 2024-10-24 03:01:51 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-24 03:01:51 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 03:01:51 --> Final output sent to browser
DEBUG - 2024-10-24 03:01:51 --> Total execution time: 0.0241
INFO - 2024-10-24 03:01:53 --> Config Class Initialized
INFO - 2024-10-24 03:01:53 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:01:53 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:01:53 --> Utf8 Class Initialized
INFO - 2024-10-24 03:01:53 --> URI Class Initialized
INFO - 2024-10-24 03:01:53 --> Router Class Initialized
INFO - 2024-10-24 03:01:53 --> Output Class Initialized
INFO - 2024-10-24 03:01:53 --> Security Class Initialized
DEBUG - 2024-10-24 03:01:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:01:53 --> Input Class Initialized
INFO - 2024-10-24 03:01:53 --> Language Class Initialized
ERROR - 2024-10-24 03:01:53 --> TEST ERROR MESSAGE - 2024-10-24 03:01:53
INFO - 2024-10-24 03:01:53 --> Loader Class Initialized
INFO - 2024-10-24 03:01:53 --> Controller Class Initialized
INFO - 2024-10-24 03:01:53 --> Database Driver Class Initialized
INFO - 2024-10-24 03:01:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:01:53 --> Helper loaded: form_helper
INFO - 2024-10-24 03:01:53 --> Helper loaded: url_helper
INFO - 2024-10-24 03:01:53 --> Model Class Initialized
INFO - 2024-10-24 03:01:53 --> Helper loaded: inflector_helper
DEBUG - 2024-10-24 03:01:53 --> _fetch_table() called
INFO - 2024-10-24 03:01:53 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:01:53 --> Helper loaded: email_helper
INFO - 2024-10-24 03:01:53 --> Model Class Initialized
DEBUG - 2024-10-24 03:01:53 --> _fetch_table() called
INFO - 2024-10-24 03:01:53 --> Model Class Initialized
DEBUG - 2024-10-24 03:01:53 --> _fetch_table() called
INFO - 2024-10-24 03:01:53 --> Model Class Initialized
DEBUG - 2024-10-24 03:01:53 --> _fetch_table() called
INFO - 2024-10-24 03:01:53 --> Model Class Initialized
DEBUG - 2024-10-24 03:01:53 --> _fetch_table() called
INFO - 2024-10-24 03:01:53 --> Model Class Initialized
DEBUG - 2024-10-24 03:01:53 --> _fetch_table() called
INFO - 2024-10-24 03:01:53 --> Model Class Initialized
DEBUG - 2024-10-24 03:01:53 --> _fetch_table() called
INFO - 2024-10-24 03:01:53 --> Model Class Initialized
DEBUG - 2024-10-24 03:01:53 --> _fetch_table() called
DEBUG - 2024-10-24 03:01:53 --> $this->_table is NULL, proceeding with name generation
DEBUG - 2024-10-24 03:01:53 --> Class name: Company_m
DEBUG - 2024-10-24 03:01:53 --> Stripped name: company
DEBUG - 2024-10-24 03:01:53 --> plural() function exists
DEBUG - 2024-10-24 03:01:53 --> Pluralized result: company
INFO - 2024-10-24 03:01:53 --> Model Class Initialized
DEBUG - 2024-10-24 03:01:53 --> _fetch_table() called
INFO - 2024-10-24 03:01:53 --> Model Class Initialized
DEBUG - 2024-10-24 03:01:53 --> _fetch_table() called
INFO - 2024-10-24 03:01:53 --> Model Class Initialized
DEBUG - 2024-10-24 03:01:53 --> _fetch_table() called
ERROR - 2024-10-24 03:01:53 --> Query error: Table 'tillmezo_a.company' doesn't exist - Invalid query: SELECT *
FROM `company`
WHERE `login` = 'admin2'
AND `password` = 'til794613'
INFO - 2024-10-24 03:01:53 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-24 03:04:11 --> Config Class Initialized
INFO - 2024-10-24 03:04:11 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:04:11 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:04:11 --> Utf8 Class Initialized
INFO - 2024-10-24 03:04:11 --> URI Class Initialized
DEBUG - 2024-10-24 03:04:11 --> No URI present. Default controller set.
INFO - 2024-10-24 03:04:11 --> Router Class Initialized
INFO - 2024-10-24 03:04:11 --> Output Class Initialized
INFO - 2024-10-24 03:04:11 --> Security Class Initialized
DEBUG - 2024-10-24 03:04:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:04:11 --> Input Class Initialized
INFO - 2024-10-24 03:04:11 --> Language Class Initialized
ERROR - 2024-10-24 03:04:11 --> TEST ERROR MESSAGE - 2024-10-24 03:04:11
INFO - 2024-10-24 03:04:11 --> Loader Class Initialized
INFO - 2024-10-24 03:04:11 --> Controller Class Initialized
INFO - 2024-10-24 03:04:11 --> Database Driver Class Initialized
INFO - 2024-10-24 03:04:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:04:11 --> Helper loaded: form_helper
INFO - 2024-10-24 03:04:11 --> Helper loaded: url_helper
INFO - 2024-10-24 03:04:11 --> Model Class Initialized
INFO - 2024-10-24 03:04:11 --> Helper loaded: inflector_helper
DEBUG - 2024-10-24 03:04:11 --> _fetch_table() called
INFO - 2024-10-24 03:04:11 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:04:11 --> Helper loaded: email_helper
INFO - 2024-10-24 03:04:11 --> Model Class Initialized
DEBUG - 2024-10-24 03:04:11 --> _fetch_table() called
INFO - 2024-10-24 03:04:11 --> Model Class Initialized
DEBUG - 2024-10-24 03:04:11 --> _fetch_table() called
INFO - 2024-10-24 03:04:11 --> Model Class Initialized
DEBUG - 2024-10-24 03:04:11 --> _fetch_table() called
INFO - 2024-10-24 03:04:11 --> Model Class Initialized
DEBUG - 2024-10-24 03:04:11 --> _fetch_table() called
INFO - 2024-10-24 03:04:11 --> Model Class Initialized
DEBUG - 2024-10-24 03:04:11 --> _fetch_table() called
INFO - 2024-10-24 03:04:11 --> Model Class Initialized
DEBUG - 2024-10-24 03:04:11 --> _fetch_table() called
INFO - 2024-10-24 03:04:11 --> Model Class Initialized
DEBUG - 2024-10-24 03:04:11 --> _fetch_table() called
DEBUG - 2024-10-24 03:04:11 --> $this->_table is NULL, proceeding with name generation
DEBUG - 2024-10-24 03:04:11 --> Class name: Company_m
DEBUG - 2024-10-24 03:04:11 --> Stripped name: company
DEBUG - 2024-10-24 03:04:11 --> plural() function exists
DEBUG - 2024-10-24 03:04:11 --> Pluralized result: company
INFO - 2024-10-24 03:04:11 --> Model Class Initialized
DEBUG - 2024-10-24 03:04:11 --> _fetch_table() called
INFO - 2024-10-24 03:04:11 --> Model Class Initialized
DEBUG - 2024-10-24 03:04:11 --> _fetch_table() called
INFO - 2024-10-24 03:04:11 --> Model Class Initialized
DEBUG - 2024-10-24 03:04:11 --> _fetch_table() called
INFO - 2024-10-24 03:04:11 --> Final output sent to browser
DEBUG - 2024-10-24 03:04:11 --> Total execution time: 0.0224
INFO - 2024-10-24 03:11:26 --> Config Class Initialized
INFO - 2024-10-24 03:11:26 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:11:26 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:11:26 --> Utf8 Class Initialized
INFO - 2024-10-24 03:11:26 --> URI Class Initialized
INFO - 2024-10-24 03:11:26 --> Router Class Initialized
INFO - 2024-10-24 03:11:26 --> Output Class Initialized
INFO - 2024-10-24 03:11:26 --> Security Class Initialized
DEBUG - 2024-10-24 03:11:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:11:26 --> Input Class Initialized
INFO - 2024-10-24 03:11:26 --> Language Class Initialized
ERROR - 2024-10-24 03:11:26 --> TEST ERROR MESSAGE - 2024-10-24 03:11:26
INFO - 2024-10-24 03:11:26 --> Loader Class Initialized
INFO - 2024-10-24 03:11:26 --> Controller Class Initialized
INFO - 2024-10-24 03:11:26 --> Database Driver Class Initialized
INFO - 2024-10-24 03:11:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:11:26 --> Helper loaded: form_helper
INFO - 2024-10-24 03:11:26 --> Helper loaded: url_helper
INFO - 2024-10-24 03:11:26 --> Model Class Initialized
INFO - 2024-10-24 03:11:26 --> Helper loaded: inflector_helper
DEBUG - 2024-10-24 03:11:26 --> _fetch_table() called
INFO - 2024-10-24 03:11:26 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:11:26 --> Helper loaded: email_helper
INFO - 2024-10-24 03:11:26 --> Model Class Initialized
DEBUG - 2024-10-24 03:11:26 --> _fetch_table() called
INFO - 2024-10-24 03:11:26 --> Model Class Initialized
DEBUG - 2024-10-24 03:11:26 --> _fetch_table() called
INFO - 2024-10-24 03:11:26 --> Model Class Initialized
DEBUG - 2024-10-24 03:11:26 --> _fetch_table() called
INFO - 2024-10-24 03:11:26 --> Model Class Initialized
DEBUG - 2024-10-24 03:11:26 --> _fetch_table() called
INFO - 2024-10-24 03:11:26 --> Model Class Initialized
DEBUG - 2024-10-24 03:11:26 --> _fetch_table() called
INFO - 2024-10-24 03:11:26 --> Model Class Initialized
DEBUG - 2024-10-24 03:11:26 --> _fetch_table() called
INFO - 2024-10-24 03:11:26 --> Model Class Initialized
DEBUG - 2024-10-24 03:11:26 --> _fetch_table() called
DEBUG - 2024-10-24 03:11:26 --> $this->_table is NULL, proceeding with name generation
DEBUG - 2024-10-24 03:11:26 --> Class name: Company_m
DEBUG - 2024-10-24 03:11:26 --> Stripped name: company
DEBUG - 2024-10-24 03:11:26 --> plural() function exists
DEBUG - 2024-10-24 03:11:26 --> plural called with: company
DEBUG - 2024-10-24 03:11:26 --> Pluralized result: company
INFO - 2024-10-24 03:11:26 --> Model Class Initialized
DEBUG - 2024-10-24 03:11:26 --> _fetch_table() called
INFO - 2024-10-24 03:11:26 --> Model Class Initialized
DEBUG - 2024-10-24 03:11:26 --> _fetch_table() called
INFO - 2024-10-24 03:11:26 --> Model Class Initialized
DEBUG - 2024-10-24 03:11:26 --> _fetch_table() called
INFO - 2024-10-24 03:11:26 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-24 03:11:26 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 03:11:26 --> Final output sent to browser
DEBUG - 2024-10-24 03:11:26 --> Total execution time: 0.0243
INFO - 2024-10-24 03:11:29 --> Config Class Initialized
INFO - 2024-10-24 03:11:29 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:11:29 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:11:29 --> Utf8 Class Initialized
INFO - 2024-10-24 03:11:29 --> URI Class Initialized
INFO - 2024-10-24 03:11:29 --> Router Class Initialized
INFO - 2024-10-24 03:11:29 --> Output Class Initialized
INFO - 2024-10-24 03:11:29 --> Security Class Initialized
DEBUG - 2024-10-24 03:11:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:11:29 --> Input Class Initialized
INFO - 2024-10-24 03:11:29 --> Language Class Initialized
ERROR - 2024-10-24 03:11:29 --> TEST ERROR MESSAGE - 2024-10-24 03:11:29
INFO - 2024-10-24 03:11:29 --> Loader Class Initialized
INFO - 2024-10-24 03:11:29 --> Controller Class Initialized
INFO - 2024-10-24 03:11:29 --> Database Driver Class Initialized
INFO - 2024-10-24 03:11:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:11:29 --> Helper loaded: form_helper
INFO - 2024-10-24 03:11:29 --> Helper loaded: url_helper
INFO - 2024-10-24 03:11:29 --> Model Class Initialized
INFO - 2024-10-24 03:11:29 --> Helper loaded: inflector_helper
DEBUG - 2024-10-24 03:11:29 --> _fetch_table() called
INFO - 2024-10-24 03:11:29 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:11:29 --> Helper loaded: email_helper
INFO - 2024-10-24 03:11:29 --> Model Class Initialized
DEBUG - 2024-10-24 03:11:29 --> _fetch_table() called
INFO - 2024-10-24 03:11:29 --> Model Class Initialized
DEBUG - 2024-10-24 03:11:29 --> _fetch_table() called
INFO - 2024-10-24 03:11:29 --> Model Class Initialized
DEBUG - 2024-10-24 03:11:29 --> _fetch_table() called
INFO - 2024-10-24 03:11:29 --> Model Class Initialized
DEBUG - 2024-10-24 03:11:29 --> _fetch_table() called
INFO - 2024-10-24 03:11:29 --> Model Class Initialized
DEBUG - 2024-10-24 03:11:29 --> _fetch_table() called
INFO - 2024-10-24 03:11:29 --> Model Class Initialized
DEBUG - 2024-10-24 03:11:29 --> _fetch_table() called
INFO - 2024-10-24 03:11:29 --> Model Class Initialized
DEBUG - 2024-10-24 03:11:29 --> _fetch_table() called
DEBUG - 2024-10-24 03:11:29 --> $this->_table is NULL, proceeding with name generation
DEBUG - 2024-10-24 03:11:29 --> Class name: Company_m
DEBUG - 2024-10-24 03:11:29 --> Stripped name: company
DEBUG - 2024-10-24 03:11:29 --> plural() function exists
DEBUG - 2024-10-24 03:11:29 --> plural called with: company
DEBUG - 2024-10-24 03:11:29 --> Pluralized result: company
INFO - 2024-10-24 03:11:29 --> Model Class Initialized
DEBUG - 2024-10-24 03:11:29 --> _fetch_table() called
INFO - 2024-10-24 03:11:29 --> Model Class Initialized
DEBUG - 2024-10-24 03:11:29 --> _fetch_table() called
INFO - 2024-10-24 03:11:29 --> Model Class Initialized
DEBUG - 2024-10-24 03:11:29 --> _fetch_table() called
ERROR - 2024-10-24 03:11:29 --> Query error: Table 'tillmezo_a.company' doesn't exist - Invalid query: SELECT *
FROM `company`
WHERE `login` = 'admin2'
AND `password` = 'til794613'
INFO - 2024-10-24 03:11:29 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-24 03:15:48 --> Config Class Initialized
INFO - 2024-10-24 03:15:48 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:15:48 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:15:48 --> Utf8 Class Initialized
INFO - 2024-10-24 03:15:48 --> URI Class Initialized
INFO - 2024-10-24 03:15:48 --> Router Class Initialized
INFO - 2024-10-24 03:15:48 --> Output Class Initialized
INFO - 2024-10-24 03:15:48 --> Security Class Initialized
DEBUG - 2024-10-24 03:15:48 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:15:48 --> Input Class Initialized
INFO - 2024-10-24 03:15:48 --> Language Class Initialized
ERROR - 2024-10-24 03:15:48 --> TEST ERROR MESSAGE - 2024-10-24 03:15:48
INFO - 2024-10-24 03:15:48 --> Loader Class Initialized
INFO - 2024-10-24 03:15:48 --> Controller Class Initialized
INFO - 2024-10-24 03:15:48 --> Database Driver Class Initialized
INFO - 2024-10-24 03:15:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:15:48 --> Helper loaded: form_helper
INFO - 2024-10-24 03:15:48 --> Helper loaded: url_helper
INFO - 2024-10-24 03:15:48 --> Model Class Initialized
INFO - 2024-10-24 03:15:48 --> Helper loaded: inflector_helper
INFO - 2024-10-24 03:15:48 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:15:48 --> Helper loaded: email_helper
INFO - 2024-10-24 03:15:48 --> Model Class Initialized
INFO - 2024-10-24 03:15:48 --> Model Class Initialized
INFO - 2024-10-24 03:15:48 --> Model Class Initialized
INFO - 2024-10-24 03:15:48 --> Model Class Initialized
INFO - 2024-10-24 03:15:48 --> Model Class Initialized
INFO - 2024-10-24 03:15:48 --> Model Class Initialized
INFO - 2024-10-24 03:15:48 --> Model Class Initialized
DEBUG - 2024-10-24 03:15:48 --> Class name after strip: company
DEBUG - 2024-10-24 03:15:48 --> Is countable: false
DEBUG - 2024-10-24 03:15:48 --> Matches y-rule: true
DEBUG - 2024-10-24 03:15:48 --> Direct replacement result: companies
DEBUG - 2024-10-24 03:15:48 --> plural called with: company
DEBUG - 2024-10-24 03:15:48 --> Final plural result: company
INFO - 2024-10-24 03:15:48 --> Model Class Initialized
INFO - 2024-10-24 03:15:48 --> Model Class Initialized
INFO - 2024-10-24 03:15:48 --> Model Class Initialized
INFO - 2024-10-24 03:15:48 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-24 03:15:48 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 03:15:48 --> Final output sent to browser
DEBUG - 2024-10-24 03:15:48 --> Total execution time: 0.0269
INFO - 2024-10-24 03:15:50 --> Config Class Initialized
INFO - 2024-10-24 03:15:50 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:15:50 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:15:50 --> Utf8 Class Initialized
INFO - 2024-10-24 03:15:50 --> URI Class Initialized
INFO - 2024-10-24 03:15:50 --> Router Class Initialized
INFO - 2024-10-24 03:15:50 --> Output Class Initialized
INFO - 2024-10-24 03:15:50 --> Security Class Initialized
DEBUG - 2024-10-24 03:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:15:50 --> Input Class Initialized
INFO - 2024-10-24 03:15:50 --> Language Class Initialized
ERROR - 2024-10-24 03:15:50 --> TEST ERROR MESSAGE - 2024-10-24 03:15:50
INFO - 2024-10-24 03:15:50 --> Loader Class Initialized
INFO - 2024-10-24 03:15:50 --> Controller Class Initialized
INFO - 2024-10-24 03:15:50 --> Database Driver Class Initialized
INFO - 2024-10-24 03:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:15:50 --> Helper loaded: form_helper
INFO - 2024-10-24 03:15:50 --> Helper loaded: url_helper
INFO - 2024-10-24 03:15:50 --> Model Class Initialized
INFO - 2024-10-24 03:15:50 --> Helper loaded: inflector_helper
INFO - 2024-10-24 03:15:50 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:15:50 --> Helper loaded: email_helper
INFO - 2024-10-24 03:15:50 --> Model Class Initialized
INFO - 2024-10-24 03:15:50 --> Model Class Initialized
INFO - 2024-10-24 03:15:50 --> Model Class Initialized
INFO - 2024-10-24 03:15:50 --> Model Class Initialized
INFO - 2024-10-24 03:15:50 --> Model Class Initialized
INFO - 2024-10-24 03:15:50 --> Model Class Initialized
INFO - 2024-10-24 03:15:50 --> Model Class Initialized
DEBUG - 2024-10-24 03:15:50 --> Class name after strip: company
DEBUG - 2024-10-24 03:15:50 --> Is countable: false
DEBUG - 2024-10-24 03:15:50 --> Matches y-rule: true
DEBUG - 2024-10-24 03:15:50 --> Direct replacement result: companies
DEBUG - 2024-10-24 03:15:50 --> plural called with: company
DEBUG - 2024-10-24 03:15:50 --> Final plural result: company
INFO - 2024-10-24 03:15:50 --> Model Class Initialized
INFO - 2024-10-24 03:15:50 --> Model Class Initialized
INFO - 2024-10-24 03:15:50 --> Model Class Initialized
ERROR - 2024-10-24 03:15:50 --> Query error: Table 'tillmezo_a.company' doesn't exist - Invalid query: SELECT *
FROM `company`
WHERE `login` = 'admin2'
AND `password` = 'til794613'
INFO - 2024-10-24 03:15:50 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-24 03:19:15 --> Config Class Initialized
INFO - 2024-10-24 03:19:15 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:19:15 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:19:15 --> Utf8 Class Initialized
INFO - 2024-10-24 03:19:15 --> URI Class Initialized
INFO - 2024-10-24 03:19:15 --> Router Class Initialized
INFO - 2024-10-24 03:19:15 --> Output Class Initialized
INFO - 2024-10-24 03:19:15 --> Security Class Initialized
DEBUG - 2024-10-24 03:19:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:19:15 --> Input Class Initialized
INFO - 2024-10-24 03:19:15 --> Language Class Initialized
ERROR - 2024-10-24 03:19:15 --> TEST ERROR MESSAGE - 2024-10-24 03:19:15
INFO - 2024-10-24 03:19:15 --> Loader Class Initialized
INFO - 2024-10-24 03:19:15 --> Controller Class Initialized
INFO - 2024-10-24 03:19:15 --> Database Driver Class Initialized
INFO - 2024-10-24 03:19:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:19:15 --> Helper loaded: form_helper
INFO - 2024-10-24 03:19:15 --> Helper loaded: url_helper
INFO - 2024-10-24 03:19:15 --> Model Class Initialized
INFO - 2024-10-24 03:19:15 --> Helper loaded: inflector_helper
INFO - 2024-10-24 03:19:15 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:19:15 --> Helper loaded: email_helper
INFO - 2024-10-24 03:19:15 --> Model Class Initialized
INFO - 2024-10-24 03:19:15 --> Model Class Initialized
INFO - 2024-10-24 03:19:15 --> Model Class Initialized
INFO - 2024-10-24 03:19:15 --> Model Class Initialized
INFO - 2024-10-24 03:19:15 --> Model Class Initialized
INFO - 2024-10-24 03:19:15 --> Model Class Initialized
INFO - 2024-10-24 03:19:15 --> Model Class Initialized
DEBUG - 2024-10-24 03:19:15 --> Class name after strip: company
DEBUG - 2024-10-24 03:19:15 --> Is countable: false
DEBUG - 2024-10-24 03:19:15 --> Matches y-rule: true
DEBUG - 2024-10-24 03:19:15 --> Direct replacement result: companies
DEBUG - 2024-10-24 03:19:15 --> plural called with: company
DEBUG - 2024-10-24 03:19:15 --> Final plural result: company
INFO - 2024-10-24 03:19:15 --> Model Class Initialized
INFO - 2024-10-24 03:19:15 --> Model Class Initialized
INFO - 2024-10-24 03:19:15 --> Model Class Initialized
INFO - 2024-10-24 03:19:15 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-24 03:19:15 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 03:19:15 --> Final output sent to browser
DEBUG - 2024-10-24 03:19:15 --> Total execution time: 0.0251
INFO - 2024-10-24 03:19:17 --> Config Class Initialized
INFO - 2024-10-24 03:19:17 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:19:17 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:19:17 --> Utf8 Class Initialized
INFO - 2024-10-24 03:19:17 --> URI Class Initialized
INFO - 2024-10-24 03:19:17 --> Router Class Initialized
INFO - 2024-10-24 03:19:17 --> Output Class Initialized
INFO - 2024-10-24 03:19:17 --> Security Class Initialized
DEBUG - 2024-10-24 03:19:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:19:17 --> Input Class Initialized
INFO - 2024-10-24 03:19:17 --> Language Class Initialized
ERROR - 2024-10-24 03:19:17 --> TEST ERROR MESSAGE - 2024-10-24 03:19:17
INFO - 2024-10-24 03:19:17 --> Loader Class Initialized
INFO - 2024-10-24 03:19:17 --> Controller Class Initialized
INFO - 2024-10-24 03:19:17 --> Database Driver Class Initialized
INFO - 2024-10-24 03:19:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:19:17 --> Helper loaded: form_helper
INFO - 2024-10-24 03:19:17 --> Helper loaded: url_helper
INFO - 2024-10-24 03:19:17 --> Model Class Initialized
INFO - 2024-10-24 03:19:17 --> Helper loaded: inflector_helper
INFO - 2024-10-24 03:19:17 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:19:17 --> Helper loaded: email_helper
INFO - 2024-10-24 03:19:17 --> Model Class Initialized
INFO - 2024-10-24 03:19:17 --> Model Class Initialized
INFO - 2024-10-24 03:19:17 --> Model Class Initialized
INFO - 2024-10-24 03:19:17 --> Model Class Initialized
INFO - 2024-10-24 03:19:17 --> Model Class Initialized
INFO - 2024-10-24 03:19:17 --> Model Class Initialized
INFO - 2024-10-24 03:19:17 --> Model Class Initialized
DEBUG - 2024-10-24 03:19:17 --> Class name after strip: company
DEBUG - 2024-10-24 03:19:17 --> Is countable: false
DEBUG - 2024-10-24 03:19:17 --> Matches y-rule: true
DEBUG - 2024-10-24 03:19:17 --> Direct replacement result: companies
DEBUG - 2024-10-24 03:19:17 --> plural called with: company
DEBUG - 2024-10-24 03:19:17 --> Final plural result: company
INFO - 2024-10-24 03:19:17 --> Model Class Initialized
INFO - 2024-10-24 03:19:17 --> Model Class Initialized
INFO - 2024-10-24 03:19:17 --> Model Class Initialized
ERROR - 2024-10-24 03:19:17 --> Query error: Table 'tillmezo_a.company' doesn't exist - Invalid query: SELECT *
FROM `company`
WHERE `login` = 'admin2'
AND `password` = 'til794613'
INFO - 2024-10-24 03:19:17 --> Language file loaded: language/english/db_lang.php
INFO - 2024-10-24 03:28:57 --> Config Class Initialized
INFO - 2024-10-24 03:28:57 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:28:57 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:28:57 --> Utf8 Class Initialized
INFO - 2024-10-24 03:28:57 --> URI Class Initialized
INFO - 2024-10-24 03:28:57 --> Router Class Initialized
INFO - 2024-10-24 03:28:57 --> Output Class Initialized
INFO - 2024-10-24 03:28:57 --> Security Class Initialized
DEBUG - 2024-10-24 03:28:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:28:57 --> Input Class Initialized
INFO - 2024-10-24 03:28:57 --> Language Class Initialized
ERROR - 2024-10-24 03:28:57 --> TEST ERROR MESSAGE - 2024-10-24 03:28:57
INFO - 2024-10-24 03:28:57 --> Loader Class Initialized
INFO - 2024-10-24 03:28:57 --> Controller Class Initialized
INFO - 2024-10-24 03:28:57 --> Database Driver Class Initialized
INFO - 2024-10-24 03:28:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:28:57 --> Helper loaded: form_helper
INFO - 2024-10-24 03:28:57 --> Helper loaded: url_helper
INFO - 2024-10-24 03:28:57 --> Model Class Initialized
INFO - 2024-10-24 03:28:57 --> Helper loaded: inflector_helper
INFO - 2024-10-24 03:28:57 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:28:57 --> Helper loaded: email_helper
INFO - 2024-10-24 03:28:57 --> Model Class Initialized
INFO - 2024-10-24 03:28:57 --> Model Class Initialized
INFO - 2024-10-24 03:28:57 --> Model Class Initialized
INFO - 2024-10-24 03:28:57 --> Model Class Initialized
INFO - 2024-10-24 03:28:57 --> Model Class Initialized
INFO - 2024-10-24 03:28:57 --> Model Class Initialized
INFO - 2024-10-24 03:28:57 --> Model Class Initialized
DEBUG - 2024-10-24 03:28:57 --> Class name after strip: company
DEBUG - 2024-10-24 03:28:57 --> Is countable: false
DEBUG - 2024-10-24 03:28:57 --> Matches y-rule: true
DEBUG - 2024-10-24 03:28:57 --> Direct replacement result: companies
DEBUG - 2024-10-24 03:28:57 --> plural called with: company
DEBUG - 2024-10-24 03:28:57 --> is_countable called with!!!!: company
DEBUG - 2024-10-24 03:28:57 --> Final plural result: companies
INFO - 2024-10-24 03:28:57 --> Model Class Initialized
INFO - 2024-10-24 03:28:57 --> Model Class Initialized
INFO - 2024-10-24 03:28:57 --> Model Class Initialized
INFO - 2024-10-24 03:28:57 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-24 03:28:57 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 03:28:57 --> Final output sent to browser
DEBUG - 2024-10-24 03:28:57 --> Total execution time: 0.0265
INFO - 2024-10-24 03:28:59 --> Config Class Initialized
INFO - 2024-10-24 03:28:59 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:28:59 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:28:59 --> Utf8 Class Initialized
INFO - 2024-10-24 03:28:59 --> URI Class Initialized
INFO - 2024-10-24 03:28:59 --> Router Class Initialized
INFO - 2024-10-24 03:28:59 --> Output Class Initialized
INFO - 2024-10-24 03:28:59 --> Security Class Initialized
DEBUG - 2024-10-24 03:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:28:59 --> Input Class Initialized
INFO - 2024-10-24 03:28:59 --> Language Class Initialized
ERROR - 2024-10-24 03:28:59 --> TEST ERROR MESSAGE - 2024-10-24 03:28:59
INFO - 2024-10-24 03:28:59 --> Loader Class Initialized
INFO - 2024-10-24 03:28:59 --> Controller Class Initialized
INFO - 2024-10-24 03:28:59 --> Database Driver Class Initialized
INFO - 2024-10-24 03:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:28:59 --> Helper loaded: form_helper
INFO - 2024-10-24 03:28:59 --> Helper loaded: url_helper
INFO - 2024-10-24 03:28:59 --> Model Class Initialized
INFO - 2024-10-24 03:28:59 --> Helper loaded: inflector_helper
INFO - 2024-10-24 03:28:59 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:28:59 --> Helper loaded: email_helper
INFO - 2024-10-24 03:28:59 --> Model Class Initialized
INFO - 2024-10-24 03:28:59 --> Model Class Initialized
INFO - 2024-10-24 03:28:59 --> Model Class Initialized
INFO - 2024-10-24 03:28:59 --> Model Class Initialized
INFO - 2024-10-24 03:28:59 --> Model Class Initialized
INFO - 2024-10-24 03:28:59 --> Model Class Initialized
INFO - 2024-10-24 03:28:59 --> Model Class Initialized
DEBUG - 2024-10-24 03:28:59 --> Class name after strip: company
DEBUG - 2024-10-24 03:28:59 --> Is countable: false
DEBUG - 2024-10-24 03:28:59 --> Matches y-rule: true
DEBUG - 2024-10-24 03:28:59 --> Direct replacement result: companies
DEBUG - 2024-10-24 03:28:59 --> plural called with: company
DEBUG - 2024-10-24 03:28:59 --> is_countable called with!!!!: company
DEBUG - 2024-10-24 03:28:59 --> Final plural result: companies
INFO - 2024-10-24 03:28:59 --> Model Class Initialized
INFO - 2024-10-24 03:28:59 --> Model Class Initialized
INFO - 2024-10-24 03:28:59 --> Model Class Initialized
INFO - 2024-10-24 03:28:59 --> Config Class Initialized
INFO - 2024-10-24 03:28:59 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:28:59 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:28:59 --> Utf8 Class Initialized
INFO - 2024-10-24 03:28:59 --> URI Class Initialized
INFO - 2024-10-24 03:28:59 --> Router Class Initialized
INFO - 2024-10-24 03:28:59 --> Output Class Initialized
INFO - 2024-10-24 03:28:59 --> Security Class Initialized
DEBUG - 2024-10-24 03:28:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:28:59 --> Input Class Initialized
INFO - 2024-10-24 03:28:59 --> Language Class Initialized
ERROR - 2024-10-24 03:28:59 --> TEST ERROR MESSAGE - 2024-10-24 03:28:59
INFO - 2024-10-24 03:28:59 --> Loader Class Initialized
INFO - 2024-10-24 03:28:59 --> Controller Class Initialized
INFO - 2024-10-24 03:28:59 --> Database Driver Class Initialized
INFO - 2024-10-24 03:28:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:28:59 --> Helper loaded: form_helper
INFO - 2024-10-24 03:28:59 --> Helper loaded: url_helper
INFO - 2024-10-24 03:28:59 --> Model Class Initialized
INFO - 2024-10-24 03:28:59 --> Helper loaded: inflector_helper
INFO - 2024-10-24 03:28:59 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:28:59 --> Helper loaded: email_helper
INFO - 2024-10-24 03:28:59 --> Model Class Initialized
INFO - 2024-10-24 03:28:59 --> Model Class Initialized
INFO - 2024-10-24 03:28:59 --> Model Class Initialized
INFO - 2024-10-24 03:28:59 --> Model Class Initialized
INFO - 2024-10-24 03:28:59 --> Model Class Initialized
INFO - 2024-10-24 03:28:59 --> Model Class Initialized
INFO - 2024-10-24 03:28:59 --> Model Class Initialized
DEBUG - 2024-10-24 03:28:59 --> Class name after strip: company
DEBUG - 2024-10-24 03:28:59 --> Is countable: false
DEBUG - 2024-10-24 03:28:59 --> Matches y-rule: true
DEBUG - 2024-10-24 03:28:59 --> Direct replacement result: companies
DEBUG - 2024-10-24 03:28:59 --> plural called with: company
DEBUG - 2024-10-24 03:28:59 --> is_countable called with!!!!: company
DEBUG - 2024-10-24 03:28:59 --> Final plural result: companies
INFO - 2024-10-24 03:28:59 --> Model Class Initialized
INFO - 2024-10-24 03:28:59 --> Model Class Initialized
INFO - 2024-10-24 03:28:59 --> Model Class Initialized
ERROR - 2024-10-24 03:29:02 --> Severity: Notice --> Undefined index: freetext /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 03:29:02 --> Severity: Notice --> Undefined index: socialDes /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 03:29:02 --> Severity: Notice --> Undefined index: company /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 03:29:02 --> Severity: Notice --> Undefined index: division /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 03:29:02 --> Severity: Notice --> Undefined index: dataGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 03:29:02 --> Severity: Notice --> Undefined index: finalGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
INFO - 2024-10-24 03:29:02 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 03:29:02 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 03:29:02 --> Final output sent to browser
DEBUG - 2024-10-24 03:29:02 --> Total execution time: 2.7171
INFO - 2024-10-24 03:30:15 --> Config Class Initialized
INFO - 2024-10-24 03:30:15 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:30:15 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:30:15 --> Utf8 Class Initialized
INFO - 2024-10-24 03:30:15 --> URI Class Initialized
INFO - 2024-10-24 03:30:15 --> Router Class Initialized
INFO - 2024-10-24 03:30:15 --> Output Class Initialized
INFO - 2024-10-24 03:30:15 --> Security Class Initialized
DEBUG - 2024-10-24 03:30:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:30:15 --> Input Class Initialized
INFO - 2024-10-24 03:30:15 --> Language Class Initialized
ERROR - 2024-10-24 03:30:15 --> TEST ERROR MESSAGE - 2024-10-24 03:30:15
INFO - 2024-10-24 03:30:15 --> Loader Class Initialized
INFO - 2024-10-24 03:30:15 --> Controller Class Initialized
INFO - 2024-10-24 03:30:15 --> Database Driver Class Initialized
INFO - 2024-10-24 03:30:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:30:15 --> Helper loaded: form_helper
INFO - 2024-10-24 03:30:15 --> Helper loaded: url_helper
INFO - 2024-10-24 03:30:15 --> Model Class Initialized
INFO - 2024-10-24 03:30:15 --> Helper loaded: inflector_helper
INFO - 2024-10-24 03:30:15 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:30:15 --> Helper loaded: email_helper
INFO - 2024-10-24 03:30:15 --> Model Class Initialized
INFO - 2024-10-24 03:30:15 --> Model Class Initialized
INFO - 2024-10-24 03:30:15 --> Model Class Initialized
INFO - 2024-10-24 03:30:15 --> Model Class Initialized
INFO - 2024-10-24 03:30:15 --> Model Class Initialized
INFO - 2024-10-24 03:30:15 --> Model Class Initialized
INFO - 2024-10-24 03:30:15 --> Model Class Initialized
DEBUG - 2024-10-24 03:30:15 --> Class name after strip: company
DEBUG - 2024-10-24 03:30:15 --> Is countable: false
DEBUG - 2024-10-24 03:30:15 --> Matches y-rule: true
DEBUG - 2024-10-24 03:30:15 --> Direct replacement result: companies
DEBUG - 2024-10-24 03:30:15 --> plural called with: company
DEBUG - 2024-10-24 03:30:15 --> is_countable called with!!!!: company
DEBUG - 2024-10-24 03:30:15 --> Final plural result: companies
INFO - 2024-10-24 03:30:15 --> Model Class Initialized
INFO - 2024-10-24 03:30:15 --> Model Class Initialized
INFO - 2024-10-24 03:30:15 --> Model Class Initialized
INFO - 2024-10-24 03:30:15 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 03:30:15 --> Final output sent to browser
DEBUG - 2024-10-24 03:30:15 --> Total execution time: 0.0278
INFO - 2024-10-24 03:31:50 --> Config Class Initialized
INFO - 2024-10-24 03:31:50 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:31:50 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:31:50 --> Utf8 Class Initialized
INFO - 2024-10-24 03:31:50 --> URI Class Initialized
INFO - 2024-10-24 03:31:50 --> Router Class Initialized
INFO - 2024-10-24 03:31:50 --> Output Class Initialized
INFO - 2024-10-24 03:31:50 --> Security Class Initialized
DEBUG - 2024-10-24 03:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:31:50 --> Input Class Initialized
INFO - 2024-10-24 03:31:50 --> Language Class Initialized
ERROR - 2024-10-24 03:31:50 --> TEST ERROR MESSAGE - 2024-10-24 03:31:50
INFO - 2024-10-24 03:31:50 --> Loader Class Initialized
INFO - 2024-10-24 03:31:50 --> Controller Class Initialized
INFO - 2024-10-24 03:31:50 --> Database Driver Class Initialized
INFO - 2024-10-24 03:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:31:50 --> Helper loaded: form_helper
INFO - 2024-10-24 03:31:50 --> Helper loaded: url_helper
INFO - 2024-10-24 03:31:50 --> Model Class Initialized
INFO - 2024-10-24 03:31:50 --> Helper loaded: inflector_helper
INFO - 2024-10-24 03:31:50 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:31:50 --> Helper loaded: email_helper
INFO - 2024-10-24 03:31:50 --> Model Class Initialized
INFO - 2024-10-24 03:31:50 --> Model Class Initialized
INFO - 2024-10-24 03:31:50 --> Model Class Initialized
INFO - 2024-10-24 03:31:50 --> Model Class Initialized
INFO - 2024-10-24 03:31:50 --> Model Class Initialized
INFO - 2024-10-24 03:31:50 --> Model Class Initialized
INFO - 2024-10-24 03:31:50 --> Model Class Initialized
DEBUG - 2024-10-24 03:31:50 --> Class name after strip: company
DEBUG - 2024-10-24 03:31:50 --> Is countable: false
DEBUG - 2024-10-24 03:31:50 --> Matches y-rule: true
DEBUG - 2024-10-24 03:31:50 --> Direct replacement result: companies
DEBUG - 2024-10-24 03:31:50 --> plural called with: company
DEBUG - 2024-10-24 03:31:50 --> is_countable called with!!!!: company
DEBUG - 2024-10-24 03:31:50 --> Final plural result: companies
INFO - 2024-10-24 03:31:50 --> Model Class Initialized
INFO - 2024-10-24 03:31:50 --> Model Class Initialized
INFO - 2024-10-24 03:31:50 --> Model Class Initialized
INFO - 2024-10-24 03:31:50 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 03:31:50 --> Final output sent to browser
DEBUG - 2024-10-24 03:31:50 --> Total execution time: 0.0267
INFO - 2024-10-24 03:31:56 --> Config Class Initialized
INFO - 2024-10-24 03:31:56 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:31:56 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:31:56 --> Utf8 Class Initialized
INFO - 2024-10-24 03:31:56 --> URI Class Initialized
INFO - 2024-10-24 03:31:56 --> Router Class Initialized
INFO - 2024-10-24 03:31:56 --> Output Class Initialized
INFO - 2024-10-24 03:31:56 --> Security Class Initialized
DEBUG - 2024-10-24 03:31:56 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:31:56 --> Input Class Initialized
INFO - 2024-10-24 03:31:56 --> Language Class Initialized
ERROR - 2024-10-24 03:31:56 --> TEST ERROR MESSAGE - 2024-10-24 03:31:56
INFO - 2024-10-24 03:31:56 --> Loader Class Initialized
INFO - 2024-10-24 03:31:56 --> Controller Class Initialized
INFO - 2024-10-24 03:31:56 --> Database Driver Class Initialized
INFO - 2024-10-24 03:31:56 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:31:56 --> Helper loaded: form_helper
INFO - 2024-10-24 03:31:56 --> Helper loaded: url_helper
INFO - 2024-10-24 03:31:56 --> Model Class Initialized
INFO - 2024-10-24 03:31:56 --> Helper loaded: inflector_helper
INFO - 2024-10-24 03:31:56 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:31:56 --> Helper loaded: email_helper
INFO - 2024-10-24 03:31:56 --> Model Class Initialized
INFO - 2024-10-24 03:31:56 --> Model Class Initialized
INFO - 2024-10-24 03:31:56 --> Model Class Initialized
INFO - 2024-10-24 03:31:56 --> Model Class Initialized
INFO - 2024-10-24 03:31:56 --> Model Class Initialized
INFO - 2024-10-24 03:31:56 --> Model Class Initialized
INFO - 2024-10-24 03:31:56 --> Model Class Initialized
DEBUG - 2024-10-24 03:31:56 --> Class name after strip: company
DEBUG - 2024-10-24 03:31:56 --> Is countable: false
DEBUG - 2024-10-24 03:31:56 --> Matches y-rule: true
DEBUG - 2024-10-24 03:31:56 --> Direct replacement result: companies
DEBUG - 2024-10-24 03:31:56 --> plural called with: company
DEBUG - 2024-10-24 03:31:56 --> is_countable called with!!!!: company
DEBUG - 2024-10-24 03:31:56 --> Final plural result: companies
INFO - 2024-10-24 03:31:56 --> Model Class Initialized
INFO - 2024-10-24 03:31:56 --> Model Class Initialized
INFO - 2024-10-24 03:31:56 --> Model Class Initialized
INFO - 2024-10-24 03:31:58 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 03:31:58 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 03:31:58 --> Final output sent to browser
DEBUG - 2024-10-24 03:31:58 --> Total execution time: 1.9605
INFO - 2024-10-24 03:32:11 --> Config Class Initialized
INFO - 2024-10-24 03:32:11 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:32:11 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:32:11 --> Utf8 Class Initialized
INFO - 2024-10-24 03:32:11 --> URI Class Initialized
INFO - 2024-10-24 03:32:11 --> Router Class Initialized
INFO - 2024-10-24 03:32:11 --> Output Class Initialized
INFO - 2024-10-24 03:32:11 --> Security Class Initialized
DEBUG - 2024-10-24 03:32:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:32:11 --> Input Class Initialized
INFO - 2024-10-24 03:32:11 --> Language Class Initialized
ERROR - 2024-10-24 03:32:11 --> TEST ERROR MESSAGE - 2024-10-24 03:32:11
INFO - 2024-10-24 03:32:11 --> Loader Class Initialized
INFO - 2024-10-24 03:32:11 --> Controller Class Initialized
INFO - 2024-10-24 03:32:11 --> Database Driver Class Initialized
INFO - 2024-10-24 03:32:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:32:11 --> Helper loaded: form_helper
INFO - 2024-10-24 03:32:11 --> Helper loaded: url_helper
INFO - 2024-10-24 03:32:11 --> Model Class Initialized
INFO - 2024-10-24 03:32:11 --> Helper loaded: inflector_helper
INFO - 2024-10-24 03:32:11 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:32:11 --> Helper loaded: email_helper
INFO - 2024-10-24 03:32:11 --> Model Class Initialized
INFO - 2024-10-24 03:32:11 --> Model Class Initialized
INFO - 2024-10-24 03:32:11 --> Model Class Initialized
INFO - 2024-10-24 03:32:11 --> Model Class Initialized
INFO - 2024-10-24 03:32:11 --> Model Class Initialized
INFO - 2024-10-24 03:32:11 --> Model Class Initialized
INFO - 2024-10-24 03:32:11 --> Model Class Initialized
DEBUG - 2024-10-24 03:32:11 --> Class name after strip: company
DEBUG - 2024-10-24 03:32:11 --> Is countable: false
DEBUG - 2024-10-24 03:32:11 --> Matches y-rule: true
DEBUG - 2024-10-24 03:32:11 --> Direct replacement result: companies
DEBUG - 2024-10-24 03:32:11 --> plural called with: company
DEBUG - 2024-10-24 03:32:11 --> is_countable called with!!!!: company
DEBUG - 2024-10-24 03:32:11 --> Final plural result: companies
INFO - 2024-10-24 03:32:11 --> Model Class Initialized
INFO - 2024-10-24 03:32:11 --> Model Class Initialized
INFO - 2024-10-24 03:32:11 --> Model Class Initialized
INFO - 2024-10-24 03:32:15 --> Config Class Initialized
INFO - 2024-10-24 03:32:15 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:32:15 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:32:15 --> Utf8 Class Initialized
INFO - 2024-10-24 03:32:15 --> URI Class Initialized
INFO - 2024-10-24 03:32:15 --> Router Class Initialized
INFO - 2024-10-24 03:32:15 --> Output Class Initialized
INFO - 2024-10-24 03:32:15 --> Security Class Initialized
DEBUG - 2024-10-24 03:32:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:32:15 --> Input Class Initialized
INFO - 2024-10-24 03:32:15 --> Language Class Initialized
ERROR - 2024-10-24 03:32:15 --> TEST ERROR MESSAGE - 2024-10-24 03:32:15
INFO - 2024-10-24 03:32:15 --> Loader Class Initialized
INFO - 2024-10-24 03:32:15 --> Controller Class Initialized
INFO - 2024-10-24 03:32:15 --> Database Driver Class Initialized
INFO - 2024-10-24 03:32:20 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 03:32:20 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 03:32:20 --> Final output sent to browser
DEBUG - 2024-10-24 03:32:20 --> Total execution time: 9.7018
INFO - 2024-10-24 03:32:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:32:20 --> Helper loaded: form_helper
INFO - 2024-10-24 03:32:20 --> Helper loaded: url_helper
INFO - 2024-10-24 03:32:20 --> Model Class Initialized
INFO - 2024-10-24 03:32:20 --> Helper loaded: inflector_helper
INFO - 2024-10-24 03:32:20 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:32:20 --> Helper loaded: email_helper
INFO - 2024-10-24 03:32:20 --> Model Class Initialized
INFO - 2024-10-24 03:32:20 --> Model Class Initialized
INFO - 2024-10-24 03:32:20 --> Model Class Initialized
INFO - 2024-10-24 03:32:20 --> Model Class Initialized
INFO - 2024-10-24 03:32:20 --> Model Class Initialized
INFO - 2024-10-24 03:32:20 --> Model Class Initialized
INFO - 2024-10-24 03:32:20 --> Model Class Initialized
DEBUG - 2024-10-24 03:32:20 --> Class name after strip: company
DEBUG - 2024-10-24 03:32:20 --> Is countable: false
DEBUG - 2024-10-24 03:32:20 --> Matches y-rule: true
DEBUG - 2024-10-24 03:32:20 --> Direct replacement result: companies
DEBUG - 2024-10-24 03:32:20 --> plural called with: company
DEBUG - 2024-10-24 03:32:20 --> is_countable called with!!!!: company
DEBUG - 2024-10-24 03:32:20 --> Final plural result: companies
INFO - 2024-10-24 03:32:20 --> Model Class Initialized
INFO - 2024-10-24 03:32:20 --> Model Class Initialized
INFO - 2024-10-24 03:32:20 --> Model Class Initialized
INFO - 2024-10-24 03:32:30 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 03:32:30 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 03:32:30 --> Final output sent to browser
DEBUG - 2024-10-24 03:32:30 --> Total execution time: 14.9957
INFO - 2024-10-24 03:33:51 --> Config Class Initialized
INFO - 2024-10-24 03:33:51 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:33:51 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:33:51 --> Utf8 Class Initialized
INFO - 2024-10-24 03:33:51 --> URI Class Initialized
INFO - 2024-10-24 03:33:51 --> Router Class Initialized
INFO - 2024-10-24 03:33:51 --> Output Class Initialized
INFO - 2024-10-24 03:33:51 --> Security Class Initialized
DEBUG - 2024-10-24 03:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:33:51 --> Input Class Initialized
INFO - 2024-10-24 03:33:51 --> Language Class Initialized
ERROR - 2024-10-24 03:33:51 --> TEST ERROR MESSAGE - 2024-10-24 03:33:51
INFO - 2024-10-24 03:33:51 --> Loader Class Initialized
INFO - 2024-10-24 03:33:51 --> Controller Class Initialized
INFO - 2024-10-24 03:33:51 --> Database Driver Class Initialized
INFO - 2024-10-24 03:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:33:51 --> Helper loaded: form_helper
INFO - 2024-10-24 03:33:51 --> Helper loaded: url_helper
INFO - 2024-10-24 03:33:51 --> Model Class Initialized
INFO - 2024-10-24 03:33:51 --> Helper loaded: inflector_helper
INFO - 2024-10-24 03:33:51 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:33:51 --> Helper loaded: email_helper
INFO - 2024-10-24 03:33:51 --> Model Class Initialized
INFO - 2024-10-24 03:33:51 --> Model Class Initialized
INFO - 2024-10-24 03:33:51 --> Model Class Initialized
INFO - 2024-10-24 03:33:51 --> Model Class Initialized
INFO - 2024-10-24 03:33:51 --> Model Class Initialized
INFO - 2024-10-24 03:33:51 --> Model Class Initialized
INFO - 2024-10-24 03:33:51 --> Model Class Initialized
DEBUG - 2024-10-24 03:33:51 --> Class name after strip: company
DEBUG - 2024-10-24 03:33:51 --> Is countable: false
DEBUG - 2024-10-24 03:33:51 --> Matches y-rule: true
DEBUG - 2024-10-24 03:33:51 --> Direct replacement result: companies
DEBUG - 2024-10-24 03:33:51 --> plural called with: company
DEBUG - 2024-10-24 03:33:51 --> is_countable called with!!!!: company
DEBUG - 2024-10-24 03:33:51 --> Final plural result: companies
INFO - 2024-10-24 03:33:51 --> Model Class Initialized
INFO - 2024-10-24 03:33:51 --> Model Class Initialized
INFO - 2024-10-24 03:33:51 --> Model Class Initialized
INFO - 2024-10-24 03:33:51 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 03:33:51 --> Final output sent to browser
DEBUG - 2024-10-24 03:33:51 --> Total execution time: 0.0300
INFO - 2024-10-24 03:33:51 --> Config Class Initialized
INFO - 2024-10-24 03:33:51 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:33:51 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:33:51 --> Utf8 Class Initialized
INFO - 2024-10-24 03:33:51 --> URI Class Initialized
INFO - 2024-10-24 03:33:51 --> Router Class Initialized
INFO - 2024-10-24 03:33:51 --> Output Class Initialized
INFO - 2024-10-24 03:33:51 --> Security Class Initialized
DEBUG - 2024-10-24 03:33:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:33:51 --> Input Class Initialized
INFO - 2024-10-24 03:33:51 --> Language Class Initialized
ERROR - 2024-10-24 03:33:51 --> TEST ERROR MESSAGE - 2024-10-24 03:33:51
INFO - 2024-10-24 03:33:51 --> Loader Class Initialized
INFO - 2024-10-24 03:33:51 --> Controller Class Initialized
INFO - 2024-10-24 03:33:51 --> Database Driver Class Initialized
INFO - 2024-10-24 03:33:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:33:51 --> Helper loaded: form_helper
INFO - 2024-10-24 03:33:51 --> Helper loaded: url_helper
INFO - 2024-10-24 03:33:51 --> Model Class Initialized
INFO - 2024-10-24 03:33:51 --> Helper loaded: inflector_helper
INFO - 2024-10-24 03:33:51 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:33:51 --> Helper loaded: email_helper
INFO - 2024-10-24 03:33:51 --> Model Class Initialized
INFO - 2024-10-24 03:33:51 --> Model Class Initialized
INFO - 2024-10-24 03:33:51 --> Model Class Initialized
INFO - 2024-10-24 03:33:51 --> Model Class Initialized
INFO - 2024-10-24 03:33:51 --> Model Class Initialized
INFO - 2024-10-24 03:33:51 --> Model Class Initialized
INFO - 2024-10-24 03:33:51 --> Model Class Initialized
DEBUG - 2024-10-24 03:33:51 --> Class name after strip: company
DEBUG - 2024-10-24 03:33:51 --> Is countable: false
DEBUG - 2024-10-24 03:33:51 --> Matches y-rule: true
DEBUG - 2024-10-24 03:33:51 --> Direct replacement result: companies
DEBUG - 2024-10-24 03:33:51 --> plural called with: company
DEBUG - 2024-10-24 03:33:51 --> is_countable called with!!!!: company
DEBUG - 2024-10-24 03:33:51 --> Final plural result: companies
INFO - 2024-10-24 03:33:51 --> Model Class Initialized
INFO - 2024-10-24 03:33:51 --> Model Class Initialized
INFO - 2024-10-24 03:33:51 --> Model Class Initialized
INFO - 2024-10-24 03:33:51 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 03:33:51 --> Final output sent to browser
DEBUG - 2024-10-24 03:33:51 --> Total execution time: 0.0241
INFO - 2024-10-24 03:35:34 --> Config Class Initialized
INFO - 2024-10-24 03:35:34 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:35:34 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:35:34 --> Utf8 Class Initialized
INFO - 2024-10-24 03:35:34 --> URI Class Initialized
INFO - 2024-10-24 03:35:34 --> Router Class Initialized
INFO - 2024-10-24 03:35:34 --> Output Class Initialized
INFO - 2024-10-24 03:35:34 --> Security Class Initialized
DEBUG - 2024-10-24 03:35:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:35:34 --> Input Class Initialized
INFO - 2024-10-24 03:35:34 --> Language Class Initialized
ERROR - 2024-10-24 03:35:34 --> TEST ERROR MESSAGE - 2024-10-24 03:35:34
INFO - 2024-10-24 03:35:34 --> Loader Class Initialized
INFO - 2024-10-24 03:35:34 --> Controller Class Initialized
INFO - 2024-10-24 03:35:34 --> Database Driver Class Initialized
INFO - 2024-10-24 03:35:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:35:34 --> Helper loaded: form_helper
INFO - 2024-10-24 03:35:34 --> Helper loaded: url_helper
INFO - 2024-10-24 03:35:34 --> Model Class Initialized
INFO - 2024-10-24 03:35:34 --> Helper loaded: inflector_helper
INFO - 2024-10-24 03:35:34 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:35:34 --> Helper loaded: email_helper
INFO - 2024-10-24 03:35:34 --> Model Class Initialized
INFO - 2024-10-24 03:35:34 --> Model Class Initialized
INFO - 2024-10-24 03:35:34 --> Model Class Initialized
INFO - 2024-10-24 03:35:34 --> Model Class Initialized
INFO - 2024-10-24 03:35:34 --> Model Class Initialized
INFO - 2024-10-24 03:35:34 --> Model Class Initialized
INFO - 2024-10-24 03:35:34 --> Model Class Initialized
DEBUG - 2024-10-24 03:35:34 --> Class name after strip: company
DEBUG - 2024-10-24 03:35:34 --> Is countable: false
DEBUG - 2024-10-24 03:35:34 --> Matches y-rule: true
DEBUG - 2024-10-24 03:35:34 --> Direct replacement result: companies
DEBUG - 2024-10-24 03:35:34 --> plural called with: company
DEBUG - 2024-10-24 03:35:34 --> is_countable called with!!!!: company
DEBUG - 2024-10-24 03:35:34 --> Final plural result: companies
INFO - 2024-10-24 03:35:34 --> Model Class Initialized
INFO - 2024-10-24 03:35:34 --> Model Class Initialized
INFO - 2024-10-24 03:35:34 --> Model Class Initialized
INFO - 2024-10-24 03:35:34 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 03:35:34 --> Final output sent to browser
DEBUG - 2024-10-24 03:35:34 --> Total execution time: 0.0364
INFO - 2024-10-24 03:37:06 --> Config Class Initialized
INFO - 2024-10-24 03:37:06 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:37:06 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:37:06 --> Utf8 Class Initialized
INFO - 2024-10-24 03:37:06 --> URI Class Initialized
INFO - 2024-10-24 03:37:06 --> Router Class Initialized
INFO - 2024-10-24 03:37:06 --> Output Class Initialized
INFO - 2024-10-24 03:37:06 --> Security Class Initialized
DEBUG - 2024-10-24 03:37:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:37:06 --> Input Class Initialized
INFO - 2024-10-24 03:37:06 --> Language Class Initialized
ERROR - 2024-10-24 03:37:06 --> TEST ERROR MESSAGE - 2024-10-24 03:37:06
INFO - 2024-10-24 03:37:06 --> Loader Class Initialized
INFO - 2024-10-24 03:37:06 --> Controller Class Initialized
INFO - 2024-10-24 03:37:06 --> Database Driver Class Initialized
INFO - 2024-10-24 03:37:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:37:06 --> Helper loaded: form_helper
INFO - 2024-10-24 03:37:06 --> Helper loaded: url_helper
INFO - 2024-10-24 03:37:06 --> Model Class Initialized
INFO - 2024-10-24 03:37:06 --> Helper loaded: inflector_helper
INFO - 2024-10-24 03:37:06 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:37:06 --> Helper loaded: email_helper
INFO - 2024-10-24 03:37:06 --> Model Class Initialized
INFO - 2024-10-24 03:37:06 --> Model Class Initialized
INFO - 2024-10-24 03:37:06 --> Model Class Initialized
INFO - 2024-10-24 03:37:06 --> Model Class Initialized
INFO - 2024-10-24 03:37:06 --> Model Class Initialized
INFO - 2024-10-24 03:37:06 --> Model Class Initialized
INFO - 2024-10-24 03:37:06 --> Model Class Initialized
DEBUG - 2024-10-24 03:37:06 --> Class name after strip: company
DEBUG - 2024-10-24 03:37:06 --> Is countable: false
DEBUG - 2024-10-24 03:37:06 --> Matches y-rule: true
DEBUG - 2024-10-24 03:37:06 --> Direct replacement result: companies
DEBUG - 2024-10-24 03:37:06 --> plural called with: company
DEBUG - 2024-10-24 03:37:06 --> is_countable called with!!!!: company
DEBUG - 2024-10-24 03:37:06 --> Final plural result: companies
INFO - 2024-10-24 03:37:06 --> Model Class Initialized
INFO - 2024-10-24 03:37:06 --> Model Class Initialized
INFO - 2024-10-24 03:37:06 --> Model Class Initialized
INFO - 2024-10-24 03:37:06 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-24 03:37:06 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 03:37:06 --> Final output sent to browser
DEBUG - 2024-10-24 03:37:06 --> Total execution time: 0.0227
INFO - 2024-10-24 03:38:01 --> Config Class Initialized
INFO - 2024-10-24 03:38:01 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:38:01 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:38:01 --> Utf8 Class Initialized
INFO - 2024-10-24 03:38:01 --> URI Class Initialized
INFO - 2024-10-24 03:38:01 --> Router Class Initialized
INFO - 2024-10-24 03:38:01 --> Output Class Initialized
INFO - 2024-10-24 03:38:01 --> Security Class Initialized
DEBUG - 2024-10-24 03:38:01 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:38:01 --> Input Class Initialized
INFO - 2024-10-24 03:38:01 --> Language Class Initialized
ERROR - 2024-10-24 03:38:01 --> TEST ERROR MESSAGE - 2024-10-24 03:38:01
INFO - 2024-10-24 03:38:01 --> Loader Class Initialized
INFO - 2024-10-24 03:38:01 --> Controller Class Initialized
INFO - 2024-10-24 03:38:01 --> Database Driver Class Initialized
INFO - 2024-10-24 03:38:01 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:38:01 --> Helper loaded: form_helper
INFO - 2024-10-24 03:38:01 --> Helper loaded: url_helper
INFO - 2024-10-24 03:38:01 --> Model Class Initialized
INFO - 2024-10-24 03:38:01 --> Helper loaded: inflector_helper
INFO - 2024-10-24 03:38:01 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:38:01 --> Helper loaded: email_helper
INFO - 2024-10-24 03:38:01 --> Model Class Initialized
INFO - 2024-10-24 03:38:01 --> Model Class Initialized
INFO - 2024-10-24 03:38:01 --> Model Class Initialized
INFO - 2024-10-24 03:38:01 --> Model Class Initialized
INFO - 2024-10-24 03:38:01 --> Model Class Initialized
INFO - 2024-10-24 03:38:01 --> Model Class Initialized
INFO - 2024-10-24 03:38:01 --> Model Class Initialized
DEBUG - 2024-10-24 03:38:01 --> Class name after strip: company
DEBUG - 2024-10-24 03:38:01 --> Is countable: false
DEBUG - 2024-10-24 03:38:01 --> Matches y-rule: true
DEBUG - 2024-10-24 03:38:01 --> Direct replacement result: companies
DEBUG - 2024-10-24 03:38:01 --> plural called with: company
DEBUG - 2024-10-24 03:38:01 --> is_countable called with!!!!: company
DEBUG - 2024-10-24 03:38:01 --> Final plural result: companies
INFO - 2024-10-24 03:38:01 --> Model Class Initialized
INFO - 2024-10-24 03:38:01 --> Model Class Initialized
INFO - 2024-10-24 03:38:01 --> Model Class Initialized
INFO - 2024-10-24 03:38:01 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 03:38:01 --> Final output sent to browser
DEBUG - 2024-10-24 03:38:01 --> Total execution time: 0.0259
INFO - 2024-10-24 03:38:09 --> Config Class Initialized
INFO - 2024-10-24 03:38:09 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:38:09 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:38:09 --> Utf8 Class Initialized
INFO - 2024-10-24 03:38:09 --> URI Class Initialized
INFO - 2024-10-24 03:38:09 --> Router Class Initialized
INFO - 2024-10-24 03:38:09 --> Output Class Initialized
INFO - 2024-10-24 03:38:09 --> Security Class Initialized
DEBUG - 2024-10-24 03:38:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:38:09 --> Input Class Initialized
INFO - 2024-10-24 03:38:09 --> Language Class Initialized
ERROR - 2024-10-24 03:38:09 --> TEST ERROR MESSAGE - 2024-10-24 03:38:09
INFO - 2024-10-24 03:38:09 --> Loader Class Initialized
INFO - 2024-10-24 03:38:09 --> Controller Class Initialized
INFO - 2024-10-24 03:38:09 --> Database Driver Class Initialized
INFO - 2024-10-24 03:38:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:38:09 --> Helper loaded: form_helper
INFO - 2024-10-24 03:38:09 --> Helper loaded: url_helper
INFO - 2024-10-24 03:38:09 --> Model Class Initialized
INFO - 2024-10-24 03:38:09 --> Helper loaded: inflector_helper
INFO - 2024-10-24 03:38:09 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:38:09 --> Helper loaded: email_helper
INFO - 2024-10-24 03:38:09 --> Model Class Initialized
INFO - 2024-10-24 03:38:09 --> Model Class Initialized
INFO - 2024-10-24 03:38:09 --> Model Class Initialized
INFO - 2024-10-24 03:38:09 --> Model Class Initialized
INFO - 2024-10-24 03:38:09 --> Model Class Initialized
INFO - 2024-10-24 03:38:09 --> Model Class Initialized
INFO - 2024-10-24 03:38:09 --> Model Class Initialized
DEBUG - 2024-10-24 03:38:09 --> Class name after strip: company
DEBUG - 2024-10-24 03:38:09 --> Is countable: false
DEBUG - 2024-10-24 03:38:09 --> Matches y-rule: true
DEBUG - 2024-10-24 03:38:09 --> Direct replacement result: companies
DEBUG - 2024-10-24 03:38:09 --> plural called with: company
DEBUG - 2024-10-24 03:38:09 --> is_countable called with!!!!: company
DEBUG - 2024-10-24 03:38:09 --> Final plural result: companies
INFO - 2024-10-24 03:38:09 --> Model Class Initialized
INFO - 2024-10-24 03:38:09 --> Model Class Initialized
INFO - 2024-10-24 03:38:09 --> Model Class Initialized
INFO - 2024-10-24 03:38:09 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 03:38:09 --> Final output sent to browser
DEBUG - 2024-10-24 03:38:09 --> Total execution time: 0.0230
INFO - 2024-10-24 03:38:13 --> Config Class Initialized
INFO - 2024-10-24 03:38:13 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:38:13 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:38:13 --> Utf8 Class Initialized
INFO - 2024-10-24 03:38:13 --> URI Class Initialized
INFO - 2024-10-24 03:38:13 --> Router Class Initialized
INFO - 2024-10-24 03:38:13 --> Output Class Initialized
INFO - 2024-10-24 03:38:13 --> Security Class Initialized
DEBUG - 2024-10-24 03:38:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:38:13 --> Input Class Initialized
INFO - 2024-10-24 03:38:13 --> Language Class Initialized
ERROR - 2024-10-24 03:38:13 --> TEST ERROR MESSAGE - 2024-10-24 03:38:13
INFO - 2024-10-24 03:38:13 --> Loader Class Initialized
INFO - 2024-10-24 03:38:13 --> Controller Class Initialized
INFO - 2024-10-24 03:38:13 --> Database Driver Class Initialized
INFO - 2024-10-24 03:38:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:38:13 --> Helper loaded: form_helper
INFO - 2024-10-24 03:38:13 --> Helper loaded: url_helper
INFO - 2024-10-24 03:38:13 --> Model Class Initialized
INFO - 2024-10-24 03:38:13 --> Helper loaded: inflector_helper
INFO - 2024-10-24 03:38:13 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:38:13 --> Helper loaded: email_helper
INFO - 2024-10-24 03:38:13 --> Model Class Initialized
INFO - 2024-10-24 03:38:13 --> Model Class Initialized
INFO - 2024-10-24 03:38:13 --> Model Class Initialized
INFO - 2024-10-24 03:38:13 --> Model Class Initialized
INFO - 2024-10-24 03:38:13 --> Model Class Initialized
INFO - 2024-10-24 03:38:13 --> Model Class Initialized
INFO - 2024-10-24 03:38:13 --> Model Class Initialized
DEBUG - 2024-10-24 03:38:13 --> Class name after strip: company
DEBUG - 2024-10-24 03:38:13 --> Is countable: false
DEBUG - 2024-10-24 03:38:13 --> Matches y-rule: true
DEBUG - 2024-10-24 03:38:13 --> Direct replacement result: companies
DEBUG - 2024-10-24 03:38:13 --> plural called with: company
DEBUG - 2024-10-24 03:38:13 --> is_countable called with!!!!: company
DEBUG - 2024-10-24 03:38:13 --> Final plural result: companies
INFO - 2024-10-24 03:38:13 --> Model Class Initialized
INFO - 2024-10-24 03:38:13 --> Model Class Initialized
INFO - 2024-10-24 03:38:13 --> Model Class Initialized
INFO - 2024-10-24 03:38:13 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 03:38:13 --> Final output sent to browser
DEBUG - 2024-10-24 03:38:13 --> Total execution time: 0.0228
INFO - 2024-10-24 03:38:31 --> Config Class Initialized
INFO - 2024-10-24 03:38:31 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:38:31 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:38:31 --> Utf8 Class Initialized
INFO - 2024-10-24 03:38:31 --> URI Class Initialized
INFO - 2024-10-24 03:38:31 --> Router Class Initialized
INFO - 2024-10-24 03:38:31 --> Output Class Initialized
INFO - 2024-10-24 03:38:31 --> Security Class Initialized
DEBUG - 2024-10-24 03:38:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:38:31 --> Input Class Initialized
INFO - 2024-10-24 03:38:31 --> Language Class Initialized
ERROR - 2024-10-24 03:38:31 --> TEST ERROR MESSAGE - 2024-10-24 03:38:31
INFO - 2024-10-24 03:38:31 --> Loader Class Initialized
INFO - 2024-10-24 03:38:31 --> Controller Class Initialized
INFO - 2024-10-24 03:38:31 --> Database Driver Class Initialized
INFO - 2024-10-24 03:38:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:38:31 --> Helper loaded: form_helper
INFO - 2024-10-24 03:38:31 --> Helper loaded: url_helper
INFO - 2024-10-24 03:38:31 --> Model Class Initialized
INFO - 2024-10-24 03:38:31 --> Helper loaded: inflector_helper
INFO - 2024-10-24 03:38:31 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:38:31 --> Helper loaded: email_helper
INFO - 2024-10-24 03:38:31 --> Model Class Initialized
INFO - 2024-10-24 03:38:31 --> Model Class Initialized
INFO - 2024-10-24 03:38:31 --> Model Class Initialized
INFO - 2024-10-24 03:38:31 --> Model Class Initialized
INFO - 2024-10-24 03:38:31 --> Model Class Initialized
INFO - 2024-10-24 03:38:31 --> Model Class Initialized
INFO - 2024-10-24 03:38:31 --> Model Class Initialized
DEBUG - 2024-10-24 03:38:31 --> Class name after strip: company
DEBUG - 2024-10-24 03:38:31 --> Is countable: false
DEBUG - 2024-10-24 03:38:31 --> Matches y-rule: true
DEBUG - 2024-10-24 03:38:31 --> Direct replacement result: companies
DEBUG - 2024-10-24 03:38:31 --> plural called with: company
DEBUG - 2024-10-24 03:38:31 --> is_countable called with!!!!: company
DEBUG - 2024-10-24 03:38:31 --> Final plural result: companies
INFO - 2024-10-24 03:38:31 --> Model Class Initialized
INFO - 2024-10-24 03:38:31 --> Model Class Initialized
INFO - 2024-10-24 03:38:31 --> Model Class Initialized
INFO - 2024-10-24 03:38:41 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 03:38:41 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 03:38:41 --> Final output sent to browser
DEBUG - 2024-10-24 03:38:41 --> Total execution time: 9.6534
INFO - 2024-10-24 03:38:46 --> Config Class Initialized
INFO - 2024-10-24 03:38:46 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:38:46 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:38:46 --> Utf8 Class Initialized
INFO - 2024-10-24 03:38:46 --> URI Class Initialized
INFO - 2024-10-24 03:38:46 --> Router Class Initialized
INFO - 2024-10-24 03:38:46 --> Output Class Initialized
INFO - 2024-10-24 03:38:46 --> Security Class Initialized
DEBUG - 2024-10-24 03:38:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:38:46 --> Input Class Initialized
INFO - 2024-10-24 03:38:46 --> Language Class Initialized
ERROR - 2024-10-24 03:38:46 --> TEST ERROR MESSAGE - 2024-10-24 03:38:46
INFO - 2024-10-24 03:38:46 --> Loader Class Initialized
INFO - 2024-10-24 03:38:46 --> Controller Class Initialized
INFO - 2024-10-24 03:38:46 --> Database Driver Class Initialized
INFO - 2024-10-24 03:38:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:38:46 --> Helper loaded: form_helper
INFO - 2024-10-24 03:38:46 --> Helper loaded: url_helper
INFO - 2024-10-24 03:38:46 --> Model Class Initialized
INFO - 2024-10-24 03:38:46 --> Helper loaded: inflector_helper
INFO - 2024-10-24 03:38:46 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:38:46 --> Helper loaded: email_helper
INFO - 2024-10-24 03:38:46 --> Model Class Initialized
INFO - 2024-10-24 03:38:46 --> Model Class Initialized
INFO - 2024-10-24 03:38:46 --> Model Class Initialized
INFO - 2024-10-24 03:38:46 --> Model Class Initialized
INFO - 2024-10-24 03:38:46 --> Model Class Initialized
INFO - 2024-10-24 03:38:46 --> Model Class Initialized
INFO - 2024-10-24 03:38:46 --> Model Class Initialized
DEBUG - 2024-10-24 03:38:46 --> Class name after strip: company
DEBUG - 2024-10-24 03:38:46 --> Is countable: false
DEBUG - 2024-10-24 03:38:46 --> Matches y-rule: true
DEBUG - 2024-10-24 03:38:46 --> Direct replacement result: companies
DEBUG - 2024-10-24 03:38:46 --> plural called with: company
DEBUG - 2024-10-24 03:38:46 --> is_countable called with!!!!: company
DEBUG - 2024-10-24 03:38:46 --> Final plural result: companies
INFO - 2024-10-24 03:38:46 --> Model Class Initialized
INFO - 2024-10-24 03:38:46 --> Model Class Initialized
INFO - 2024-10-24 03:38:46 --> Model Class Initialized
INFO - 2024-10-24 03:38:56 --> Final output sent to browser
DEBUG - 2024-10-24 03:38:56 --> Total execution time: 9.4391
INFO - 2024-10-24 03:39:30 --> Config Class Initialized
INFO - 2024-10-24 03:39:30 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:39:30 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:39:30 --> Utf8 Class Initialized
INFO - 2024-10-24 03:39:30 --> URI Class Initialized
INFO - 2024-10-24 03:39:30 --> Router Class Initialized
INFO - 2024-10-24 03:39:30 --> Output Class Initialized
INFO - 2024-10-24 03:39:30 --> Security Class Initialized
DEBUG - 2024-10-24 03:39:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:39:30 --> Input Class Initialized
INFO - 2024-10-24 03:39:30 --> Language Class Initialized
ERROR - 2024-10-24 03:39:30 --> TEST ERROR MESSAGE - 2024-10-24 03:39:30
INFO - 2024-10-24 03:39:30 --> Loader Class Initialized
INFO - 2024-10-24 03:39:30 --> Controller Class Initialized
INFO - 2024-10-24 03:39:30 --> Database Driver Class Initialized
INFO - 2024-10-24 03:39:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:39:30 --> Helper loaded: form_helper
INFO - 2024-10-24 03:39:30 --> Helper loaded: url_helper
INFO - 2024-10-24 03:39:30 --> Model Class Initialized
INFO - 2024-10-24 03:39:30 --> Helper loaded: inflector_helper
INFO - 2024-10-24 03:39:30 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:39:30 --> Helper loaded: email_helper
INFO - 2024-10-24 03:39:30 --> Model Class Initialized
INFO - 2024-10-24 03:39:30 --> Model Class Initialized
INFO - 2024-10-24 03:39:30 --> Model Class Initialized
INFO - 2024-10-24 03:39:30 --> Model Class Initialized
INFO - 2024-10-24 03:39:30 --> Model Class Initialized
INFO - 2024-10-24 03:39:30 --> Model Class Initialized
INFO - 2024-10-24 03:39:30 --> Model Class Initialized
DEBUG - 2024-10-24 03:39:30 --> Class name after strip: company
DEBUG - 2024-10-24 03:39:30 --> Is countable: false
DEBUG - 2024-10-24 03:39:30 --> Matches y-rule: true
DEBUG - 2024-10-24 03:39:30 --> Direct replacement result: companies
DEBUG - 2024-10-24 03:39:30 --> plural called with: company
DEBUG - 2024-10-24 03:39:30 --> is_countable called with!!!!: company
DEBUG - 2024-10-24 03:39:30 --> Final plural result: companies
INFO - 2024-10-24 03:39:30 --> Model Class Initialized
INFO - 2024-10-24 03:39:30 --> Model Class Initialized
INFO - 2024-10-24 03:39:30 --> Model Class Initialized
INFO - 2024-10-24 03:39:30 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 03:39:30 --> Final output sent to browser
DEBUG - 2024-10-24 03:39:30 --> Total execution time: 0.0264
INFO - 2024-10-24 03:39:34 --> Config Class Initialized
INFO - 2024-10-24 03:39:34 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:39:34 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:39:34 --> Utf8 Class Initialized
INFO - 2024-10-24 03:39:34 --> URI Class Initialized
INFO - 2024-10-24 03:39:34 --> Router Class Initialized
INFO - 2024-10-24 03:39:34 --> Output Class Initialized
INFO - 2024-10-24 03:39:34 --> Security Class Initialized
DEBUG - 2024-10-24 03:39:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:39:34 --> Input Class Initialized
INFO - 2024-10-24 03:39:34 --> Language Class Initialized
ERROR - 2024-10-24 03:39:34 --> TEST ERROR MESSAGE - 2024-10-24 03:39:34
INFO - 2024-10-24 03:39:34 --> Loader Class Initialized
INFO - 2024-10-24 03:39:34 --> Controller Class Initialized
INFO - 2024-10-24 03:39:34 --> Database Driver Class Initialized
INFO - 2024-10-24 03:39:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:39:34 --> Helper loaded: form_helper
INFO - 2024-10-24 03:39:34 --> Helper loaded: url_helper
INFO - 2024-10-24 03:39:34 --> Model Class Initialized
INFO - 2024-10-24 03:39:34 --> Helper loaded: inflector_helper
INFO - 2024-10-24 03:39:34 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:39:34 --> Helper loaded: email_helper
INFO - 2024-10-24 03:39:34 --> Model Class Initialized
INFO - 2024-10-24 03:39:34 --> Model Class Initialized
INFO - 2024-10-24 03:39:34 --> Model Class Initialized
INFO - 2024-10-24 03:39:34 --> Model Class Initialized
INFO - 2024-10-24 03:39:34 --> Model Class Initialized
INFO - 2024-10-24 03:39:34 --> Model Class Initialized
INFO - 2024-10-24 03:39:34 --> Model Class Initialized
DEBUG - 2024-10-24 03:39:34 --> Class name after strip: company
DEBUG - 2024-10-24 03:39:34 --> Is countable: false
DEBUG - 2024-10-24 03:39:34 --> Matches y-rule: true
DEBUG - 2024-10-24 03:39:34 --> Direct replacement result: companies
DEBUG - 2024-10-24 03:39:34 --> plural called with: company
DEBUG - 2024-10-24 03:39:34 --> is_countable called with!!!!: company
DEBUG - 2024-10-24 03:39:34 --> Final plural result: companies
INFO - 2024-10-24 03:39:34 --> Model Class Initialized
INFO - 2024-10-24 03:39:34 --> Model Class Initialized
INFO - 2024-10-24 03:39:34 --> Model Class Initialized
INFO - 2024-10-24 03:39:34 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 03:39:34 --> Final output sent to browser
DEBUG - 2024-10-24 03:39:34 --> Total execution time: 0.0250
INFO - 2024-10-24 03:52:55 --> Config Class Initialized
INFO - 2024-10-24 03:52:55 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:52:55 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:52:55 --> Utf8 Class Initialized
INFO - 2024-10-24 03:52:55 --> URI Class Initialized
INFO - 2024-10-24 03:52:55 --> Router Class Initialized
INFO - 2024-10-24 03:52:55 --> Output Class Initialized
INFO - 2024-10-24 03:52:55 --> Security Class Initialized
DEBUG - 2024-10-24 03:52:55 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:52:55 --> Input Class Initialized
INFO - 2024-10-24 03:52:55 --> Language Class Initialized
ERROR - 2024-10-24 03:52:55 --> TEST ERROR MESSAGE - 2024-10-24 03:52:55
INFO - 2024-10-24 03:52:55 --> Loader Class Initialized
INFO - 2024-10-24 03:52:55 --> Controller Class Initialized
INFO - 2024-10-24 03:52:55 --> Database Driver Class Initialized
INFO - 2024-10-24 03:52:55 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:52:55 --> Helper loaded: form_helper
INFO - 2024-10-24 03:52:55 --> Helper loaded: url_helper
INFO - 2024-10-24 03:52:55 --> Model Class Initialized
INFO - 2024-10-24 03:52:55 --> Helper loaded: inflector_helper
INFO - 2024-10-24 03:52:55 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:52:55 --> Helper loaded: email_helper
INFO - 2024-10-24 03:52:55 --> Model Class Initialized
INFO - 2024-10-24 03:52:55 --> Model Class Initialized
INFO - 2024-10-24 03:52:55 --> Model Class Initialized
INFO - 2024-10-24 03:52:55 --> Model Class Initialized
INFO - 2024-10-24 03:52:55 --> Model Class Initialized
INFO - 2024-10-24 03:52:55 --> Model Class Initialized
INFO - 2024-10-24 03:52:55 --> Model Class Initialized
DEBUG - 2024-10-24 03:52:55 --> Class name after strip: company
DEBUG - 2024-10-24 03:52:55 --> Is countable: false
DEBUG - 2024-10-24 03:52:55 --> Matches y-rule: true
DEBUG - 2024-10-24 03:52:55 --> Direct replacement result: companies
DEBUG - 2024-10-24 03:52:55 --> plural called with: company
DEBUG - 2024-10-24 03:52:55 --> is_countable called with!!!!: company
DEBUG - 2024-10-24 03:52:55 --> Final plural result: companies
INFO - 2024-10-24 03:52:55 --> Model Class Initialized
INFO - 2024-10-24 03:52:55 --> Model Class Initialized
INFO - 2024-10-24 03:52:55 --> Model Class Initialized
INFO - 2024-10-24 03:52:55 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 03:52:55 --> Final output sent to browser
DEBUG - 2024-10-24 03:52:55 --> Total execution time: 0.0251
INFO - 2024-10-24 03:53:04 --> Config Class Initialized
INFO - 2024-10-24 03:53:04 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:53:04 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:53:04 --> Utf8 Class Initialized
INFO - 2024-10-24 03:53:04 --> URI Class Initialized
INFO - 2024-10-24 03:53:04 --> Router Class Initialized
INFO - 2024-10-24 03:53:04 --> Output Class Initialized
INFO - 2024-10-24 03:53:04 --> Security Class Initialized
DEBUG - 2024-10-24 03:53:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:53:04 --> Input Class Initialized
INFO - 2024-10-24 03:53:04 --> Language Class Initialized
ERROR - 2024-10-24 03:53:04 --> TEST ERROR MESSAGE - 2024-10-24 03:53:04
INFO - 2024-10-24 03:53:04 --> Loader Class Initialized
INFO - 2024-10-24 03:53:04 --> Controller Class Initialized
INFO - 2024-10-24 03:53:04 --> Database Driver Class Initialized
INFO - 2024-10-24 03:53:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:53:04 --> Helper loaded: form_helper
INFO - 2024-10-24 03:53:04 --> Helper loaded: url_helper
INFO - 2024-10-24 03:53:04 --> Model Class Initialized
INFO - 2024-10-24 03:53:04 --> Helper loaded: inflector_helper
INFO - 2024-10-24 03:53:04 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:53:04 --> Helper loaded: email_helper
INFO - 2024-10-24 03:53:04 --> Model Class Initialized
INFO - 2024-10-24 03:53:04 --> Model Class Initialized
INFO - 2024-10-24 03:53:04 --> Model Class Initialized
INFO - 2024-10-24 03:53:04 --> Model Class Initialized
INFO - 2024-10-24 03:53:04 --> Model Class Initialized
INFO - 2024-10-24 03:53:04 --> Model Class Initialized
INFO - 2024-10-24 03:53:04 --> Model Class Initialized
DEBUG - 2024-10-24 03:53:04 --> Class name after strip: company
DEBUG - 2024-10-24 03:53:04 --> Is countable: false
DEBUG - 2024-10-24 03:53:04 --> Matches y-rule: true
DEBUG - 2024-10-24 03:53:04 --> Direct replacement result: companies
DEBUG - 2024-10-24 03:53:04 --> plural called with: company
DEBUG - 2024-10-24 03:53:04 --> is_countable called with!!!!: company
DEBUG - 2024-10-24 03:53:04 --> Final plural result: companies
INFO - 2024-10-24 03:53:04 --> Model Class Initialized
INFO - 2024-10-24 03:53:04 --> Model Class Initialized
INFO - 2024-10-24 03:53:04 --> Model Class Initialized
INFO - 2024-10-24 03:53:04 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 03:53:04 --> Final output sent to browser
DEBUG - 2024-10-24 03:53:04 --> Total execution time: 0.0252
INFO - 2024-10-24 03:53:13 --> Config Class Initialized
INFO - 2024-10-24 03:53:13 --> Hooks Class Initialized
DEBUG - 2024-10-24 03:53:13 --> UTF-8 Support Enabled
INFO - 2024-10-24 03:53:13 --> Utf8 Class Initialized
INFO - 2024-10-24 03:53:13 --> URI Class Initialized
INFO - 2024-10-24 03:53:13 --> Router Class Initialized
INFO - 2024-10-24 03:53:13 --> Output Class Initialized
INFO - 2024-10-24 03:53:13 --> Security Class Initialized
DEBUG - 2024-10-24 03:53:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 03:53:13 --> Input Class Initialized
INFO - 2024-10-24 03:53:14 --> Language Class Initialized
ERROR - 2024-10-24 03:53:14 --> TEST ERROR MESSAGE - 2024-10-24 03:53:14
INFO - 2024-10-24 03:53:14 --> Loader Class Initialized
INFO - 2024-10-24 03:53:14 --> Controller Class Initialized
INFO - 2024-10-24 03:53:14 --> Database Driver Class Initialized
INFO - 2024-10-24 03:53:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 03:53:14 --> Helper loaded: form_helper
INFO - 2024-10-24 03:53:14 --> Helper loaded: url_helper
INFO - 2024-10-24 03:53:14 --> Model Class Initialized
INFO - 2024-10-24 03:53:14 --> Helper loaded: inflector_helper
INFO - 2024-10-24 03:53:14 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 03:53:14 --> Helper loaded: email_helper
INFO - 2024-10-24 03:53:14 --> Model Class Initialized
INFO - 2024-10-24 03:53:14 --> Model Class Initialized
INFO - 2024-10-24 03:53:14 --> Model Class Initialized
INFO - 2024-10-24 03:53:14 --> Model Class Initialized
INFO - 2024-10-24 03:53:14 --> Model Class Initialized
INFO - 2024-10-24 03:53:14 --> Model Class Initialized
INFO - 2024-10-24 03:53:14 --> Model Class Initialized
DEBUG - 2024-10-24 03:53:14 --> Class name after strip: company
DEBUG - 2024-10-24 03:53:14 --> Is countable: false
DEBUG - 2024-10-24 03:53:14 --> Matches y-rule: true
DEBUG - 2024-10-24 03:53:14 --> Direct replacement result: companies
DEBUG - 2024-10-24 03:53:14 --> plural called with: company
DEBUG - 2024-10-24 03:53:14 --> is_countable called with!!!!: company
DEBUG - 2024-10-24 03:53:14 --> Final plural result: companies
INFO - 2024-10-24 03:53:14 --> Model Class Initialized
INFO - 2024-10-24 03:53:14 --> Model Class Initialized
INFO - 2024-10-24 03:53:14 --> Model Class Initialized
ERROR - 2024-10-24 03:53:16 --> Severity: Notice --> Undefined index: freetext /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 03:53:16 --> Severity: Notice --> Undefined index: socialDes /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 03:53:16 --> Severity: Notice --> Undefined index: company /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 03:53:16 --> Severity: Notice --> Undefined index: division /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 03:53:16 --> Severity: Notice --> Undefined index: dataGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 03:53:16 --> Severity: Notice --> Undefined index: finalGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
INFO - 2024-10-24 03:53:16 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 03:53:16 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 03:53:16 --> Final output sent to browser
DEBUG - 2024-10-24 03:53:16 --> Total execution time: 2.4941
INFO - 2024-10-24 04:05:07 --> Config Class Initialized
INFO - 2024-10-24 04:05:07 --> Hooks Class Initialized
DEBUG - 2024-10-24 04:05:07 --> UTF-8 Support Enabled
INFO - 2024-10-24 04:05:07 --> Utf8 Class Initialized
INFO - 2024-10-24 04:05:07 --> URI Class Initialized
INFO - 2024-10-24 04:05:07 --> Router Class Initialized
INFO - 2024-10-24 04:05:07 --> Output Class Initialized
INFO - 2024-10-24 04:05:07 --> Security Class Initialized
DEBUG - 2024-10-24 04:05:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 04:05:07 --> Input Class Initialized
INFO - 2024-10-24 04:05:07 --> Language Class Initialized
ERROR - 2024-10-24 04:05:07 --> TEST ERROR MESSAGE - 2024-10-24 04:05:07
INFO - 2024-10-24 04:05:07 --> Loader Class Initialized
INFO - 2024-10-24 04:05:07 --> Controller Class Initialized
INFO - 2024-10-24 04:05:07 --> Database Driver Class Initialized
INFO - 2024-10-24 04:05:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 04:05:07 --> Helper loaded: form_helper
INFO - 2024-10-24 04:05:07 --> Helper loaded: url_helper
INFO - 2024-10-24 04:05:07 --> Model Class Initialized
INFO - 2024-10-24 04:05:07 --> Helper loaded: inflector_helper
INFO - 2024-10-24 04:05:07 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 04:05:07 --> Helper loaded: email_helper
INFO - 2024-10-24 04:05:07 --> Model Class Initialized
INFO - 2024-10-24 04:05:07 --> Model Class Initialized
INFO - 2024-10-24 04:05:07 --> Model Class Initialized
INFO - 2024-10-24 04:05:07 --> Model Class Initialized
INFO - 2024-10-24 04:05:07 --> Model Class Initialized
INFO - 2024-10-24 04:05:07 --> Model Class Initialized
INFO - 2024-10-24 04:05:07 --> Model Class Initialized
DEBUG - 2024-10-24 04:05:07 --> plural called with: company
DEBUG - 2024-10-24 04:05:07 --> is_countable called with!!!!: company
INFO - 2024-10-24 04:05:07 --> Model Class Initialized
INFO - 2024-10-24 04:05:07 --> Model Class Initialized
INFO - 2024-10-24 04:05:07 --> Model Class Initialized
INFO - 2024-10-24 04:05:07 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-24 04:05:07 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 04:05:07 --> Final output sent to browser
DEBUG - 2024-10-24 04:05:07 --> Total execution time: 0.0256
INFO - 2024-10-24 04:05:13 --> Config Class Initialized
INFO - 2024-10-24 04:05:13 --> Hooks Class Initialized
DEBUG - 2024-10-24 04:05:13 --> UTF-8 Support Enabled
INFO - 2024-10-24 04:05:13 --> Utf8 Class Initialized
INFO - 2024-10-24 04:05:13 --> URI Class Initialized
INFO - 2024-10-24 04:05:13 --> Router Class Initialized
INFO - 2024-10-24 04:05:13 --> Output Class Initialized
INFO - 2024-10-24 04:05:13 --> Security Class Initialized
DEBUG - 2024-10-24 04:05:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 04:05:13 --> Input Class Initialized
INFO - 2024-10-24 04:05:13 --> Language Class Initialized
ERROR - 2024-10-24 04:05:13 --> TEST ERROR MESSAGE - 2024-10-24 04:05:13
INFO - 2024-10-24 04:05:13 --> Loader Class Initialized
INFO - 2024-10-24 04:05:13 --> Controller Class Initialized
INFO - 2024-10-24 04:05:13 --> Database Driver Class Initialized
INFO - 2024-10-24 04:05:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 04:05:13 --> Helper loaded: form_helper
INFO - 2024-10-24 04:05:13 --> Helper loaded: url_helper
INFO - 2024-10-24 04:05:13 --> Model Class Initialized
INFO - 2024-10-24 04:05:13 --> Helper loaded: inflector_helper
INFO - 2024-10-24 04:05:13 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 04:05:13 --> Helper loaded: email_helper
INFO - 2024-10-24 04:05:13 --> Model Class Initialized
INFO - 2024-10-24 04:05:13 --> Model Class Initialized
INFO - 2024-10-24 04:05:13 --> Model Class Initialized
INFO - 2024-10-24 04:05:13 --> Model Class Initialized
INFO - 2024-10-24 04:05:13 --> Model Class Initialized
INFO - 2024-10-24 04:05:13 --> Model Class Initialized
INFO - 2024-10-24 04:05:13 --> Model Class Initialized
DEBUG - 2024-10-24 04:05:13 --> plural called with: company
DEBUG - 2024-10-24 04:05:13 --> is_countable called with!!!!: company
INFO - 2024-10-24 04:05:13 --> Model Class Initialized
INFO - 2024-10-24 04:05:13 --> Model Class Initialized
INFO - 2024-10-24 04:05:13 --> Model Class Initialized
INFO - 2024-10-24 04:05:13 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-24 04:05:13 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 04:05:13 --> Final output sent to browser
DEBUG - 2024-10-24 04:05:13 --> Total execution time: 0.0339
INFO - 2024-10-24 04:05:19 --> Config Class Initialized
INFO - 2024-10-24 04:05:19 --> Hooks Class Initialized
DEBUG - 2024-10-24 04:05:19 --> UTF-8 Support Enabled
INFO - 2024-10-24 04:05:19 --> Utf8 Class Initialized
INFO - 2024-10-24 04:05:19 --> URI Class Initialized
INFO - 2024-10-24 04:05:19 --> Router Class Initialized
INFO - 2024-10-24 04:05:19 --> Output Class Initialized
INFO - 2024-10-24 04:05:19 --> Security Class Initialized
DEBUG - 2024-10-24 04:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 04:05:19 --> Input Class Initialized
INFO - 2024-10-24 04:05:19 --> Language Class Initialized
ERROR - 2024-10-24 04:05:19 --> TEST ERROR MESSAGE - 2024-10-24 04:05:19
INFO - 2024-10-24 04:05:19 --> Loader Class Initialized
INFO - 2024-10-24 04:05:19 --> Controller Class Initialized
INFO - 2024-10-24 04:05:19 --> Database Driver Class Initialized
INFO - 2024-10-24 04:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 04:05:19 --> Helper loaded: form_helper
INFO - 2024-10-24 04:05:19 --> Helper loaded: url_helper
INFO - 2024-10-24 04:05:19 --> Model Class Initialized
INFO - 2024-10-24 04:05:19 --> Helper loaded: inflector_helper
INFO - 2024-10-24 04:05:19 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 04:05:19 --> Helper loaded: email_helper
INFO - 2024-10-24 04:05:19 --> Model Class Initialized
INFO - 2024-10-24 04:05:19 --> Model Class Initialized
INFO - 2024-10-24 04:05:19 --> Model Class Initialized
INFO - 2024-10-24 04:05:19 --> Model Class Initialized
INFO - 2024-10-24 04:05:19 --> Model Class Initialized
INFO - 2024-10-24 04:05:19 --> Model Class Initialized
INFO - 2024-10-24 04:05:19 --> Model Class Initialized
DEBUG - 2024-10-24 04:05:19 --> plural called with: company
DEBUG - 2024-10-24 04:05:19 --> is_countable called with!!!!: company
INFO - 2024-10-24 04:05:19 --> Model Class Initialized
INFO - 2024-10-24 04:05:19 --> Model Class Initialized
INFO - 2024-10-24 04:05:19 --> Model Class Initialized
INFO - 2024-10-24 04:05:19 --> Config Class Initialized
INFO - 2024-10-24 04:05:19 --> Hooks Class Initialized
DEBUG - 2024-10-24 04:05:19 --> UTF-8 Support Enabled
INFO - 2024-10-24 04:05:19 --> Utf8 Class Initialized
INFO - 2024-10-24 04:05:19 --> URI Class Initialized
INFO - 2024-10-24 04:05:19 --> Router Class Initialized
INFO - 2024-10-24 04:05:19 --> Output Class Initialized
INFO - 2024-10-24 04:05:19 --> Security Class Initialized
DEBUG - 2024-10-24 04:05:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 04:05:19 --> Input Class Initialized
INFO - 2024-10-24 04:05:19 --> Language Class Initialized
ERROR - 2024-10-24 04:05:19 --> TEST ERROR MESSAGE - 2024-10-24 04:05:19
INFO - 2024-10-24 04:05:19 --> Loader Class Initialized
INFO - 2024-10-24 04:05:19 --> Controller Class Initialized
INFO - 2024-10-24 04:05:19 --> Database Driver Class Initialized
INFO - 2024-10-24 04:05:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 04:05:19 --> Helper loaded: form_helper
INFO - 2024-10-24 04:05:19 --> Helper loaded: url_helper
INFO - 2024-10-24 04:05:19 --> Model Class Initialized
INFO - 2024-10-24 04:05:19 --> Helper loaded: inflector_helper
INFO - 2024-10-24 04:05:19 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 04:05:19 --> Helper loaded: email_helper
INFO - 2024-10-24 04:05:19 --> Model Class Initialized
INFO - 2024-10-24 04:05:19 --> Model Class Initialized
INFO - 2024-10-24 04:05:19 --> Model Class Initialized
INFO - 2024-10-24 04:05:19 --> Model Class Initialized
INFO - 2024-10-24 04:05:19 --> Model Class Initialized
INFO - 2024-10-24 04:05:19 --> Model Class Initialized
INFO - 2024-10-24 04:05:19 --> Model Class Initialized
DEBUG - 2024-10-24 04:05:19 --> plural called with: company
DEBUG - 2024-10-24 04:05:19 --> is_countable called with!!!!: company
INFO - 2024-10-24 04:05:19 --> Model Class Initialized
INFO - 2024-10-24 04:05:19 --> Model Class Initialized
INFO - 2024-10-24 04:05:19 --> Model Class Initialized
ERROR - 2024-10-24 04:05:22 --> Severity: Notice --> Undefined index: freetext /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 04:05:22 --> Severity: Notice --> Undefined index: socialDes /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 04:05:22 --> Severity: Notice --> Undefined index: company /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 04:05:22 --> Severity: Notice --> Undefined index: division /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 04:05:22 --> Severity: Notice --> Undefined index: dataGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 04:05:22 --> Severity: Notice --> Undefined index: finalGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
INFO - 2024-10-24 04:05:22 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 04:05:22 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 04:05:22 --> Final output sent to browser
DEBUG - 2024-10-24 04:05:22 --> Total execution time: 2.5357
INFO - 2024-10-24 09:53:19 --> Config Class Initialized
INFO - 2024-10-24 09:53:19 --> Hooks Class Initialized
DEBUG - 2024-10-24 09:53:19 --> UTF-8 Support Enabled
INFO - 2024-10-24 09:53:19 --> Utf8 Class Initialized
INFO - 2024-10-24 09:53:19 --> URI Class Initialized
DEBUG - 2024-10-24 09:53:19 --> No URI present. Default controller set.
INFO - 2024-10-24 09:53:19 --> Router Class Initialized
INFO - 2024-10-24 09:53:19 --> Output Class Initialized
INFO - 2024-10-24 09:53:19 --> Security Class Initialized
DEBUG - 2024-10-24 09:53:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 09:53:19 --> Input Class Initialized
INFO - 2024-10-24 09:53:19 --> Language Class Initialized
ERROR - 2024-10-24 09:53:19 --> TEST ERROR MESSAGE - 2024-10-24 09:53:19
INFO - 2024-10-24 09:53:19 --> Loader Class Initialized
INFO - 2024-10-24 09:53:19 --> Controller Class Initialized
INFO - 2024-10-24 09:53:19 --> Database Driver Class Initialized
INFO - 2024-10-24 09:53:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 09:53:19 --> Helper loaded: form_helper
INFO - 2024-10-24 09:53:19 --> Helper loaded: url_helper
INFO - 2024-10-24 09:53:19 --> Model Class Initialized
INFO - 2024-10-24 09:53:19 --> Helper loaded: inflector_helper
INFO - 2024-10-24 09:53:19 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 09:53:19 --> Helper loaded: email_helper
INFO - 2024-10-24 09:53:19 --> Model Class Initialized
INFO - 2024-10-24 09:53:19 --> Model Class Initialized
INFO - 2024-10-24 09:53:19 --> Model Class Initialized
INFO - 2024-10-24 09:53:19 --> Model Class Initialized
INFO - 2024-10-24 09:53:19 --> Model Class Initialized
INFO - 2024-10-24 09:53:19 --> Model Class Initialized
INFO - 2024-10-24 09:53:19 --> Model Class Initialized
DEBUG - 2024-10-24 09:53:19 --> plural called with: company
DEBUG - 2024-10-24 09:53:19 --> is_countable called with!!!!: company
INFO - 2024-10-24 09:53:19 --> Model Class Initialized
INFO - 2024-10-24 09:53:19 --> Model Class Initialized
INFO - 2024-10-24 09:53:19 --> Model Class Initialized
INFO - 2024-10-24 09:53:19 --> Final output sent to browser
DEBUG - 2024-10-24 09:53:19 --> Total execution time: 0.0258
INFO - 2024-10-24 12:01:38 --> Config Class Initialized
INFO - 2024-10-24 12:01:38 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:01:38 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:01:38 --> Utf8 Class Initialized
INFO - 2024-10-24 12:01:38 --> URI Class Initialized
INFO - 2024-10-24 12:01:38 --> Router Class Initialized
INFO - 2024-10-24 12:01:38 --> Output Class Initialized
INFO - 2024-10-24 12:01:38 --> Security Class Initialized
DEBUG - 2024-10-24 12:01:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:01:38 --> Input Class Initialized
INFO - 2024-10-24 12:01:38 --> Language Class Initialized
ERROR - 2024-10-24 12:01:38 --> TEST ERROR MESSAGE - 2024-10-24 12:01:38
INFO - 2024-10-24 12:01:38 --> Loader Class Initialized
INFO - 2024-10-24 12:01:38 --> Controller Class Initialized
INFO - 2024-10-24 12:01:38 --> Database Driver Class Initialized
INFO - 2024-10-24 12:01:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:01:38 --> Helper loaded: form_helper
INFO - 2024-10-24 12:01:38 --> Helper loaded: url_helper
INFO - 2024-10-24 12:01:38 --> Model Class Initialized
INFO - 2024-10-24 12:01:38 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:01:38 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:01:38 --> Helper loaded: email_helper
INFO - 2024-10-24 12:01:38 --> Model Class Initialized
INFO - 2024-10-24 12:01:38 --> Model Class Initialized
INFO - 2024-10-24 12:01:38 --> Model Class Initialized
INFO - 2024-10-24 12:01:38 --> Model Class Initialized
INFO - 2024-10-24 12:01:38 --> Model Class Initialized
INFO - 2024-10-24 12:01:38 --> Model Class Initialized
INFO - 2024-10-24 12:01:38 --> Model Class Initialized
DEBUG - 2024-10-24 12:01:38 --> plural called with: company
DEBUG - 2024-10-24 12:01:38 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:01:38 --> Model Class Initialized
INFO - 2024-10-24 12:01:38 --> Model Class Initialized
INFO - 2024-10-24 12:01:38 --> Model Class Initialized
INFO - 2024-10-24 12:01:38 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-24 12:01:38 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 12:01:38 --> Final output sent to browser
DEBUG - 2024-10-24 12:01:38 --> Total execution time: 0.0268
INFO - 2024-10-24 12:01:45 --> Config Class Initialized
INFO - 2024-10-24 12:01:45 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:01:45 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:01:45 --> Utf8 Class Initialized
INFO - 2024-10-24 12:01:45 --> URI Class Initialized
INFO - 2024-10-24 12:01:45 --> Router Class Initialized
INFO - 2024-10-24 12:01:45 --> Output Class Initialized
INFO - 2024-10-24 12:01:45 --> Security Class Initialized
DEBUG - 2024-10-24 12:01:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:01:45 --> Input Class Initialized
INFO - 2024-10-24 12:01:45 --> Language Class Initialized
ERROR - 2024-10-24 12:01:45 --> TEST ERROR MESSAGE - 2024-10-24 12:01:45
INFO - 2024-10-24 12:01:45 --> Loader Class Initialized
INFO - 2024-10-24 12:01:45 --> Controller Class Initialized
INFO - 2024-10-24 12:01:45 --> Database Driver Class Initialized
INFO - 2024-10-24 12:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:01:45 --> Helper loaded: form_helper
INFO - 2024-10-24 12:01:45 --> Helper loaded: url_helper
INFO - 2024-10-24 12:01:45 --> Model Class Initialized
INFO - 2024-10-24 12:01:45 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:01:45 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:01:45 --> Helper loaded: email_helper
INFO - 2024-10-24 12:01:45 --> Model Class Initialized
INFO - 2024-10-24 12:01:45 --> Model Class Initialized
INFO - 2024-10-24 12:01:45 --> Model Class Initialized
INFO - 2024-10-24 12:01:45 --> Model Class Initialized
INFO - 2024-10-24 12:01:45 --> Model Class Initialized
INFO - 2024-10-24 12:01:45 --> Model Class Initialized
INFO - 2024-10-24 12:01:45 --> Model Class Initialized
DEBUG - 2024-10-24 12:01:45 --> plural called with: company
DEBUG - 2024-10-24 12:01:45 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:01:45 --> Model Class Initialized
INFO - 2024-10-24 12:01:45 --> Model Class Initialized
INFO - 2024-10-24 12:01:45 --> Model Class Initialized
INFO - 2024-10-24 12:01:45 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-24 12:01:45 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 12:01:45 --> Final output sent to browser
DEBUG - 2024-10-24 12:01:45 --> Total execution time: 0.0241
INFO - 2024-10-24 12:02:06 --> Config Class Initialized
INFO - 2024-10-24 12:02:06 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:02:06 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:02:06 --> Utf8 Class Initialized
INFO - 2024-10-24 12:02:06 --> URI Class Initialized
INFO - 2024-10-24 12:02:06 --> Router Class Initialized
INFO - 2024-10-24 12:02:06 --> Output Class Initialized
INFO - 2024-10-24 12:02:06 --> Security Class Initialized
DEBUG - 2024-10-24 12:02:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:02:06 --> Input Class Initialized
INFO - 2024-10-24 12:02:06 --> Language Class Initialized
ERROR - 2024-10-24 12:02:06 --> TEST ERROR MESSAGE - 2024-10-24 12:02:06
INFO - 2024-10-24 12:02:06 --> Loader Class Initialized
INFO - 2024-10-24 12:02:06 --> Controller Class Initialized
INFO - 2024-10-24 12:02:06 --> Database Driver Class Initialized
INFO - 2024-10-24 12:02:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:02:06 --> Helper loaded: form_helper
INFO - 2024-10-24 12:02:06 --> Helper loaded: url_helper
INFO - 2024-10-24 12:02:06 --> Model Class Initialized
INFO - 2024-10-24 12:02:06 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:02:06 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:02:06 --> Helper loaded: email_helper
INFO - 2024-10-24 12:02:06 --> Model Class Initialized
INFO - 2024-10-24 12:02:06 --> Model Class Initialized
INFO - 2024-10-24 12:02:06 --> Model Class Initialized
INFO - 2024-10-24 12:02:06 --> Model Class Initialized
INFO - 2024-10-24 12:02:06 --> Model Class Initialized
INFO - 2024-10-24 12:02:06 --> Model Class Initialized
INFO - 2024-10-24 12:02:06 --> Model Class Initialized
DEBUG - 2024-10-24 12:02:06 --> plural called with: company
DEBUG - 2024-10-24 12:02:06 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:02:06 --> Model Class Initialized
INFO - 2024-10-24 12:02:06 --> Model Class Initialized
INFO - 2024-10-24 12:02:06 --> Model Class Initialized
INFO - 2024-10-24 12:02:06 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-24 12:02:06 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 12:02:06 --> Final output sent to browser
DEBUG - 2024-10-24 12:02:06 --> Total execution time: 0.0398
INFO - 2024-10-24 12:02:27 --> Config Class Initialized
INFO - 2024-10-24 12:02:27 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:02:27 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:02:27 --> Utf8 Class Initialized
INFO - 2024-10-24 12:02:27 --> URI Class Initialized
INFO - 2024-10-24 12:02:27 --> Router Class Initialized
INFO - 2024-10-24 12:02:27 --> Output Class Initialized
INFO - 2024-10-24 12:02:27 --> Security Class Initialized
DEBUG - 2024-10-24 12:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:02:27 --> Input Class Initialized
INFO - 2024-10-24 12:02:27 --> Language Class Initialized
ERROR - 2024-10-24 12:02:27 --> TEST ERROR MESSAGE - 2024-10-24 12:02:27
INFO - 2024-10-24 12:02:27 --> Loader Class Initialized
INFO - 2024-10-24 12:02:27 --> Controller Class Initialized
INFO - 2024-10-24 12:02:27 --> Database Driver Class Initialized
INFO - 2024-10-24 12:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:02:27 --> Helper loaded: form_helper
INFO - 2024-10-24 12:02:27 --> Helper loaded: url_helper
INFO - 2024-10-24 12:02:27 --> Model Class Initialized
INFO - 2024-10-24 12:02:27 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:02:27 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:02:27 --> Helper loaded: email_helper
INFO - 2024-10-24 12:02:27 --> Model Class Initialized
INFO - 2024-10-24 12:02:27 --> Model Class Initialized
INFO - 2024-10-24 12:02:27 --> Model Class Initialized
INFO - 2024-10-24 12:02:27 --> Model Class Initialized
INFO - 2024-10-24 12:02:27 --> Model Class Initialized
INFO - 2024-10-24 12:02:27 --> Model Class Initialized
INFO - 2024-10-24 12:02:27 --> Model Class Initialized
DEBUG - 2024-10-24 12:02:27 --> plural called with: company
DEBUG - 2024-10-24 12:02:27 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:02:27 --> Model Class Initialized
INFO - 2024-10-24 12:02:27 --> Model Class Initialized
INFO - 2024-10-24 12:02:27 --> Model Class Initialized
INFO - 2024-10-24 12:02:27 --> Config Class Initialized
INFO - 2024-10-24 12:02:27 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:02:27 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:02:27 --> Utf8 Class Initialized
INFO - 2024-10-24 12:02:27 --> URI Class Initialized
INFO - 2024-10-24 12:02:27 --> Router Class Initialized
INFO - 2024-10-24 12:02:27 --> Output Class Initialized
INFO - 2024-10-24 12:02:27 --> Security Class Initialized
DEBUG - 2024-10-24 12:02:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:02:27 --> Input Class Initialized
INFO - 2024-10-24 12:02:27 --> Language Class Initialized
ERROR - 2024-10-24 12:02:27 --> TEST ERROR MESSAGE - 2024-10-24 12:02:27
INFO - 2024-10-24 12:02:27 --> Loader Class Initialized
INFO - 2024-10-24 12:02:27 --> Controller Class Initialized
INFO - 2024-10-24 12:02:27 --> Database Driver Class Initialized
INFO - 2024-10-24 12:02:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:02:27 --> Helper loaded: form_helper
INFO - 2024-10-24 12:02:27 --> Helper loaded: url_helper
INFO - 2024-10-24 12:02:27 --> Model Class Initialized
INFO - 2024-10-24 12:02:27 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:02:27 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:02:27 --> Helper loaded: email_helper
INFO - 2024-10-24 12:02:27 --> Model Class Initialized
INFO - 2024-10-24 12:02:27 --> Model Class Initialized
INFO - 2024-10-24 12:02:27 --> Model Class Initialized
INFO - 2024-10-24 12:02:27 --> Model Class Initialized
INFO - 2024-10-24 12:02:27 --> Model Class Initialized
INFO - 2024-10-24 12:02:27 --> Model Class Initialized
INFO - 2024-10-24 12:02:27 --> Model Class Initialized
DEBUG - 2024-10-24 12:02:27 --> plural called with: company
DEBUG - 2024-10-24 12:02:27 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:02:27 --> Model Class Initialized
INFO - 2024-10-24 12:02:27 --> Model Class Initialized
INFO - 2024-10-24 12:02:27 --> Model Class Initialized
ERROR - 2024-10-24 12:02:30 --> Severity: Notice --> Undefined index: freetext /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 12:02:30 --> Severity: Notice --> Undefined index: socialDes /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 12:02:30 --> Severity: Notice --> Undefined index: company /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 12:02:30 --> Severity: Notice --> Undefined index: division /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 12:02:30 --> Severity: Notice --> Undefined index: dataGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 12:02:30 --> Severity: Notice --> Undefined index: finalGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
INFO - 2024-10-24 12:02:30 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 12:02:30 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 12:02:30 --> Final output sent to browser
DEBUG - 2024-10-24 12:02:30 --> Total execution time: 2.4497
INFO - 2024-10-24 12:03:04 --> Config Class Initialized
INFO - 2024-10-24 12:03:04 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:03:04 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:03:04 --> Utf8 Class Initialized
INFO - 2024-10-24 12:03:04 --> URI Class Initialized
INFO - 2024-10-24 12:03:04 --> Router Class Initialized
INFO - 2024-10-24 12:03:04 --> Output Class Initialized
INFO - 2024-10-24 12:03:04 --> Security Class Initialized
DEBUG - 2024-10-24 12:03:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:03:04 --> Input Class Initialized
INFO - 2024-10-24 12:03:04 --> Language Class Initialized
ERROR - 2024-10-24 12:03:04 --> TEST ERROR MESSAGE - 2024-10-24 12:03:04
INFO - 2024-10-24 12:03:04 --> Loader Class Initialized
INFO - 2024-10-24 12:03:04 --> Controller Class Initialized
INFO - 2024-10-24 12:03:04 --> Database Driver Class Initialized
INFO - 2024-10-24 12:03:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:03:04 --> Helper loaded: form_helper
INFO - 2024-10-24 12:03:04 --> Helper loaded: url_helper
INFO - 2024-10-24 12:03:04 --> Model Class Initialized
INFO - 2024-10-24 12:03:04 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:03:04 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:03:04 --> Helper loaded: email_helper
INFO - 2024-10-24 12:03:05 --> Model Class Initialized
INFO - 2024-10-24 12:03:05 --> Model Class Initialized
INFO - 2024-10-24 12:03:05 --> Model Class Initialized
INFO - 2024-10-24 12:03:05 --> Model Class Initialized
INFO - 2024-10-24 12:03:05 --> Model Class Initialized
INFO - 2024-10-24 12:03:05 --> Model Class Initialized
INFO - 2024-10-24 12:03:05 --> Model Class Initialized
DEBUG - 2024-10-24 12:03:05 --> plural called with: company
DEBUG - 2024-10-24 12:03:05 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:03:05 --> Model Class Initialized
INFO - 2024-10-24 12:03:05 --> Model Class Initialized
INFO - 2024-10-24 12:03:05 --> Model Class Initialized
INFO - 2024-10-24 12:03:06 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 12:03:06 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 12:03:06 --> Final output sent to browser
DEBUG - 2024-10-24 12:03:06 --> Total execution time: 1.9963
INFO - 2024-10-24 12:03:21 --> Config Class Initialized
INFO - 2024-10-24 12:03:21 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:03:21 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:03:21 --> Utf8 Class Initialized
INFO - 2024-10-24 12:03:21 --> URI Class Initialized
INFO - 2024-10-24 12:03:21 --> Router Class Initialized
INFO - 2024-10-24 12:03:21 --> Output Class Initialized
INFO - 2024-10-24 12:03:21 --> Security Class Initialized
DEBUG - 2024-10-24 12:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:03:21 --> Input Class Initialized
INFO - 2024-10-24 12:03:21 --> Language Class Initialized
ERROR - 2024-10-24 12:03:21 --> TEST ERROR MESSAGE - 2024-10-24 12:03:21
INFO - 2024-10-24 12:03:21 --> Loader Class Initialized
INFO - 2024-10-24 12:03:21 --> Controller Class Initialized
INFO - 2024-10-24 12:03:21 --> Database Driver Class Initialized
INFO - 2024-10-24 12:03:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:03:21 --> Helper loaded: form_helper
INFO - 2024-10-24 12:03:21 --> Helper loaded: url_helper
INFO - 2024-10-24 12:03:21 --> Model Class Initialized
INFO - 2024-10-24 12:03:21 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:03:21 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:03:21 --> Helper loaded: email_helper
INFO - 2024-10-24 12:03:21 --> Model Class Initialized
INFO - 2024-10-24 12:03:21 --> Model Class Initialized
INFO - 2024-10-24 12:03:21 --> Model Class Initialized
INFO - 2024-10-24 12:03:21 --> Model Class Initialized
INFO - 2024-10-24 12:03:21 --> Model Class Initialized
INFO - 2024-10-24 12:03:21 --> Model Class Initialized
INFO - 2024-10-24 12:03:21 --> Model Class Initialized
DEBUG - 2024-10-24 12:03:21 --> plural called with: company
DEBUG - 2024-10-24 12:03:21 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:03:21 --> Model Class Initialized
INFO - 2024-10-24 12:03:21 --> Model Class Initialized
INFO - 2024-10-24 12:03:21 --> Model Class Initialized
INFO - 2024-10-24 12:03:21 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 12:03:21 --> Final output sent to browser
DEBUG - 2024-10-24 12:03:21 --> Total execution time: 0.0216
INFO - 2024-10-24 12:03:25 --> Config Class Initialized
INFO - 2024-10-24 12:03:25 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:03:25 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:03:25 --> Utf8 Class Initialized
INFO - 2024-10-24 12:03:25 --> URI Class Initialized
INFO - 2024-10-24 12:03:25 --> Router Class Initialized
INFO - 2024-10-24 12:03:25 --> Output Class Initialized
INFO - 2024-10-24 12:03:25 --> Security Class Initialized
DEBUG - 2024-10-24 12:03:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:03:25 --> Input Class Initialized
INFO - 2024-10-24 12:03:25 --> Language Class Initialized
ERROR - 2024-10-24 12:03:25 --> TEST ERROR MESSAGE - 2024-10-24 12:03:25
INFO - 2024-10-24 12:03:25 --> Loader Class Initialized
INFO - 2024-10-24 12:03:25 --> Controller Class Initialized
INFO - 2024-10-24 12:03:25 --> Database Driver Class Initialized
INFO - 2024-10-24 12:03:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:03:25 --> Helper loaded: form_helper
INFO - 2024-10-24 12:03:25 --> Helper loaded: url_helper
INFO - 2024-10-24 12:03:25 --> Model Class Initialized
INFO - 2024-10-24 12:03:25 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:03:25 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:03:25 --> Helper loaded: email_helper
INFO - 2024-10-24 12:03:25 --> Model Class Initialized
INFO - 2024-10-24 12:03:25 --> Model Class Initialized
INFO - 2024-10-24 12:03:25 --> Model Class Initialized
INFO - 2024-10-24 12:03:25 --> Model Class Initialized
INFO - 2024-10-24 12:03:25 --> Model Class Initialized
INFO - 2024-10-24 12:03:25 --> Model Class Initialized
INFO - 2024-10-24 12:03:25 --> Model Class Initialized
DEBUG - 2024-10-24 12:03:25 --> plural called with: company
DEBUG - 2024-10-24 12:03:25 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:03:25 --> Model Class Initialized
INFO - 2024-10-24 12:03:25 --> Model Class Initialized
INFO - 2024-10-24 12:03:25 --> Model Class Initialized
INFO - 2024-10-24 12:03:25 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 12:03:25 --> Final output sent to browser
DEBUG - 2024-10-24 12:03:25 --> Total execution time: 0.0246
INFO - 2024-10-24 12:06:19 --> Config Class Initialized
INFO - 2024-10-24 12:06:19 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:06:19 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:06:19 --> Utf8 Class Initialized
INFO - 2024-10-24 12:06:19 --> URI Class Initialized
INFO - 2024-10-24 12:06:19 --> Router Class Initialized
INFO - 2024-10-24 12:06:19 --> Output Class Initialized
INFO - 2024-10-24 12:06:19 --> Security Class Initialized
DEBUG - 2024-10-24 12:06:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:06:19 --> Input Class Initialized
INFO - 2024-10-24 12:06:19 --> Language Class Initialized
ERROR - 2024-10-24 12:06:19 --> TEST ERROR MESSAGE - 2024-10-24 12:06:19
INFO - 2024-10-24 12:06:19 --> Loader Class Initialized
INFO - 2024-10-24 12:06:19 --> Controller Class Initialized
INFO - 2024-10-24 12:06:19 --> Database Driver Class Initialized
INFO - 2024-10-24 12:06:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:06:19 --> Helper loaded: form_helper
INFO - 2024-10-24 12:06:19 --> Helper loaded: url_helper
INFO - 2024-10-24 12:06:19 --> Model Class Initialized
INFO - 2024-10-24 12:06:19 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:06:19 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:06:19 --> Helper loaded: email_helper
INFO - 2024-10-24 12:06:19 --> Model Class Initialized
INFO - 2024-10-24 12:06:19 --> Model Class Initialized
INFO - 2024-10-24 12:06:19 --> Model Class Initialized
INFO - 2024-10-24 12:06:19 --> Model Class Initialized
INFO - 2024-10-24 12:06:19 --> Model Class Initialized
INFO - 2024-10-24 12:06:19 --> Model Class Initialized
INFO - 2024-10-24 12:06:19 --> Model Class Initialized
DEBUG - 2024-10-24 12:06:19 --> plural called with: company
DEBUG - 2024-10-24 12:06:19 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:06:19 --> Model Class Initialized
INFO - 2024-10-24 12:06:19 --> Model Class Initialized
INFO - 2024-10-24 12:06:19 --> Model Class Initialized
INFO - 2024-10-24 12:06:21 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 12:06:21 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 12:06:21 --> Final output sent to browser
DEBUG - 2024-10-24 12:06:21 --> Total execution time: 1.8948
INFO - 2024-10-24 12:06:25 --> Config Class Initialized
INFO - 2024-10-24 12:06:25 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:06:25 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:06:25 --> Utf8 Class Initialized
INFO - 2024-10-24 12:06:25 --> URI Class Initialized
INFO - 2024-10-24 12:06:25 --> Router Class Initialized
INFO - 2024-10-24 12:06:25 --> Output Class Initialized
INFO - 2024-10-24 12:06:25 --> Security Class Initialized
DEBUG - 2024-10-24 12:06:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:06:25 --> Input Class Initialized
INFO - 2024-10-24 12:06:25 --> Language Class Initialized
ERROR - 2024-10-24 12:06:25 --> TEST ERROR MESSAGE - 2024-10-24 12:06:25
INFO - 2024-10-24 12:06:25 --> Loader Class Initialized
INFO - 2024-10-24 12:06:25 --> Controller Class Initialized
INFO - 2024-10-24 12:06:25 --> Database Driver Class Initialized
INFO - 2024-10-24 12:06:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:06:25 --> Helper loaded: form_helper
INFO - 2024-10-24 12:06:25 --> Helper loaded: url_helper
INFO - 2024-10-24 12:06:25 --> Model Class Initialized
INFO - 2024-10-24 12:06:25 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:06:25 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:06:25 --> Helper loaded: email_helper
INFO - 2024-10-24 12:06:25 --> Model Class Initialized
INFO - 2024-10-24 12:06:25 --> Model Class Initialized
INFO - 2024-10-24 12:06:25 --> Model Class Initialized
INFO - 2024-10-24 12:06:25 --> Model Class Initialized
INFO - 2024-10-24 12:06:25 --> Model Class Initialized
INFO - 2024-10-24 12:06:25 --> Model Class Initialized
INFO - 2024-10-24 12:06:25 --> Model Class Initialized
DEBUG - 2024-10-24 12:06:25 --> plural called with: company
DEBUG - 2024-10-24 12:06:25 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:06:25 --> Model Class Initialized
INFO - 2024-10-24 12:06:25 --> Model Class Initialized
INFO - 2024-10-24 12:06:25 --> Model Class Initialized
INFO - 2024-10-24 12:06:25 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 12:06:25 --> Final output sent to browser
DEBUG - 2024-10-24 12:06:25 --> Total execution time: 0.0249
INFO - 2024-10-24 12:12:20 --> Config Class Initialized
INFO - 2024-10-24 12:12:20 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:12:20 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:12:20 --> Utf8 Class Initialized
INFO - 2024-10-24 12:12:20 --> URI Class Initialized
INFO - 2024-10-24 12:12:20 --> Router Class Initialized
INFO - 2024-10-24 12:12:20 --> Output Class Initialized
INFO - 2024-10-24 12:12:20 --> Security Class Initialized
DEBUG - 2024-10-24 12:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:12:20 --> Input Class Initialized
INFO - 2024-10-24 12:12:20 --> Language Class Initialized
ERROR - 2024-10-24 12:12:20 --> TEST ERROR MESSAGE - 2024-10-24 12:12:20
INFO - 2024-10-24 12:12:20 --> Loader Class Initialized
INFO - 2024-10-24 12:12:20 --> Controller Class Initialized
INFO - 2024-10-24 12:12:20 --> Database Driver Class Initialized
INFO - 2024-10-24 12:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:12:20 --> Helper loaded: form_helper
INFO - 2024-10-24 12:12:20 --> Helper loaded: url_helper
INFO - 2024-10-24 12:12:20 --> Model Class Initialized
INFO - 2024-10-24 12:12:20 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:12:20 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:12:20 --> Helper loaded: email_helper
INFO - 2024-10-24 12:12:20 --> Model Class Initialized
INFO - 2024-10-24 12:12:20 --> Model Class Initialized
INFO - 2024-10-24 12:12:20 --> Model Class Initialized
INFO - 2024-10-24 12:12:20 --> Model Class Initialized
INFO - 2024-10-24 12:12:20 --> Model Class Initialized
INFO - 2024-10-24 12:12:20 --> Model Class Initialized
INFO - 2024-10-24 12:12:20 --> Model Class Initialized
DEBUG - 2024-10-24 12:12:20 --> plural called with: company
DEBUG - 2024-10-24 12:12:20 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:12:20 --> Model Class Initialized
INFO - 2024-10-24 12:12:20 --> Model Class Initialized
INFO - 2024-10-24 12:12:20 --> Model Class Initialized
INFO - 2024-10-24 12:12:20 --> Config Class Initialized
INFO - 2024-10-24 12:12:20 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:12:20 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:12:20 --> Utf8 Class Initialized
INFO - 2024-10-24 12:12:20 --> URI Class Initialized
INFO - 2024-10-24 12:12:20 --> Router Class Initialized
INFO - 2024-10-24 12:12:20 --> Output Class Initialized
INFO - 2024-10-24 12:12:20 --> Security Class Initialized
DEBUG - 2024-10-24 12:12:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:12:20 --> Input Class Initialized
INFO - 2024-10-24 12:12:20 --> Language Class Initialized
ERROR - 2024-10-24 12:12:20 --> TEST ERROR MESSAGE - 2024-10-24 12:12:20
INFO - 2024-10-24 12:12:20 --> Loader Class Initialized
INFO - 2024-10-24 12:12:20 --> Controller Class Initialized
INFO - 2024-10-24 12:12:20 --> Database Driver Class Initialized
INFO - 2024-10-24 12:12:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:12:20 --> Helper loaded: form_helper
INFO - 2024-10-24 12:12:20 --> Helper loaded: url_helper
INFO - 2024-10-24 12:12:20 --> Model Class Initialized
INFO - 2024-10-24 12:12:20 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:12:20 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:12:20 --> Helper loaded: email_helper
INFO - 2024-10-24 12:12:20 --> Model Class Initialized
INFO - 2024-10-24 12:12:20 --> Model Class Initialized
INFO - 2024-10-24 12:12:20 --> Model Class Initialized
INFO - 2024-10-24 12:12:20 --> Model Class Initialized
INFO - 2024-10-24 12:12:20 --> Model Class Initialized
INFO - 2024-10-24 12:12:20 --> Model Class Initialized
INFO - 2024-10-24 12:12:20 --> Model Class Initialized
DEBUG - 2024-10-24 12:12:20 --> plural called with: company
DEBUG - 2024-10-24 12:12:20 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:12:20 --> Model Class Initialized
INFO - 2024-10-24 12:12:20 --> Model Class Initialized
INFO - 2024-10-24 12:12:20 --> Model Class Initialized
INFO - 2024-10-24 12:12:20 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-24 12:12:20 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 12:12:20 --> Final output sent to browser
DEBUG - 2024-10-24 12:12:20 --> Total execution time: 0.0217
INFO - 2024-10-24 12:12:44 --> Config Class Initialized
INFO - 2024-10-24 12:12:44 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:12:44 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:12:44 --> Utf8 Class Initialized
INFO - 2024-10-24 12:12:44 --> URI Class Initialized
INFO - 2024-10-24 12:12:44 --> Router Class Initialized
INFO - 2024-10-24 12:12:44 --> Output Class Initialized
INFO - 2024-10-24 12:12:44 --> Security Class Initialized
DEBUG - 2024-10-24 12:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:12:44 --> Input Class Initialized
INFO - 2024-10-24 12:12:44 --> Language Class Initialized
ERROR - 2024-10-24 12:12:44 --> TEST ERROR MESSAGE - 2024-10-24 12:12:44
INFO - 2024-10-24 12:12:44 --> Loader Class Initialized
INFO - 2024-10-24 12:12:44 --> Controller Class Initialized
INFO - 2024-10-24 12:12:44 --> Database Driver Class Initialized
INFO - 2024-10-24 12:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:12:44 --> Helper loaded: form_helper
INFO - 2024-10-24 12:12:44 --> Helper loaded: url_helper
INFO - 2024-10-24 12:12:44 --> Model Class Initialized
INFO - 2024-10-24 12:12:44 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:12:44 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:12:44 --> Helper loaded: email_helper
INFO - 2024-10-24 12:12:44 --> Model Class Initialized
INFO - 2024-10-24 12:12:44 --> Model Class Initialized
INFO - 2024-10-24 12:12:44 --> Model Class Initialized
INFO - 2024-10-24 12:12:44 --> Model Class Initialized
INFO - 2024-10-24 12:12:44 --> Model Class Initialized
INFO - 2024-10-24 12:12:44 --> Model Class Initialized
INFO - 2024-10-24 12:12:44 --> Model Class Initialized
DEBUG - 2024-10-24 12:12:44 --> plural called with: company
DEBUG - 2024-10-24 12:12:44 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:12:44 --> Model Class Initialized
INFO - 2024-10-24 12:12:44 --> Model Class Initialized
INFO - 2024-10-24 12:12:44 --> Model Class Initialized
INFO - 2024-10-24 12:12:44 --> Config Class Initialized
INFO - 2024-10-24 12:12:44 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:12:44 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:12:44 --> Utf8 Class Initialized
INFO - 2024-10-24 12:12:44 --> URI Class Initialized
INFO - 2024-10-24 12:12:44 --> Router Class Initialized
INFO - 2024-10-24 12:12:44 --> Output Class Initialized
INFO - 2024-10-24 12:12:44 --> Security Class Initialized
DEBUG - 2024-10-24 12:12:44 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:12:44 --> Input Class Initialized
INFO - 2024-10-24 12:12:44 --> Language Class Initialized
ERROR - 2024-10-24 12:12:44 --> TEST ERROR MESSAGE - 2024-10-24 12:12:44
INFO - 2024-10-24 12:12:44 --> Loader Class Initialized
INFO - 2024-10-24 12:12:44 --> Controller Class Initialized
INFO - 2024-10-24 12:12:44 --> Database Driver Class Initialized
INFO - 2024-10-24 12:12:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:12:44 --> Helper loaded: form_helper
INFO - 2024-10-24 12:12:44 --> Helper loaded: url_helper
INFO - 2024-10-24 12:12:44 --> Model Class Initialized
INFO - 2024-10-24 12:12:44 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:12:44 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:12:44 --> Helper loaded: email_helper
INFO - 2024-10-24 12:12:44 --> Model Class Initialized
INFO - 2024-10-24 12:12:44 --> Model Class Initialized
INFO - 2024-10-24 12:12:44 --> Model Class Initialized
INFO - 2024-10-24 12:12:44 --> Model Class Initialized
INFO - 2024-10-24 12:12:44 --> Model Class Initialized
INFO - 2024-10-24 12:12:44 --> Model Class Initialized
INFO - 2024-10-24 12:12:44 --> Model Class Initialized
DEBUG - 2024-10-24 12:12:44 --> plural called with: company
DEBUG - 2024-10-24 12:12:44 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:12:44 --> Model Class Initialized
INFO - 2024-10-24 12:12:44 --> Model Class Initialized
INFO - 2024-10-24 12:12:44 --> Model Class Initialized
INFO - 2024-10-24 12:12:45 --> Config Class Initialized
INFO - 2024-10-24 12:12:45 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:12:45 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:12:45 --> Utf8 Class Initialized
INFO - 2024-10-24 12:12:45 --> URI Class Initialized
INFO - 2024-10-24 12:12:45 --> Router Class Initialized
INFO - 2024-10-24 12:12:45 --> Output Class Initialized
INFO - 2024-10-24 12:12:45 --> Security Class Initialized
DEBUG - 2024-10-24 12:12:45 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:12:45 --> Input Class Initialized
INFO - 2024-10-24 12:12:45 --> Language Class Initialized
ERROR - 2024-10-24 12:12:45 --> TEST ERROR MESSAGE - 2024-10-24 12:12:45
INFO - 2024-10-24 12:12:45 --> Loader Class Initialized
INFO - 2024-10-24 12:12:45 --> Controller Class Initialized
INFO - 2024-10-24 12:12:45 --> Database Driver Class Initialized
ERROR - 2024-10-24 12:12:47 --> Severity: Notice --> Undefined index: freetext /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 12:12:47 --> Severity: Notice --> Undefined index: socialDes /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 12:12:47 --> Severity: Notice --> Undefined index: company /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 12:12:47 --> Severity: Notice --> Undefined index: division /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 12:12:47 --> Severity: Notice --> Undefined index: dataGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 12:12:47 --> Severity: Notice --> Undefined index: finalGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
INFO - 2024-10-24 12:12:47 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 12:12:47 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 12:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:12:47 --> Helper loaded: form_helper
INFO - 2024-10-24 12:12:47 --> Helper loaded: url_helper
INFO - 2024-10-24 12:12:47 --> Model Class Initialized
INFO - 2024-10-24 12:12:47 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:12:47 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:12:47 --> Helper loaded: email_helper
INFO - 2024-10-24 12:12:47 --> Model Class Initialized
INFO - 2024-10-24 12:12:47 --> Model Class Initialized
INFO - 2024-10-24 12:12:47 --> Model Class Initialized
INFO - 2024-10-24 12:12:47 --> Model Class Initialized
INFO - 2024-10-24 12:12:47 --> Model Class Initialized
INFO - 2024-10-24 12:12:47 --> Model Class Initialized
INFO - 2024-10-24 12:12:47 --> Model Class Initialized
DEBUG - 2024-10-24 12:12:47 --> plural called with: company
DEBUG - 2024-10-24 12:12:47 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:12:47 --> Model Class Initialized
INFO - 2024-10-24 12:12:47 --> Model Class Initialized
INFO - 2024-10-24 12:12:47 --> Model Class Initialized
INFO - 2024-10-24 12:12:47 --> Config Class Initialized
INFO - 2024-10-24 12:12:47 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:12:47 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:12:47 --> Utf8 Class Initialized
INFO - 2024-10-24 12:12:47 --> URI Class Initialized
INFO - 2024-10-24 12:12:47 --> Router Class Initialized
INFO - 2024-10-24 12:12:47 --> Output Class Initialized
INFO - 2024-10-24 12:12:47 --> Security Class Initialized
DEBUG - 2024-10-24 12:12:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:12:47 --> Input Class Initialized
INFO - 2024-10-24 12:12:47 --> Language Class Initialized
ERROR - 2024-10-24 12:12:47 --> TEST ERROR MESSAGE - 2024-10-24 12:12:47
INFO - 2024-10-24 12:12:47 --> Loader Class Initialized
INFO - 2024-10-24 12:12:47 --> Controller Class Initialized
INFO - 2024-10-24 12:12:47 --> Database Driver Class Initialized
INFO - 2024-10-24 12:12:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:12:47 --> Helper loaded: form_helper
INFO - 2024-10-24 12:12:47 --> Helper loaded: url_helper
INFO - 2024-10-24 12:12:47 --> Model Class Initialized
INFO - 2024-10-24 12:12:47 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:12:47 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:12:47 --> Helper loaded: email_helper
INFO - 2024-10-24 12:12:47 --> Model Class Initialized
INFO - 2024-10-24 12:12:47 --> Model Class Initialized
INFO - 2024-10-24 12:12:47 --> Model Class Initialized
INFO - 2024-10-24 12:12:47 --> Model Class Initialized
INFO - 2024-10-24 12:12:47 --> Model Class Initialized
INFO - 2024-10-24 12:12:47 --> Model Class Initialized
INFO - 2024-10-24 12:12:47 --> Model Class Initialized
DEBUG - 2024-10-24 12:12:47 --> plural called with: company
DEBUG - 2024-10-24 12:12:47 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:12:47 --> Model Class Initialized
INFO - 2024-10-24 12:12:47 --> Model Class Initialized
INFO - 2024-10-24 12:12:47 --> Model Class Initialized
ERROR - 2024-10-24 12:12:47 --> Severity: Notice --> Undefined index: freetext /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 12:12:47 --> Severity: Notice --> Undefined index: socialDes /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 12:12:47 --> Severity: Notice --> Undefined index: company /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 12:12:47 --> Severity: Notice --> Undefined index: division /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 12:12:47 --> Severity: Notice --> Undefined index: dataGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 12:12:47 --> Severity: Notice --> Undefined index: finalGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
INFO - 2024-10-24 12:12:47 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 12:12:47 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 12:12:47 --> Final output sent to browser
DEBUG - 2024-10-24 12:12:47 --> Total execution time: 0.0349
INFO - 2024-10-24 12:12:52 --> Config Class Initialized
INFO - 2024-10-24 12:12:52 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:12:52 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:12:52 --> Utf8 Class Initialized
INFO - 2024-10-24 12:12:52 --> URI Class Initialized
INFO - 2024-10-24 12:12:52 --> Router Class Initialized
INFO - 2024-10-24 12:12:52 --> Output Class Initialized
INFO - 2024-10-24 12:12:52 --> Security Class Initialized
DEBUG - 2024-10-24 12:12:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:12:52 --> Input Class Initialized
INFO - 2024-10-24 12:12:52 --> Language Class Initialized
ERROR - 2024-10-24 12:12:52 --> TEST ERROR MESSAGE - 2024-10-24 12:12:52
INFO - 2024-10-24 12:12:52 --> Loader Class Initialized
INFO - 2024-10-24 12:12:52 --> Controller Class Initialized
INFO - 2024-10-24 12:12:52 --> Database Driver Class Initialized
INFO - 2024-10-24 12:12:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:12:52 --> Helper loaded: form_helper
INFO - 2024-10-24 12:12:52 --> Helper loaded: url_helper
INFO - 2024-10-24 12:12:52 --> Model Class Initialized
INFO - 2024-10-24 12:12:52 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:12:52 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:12:52 --> Helper loaded: email_helper
INFO - 2024-10-24 12:12:52 --> Model Class Initialized
INFO - 2024-10-24 12:12:52 --> Model Class Initialized
INFO - 2024-10-24 12:12:52 --> Model Class Initialized
INFO - 2024-10-24 12:12:52 --> Model Class Initialized
INFO - 2024-10-24 12:12:52 --> Model Class Initialized
INFO - 2024-10-24 12:12:52 --> Model Class Initialized
INFO - 2024-10-24 12:12:52 --> Model Class Initialized
DEBUG - 2024-10-24 12:12:52 --> plural called with: company
DEBUG - 2024-10-24 12:12:52 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:12:52 --> Model Class Initialized
INFO - 2024-10-24 12:12:52 --> Model Class Initialized
INFO - 2024-10-24 12:12:52 --> Model Class Initialized
INFO - 2024-10-24 12:12:54 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 12:12:54 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 12:12:54 --> Final output sent to browser
DEBUG - 2024-10-24 12:12:54 --> Total execution time: 2.0947
INFO - 2024-10-24 12:13:03 --> Config Class Initialized
INFO - 2024-10-24 12:13:03 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:13:03 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:13:03 --> Utf8 Class Initialized
INFO - 2024-10-24 12:13:03 --> URI Class Initialized
INFO - 2024-10-24 12:13:03 --> Router Class Initialized
INFO - 2024-10-24 12:13:03 --> Output Class Initialized
INFO - 2024-10-24 12:13:03 --> Security Class Initialized
DEBUG - 2024-10-24 12:13:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:13:03 --> Input Class Initialized
INFO - 2024-10-24 12:13:03 --> Language Class Initialized
ERROR - 2024-10-24 12:13:03 --> TEST ERROR MESSAGE - 2024-10-24 12:13:03
INFO - 2024-10-24 12:13:03 --> Loader Class Initialized
INFO - 2024-10-24 12:13:03 --> Controller Class Initialized
INFO - 2024-10-24 12:13:03 --> Database Driver Class Initialized
INFO - 2024-10-24 12:13:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:13:03 --> Helper loaded: form_helper
INFO - 2024-10-24 12:13:03 --> Helper loaded: url_helper
INFO - 2024-10-24 12:13:03 --> Model Class Initialized
INFO - 2024-10-24 12:13:03 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:13:03 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:13:03 --> Helper loaded: email_helper
INFO - 2024-10-24 12:13:03 --> Model Class Initialized
INFO - 2024-10-24 12:13:03 --> Model Class Initialized
INFO - 2024-10-24 12:13:03 --> Model Class Initialized
INFO - 2024-10-24 12:13:03 --> Model Class Initialized
INFO - 2024-10-24 12:13:03 --> Model Class Initialized
INFO - 2024-10-24 12:13:03 --> Model Class Initialized
INFO - 2024-10-24 12:13:03 --> Model Class Initialized
DEBUG - 2024-10-24 12:13:03 --> plural called with: company
DEBUG - 2024-10-24 12:13:03 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:13:03 --> Model Class Initialized
INFO - 2024-10-24 12:13:03 --> Model Class Initialized
INFO - 2024-10-24 12:13:03 --> Model Class Initialized
INFO - 2024-10-24 12:13:04 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 12:13:04 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 12:13:04 --> Final output sent to browser
DEBUG - 2024-10-24 12:13:04 --> Total execution time: 1.8004
INFO - 2024-10-24 12:14:39 --> Config Class Initialized
INFO - 2024-10-24 12:14:39 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:14:39 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:14:39 --> Utf8 Class Initialized
INFO - 2024-10-24 12:14:39 --> URI Class Initialized
INFO - 2024-10-24 12:14:39 --> Router Class Initialized
INFO - 2024-10-24 12:14:39 --> Output Class Initialized
INFO - 2024-10-24 12:14:39 --> Security Class Initialized
DEBUG - 2024-10-24 12:14:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:14:39 --> Input Class Initialized
INFO - 2024-10-24 12:14:39 --> Language Class Initialized
ERROR - 2024-10-24 12:14:39 --> TEST ERROR MESSAGE - 2024-10-24 12:14:39
INFO - 2024-10-24 12:14:39 --> Loader Class Initialized
INFO - 2024-10-24 12:14:39 --> Controller Class Initialized
INFO - 2024-10-24 12:14:39 --> Database Driver Class Initialized
INFO - 2024-10-24 12:14:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:14:39 --> Helper loaded: form_helper
INFO - 2024-10-24 12:14:39 --> Helper loaded: url_helper
INFO - 2024-10-24 12:14:39 --> Model Class Initialized
INFO - 2024-10-24 12:14:39 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:14:39 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:14:39 --> Helper loaded: email_helper
INFO - 2024-10-24 12:14:39 --> Model Class Initialized
INFO - 2024-10-24 12:14:39 --> Model Class Initialized
INFO - 2024-10-24 12:14:39 --> Model Class Initialized
INFO - 2024-10-24 12:14:39 --> Model Class Initialized
INFO - 2024-10-24 12:14:39 --> Model Class Initialized
INFO - 2024-10-24 12:14:39 --> Model Class Initialized
INFO - 2024-10-24 12:14:39 --> Model Class Initialized
DEBUG - 2024-10-24 12:14:39 --> plural called with: company
DEBUG - 2024-10-24 12:14:39 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:14:39 --> Model Class Initialized
INFO - 2024-10-24 12:14:39 --> Model Class Initialized
INFO - 2024-10-24 12:14:39 --> Model Class Initialized
INFO - 2024-10-24 12:14:39 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 12:14:39 --> Final output sent to browser
DEBUG - 2024-10-24 12:14:39 --> Total execution time: 0.0371
INFO - 2024-10-24 12:15:16 --> Config Class Initialized
INFO - 2024-10-24 12:15:16 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:15:16 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:15:16 --> Utf8 Class Initialized
INFO - 2024-10-24 12:15:16 --> URI Class Initialized
INFO - 2024-10-24 12:15:16 --> Router Class Initialized
INFO - 2024-10-24 12:15:16 --> Output Class Initialized
INFO - 2024-10-24 12:15:16 --> Security Class Initialized
DEBUG - 2024-10-24 12:15:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:15:16 --> Input Class Initialized
INFO - 2024-10-24 12:15:16 --> Language Class Initialized
ERROR - 2024-10-24 12:15:16 --> TEST ERROR MESSAGE - 2024-10-24 12:15:16
INFO - 2024-10-24 12:15:16 --> Loader Class Initialized
INFO - 2024-10-24 12:15:16 --> Controller Class Initialized
INFO - 2024-10-24 12:15:16 --> Database Driver Class Initialized
INFO - 2024-10-24 12:15:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:15:16 --> Helper loaded: form_helper
INFO - 2024-10-24 12:15:16 --> Helper loaded: url_helper
INFO - 2024-10-24 12:15:16 --> Model Class Initialized
INFO - 2024-10-24 12:15:16 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:15:16 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:15:16 --> Helper loaded: email_helper
INFO - 2024-10-24 12:15:16 --> Model Class Initialized
INFO - 2024-10-24 12:15:16 --> Model Class Initialized
INFO - 2024-10-24 12:15:16 --> Model Class Initialized
INFO - 2024-10-24 12:15:16 --> Model Class Initialized
INFO - 2024-10-24 12:15:16 --> Model Class Initialized
INFO - 2024-10-24 12:15:16 --> Model Class Initialized
INFO - 2024-10-24 12:15:16 --> Model Class Initialized
DEBUG - 2024-10-24 12:15:16 --> plural called with: company
DEBUG - 2024-10-24 12:15:16 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:15:16 --> Model Class Initialized
INFO - 2024-10-24 12:15:16 --> Model Class Initialized
INFO - 2024-10-24 12:15:16 --> Model Class Initialized
INFO - 2024-10-24 12:15:16 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 12:15:16 --> Final output sent to browser
DEBUG - 2024-10-24 12:15:16 --> Total execution time: 0.0247
INFO - 2024-10-24 12:15:20 --> Config Class Initialized
INFO - 2024-10-24 12:15:20 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:15:20 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:15:20 --> Utf8 Class Initialized
INFO - 2024-10-24 12:15:20 --> URI Class Initialized
INFO - 2024-10-24 12:15:20 --> Router Class Initialized
INFO - 2024-10-24 12:15:20 --> Output Class Initialized
INFO - 2024-10-24 12:15:20 --> Security Class Initialized
DEBUG - 2024-10-24 12:15:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:15:20 --> Input Class Initialized
INFO - 2024-10-24 12:15:20 --> Language Class Initialized
ERROR - 2024-10-24 12:15:20 --> TEST ERROR MESSAGE - 2024-10-24 12:15:20
INFO - 2024-10-24 12:15:20 --> Loader Class Initialized
INFO - 2024-10-24 12:15:20 --> Controller Class Initialized
INFO - 2024-10-24 12:15:20 --> Database Driver Class Initialized
INFO - 2024-10-24 12:15:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:15:20 --> Helper loaded: form_helper
INFO - 2024-10-24 12:15:20 --> Helper loaded: url_helper
INFO - 2024-10-24 12:15:20 --> Model Class Initialized
INFO - 2024-10-24 12:15:20 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:15:20 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:15:20 --> Helper loaded: email_helper
INFO - 2024-10-24 12:15:20 --> Model Class Initialized
INFO - 2024-10-24 12:15:20 --> Model Class Initialized
INFO - 2024-10-24 12:15:20 --> Model Class Initialized
INFO - 2024-10-24 12:15:20 --> Model Class Initialized
INFO - 2024-10-24 12:15:20 --> Model Class Initialized
INFO - 2024-10-24 12:15:20 --> Model Class Initialized
INFO - 2024-10-24 12:15:20 --> Model Class Initialized
DEBUG - 2024-10-24 12:15:20 --> plural called with: company
DEBUG - 2024-10-24 12:15:20 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:15:20 --> Model Class Initialized
INFO - 2024-10-24 12:15:20 --> Model Class Initialized
INFO - 2024-10-24 12:15:20 --> Model Class Initialized
INFO - 2024-10-24 12:15:22 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 12:15:22 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 12:15:22 --> Final output sent to browser
DEBUG - 2024-10-24 12:15:22 --> Total execution time: 1.7338
INFO - 2024-10-24 12:15:50 --> Config Class Initialized
INFO - 2024-10-24 12:15:50 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:15:50 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:15:50 --> Utf8 Class Initialized
INFO - 2024-10-24 12:15:50 --> URI Class Initialized
INFO - 2024-10-24 12:15:50 --> Router Class Initialized
INFO - 2024-10-24 12:15:50 --> Output Class Initialized
INFO - 2024-10-24 12:15:50 --> Security Class Initialized
DEBUG - 2024-10-24 12:15:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:15:50 --> Input Class Initialized
INFO - 2024-10-24 12:15:50 --> Language Class Initialized
ERROR - 2024-10-24 12:15:50 --> TEST ERROR MESSAGE - 2024-10-24 12:15:50
INFO - 2024-10-24 12:15:50 --> Loader Class Initialized
INFO - 2024-10-24 12:15:50 --> Controller Class Initialized
INFO - 2024-10-24 12:15:50 --> Database Driver Class Initialized
INFO - 2024-10-24 12:15:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:15:50 --> Helper loaded: form_helper
INFO - 2024-10-24 12:15:50 --> Helper loaded: url_helper
INFO - 2024-10-24 12:15:50 --> Model Class Initialized
INFO - 2024-10-24 12:15:50 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:15:50 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:15:50 --> Helper loaded: email_helper
INFO - 2024-10-24 12:15:50 --> Model Class Initialized
INFO - 2024-10-24 12:15:50 --> Model Class Initialized
INFO - 2024-10-24 12:15:50 --> Model Class Initialized
INFO - 2024-10-24 12:15:50 --> Model Class Initialized
INFO - 2024-10-24 12:15:50 --> Model Class Initialized
INFO - 2024-10-24 12:15:50 --> Model Class Initialized
INFO - 2024-10-24 12:15:50 --> Model Class Initialized
DEBUG - 2024-10-24 12:15:50 --> plural called with: company
DEBUG - 2024-10-24 12:15:50 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:15:50 --> Model Class Initialized
INFO - 2024-10-24 12:15:50 --> Model Class Initialized
INFO - 2024-10-24 12:15:50 --> Model Class Initialized
INFO - 2024-10-24 12:15:51 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 12:15:51 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 12:15:51 --> Final output sent to browser
DEBUG - 2024-10-24 12:15:51 --> Total execution time: 1.8192
INFO - 2024-10-24 12:35:59 --> Config Class Initialized
INFO - 2024-10-24 12:35:59 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:35:59 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:35:59 --> Utf8 Class Initialized
INFO - 2024-10-24 12:35:59 --> URI Class Initialized
INFO - 2024-10-24 12:35:59 --> Router Class Initialized
INFO - 2024-10-24 12:35:59 --> Output Class Initialized
INFO - 2024-10-24 12:35:59 --> Security Class Initialized
DEBUG - 2024-10-24 12:35:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:35:59 --> Input Class Initialized
INFO - 2024-10-24 12:35:59 --> Language Class Initialized
ERROR - 2024-10-24 12:35:59 --> TEST ERROR MESSAGE - 2024-10-24 12:35:59
INFO - 2024-10-24 12:35:59 --> Loader Class Initialized
INFO - 2024-10-24 12:35:59 --> Controller Class Initialized
INFO - 2024-10-24 12:35:59 --> Database Driver Class Initialized
INFO - 2024-10-24 12:35:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:35:59 --> Helper loaded: form_helper
INFO - 2024-10-24 12:35:59 --> Helper loaded: url_helper
INFO - 2024-10-24 12:35:59 --> Model Class Initialized
INFO - 2024-10-24 12:35:59 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:35:59 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:35:59 --> Helper loaded: email_helper
INFO - 2024-10-24 12:35:59 --> Model Class Initialized
INFO - 2024-10-24 12:35:59 --> Model Class Initialized
INFO - 2024-10-24 12:35:59 --> Model Class Initialized
INFO - 2024-10-24 12:35:59 --> Model Class Initialized
INFO - 2024-10-24 12:35:59 --> Model Class Initialized
INFO - 2024-10-24 12:35:59 --> Model Class Initialized
INFO - 2024-10-24 12:35:59 --> Model Class Initialized
DEBUG - 2024-10-24 12:35:59 --> plural called with: company
DEBUG - 2024-10-24 12:35:59 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:35:59 --> Model Class Initialized
INFO - 2024-10-24 12:35:59 --> Model Class Initialized
INFO - 2024-10-24 12:35:59 --> Model Class Initialized
INFO - 2024-10-24 12:35:59 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 12:35:59 --> Final output sent to browser
DEBUG - 2024-10-24 12:35:59 --> Total execution time: 0.0337
INFO - 2024-10-24 12:36:02 --> Config Class Initialized
INFO - 2024-10-24 12:36:02 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:36:02 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:36:02 --> Utf8 Class Initialized
INFO - 2024-10-24 12:36:02 --> URI Class Initialized
INFO - 2024-10-24 12:36:02 --> Router Class Initialized
INFO - 2024-10-24 12:36:02 --> Output Class Initialized
INFO - 2024-10-24 12:36:02 --> Security Class Initialized
DEBUG - 2024-10-24 12:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:36:02 --> Input Class Initialized
INFO - 2024-10-24 12:36:02 --> Language Class Initialized
ERROR - 2024-10-24 12:36:02 --> TEST ERROR MESSAGE - 2024-10-24 12:36:02
INFO - 2024-10-24 12:36:02 --> Loader Class Initialized
INFO - 2024-10-24 12:36:02 --> Controller Class Initialized
INFO - 2024-10-24 12:36:02 --> Database Driver Class Initialized
INFO - 2024-10-24 12:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:36:02 --> Helper loaded: form_helper
INFO - 2024-10-24 12:36:02 --> Helper loaded: url_helper
INFO - 2024-10-24 12:36:02 --> Model Class Initialized
INFO - 2024-10-24 12:36:02 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:36:02 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:36:02 --> Helper loaded: email_helper
INFO - 2024-10-24 12:36:02 --> Model Class Initialized
INFO - 2024-10-24 12:36:02 --> Model Class Initialized
INFO - 2024-10-24 12:36:02 --> Model Class Initialized
INFO - 2024-10-24 12:36:02 --> Model Class Initialized
INFO - 2024-10-24 12:36:02 --> Model Class Initialized
INFO - 2024-10-24 12:36:02 --> Model Class Initialized
INFO - 2024-10-24 12:36:02 --> Model Class Initialized
DEBUG - 2024-10-24 12:36:02 --> plural called with: company
DEBUG - 2024-10-24 12:36:02 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:36:02 --> Model Class Initialized
INFO - 2024-10-24 12:36:02 --> Model Class Initialized
INFO - 2024-10-24 12:36:02 --> Model Class Initialized
INFO - 2024-10-24 12:36:02 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 12:36:02 --> Final output sent to browser
DEBUG - 2024-10-24 12:36:02 --> Total execution time: 0.0246
INFO - 2024-10-24 12:37:41 --> Config Class Initialized
INFO - 2024-10-24 12:37:41 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:37:41 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:37:41 --> Utf8 Class Initialized
INFO - 2024-10-24 12:37:41 --> URI Class Initialized
INFO - 2024-10-24 12:37:41 --> Router Class Initialized
INFO - 2024-10-24 12:37:41 --> Output Class Initialized
INFO - 2024-10-24 12:37:41 --> Security Class Initialized
DEBUG - 2024-10-24 12:37:41 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:37:41 --> Input Class Initialized
INFO - 2024-10-24 12:37:41 --> Language Class Initialized
ERROR - 2024-10-24 12:37:41 --> TEST ERROR MESSAGE - 2024-10-24 12:37:41
INFO - 2024-10-24 12:37:41 --> Loader Class Initialized
INFO - 2024-10-24 12:37:41 --> Controller Class Initialized
INFO - 2024-10-24 12:37:41 --> Database Driver Class Initialized
INFO - 2024-10-24 12:37:41 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:37:41 --> Helper loaded: form_helper
INFO - 2024-10-24 12:37:41 --> Helper loaded: url_helper
INFO - 2024-10-24 12:37:41 --> Model Class Initialized
INFO - 2024-10-24 12:37:41 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:37:41 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:37:41 --> Helper loaded: email_helper
INFO - 2024-10-24 12:37:41 --> Model Class Initialized
INFO - 2024-10-24 12:37:41 --> Model Class Initialized
INFO - 2024-10-24 12:37:41 --> Model Class Initialized
INFO - 2024-10-24 12:37:41 --> Model Class Initialized
INFO - 2024-10-24 12:37:41 --> Model Class Initialized
INFO - 2024-10-24 12:37:41 --> Model Class Initialized
INFO - 2024-10-24 12:37:41 --> Model Class Initialized
DEBUG - 2024-10-24 12:37:41 --> plural called with: company
DEBUG - 2024-10-24 12:37:41 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:37:41 --> Model Class Initialized
INFO - 2024-10-24 12:37:41 --> Model Class Initialized
INFO - 2024-10-24 12:37:41 --> Model Class Initialized
INFO - 2024-10-24 12:37:41 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 12:37:41 --> Final output sent to browser
DEBUG - 2024-10-24 12:37:41 --> Total execution time: 0.0272
INFO - 2024-10-24 12:37:54 --> Config Class Initialized
INFO - 2024-10-24 12:37:54 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:37:54 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:37:54 --> Utf8 Class Initialized
INFO - 2024-10-24 12:37:54 --> URI Class Initialized
INFO - 2024-10-24 12:37:54 --> Router Class Initialized
INFO - 2024-10-24 12:37:54 --> Output Class Initialized
INFO - 2024-10-24 12:37:54 --> Security Class Initialized
DEBUG - 2024-10-24 12:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:37:54 --> Input Class Initialized
INFO - 2024-10-24 12:37:54 --> Language Class Initialized
ERROR - 2024-10-24 12:37:54 --> TEST ERROR MESSAGE - 2024-10-24 12:37:54
INFO - 2024-10-24 12:37:54 --> Loader Class Initialized
INFO - 2024-10-24 12:37:54 --> Controller Class Initialized
INFO - 2024-10-24 12:37:54 --> Database Driver Class Initialized
INFO - 2024-10-24 12:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:37:54 --> Helper loaded: form_helper
INFO - 2024-10-24 12:37:54 --> Helper loaded: url_helper
INFO - 2024-10-24 12:37:54 --> Model Class Initialized
INFO - 2024-10-24 12:37:54 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:37:54 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:37:54 --> Helper loaded: email_helper
INFO - 2024-10-24 12:37:54 --> Model Class Initialized
INFO - 2024-10-24 12:37:54 --> Model Class Initialized
INFO - 2024-10-24 12:37:54 --> Model Class Initialized
INFO - 2024-10-24 12:37:54 --> Model Class Initialized
INFO - 2024-10-24 12:37:54 --> Model Class Initialized
INFO - 2024-10-24 12:37:54 --> Model Class Initialized
INFO - 2024-10-24 12:37:54 --> Model Class Initialized
DEBUG - 2024-10-24 12:37:54 --> plural called with: company
DEBUG - 2024-10-24 12:37:54 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:37:54 --> Model Class Initialized
INFO - 2024-10-24 12:37:54 --> Model Class Initialized
INFO - 2024-10-24 12:37:54 --> Model Class Initialized
INFO - 2024-10-24 12:37:54 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 12:37:54 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 12:37:54 --> Final output sent to browser
DEBUG - 2024-10-24 12:37:54 --> Total execution time: 0.1640
INFO - 2024-10-24 12:38:04 --> Config Class Initialized
INFO - 2024-10-24 12:38:04 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:38:04 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:38:04 --> Utf8 Class Initialized
INFO - 2024-10-24 12:38:04 --> URI Class Initialized
INFO - 2024-10-24 12:38:04 --> Router Class Initialized
INFO - 2024-10-24 12:38:04 --> Output Class Initialized
INFO - 2024-10-24 12:38:04 --> Security Class Initialized
DEBUG - 2024-10-24 12:38:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:38:04 --> Input Class Initialized
INFO - 2024-10-24 12:38:04 --> Language Class Initialized
ERROR - 2024-10-24 12:38:04 --> TEST ERROR MESSAGE - 2024-10-24 12:38:04
INFO - 2024-10-24 12:38:04 --> Loader Class Initialized
INFO - 2024-10-24 12:38:04 --> Controller Class Initialized
INFO - 2024-10-24 12:38:04 --> Database Driver Class Initialized
INFO - 2024-10-24 12:38:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:38:04 --> Helper loaded: form_helper
INFO - 2024-10-24 12:38:04 --> Helper loaded: url_helper
INFO - 2024-10-24 12:38:04 --> Model Class Initialized
INFO - 2024-10-24 12:38:04 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:38:04 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:38:04 --> Helper loaded: email_helper
INFO - 2024-10-24 12:38:04 --> Model Class Initialized
INFO - 2024-10-24 12:38:04 --> Model Class Initialized
INFO - 2024-10-24 12:38:04 --> Model Class Initialized
INFO - 2024-10-24 12:38:04 --> Model Class Initialized
INFO - 2024-10-24 12:38:04 --> Model Class Initialized
INFO - 2024-10-24 12:38:04 --> Model Class Initialized
INFO - 2024-10-24 12:38:04 --> Model Class Initialized
DEBUG - 2024-10-24 12:38:04 --> plural called with: company
DEBUG - 2024-10-24 12:38:04 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:38:04 --> Model Class Initialized
INFO - 2024-10-24 12:38:04 --> Model Class Initialized
INFO - 2024-10-24 12:38:04 --> Model Class Initialized
INFO - 2024-10-24 12:38:39 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 12:38:39 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 12:38:39 --> Final output sent to browser
DEBUG - 2024-10-24 12:38:39 --> Total execution time: 35.1252
INFO - 2024-10-24 12:39:04 --> Config Class Initialized
INFO - 2024-10-24 12:39:04 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:39:04 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:39:04 --> Utf8 Class Initialized
INFO - 2024-10-24 12:39:04 --> URI Class Initialized
INFO - 2024-10-24 12:39:04 --> Router Class Initialized
INFO - 2024-10-24 12:39:04 --> Output Class Initialized
INFO - 2024-10-24 12:39:04 --> Security Class Initialized
DEBUG - 2024-10-24 12:39:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:39:04 --> Input Class Initialized
INFO - 2024-10-24 12:39:04 --> Language Class Initialized
ERROR - 2024-10-24 12:39:04 --> TEST ERROR MESSAGE - 2024-10-24 12:39:04
INFO - 2024-10-24 12:39:04 --> Loader Class Initialized
INFO - 2024-10-24 12:39:04 --> Controller Class Initialized
INFO - 2024-10-24 12:39:04 --> Database Driver Class Initialized
INFO - 2024-10-24 12:39:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:39:04 --> Helper loaded: form_helper
INFO - 2024-10-24 12:39:04 --> Helper loaded: url_helper
INFO - 2024-10-24 12:39:04 --> Model Class Initialized
INFO - 2024-10-24 12:39:04 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:39:04 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:39:04 --> Helper loaded: email_helper
INFO - 2024-10-24 12:39:04 --> Model Class Initialized
INFO - 2024-10-24 12:39:04 --> Model Class Initialized
INFO - 2024-10-24 12:39:04 --> Model Class Initialized
INFO - 2024-10-24 12:39:04 --> Model Class Initialized
INFO - 2024-10-24 12:39:04 --> Model Class Initialized
INFO - 2024-10-24 12:39:04 --> Model Class Initialized
INFO - 2024-10-24 12:39:04 --> Model Class Initialized
DEBUG - 2024-10-24 12:39:04 --> plural called with: company
DEBUG - 2024-10-24 12:39:04 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:39:04 --> Model Class Initialized
INFO - 2024-10-24 12:39:04 --> Model Class Initialized
INFO - 2024-10-24 12:39:04 --> Model Class Initialized
INFO - 2024-10-24 12:39:09 --> Config Class Initialized
INFO - 2024-10-24 12:39:09 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:39:09 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:39:09 --> Utf8 Class Initialized
INFO - 2024-10-24 12:39:09 --> URI Class Initialized
INFO - 2024-10-24 12:39:09 --> Router Class Initialized
INFO - 2024-10-24 12:39:09 --> Output Class Initialized
INFO - 2024-10-24 12:39:09 --> Security Class Initialized
DEBUG - 2024-10-24 12:39:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:39:09 --> Input Class Initialized
INFO - 2024-10-24 12:39:09 --> Language Class Initialized
ERROR - 2024-10-24 12:39:09 --> TEST ERROR MESSAGE - 2024-10-24 12:39:09
INFO - 2024-10-24 12:39:09 --> Loader Class Initialized
INFO - 2024-10-24 12:39:09 --> Controller Class Initialized
INFO - 2024-10-24 12:39:09 --> Database Driver Class Initialized
INFO - 2024-10-24 12:39:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:39:09 --> Helper loaded: form_helper
INFO - 2024-10-24 12:39:09 --> Helper loaded: url_helper
INFO - 2024-10-24 12:39:09 --> Model Class Initialized
INFO - 2024-10-24 12:39:09 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:39:09 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:39:09 --> Helper loaded: email_helper
INFO - 2024-10-24 12:39:09 --> Model Class Initialized
INFO - 2024-10-24 12:39:09 --> Model Class Initialized
INFO - 2024-10-24 12:39:09 --> Model Class Initialized
INFO - 2024-10-24 12:39:09 --> Model Class Initialized
INFO - 2024-10-24 12:39:09 --> Model Class Initialized
INFO - 2024-10-24 12:39:09 --> Model Class Initialized
INFO - 2024-10-24 12:39:09 --> Model Class Initialized
DEBUG - 2024-10-24 12:39:09 --> plural called with: company
DEBUG - 2024-10-24 12:39:09 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:39:09 --> Model Class Initialized
INFO - 2024-10-24 12:39:09 --> Model Class Initialized
INFO - 2024-10-24 12:39:09 --> Model Class Initialized
INFO - 2024-10-24 12:39:14 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 12:39:14 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 12:39:14 --> Final output sent to browser
DEBUG - 2024-10-24 12:39:14 --> Total execution time: 9.5533
INFO - 2024-10-24 12:39:15 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 12:39:15 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 12:39:15 --> Final output sent to browser
DEBUG - 2024-10-24 12:39:15 --> Total execution time: 6.0252
INFO - 2024-10-24 12:39:19 --> Config Class Initialized
INFO - 2024-10-24 12:39:19 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:39:19 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:39:19 --> Utf8 Class Initialized
INFO - 2024-10-24 12:39:19 --> URI Class Initialized
INFO - 2024-10-24 12:39:19 --> Router Class Initialized
INFO - 2024-10-24 12:39:19 --> Output Class Initialized
INFO - 2024-10-24 12:39:19 --> Security Class Initialized
DEBUG - 2024-10-24 12:39:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:39:19 --> Input Class Initialized
INFO - 2024-10-24 12:39:19 --> Language Class Initialized
ERROR - 2024-10-24 12:39:19 --> TEST ERROR MESSAGE - 2024-10-24 12:39:19
INFO - 2024-10-24 12:39:19 --> Loader Class Initialized
INFO - 2024-10-24 12:39:19 --> Controller Class Initialized
INFO - 2024-10-24 12:39:19 --> Database Driver Class Initialized
INFO - 2024-10-24 12:39:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:39:19 --> Helper loaded: form_helper
INFO - 2024-10-24 12:39:19 --> Helper loaded: url_helper
INFO - 2024-10-24 12:39:19 --> Model Class Initialized
INFO - 2024-10-24 12:39:19 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:39:19 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:39:19 --> Helper loaded: email_helper
INFO - 2024-10-24 12:39:19 --> Model Class Initialized
INFO - 2024-10-24 12:39:19 --> Model Class Initialized
INFO - 2024-10-24 12:39:19 --> Model Class Initialized
INFO - 2024-10-24 12:39:19 --> Model Class Initialized
INFO - 2024-10-24 12:39:19 --> Model Class Initialized
INFO - 2024-10-24 12:39:19 --> Model Class Initialized
INFO - 2024-10-24 12:39:19 --> Model Class Initialized
DEBUG - 2024-10-24 12:39:19 --> plural called with: company
DEBUG - 2024-10-24 12:39:19 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:39:19 --> Model Class Initialized
INFO - 2024-10-24 12:39:19 --> Model Class Initialized
INFO - 2024-10-24 12:39:19 --> Model Class Initialized
INFO - 2024-10-24 12:39:19 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 12:39:19 --> Final output sent to browser
DEBUG - 2024-10-24 12:39:19 --> Total execution time: 0.0239
INFO - 2024-10-24 12:39:28 --> Config Class Initialized
INFO - 2024-10-24 12:39:28 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:39:28 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:39:28 --> Utf8 Class Initialized
INFO - 2024-10-24 12:39:28 --> URI Class Initialized
INFO - 2024-10-24 12:39:28 --> Router Class Initialized
INFO - 2024-10-24 12:39:28 --> Output Class Initialized
INFO - 2024-10-24 12:39:28 --> Security Class Initialized
DEBUG - 2024-10-24 12:39:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:39:28 --> Input Class Initialized
INFO - 2024-10-24 12:39:28 --> Language Class Initialized
ERROR - 2024-10-24 12:39:28 --> TEST ERROR MESSAGE - 2024-10-24 12:39:28
INFO - 2024-10-24 12:39:28 --> Loader Class Initialized
INFO - 2024-10-24 12:39:28 --> Controller Class Initialized
INFO - 2024-10-24 12:39:28 --> Database Driver Class Initialized
INFO - 2024-10-24 12:39:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:39:28 --> Helper loaded: form_helper
INFO - 2024-10-24 12:39:28 --> Helper loaded: url_helper
INFO - 2024-10-24 12:39:28 --> Model Class Initialized
INFO - 2024-10-24 12:39:28 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:39:28 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:39:28 --> Helper loaded: email_helper
INFO - 2024-10-24 12:39:28 --> Model Class Initialized
INFO - 2024-10-24 12:39:28 --> Model Class Initialized
INFO - 2024-10-24 12:39:28 --> Model Class Initialized
INFO - 2024-10-24 12:39:28 --> Model Class Initialized
INFO - 2024-10-24 12:39:28 --> Model Class Initialized
INFO - 2024-10-24 12:39:28 --> Model Class Initialized
INFO - 2024-10-24 12:39:28 --> Model Class Initialized
DEBUG - 2024-10-24 12:39:28 --> plural called with: company
DEBUG - 2024-10-24 12:39:28 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:39:28 --> Model Class Initialized
INFO - 2024-10-24 12:39:28 --> Model Class Initialized
INFO - 2024-10-24 12:39:28 --> Model Class Initialized
INFO - 2024-10-24 12:39:38 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 12:39:38 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 12:39:38 --> Final output sent to browser
DEBUG - 2024-10-24 12:39:38 --> Total execution time: 9.6627
INFO - 2024-10-24 12:39:51 --> Config Class Initialized
INFO - 2024-10-24 12:39:51 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:39:51 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:39:51 --> Utf8 Class Initialized
INFO - 2024-10-24 12:39:51 --> URI Class Initialized
INFO - 2024-10-24 12:39:51 --> Router Class Initialized
INFO - 2024-10-24 12:39:51 --> Output Class Initialized
INFO - 2024-10-24 12:39:51 --> Security Class Initialized
DEBUG - 2024-10-24 12:39:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:39:51 --> Input Class Initialized
INFO - 2024-10-24 12:39:51 --> Language Class Initialized
ERROR - 2024-10-24 12:39:51 --> TEST ERROR MESSAGE - 2024-10-24 12:39:51
INFO - 2024-10-24 12:39:51 --> Loader Class Initialized
INFO - 2024-10-24 12:39:51 --> Controller Class Initialized
INFO - 2024-10-24 12:39:51 --> Database Driver Class Initialized
INFO - 2024-10-24 12:39:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:39:51 --> Helper loaded: form_helper
INFO - 2024-10-24 12:39:51 --> Helper loaded: url_helper
INFO - 2024-10-24 12:39:51 --> Model Class Initialized
INFO - 2024-10-24 12:39:51 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:39:51 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:39:51 --> Helper loaded: email_helper
INFO - 2024-10-24 12:39:51 --> Model Class Initialized
INFO - 2024-10-24 12:39:51 --> Model Class Initialized
INFO - 2024-10-24 12:39:51 --> Model Class Initialized
INFO - 2024-10-24 12:39:51 --> Model Class Initialized
INFO - 2024-10-24 12:39:51 --> Model Class Initialized
INFO - 2024-10-24 12:39:51 --> Model Class Initialized
INFO - 2024-10-24 12:39:51 --> Model Class Initialized
DEBUG - 2024-10-24 12:39:51 --> plural called with: company
DEBUG - 2024-10-24 12:39:51 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:39:51 --> Model Class Initialized
INFO - 2024-10-24 12:39:51 --> Model Class Initialized
INFO - 2024-10-24 12:39:51 --> Model Class Initialized
INFO - 2024-10-24 12:39:51 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 12:39:51 --> Final output sent to browser
DEBUG - 2024-10-24 12:39:51 --> Total execution time: 0.0221
INFO - 2024-10-24 12:40:28 --> Config Class Initialized
INFO - 2024-10-24 12:40:28 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:40:28 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:40:28 --> Utf8 Class Initialized
INFO - 2024-10-24 12:40:28 --> URI Class Initialized
INFO - 2024-10-24 12:40:28 --> Router Class Initialized
INFO - 2024-10-24 12:40:28 --> Output Class Initialized
INFO - 2024-10-24 12:40:28 --> Security Class Initialized
DEBUG - 2024-10-24 12:40:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:40:28 --> Input Class Initialized
INFO - 2024-10-24 12:40:28 --> Language Class Initialized
ERROR - 2024-10-24 12:40:28 --> TEST ERROR MESSAGE - 2024-10-24 12:40:28
INFO - 2024-10-24 12:40:28 --> Loader Class Initialized
INFO - 2024-10-24 12:40:28 --> Controller Class Initialized
INFO - 2024-10-24 12:40:28 --> Database Driver Class Initialized
INFO - 2024-10-24 12:40:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:40:28 --> Helper loaded: form_helper
INFO - 2024-10-24 12:40:28 --> Helper loaded: url_helper
INFO - 2024-10-24 12:40:28 --> Model Class Initialized
INFO - 2024-10-24 12:40:28 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:40:28 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:40:28 --> Helper loaded: email_helper
INFO - 2024-10-24 12:40:28 --> Model Class Initialized
INFO - 2024-10-24 12:40:28 --> Model Class Initialized
INFO - 2024-10-24 12:40:28 --> Model Class Initialized
INFO - 2024-10-24 12:40:28 --> Model Class Initialized
INFO - 2024-10-24 12:40:28 --> Model Class Initialized
INFO - 2024-10-24 12:40:28 --> Model Class Initialized
INFO - 2024-10-24 12:40:28 --> Model Class Initialized
DEBUG - 2024-10-24 12:40:28 --> plural called with: company
DEBUG - 2024-10-24 12:40:28 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:40:28 --> Model Class Initialized
INFO - 2024-10-24 12:40:28 --> Model Class Initialized
INFO - 2024-10-24 12:40:28 --> Model Class Initialized
INFO - 2024-10-24 12:40:28 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 12:40:28 --> Final output sent to browser
DEBUG - 2024-10-24 12:40:28 --> Total execution time: 0.0254
INFO - 2024-10-24 12:41:14 --> Config Class Initialized
INFO - 2024-10-24 12:41:14 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:41:14 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:41:14 --> Utf8 Class Initialized
INFO - 2024-10-24 12:41:14 --> URI Class Initialized
INFO - 2024-10-24 12:41:14 --> Router Class Initialized
INFO - 2024-10-24 12:41:14 --> Output Class Initialized
INFO - 2024-10-24 12:41:14 --> Security Class Initialized
DEBUG - 2024-10-24 12:41:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:41:14 --> Input Class Initialized
INFO - 2024-10-24 12:41:14 --> Language Class Initialized
ERROR - 2024-10-24 12:41:14 --> TEST ERROR MESSAGE - 2024-10-24 12:41:14
INFO - 2024-10-24 12:41:14 --> Loader Class Initialized
INFO - 2024-10-24 12:41:14 --> Controller Class Initialized
INFO - 2024-10-24 12:41:14 --> Database Driver Class Initialized
INFO - 2024-10-24 12:41:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:41:14 --> Helper loaded: form_helper
INFO - 2024-10-24 12:41:14 --> Helper loaded: url_helper
INFO - 2024-10-24 12:41:14 --> Model Class Initialized
INFO - 2024-10-24 12:41:14 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:41:14 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:41:14 --> Helper loaded: email_helper
INFO - 2024-10-24 12:41:14 --> Model Class Initialized
INFO - 2024-10-24 12:41:14 --> Model Class Initialized
INFO - 2024-10-24 12:41:14 --> Model Class Initialized
INFO - 2024-10-24 12:41:14 --> Model Class Initialized
INFO - 2024-10-24 12:41:14 --> Model Class Initialized
INFO - 2024-10-24 12:41:14 --> Model Class Initialized
INFO - 2024-10-24 12:41:14 --> Model Class Initialized
DEBUG - 2024-10-24 12:41:14 --> plural called with: company
DEBUG - 2024-10-24 12:41:14 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:41:14 --> Model Class Initialized
INFO - 2024-10-24 12:41:14 --> Model Class Initialized
INFO - 2024-10-24 12:41:14 --> Model Class Initialized
INFO - 2024-10-24 12:41:24 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 12:41:24 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 12:41:24 --> Final output sent to browser
DEBUG - 2024-10-24 12:41:24 --> Total execution time: 9.5124
INFO - 2024-10-24 12:41:28 --> Config Class Initialized
INFO - 2024-10-24 12:41:28 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:41:28 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:41:28 --> Utf8 Class Initialized
INFO - 2024-10-24 12:41:28 --> URI Class Initialized
INFO - 2024-10-24 12:41:28 --> Router Class Initialized
INFO - 2024-10-24 12:41:28 --> Output Class Initialized
INFO - 2024-10-24 12:41:28 --> Security Class Initialized
DEBUG - 2024-10-24 12:41:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:41:28 --> Input Class Initialized
INFO - 2024-10-24 12:41:28 --> Language Class Initialized
ERROR - 2024-10-24 12:41:28 --> TEST ERROR MESSAGE - 2024-10-24 12:41:28
INFO - 2024-10-24 12:41:28 --> Loader Class Initialized
INFO - 2024-10-24 12:41:28 --> Controller Class Initialized
INFO - 2024-10-24 12:41:28 --> Database Driver Class Initialized
INFO - 2024-10-24 12:41:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:41:28 --> Helper loaded: form_helper
INFO - 2024-10-24 12:41:28 --> Helper loaded: url_helper
INFO - 2024-10-24 12:41:28 --> Model Class Initialized
INFO - 2024-10-24 12:41:28 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:41:28 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:41:28 --> Helper loaded: email_helper
INFO - 2024-10-24 12:41:28 --> Model Class Initialized
INFO - 2024-10-24 12:41:28 --> Model Class Initialized
INFO - 2024-10-24 12:41:28 --> Model Class Initialized
INFO - 2024-10-24 12:41:28 --> Model Class Initialized
INFO - 2024-10-24 12:41:28 --> Model Class Initialized
INFO - 2024-10-24 12:41:28 --> Model Class Initialized
INFO - 2024-10-24 12:41:28 --> Model Class Initialized
DEBUG - 2024-10-24 12:41:28 --> plural called with: company
DEBUG - 2024-10-24 12:41:28 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:41:28 --> Model Class Initialized
INFO - 2024-10-24 12:41:28 --> Model Class Initialized
INFO - 2024-10-24 12:41:28 --> Model Class Initialized
INFO - 2024-10-24 12:41:28 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 12:41:28 --> Final output sent to browser
DEBUG - 2024-10-24 12:41:28 --> Total execution time: 0.0241
INFO - 2024-10-24 12:46:42 --> Config Class Initialized
INFO - 2024-10-24 12:46:42 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:46:42 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:46:42 --> Utf8 Class Initialized
INFO - 2024-10-24 12:46:42 --> URI Class Initialized
INFO - 2024-10-24 12:46:42 --> Router Class Initialized
INFO - 2024-10-24 12:46:42 --> Output Class Initialized
INFO - 2024-10-24 12:46:42 --> Security Class Initialized
DEBUG - 2024-10-24 12:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:46:42 --> Input Class Initialized
INFO - 2024-10-24 12:46:42 --> Language Class Initialized
ERROR - 2024-10-24 12:46:42 --> TEST ERROR MESSAGE - 2024-10-24 12:46:42
INFO - 2024-10-24 12:46:42 --> Loader Class Initialized
INFO - 2024-10-24 12:46:42 --> Controller Class Initialized
INFO - 2024-10-24 12:46:42 --> Database Driver Class Initialized
INFO - 2024-10-24 12:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:46:42 --> Helper loaded: form_helper
INFO - 2024-10-24 12:46:42 --> Helper loaded: url_helper
INFO - 2024-10-24 12:46:42 --> Model Class Initialized
INFO - 2024-10-24 12:46:42 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:46:42 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:46:42 --> Helper loaded: email_helper
INFO - 2024-10-24 12:46:42 --> Model Class Initialized
INFO - 2024-10-24 12:46:42 --> Model Class Initialized
INFO - 2024-10-24 12:46:42 --> Model Class Initialized
INFO - 2024-10-24 12:46:42 --> Model Class Initialized
INFO - 2024-10-24 12:46:42 --> Model Class Initialized
INFO - 2024-10-24 12:46:42 --> Model Class Initialized
INFO - 2024-10-24 12:46:42 --> Model Class Initialized
DEBUG - 2024-10-24 12:46:42 --> plural called with: company
DEBUG - 2024-10-24 12:46:42 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:46:42 --> Model Class Initialized
INFO - 2024-10-24 12:46:42 --> Model Class Initialized
INFO - 2024-10-24 12:46:42 --> Model Class Initialized
INFO - 2024-10-24 12:46:42 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 12:46:42 --> Final output sent to browser
DEBUG - 2024-10-24 12:46:42 --> Total execution time: 0.0272
INFO - 2024-10-24 12:51:22 --> Config Class Initialized
INFO - 2024-10-24 12:51:22 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:51:22 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:51:22 --> Utf8 Class Initialized
INFO - 2024-10-24 12:51:22 --> URI Class Initialized
INFO - 2024-10-24 12:51:22 --> Router Class Initialized
INFO - 2024-10-24 12:51:22 --> Output Class Initialized
INFO - 2024-10-24 12:51:22 --> Security Class Initialized
DEBUG - 2024-10-24 12:51:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:51:22 --> Input Class Initialized
INFO - 2024-10-24 12:51:22 --> Language Class Initialized
ERROR - 2024-10-24 12:51:22 --> TEST ERROR MESSAGE - 2024-10-24 12:51:22
INFO - 2024-10-24 12:51:22 --> Loader Class Initialized
INFO - 2024-10-24 12:51:22 --> Controller Class Initialized
INFO - 2024-10-24 12:51:22 --> Database Driver Class Initialized
INFO - 2024-10-24 12:51:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:51:22 --> Helper loaded: form_helper
INFO - 2024-10-24 12:51:22 --> Helper loaded: url_helper
INFO - 2024-10-24 12:51:22 --> Model Class Initialized
INFO - 2024-10-24 12:51:22 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:51:22 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:51:22 --> Helper loaded: email_helper
INFO - 2024-10-24 12:51:22 --> Model Class Initialized
INFO - 2024-10-24 12:51:22 --> Model Class Initialized
INFO - 2024-10-24 12:51:22 --> Model Class Initialized
INFO - 2024-10-24 12:51:22 --> Model Class Initialized
INFO - 2024-10-24 12:51:22 --> Model Class Initialized
INFO - 2024-10-24 12:51:22 --> Model Class Initialized
INFO - 2024-10-24 12:51:22 --> Model Class Initialized
DEBUG - 2024-10-24 12:51:22 --> plural called with: company
DEBUG - 2024-10-24 12:51:22 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:51:22 --> Model Class Initialized
INFO - 2024-10-24 12:51:22 --> Model Class Initialized
INFO - 2024-10-24 12:51:22 --> Model Class Initialized
INFO - 2024-10-24 12:51:25 --> Config Class Initialized
INFO - 2024-10-24 12:51:25 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:51:25 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:51:25 --> Utf8 Class Initialized
INFO - 2024-10-24 12:51:25 --> URI Class Initialized
INFO - 2024-10-24 12:51:25 --> Router Class Initialized
INFO - 2024-10-24 12:51:25 --> Output Class Initialized
INFO - 2024-10-24 12:51:25 --> Security Class Initialized
DEBUG - 2024-10-24 12:51:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:51:25 --> Input Class Initialized
INFO - 2024-10-24 12:51:25 --> Language Class Initialized
ERROR - 2024-10-24 12:51:25 --> TEST ERROR MESSAGE - 2024-10-24 12:51:25
INFO - 2024-10-24 12:51:25 --> Loader Class Initialized
INFO - 2024-10-24 12:51:25 --> Controller Class Initialized
INFO - 2024-10-24 12:51:25 --> Database Driver Class Initialized
INFO - 2024-10-24 12:51:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:51:25 --> Helper loaded: form_helper
INFO - 2024-10-24 12:51:25 --> Helper loaded: url_helper
INFO - 2024-10-24 12:51:25 --> Model Class Initialized
INFO - 2024-10-24 12:51:25 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:51:25 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:51:25 --> Helper loaded: email_helper
INFO - 2024-10-24 12:51:25 --> Model Class Initialized
INFO - 2024-10-24 12:51:25 --> Model Class Initialized
INFO - 2024-10-24 12:51:25 --> Model Class Initialized
INFO - 2024-10-24 12:51:25 --> Model Class Initialized
INFO - 2024-10-24 12:51:25 --> Model Class Initialized
INFO - 2024-10-24 12:51:25 --> Model Class Initialized
INFO - 2024-10-24 12:51:25 --> Model Class Initialized
DEBUG - 2024-10-24 12:51:25 --> plural called with: company
DEBUG - 2024-10-24 12:51:25 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:51:25 --> Model Class Initialized
INFO - 2024-10-24 12:51:25 --> Model Class Initialized
INFO - 2024-10-24 12:51:25 --> Model Class Initialized
INFO - 2024-10-24 12:51:35 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 12:51:35 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 12:51:35 --> Final output sent to browser
DEBUG - 2024-10-24 12:51:35 --> Total execution time: 9.1845
INFO - 2024-10-24 12:51:49 --> Config Class Initialized
INFO - 2024-10-24 12:51:49 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:51:49 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:51:49 --> Utf8 Class Initialized
INFO - 2024-10-24 12:51:49 --> URI Class Initialized
INFO - 2024-10-24 12:51:49 --> Router Class Initialized
INFO - 2024-10-24 12:51:49 --> Output Class Initialized
INFO - 2024-10-24 12:51:49 --> Security Class Initialized
DEBUG - 2024-10-24 12:51:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:51:49 --> Input Class Initialized
INFO - 2024-10-24 12:51:49 --> Language Class Initialized
ERROR - 2024-10-24 12:51:49 --> TEST ERROR MESSAGE - 2024-10-24 12:51:49
INFO - 2024-10-24 12:51:49 --> Loader Class Initialized
INFO - 2024-10-24 12:51:49 --> Controller Class Initialized
INFO - 2024-10-24 12:51:49 --> Database Driver Class Initialized
INFO - 2024-10-24 12:51:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:51:49 --> Helper loaded: form_helper
INFO - 2024-10-24 12:51:49 --> Helper loaded: url_helper
INFO - 2024-10-24 12:51:49 --> Model Class Initialized
INFO - 2024-10-24 12:51:49 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:51:49 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:51:49 --> Helper loaded: email_helper
INFO - 2024-10-24 12:51:49 --> Model Class Initialized
INFO - 2024-10-24 12:51:49 --> Model Class Initialized
INFO - 2024-10-24 12:51:49 --> Model Class Initialized
INFO - 2024-10-24 12:51:49 --> Model Class Initialized
INFO - 2024-10-24 12:51:49 --> Model Class Initialized
INFO - 2024-10-24 12:51:49 --> Model Class Initialized
INFO - 2024-10-24 12:51:49 --> Model Class Initialized
DEBUG - 2024-10-24 12:51:49 --> plural called with: company
DEBUG - 2024-10-24 12:51:49 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:51:49 --> Model Class Initialized
INFO - 2024-10-24 12:51:49 --> Model Class Initialized
INFO - 2024-10-24 12:51:49 --> Model Class Initialized
INFO - 2024-10-24 12:51:58 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 12:51:58 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 12:51:58 --> Final output sent to browser
DEBUG - 2024-10-24 12:51:58 --> Total execution time: 35.8727
INFO - 2024-10-24 12:52:26 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 12:52:26 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 12:52:26 --> Final output sent to browser
DEBUG - 2024-10-24 12:52:26 --> Total execution time: 36.6283
INFO - 2024-10-24 12:52:31 --> Config Class Initialized
INFO - 2024-10-24 12:52:31 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:52:31 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:52:31 --> Utf8 Class Initialized
INFO - 2024-10-24 12:52:31 --> URI Class Initialized
INFO - 2024-10-24 12:52:31 --> Router Class Initialized
INFO - 2024-10-24 12:52:31 --> Output Class Initialized
INFO - 2024-10-24 12:52:31 --> Security Class Initialized
DEBUG - 2024-10-24 12:52:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:52:31 --> Input Class Initialized
INFO - 2024-10-24 12:52:31 --> Language Class Initialized
ERROR - 2024-10-24 12:52:31 --> TEST ERROR MESSAGE - 2024-10-24 12:52:31
INFO - 2024-10-24 12:52:31 --> Loader Class Initialized
INFO - 2024-10-24 12:52:31 --> Controller Class Initialized
INFO - 2024-10-24 12:52:31 --> Database Driver Class Initialized
INFO - 2024-10-24 12:52:31 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:52:31 --> Helper loaded: form_helper
INFO - 2024-10-24 12:52:31 --> Helper loaded: url_helper
INFO - 2024-10-24 12:52:31 --> Model Class Initialized
INFO - 2024-10-24 12:52:31 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:52:31 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:52:31 --> Helper loaded: email_helper
INFO - 2024-10-24 12:52:31 --> Model Class Initialized
INFO - 2024-10-24 12:52:31 --> Model Class Initialized
INFO - 2024-10-24 12:52:31 --> Model Class Initialized
INFO - 2024-10-24 12:52:31 --> Model Class Initialized
INFO - 2024-10-24 12:52:31 --> Model Class Initialized
INFO - 2024-10-24 12:52:31 --> Model Class Initialized
INFO - 2024-10-24 12:52:31 --> Model Class Initialized
DEBUG - 2024-10-24 12:52:31 --> plural called with: company
DEBUG - 2024-10-24 12:52:31 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:52:31 --> Model Class Initialized
INFO - 2024-10-24 12:52:31 --> Model Class Initialized
INFO - 2024-10-24 12:52:31 --> Model Class Initialized
INFO - 2024-10-24 12:52:31 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 12:52:31 --> Final output sent to browser
DEBUG - 2024-10-24 12:52:31 --> Total execution time: 0.0262
INFO - 2024-10-24 12:52:49 --> Config Class Initialized
INFO - 2024-10-24 12:52:49 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:52:49 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:52:49 --> Utf8 Class Initialized
INFO - 2024-10-24 12:52:49 --> URI Class Initialized
INFO - 2024-10-24 12:52:49 --> Router Class Initialized
INFO - 2024-10-24 12:52:49 --> Output Class Initialized
INFO - 2024-10-24 12:52:49 --> Security Class Initialized
DEBUG - 2024-10-24 12:52:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:52:49 --> Input Class Initialized
INFO - 2024-10-24 12:52:49 --> Language Class Initialized
ERROR - 2024-10-24 12:52:49 --> TEST ERROR MESSAGE - 2024-10-24 12:52:49
INFO - 2024-10-24 12:52:49 --> Loader Class Initialized
INFO - 2024-10-24 12:52:49 --> Controller Class Initialized
INFO - 2024-10-24 12:52:49 --> Database Driver Class Initialized
INFO - 2024-10-24 12:52:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:52:49 --> Helper loaded: form_helper
INFO - 2024-10-24 12:52:49 --> Helper loaded: url_helper
INFO - 2024-10-24 12:52:49 --> Model Class Initialized
INFO - 2024-10-24 12:52:49 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:52:49 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:52:49 --> Helper loaded: email_helper
INFO - 2024-10-24 12:52:49 --> Model Class Initialized
INFO - 2024-10-24 12:52:49 --> Model Class Initialized
INFO - 2024-10-24 12:52:49 --> Model Class Initialized
INFO - 2024-10-24 12:52:49 --> Model Class Initialized
INFO - 2024-10-24 12:52:49 --> Model Class Initialized
INFO - 2024-10-24 12:52:49 --> Model Class Initialized
INFO - 2024-10-24 12:52:49 --> Model Class Initialized
DEBUG - 2024-10-24 12:52:49 --> plural called with: company
DEBUG - 2024-10-24 12:52:49 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:52:49 --> Model Class Initialized
INFO - 2024-10-24 12:52:49 --> Model Class Initialized
INFO - 2024-10-24 12:52:49 --> Model Class Initialized
INFO - 2024-10-24 12:52:49 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 12:52:49 --> Final output sent to browser
DEBUG - 2024-10-24 12:52:49 --> Total execution time: 0.0225
INFO - 2024-10-24 12:54:03 --> Config Class Initialized
INFO - 2024-10-24 12:54:03 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:54:03 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:54:03 --> Utf8 Class Initialized
INFO - 2024-10-24 12:54:03 --> URI Class Initialized
INFO - 2024-10-24 12:54:03 --> Router Class Initialized
INFO - 2024-10-24 12:54:03 --> Output Class Initialized
INFO - 2024-10-24 12:54:03 --> Security Class Initialized
DEBUG - 2024-10-24 12:54:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:54:03 --> Input Class Initialized
INFO - 2024-10-24 12:54:03 --> Language Class Initialized
ERROR - 2024-10-24 12:54:03 --> TEST ERROR MESSAGE - 2024-10-24 12:54:03
INFO - 2024-10-24 12:54:03 --> Loader Class Initialized
INFO - 2024-10-24 12:54:03 --> Controller Class Initialized
INFO - 2024-10-24 12:54:03 --> Database Driver Class Initialized
INFO - 2024-10-24 12:54:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:54:03 --> Helper loaded: form_helper
INFO - 2024-10-24 12:54:03 --> Helper loaded: url_helper
INFO - 2024-10-24 12:54:03 --> Model Class Initialized
INFO - 2024-10-24 12:54:03 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:54:03 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:54:03 --> Helper loaded: email_helper
INFO - 2024-10-24 12:54:03 --> Model Class Initialized
INFO - 2024-10-24 12:54:03 --> Model Class Initialized
INFO - 2024-10-24 12:54:03 --> Model Class Initialized
INFO - 2024-10-24 12:54:03 --> Model Class Initialized
INFO - 2024-10-24 12:54:03 --> Model Class Initialized
INFO - 2024-10-24 12:54:03 --> Model Class Initialized
INFO - 2024-10-24 12:54:03 --> Model Class Initialized
DEBUG - 2024-10-24 12:54:03 --> plural called with: company
DEBUG - 2024-10-24 12:54:03 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:54:03 --> Model Class Initialized
INFO - 2024-10-24 12:54:03 --> Model Class Initialized
INFO - 2024-10-24 12:54:03 --> Model Class Initialized
INFO - 2024-10-24 12:54:03 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 12:54:03 --> Final output sent to browser
DEBUG - 2024-10-24 12:54:03 --> Total execution time: 0.0245
INFO - 2024-10-24 12:54:05 --> Config Class Initialized
INFO - 2024-10-24 12:54:05 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:54:05 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:54:05 --> Utf8 Class Initialized
INFO - 2024-10-24 12:54:05 --> URI Class Initialized
INFO - 2024-10-24 12:54:05 --> Router Class Initialized
INFO - 2024-10-24 12:54:05 --> Output Class Initialized
INFO - 2024-10-24 12:54:05 --> Security Class Initialized
DEBUG - 2024-10-24 12:54:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:54:05 --> Input Class Initialized
INFO - 2024-10-24 12:54:05 --> Language Class Initialized
ERROR - 2024-10-24 12:54:05 --> TEST ERROR MESSAGE - 2024-10-24 12:54:05
INFO - 2024-10-24 12:54:05 --> Loader Class Initialized
INFO - 2024-10-24 12:54:05 --> Controller Class Initialized
INFO - 2024-10-24 12:54:05 --> Database Driver Class Initialized
INFO - 2024-10-24 12:54:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:54:05 --> Helper loaded: form_helper
INFO - 2024-10-24 12:54:05 --> Helper loaded: url_helper
INFO - 2024-10-24 12:54:05 --> Model Class Initialized
INFO - 2024-10-24 12:54:05 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:54:05 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:54:05 --> Helper loaded: email_helper
INFO - 2024-10-24 12:54:05 --> Model Class Initialized
INFO - 2024-10-24 12:54:05 --> Model Class Initialized
INFO - 2024-10-24 12:54:05 --> Model Class Initialized
INFO - 2024-10-24 12:54:05 --> Model Class Initialized
INFO - 2024-10-24 12:54:05 --> Model Class Initialized
INFO - 2024-10-24 12:54:05 --> Model Class Initialized
INFO - 2024-10-24 12:54:05 --> Model Class Initialized
DEBUG - 2024-10-24 12:54:05 --> plural called with: company
DEBUG - 2024-10-24 12:54:05 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:54:05 --> Model Class Initialized
INFO - 2024-10-24 12:54:05 --> Model Class Initialized
INFO - 2024-10-24 12:54:05 --> Model Class Initialized
INFO - 2024-10-24 12:54:05 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 12:54:05 --> Final output sent to browser
DEBUG - 2024-10-24 12:54:05 --> Total execution time: 0.0236
INFO - 2024-10-24 12:57:22 --> Config Class Initialized
INFO - 2024-10-24 12:57:22 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:57:22 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:57:22 --> Utf8 Class Initialized
INFO - 2024-10-24 12:57:22 --> URI Class Initialized
INFO - 2024-10-24 12:57:22 --> Router Class Initialized
INFO - 2024-10-24 12:57:22 --> Output Class Initialized
INFO - 2024-10-24 12:57:22 --> Security Class Initialized
DEBUG - 2024-10-24 12:57:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:57:22 --> Input Class Initialized
INFO - 2024-10-24 12:57:22 --> Language Class Initialized
ERROR - 2024-10-24 12:57:22 --> TEST ERROR MESSAGE - 2024-10-24 12:57:22
INFO - 2024-10-24 12:57:22 --> Loader Class Initialized
INFO - 2024-10-24 12:57:22 --> Controller Class Initialized
INFO - 2024-10-24 12:57:22 --> Database Driver Class Initialized
INFO - 2024-10-24 12:57:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:57:22 --> Helper loaded: form_helper
INFO - 2024-10-24 12:57:22 --> Helper loaded: url_helper
INFO - 2024-10-24 12:57:22 --> Model Class Initialized
INFO - 2024-10-24 12:57:22 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:57:22 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:57:22 --> Helper loaded: email_helper
INFO - 2024-10-24 12:57:22 --> Model Class Initialized
INFO - 2024-10-24 12:57:22 --> Model Class Initialized
INFO - 2024-10-24 12:57:22 --> Model Class Initialized
INFO - 2024-10-24 12:57:22 --> Model Class Initialized
INFO - 2024-10-24 12:57:22 --> Model Class Initialized
INFO - 2024-10-24 12:57:22 --> Model Class Initialized
INFO - 2024-10-24 12:57:22 --> Model Class Initialized
DEBUG - 2024-10-24 12:57:22 --> plural called with: company
DEBUG - 2024-10-24 12:57:22 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:57:22 --> Model Class Initialized
INFO - 2024-10-24 12:57:22 --> Model Class Initialized
INFO - 2024-10-24 12:57:22 --> Model Class Initialized
INFO - 2024-10-24 12:57:27 --> Config Class Initialized
INFO - 2024-10-24 12:57:27 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:57:27 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:57:27 --> Utf8 Class Initialized
INFO - 2024-10-24 12:57:27 --> URI Class Initialized
INFO - 2024-10-24 12:57:27 --> Router Class Initialized
INFO - 2024-10-24 12:57:27 --> Output Class Initialized
INFO - 2024-10-24 12:57:27 --> Security Class Initialized
DEBUG - 2024-10-24 12:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:57:27 --> Input Class Initialized
INFO - 2024-10-24 12:57:27 --> Language Class Initialized
ERROR - 2024-10-24 12:57:27 --> TEST ERROR MESSAGE - 2024-10-24 12:57:27
INFO - 2024-10-24 12:57:27 --> Loader Class Initialized
INFO - 2024-10-24 12:57:27 --> Controller Class Initialized
INFO - 2024-10-24 12:57:28 --> Database Driver Class Initialized
INFO - 2024-10-24 12:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:57:28 --> Helper loaded: form_helper
INFO - 2024-10-24 12:57:28 --> Helper loaded: url_helper
INFO - 2024-10-24 12:57:28 --> Model Class Initialized
INFO - 2024-10-24 12:57:28 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:57:28 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:57:28 --> Helper loaded: email_helper
INFO - 2024-10-24 12:57:28 --> Model Class Initialized
INFO - 2024-10-24 12:57:28 --> Model Class Initialized
INFO - 2024-10-24 12:57:28 --> Model Class Initialized
INFO - 2024-10-24 12:57:28 --> Model Class Initialized
INFO - 2024-10-24 12:57:28 --> Model Class Initialized
INFO - 2024-10-24 12:57:28 --> Model Class Initialized
INFO - 2024-10-24 12:57:28 --> Model Class Initialized
DEBUG - 2024-10-24 12:57:28 --> plural called with: company
DEBUG - 2024-10-24 12:57:28 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:57:28 --> Model Class Initialized
INFO - 2024-10-24 12:57:28 --> Model Class Initialized
INFO - 2024-10-24 12:57:28 --> Model Class Initialized
INFO - 2024-10-24 12:57:28 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-24 12:57:28 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 12:57:28 --> Final output sent to browser
DEBUG - 2024-10-24 12:57:28 --> Total execution time: 0.0300
INFO - 2024-10-24 12:57:28 --> Config Class Initialized
INFO - 2024-10-24 12:57:28 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:57:28 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:57:28 --> Utf8 Class Initialized
INFO - 2024-10-24 12:57:28 --> URI Class Initialized
INFO - 2024-10-24 12:57:28 --> Router Class Initialized
INFO - 2024-10-24 12:57:28 --> Output Class Initialized
INFO - 2024-10-24 12:57:28 --> Security Class Initialized
DEBUG - 2024-10-24 12:57:28 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:57:28 --> Input Class Initialized
INFO - 2024-10-24 12:57:28 --> Language Class Initialized
ERROR - 2024-10-24 12:57:28 --> TEST ERROR MESSAGE - 2024-10-24 12:57:28
INFO - 2024-10-24 12:57:28 --> Loader Class Initialized
INFO - 2024-10-24 12:57:28 --> Controller Class Initialized
INFO - 2024-10-24 12:57:28 --> Database Driver Class Initialized
INFO - 2024-10-24 12:57:28 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:57:28 --> Helper loaded: form_helper
INFO - 2024-10-24 12:57:28 --> Helper loaded: url_helper
INFO - 2024-10-24 12:57:28 --> Model Class Initialized
INFO - 2024-10-24 12:57:28 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:57:28 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:57:28 --> Helper loaded: email_helper
INFO - 2024-10-24 12:57:28 --> Model Class Initialized
INFO - 2024-10-24 12:57:28 --> Model Class Initialized
INFO - 2024-10-24 12:57:28 --> Model Class Initialized
INFO - 2024-10-24 12:57:28 --> Model Class Initialized
INFO - 2024-10-24 12:57:28 --> Model Class Initialized
INFO - 2024-10-24 12:57:28 --> Model Class Initialized
INFO - 2024-10-24 12:57:28 --> Model Class Initialized
DEBUG - 2024-10-24 12:57:28 --> plural called with: company
DEBUG - 2024-10-24 12:57:28 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:57:28 --> Model Class Initialized
INFO - 2024-10-24 12:57:28 --> Model Class Initialized
INFO - 2024-10-24 12:57:28 --> Model Class Initialized
INFO - 2024-10-24 12:57:28 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-24 12:57:28 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 12:57:28 --> Final output sent to browser
DEBUG - 2024-10-24 12:57:28 --> Total execution time: 0.0226
INFO - 2024-10-24 12:57:30 --> Config Class Initialized
INFO - 2024-10-24 12:57:30 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:57:30 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:57:30 --> Utf8 Class Initialized
INFO - 2024-10-24 12:57:30 --> URI Class Initialized
INFO - 2024-10-24 12:57:30 --> Router Class Initialized
INFO - 2024-10-24 12:57:30 --> Output Class Initialized
INFO - 2024-10-24 12:57:30 --> Security Class Initialized
DEBUG - 2024-10-24 12:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:57:30 --> Input Class Initialized
INFO - 2024-10-24 12:57:30 --> Language Class Initialized
ERROR - 2024-10-24 12:57:30 --> TEST ERROR MESSAGE - 2024-10-24 12:57:30
INFO - 2024-10-24 12:57:30 --> Loader Class Initialized
INFO - 2024-10-24 12:57:30 --> Controller Class Initialized
INFO - 2024-10-24 12:57:30 --> Database Driver Class Initialized
INFO - 2024-10-24 12:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:57:30 --> Helper loaded: form_helper
INFO - 2024-10-24 12:57:30 --> Helper loaded: url_helper
INFO - 2024-10-24 12:57:30 --> Model Class Initialized
INFO - 2024-10-24 12:57:30 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:57:30 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:57:30 --> Helper loaded: email_helper
INFO - 2024-10-24 12:57:30 --> Model Class Initialized
INFO - 2024-10-24 12:57:30 --> Model Class Initialized
INFO - 2024-10-24 12:57:30 --> Model Class Initialized
INFO - 2024-10-24 12:57:30 --> Model Class Initialized
INFO - 2024-10-24 12:57:30 --> Model Class Initialized
INFO - 2024-10-24 12:57:30 --> Model Class Initialized
INFO - 2024-10-24 12:57:30 --> Model Class Initialized
DEBUG - 2024-10-24 12:57:30 --> plural called with: company
DEBUG - 2024-10-24 12:57:30 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:57:30 --> Model Class Initialized
INFO - 2024-10-24 12:57:30 --> Model Class Initialized
INFO - 2024-10-24 12:57:30 --> Model Class Initialized
INFO - 2024-10-24 12:57:30 --> Config Class Initialized
INFO - 2024-10-24 12:57:30 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:57:30 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:57:30 --> Utf8 Class Initialized
INFO - 2024-10-24 12:57:30 --> URI Class Initialized
INFO - 2024-10-24 12:57:30 --> Router Class Initialized
INFO - 2024-10-24 12:57:30 --> Output Class Initialized
INFO - 2024-10-24 12:57:30 --> Security Class Initialized
DEBUG - 2024-10-24 12:57:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:57:30 --> Input Class Initialized
INFO - 2024-10-24 12:57:30 --> Language Class Initialized
ERROR - 2024-10-24 12:57:30 --> TEST ERROR MESSAGE - 2024-10-24 12:57:30
INFO - 2024-10-24 12:57:30 --> Loader Class Initialized
INFO - 2024-10-24 12:57:30 --> Controller Class Initialized
INFO - 2024-10-24 12:57:30 --> Database Driver Class Initialized
INFO - 2024-10-24 12:57:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:57:30 --> Helper loaded: form_helper
INFO - 2024-10-24 12:57:30 --> Helper loaded: url_helper
INFO - 2024-10-24 12:57:30 --> Model Class Initialized
INFO - 2024-10-24 12:57:30 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:57:30 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:57:30 --> Helper loaded: email_helper
INFO - 2024-10-24 12:57:30 --> Model Class Initialized
INFO - 2024-10-24 12:57:30 --> Model Class Initialized
INFO - 2024-10-24 12:57:30 --> Model Class Initialized
INFO - 2024-10-24 12:57:30 --> Model Class Initialized
INFO - 2024-10-24 12:57:30 --> Model Class Initialized
INFO - 2024-10-24 12:57:30 --> Model Class Initialized
INFO - 2024-10-24 12:57:30 --> Model Class Initialized
DEBUG - 2024-10-24 12:57:30 --> plural called with: company
DEBUG - 2024-10-24 12:57:30 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:57:30 --> Model Class Initialized
INFO - 2024-10-24 12:57:30 --> Model Class Initialized
INFO - 2024-10-24 12:57:30 --> Model Class Initialized
ERROR - 2024-10-24 12:57:33 --> Severity: Notice --> Undefined index: freetext /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 12:57:33 --> Severity: Notice --> Undefined index: socialDes /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 12:57:33 --> Severity: Notice --> Undefined index: company /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 12:57:33 --> Severity: Notice --> Undefined index: division /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 12:57:33 --> Severity: Notice --> Undefined index: dataGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 12:57:33 --> Severity: Notice --> Undefined index: finalGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
INFO - 2024-10-24 12:57:33 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 12:57:33 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 12:57:33 --> Final output sent to browser
DEBUG - 2024-10-24 12:57:33 --> Total execution time: 2.5049
INFO - 2024-10-24 12:57:57 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 12:57:57 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 12:57:57 --> Final output sent to browser
DEBUG - 2024-10-24 12:57:57 --> Total execution time: 34.4524
INFO - 2024-10-24 12:57:58 --> Config Class Initialized
INFO - 2024-10-24 12:57:58 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:57:58 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:57:58 --> Utf8 Class Initialized
INFO - 2024-10-24 12:57:58 --> URI Class Initialized
INFO - 2024-10-24 12:57:58 --> Router Class Initialized
INFO - 2024-10-24 12:57:58 --> Output Class Initialized
INFO - 2024-10-24 12:57:58 --> Security Class Initialized
DEBUG - 2024-10-24 12:57:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:57:58 --> Input Class Initialized
INFO - 2024-10-24 12:57:58 --> Language Class Initialized
ERROR - 2024-10-24 12:57:58 --> TEST ERROR MESSAGE - 2024-10-24 12:57:58
INFO - 2024-10-24 12:57:58 --> Loader Class Initialized
INFO - 2024-10-24 12:57:58 --> Controller Class Initialized
INFO - 2024-10-24 12:57:58 --> Database Driver Class Initialized
INFO - 2024-10-24 12:57:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:57:58 --> Helper loaded: form_helper
INFO - 2024-10-24 12:57:58 --> Helper loaded: url_helper
INFO - 2024-10-24 12:57:58 --> Model Class Initialized
INFO - 2024-10-24 12:57:58 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:57:58 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:57:58 --> Helper loaded: email_helper
INFO - 2024-10-24 12:57:58 --> Model Class Initialized
INFO - 2024-10-24 12:57:58 --> Model Class Initialized
INFO - 2024-10-24 12:57:58 --> Model Class Initialized
INFO - 2024-10-24 12:57:58 --> Model Class Initialized
INFO - 2024-10-24 12:57:58 --> Model Class Initialized
INFO - 2024-10-24 12:57:58 --> Model Class Initialized
INFO - 2024-10-24 12:57:58 --> Model Class Initialized
DEBUG - 2024-10-24 12:57:58 --> plural called with: company
DEBUG - 2024-10-24 12:57:58 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:57:58 --> Model Class Initialized
INFO - 2024-10-24 12:57:58 --> Model Class Initialized
INFO - 2024-10-24 12:57:58 --> Model Class Initialized
ERROR - 2024-10-24 12:57:58 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 298
ERROR - 2024-10-24 12:57:58 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 312
ERROR - 2024-10-24 12:57:58 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 317
INFO - 2024-10-24 12:57:58 --> Final output sent to browser
DEBUG - 2024-10-24 12:57:58 --> Total execution time: 0.1313
INFO - 2024-10-24 12:59:38 --> Config Class Initialized
INFO - 2024-10-24 12:59:38 --> Hooks Class Initialized
DEBUG - 2024-10-24 12:59:38 --> UTF-8 Support Enabled
INFO - 2024-10-24 12:59:38 --> Utf8 Class Initialized
INFO - 2024-10-24 12:59:38 --> URI Class Initialized
INFO - 2024-10-24 12:59:38 --> Router Class Initialized
INFO - 2024-10-24 12:59:38 --> Output Class Initialized
INFO - 2024-10-24 12:59:38 --> Security Class Initialized
DEBUG - 2024-10-24 12:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 12:59:38 --> Input Class Initialized
INFO - 2024-10-24 12:59:38 --> Language Class Initialized
ERROR - 2024-10-24 12:59:38 --> TEST ERROR MESSAGE - 2024-10-24 12:59:38
INFO - 2024-10-24 12:59:38 --> Loader Class Initialized
INFO - 2024-10-24 12:59:38 --> Controller Class Initialized
INFO - 2024-10-24 12:59:38 --> Database Driver Class Initialized
INFO - 2024-10-24 12:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 12:59:38 --> Helper loaded: form_helper
INFO - 2024-10-24 12:59:38 --> Helper loaded: url_helper
INFO - 2024-10-24 12:59:38 --> Model Class Initialized
INFO - 2024-10-24 12:59:38 --> Helper loaded: inflector_helper
INFO - 2024-10-24 12:59:38 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 12:59:38 --> Helper loaded: email_helper
INFO - 2024-10-24 12:59:38 --> Model Class Initialized
INFO - 2024-10-24 12:59:38 --> Model Class Initialized
INFO - 2024-10-24 12:59:38 --> Model Class Initialized
INFO - 2024-10-24 12:59:38 --> Model Class Initialized
INFO - 2024-10-24 12:59:38 --> Model Class Initialized
INFO - 2024-10-24 12:59:38 --> Model Class Initialized
INFO - 2024-10-24 12:59:38 --> Model Class Initialized
DEBUG - 2024-10-24 12:59:38 --> plural called with: company
DEBUG - 2024-10-24 12:59:38 --> is_countable called with!!!!: company
INFO - 2024-10-24 12:59:38 --> Model Class Initialized
INFO - 2024-10-24 12:59:38 --> Model Class Initialized
INFO - 2024-10-24 12:59:38 --> Model Class Initialized
ERROR - 2024-10-24 12:59:38 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 298
ERROR - 2024-10-24 12:59:38 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 312
ERROR - 2024-10-24 12:59:38 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 317
INFO - 2024-10-24 12:59:38 --> Final output sent to browser
DEBUG - 2024-10-24 12:59:38 --> Total execution time: 0.1137
INFO - 2024-10-24 13:01:11 --> Config Class Initialized
INFO - 2024-10-24 13:01:11 --> Hooks Class Initialized
DEBUG - 2024-10-24 13:01:11 --> UTF-8 Support Enabled
INFO - 2024-10-24 13:01:11 --> Utf8 Class Initialized
INFO - 2024-10-24 13:01:11 --> URI Class Initialized
INFO - 2024-10-24 13:01:11 --> Router Class Initialized
INFO - 2024-10-24 13:01:11 --> Output Class Initialized
INFO - 2024-10-24 13:01:11 --> Security Class Initialized
DEBUG - 2024-10-24 13:01:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 13:01:11 --> Input Class Initialized
INFO - 2024-10-24 13:01:11 --> Language Class Initialized
ERROR - 2024-10-24 13:01:11 --> TEST ERROR MESSAGE - 2024-10-24 13:01:11
INFO - 2024-10-24 13:01:11 --> Loader Class Initialized
INFO - 2024-10-24 13:01:11 --> Controller Class Initialized
INFO - 2024-10-24 13:01:11 --> Database Driver Class Initialized
INFO - 2024-10-24 13:01:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 13:01:11 --> Helper loaded: form_helper
INFO - 2024-10-24 13:01:11 --> Helper loaded: url_helper
INFO - 2024-10-24 13:01:11 --> Model Class Initialized
INFO - 2024-10-24 13:01:11 --> Helper loaded: inflector_helper
INFO - 2024-10-24 13:01:11 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 13:01:11 --> Helper loaded: email_helper
INFO - 2024-10-24 13:01:11 --> Model Class Initialized
INFO - 2024-10-24 13:01:11 --> Model Class Initialized
INFO - 2024-10-24 13:01:11 --> Model Class Initialized
INFO - 2024-10-24 13:01:11 --> Model Class Initialized
INFO - 2024-10-24 13:01:11 --> Model Class Initialized
INFO - 2024-10-24 13:01:11 --> Model Class Initialized
INFO - 2024-10-24 13:01:11 --> Model Class Initialized
DEBUG - 2024-10-24 13:01:11 --> plural called with: company
DEBUG - 2024-10-24 13:01:11 --> is_countable called with!!!!: company
INFO - 2024-10-24 13:01:11 --> Model Class Initialized
INFO - 2024-10-24 13:01:11 --> Model Class Initialized
INFO - 2024-10-24 13:01:11 --> Model Class Initialized
INFO - 2024-10-24 13:01:20 --> Config Class Initialized
INFO - 2024-10-24 13:01:20 --> Hooks Class Initialized
DEBUG - 2024-10-24 13:01:20 --> UTF-8 Support Enabled
INFO - 2024-10-24 13:01:20 --> Utf8 Class Initialized
INFO - 2024-10-24 13:01:20 --> URI Class Initialized
INFO - 2024-10-24 13:01:20 --> Router Class Initialized
INFO - 2024-10-24 13:01:20 --> Output Class Initialized
INFO - 2024-10-24 13:01:20 --> Security Class Initialized
DEBUG - 2024-10-24 13:01:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 13:01:20 --> Input Class Initialized
INFO - 2024-10-24 13:01:20 --> Language Class Initialized
ERROR - 2024-10-24 13:01:20 --> TEST ERROR MESSAGE - 2024-10-24 13:01:20
INFO - 2024-10-24 13:01:20 --> Loader Class Initialized
INFO - 2024-10-24 13:01:20 --> Controller Class Initialized
INFO - 2024-10-24 13:01:20 --> Database Driver Class Initialized
INFO - 2024-10-24 13:01:43 --> Config Class Initialized
INFO - 2024-10-24 13:01:43 --> Hooks Class Initialized
DEBUG - 2024-10-24 13:01:43 --> UTF-8 Support Enabled
INFO - 2024-10-24 13:01:43 --> Utf8 Class Initialized
INFO - 2024-10-24 13:01:43 --> URI Class Initialized
DEBUG - 2024-10-24 13:01:43 --> No URI present. Default controller set.
INFO - 2024-10-24 13:01:43 --> Router Class Initialized
INFO - 2024-10-24 13:01:43 --> Output Class Initialized
INFO - 2024-10-24 13:01:43 --> Security Class Initialized
DEBUG - 2024-10-24 13:01:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 13:01:43 --> Input Class Initialized
INFO - 2024-10-24 13:01:43 --> Language Class Initialized
ERROR - 2024-10-24 13:01:43 --> TEST ERROR MESSAGE - 2024-10-24 13:01:43
INFO - 2024-10-24 13:01:43 --> Loader Class Initialized
INFO - 2024-10-24 13:01:43 --> Controller Class Initialized
INFO - 2024-10-24 13:01:43 --> Database Driver Class Initialized
INFO - 2024-10-24 13:01:45 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 13:01:45 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 13:01:45 --> Final output sent to browser
DEBUG - 2024-10-24 13:01:45 --> Total execution time: 34.5599
INFO - 2024-10-24 13:01:45 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 13:01:45 --> Helper loaded: form_helper
INFO - 2024-10-24 13:01:45 --> Helper loaded: url_helper
INFO - 2024-10-24 13:01:45 --> Model Class Initialized
INFO - 2024-10-24 13:01:45 --> Helper loaded: inflector_helper
INFO - 2024-10-24 13:01:45 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 13:01:45 --> Helper loaded: email_helper
INFO - 2024-10-24 13:01:45 --> Model Class Initialized
INFO - 2024-10-24 13:01:45 --> Model Class Initialized
INFO - 2024-10-24 13:01:45 --> Model Class Initialized
INFO - 2024-10-24 13:01:45 --> Model Class Initialized
INFO - 2024-10-24 13:01:45 --> Model Class Initialized
INFO - 2024-10-24 13:01:45 --> Model Class Initialized
INFO - 2024-10-24 13:01:45 --> Model Class Initialized
DEBUG - 2024-10-24 13:01:45 --> plural called with: company
DEBUG - 2024-10-24 13:01:45 --> is_countable called with!!!!: company
INFO - 2024-10-24 13:01:45 --> Model Class Initialized
INFO - 2024-10-24 13:01:45 --> Model Class Initialized
INFO - 2024-10-24 13:01:45 --> Model Class Initialized
ERROR - 2024-10-24 13:01:48 --> Severity: Notice --> Undefined index: freetext /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 13:01:48 --> Severity: Notice --> Undefined index: socialDes /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 13:01:48 --> Severity: Notice --> Undefined index: company /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 13:01:48 --> Severity: Notice --> Undefined index: division /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 13:01:48 --> Severity: Notice --> Undefined index: dataGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 13:01:48 --> Severity: Notice --> Undefined index: finalGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
INFO - 2024-10-24 13:01:48 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 13:01:48 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 13:01:48 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 13:01:48 --> Helper loaded: form_helper
INFO - 2024-10-24 13:01:48 --> Helper loaded: url_helper
INFO - 2024-10-24 13:01:48 --> Model Class Initialized
INFO - 2024-10-24 13:01:48 --> Helper loaded: inflector_helper
INFO - 2024-10-24 13:01:48 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 13:01:48 --> Helper loaded: email_helper
INFO - 2024-10-24 13:01:48 --> Model Class Initialized
INFO - 2024-10-24 13:01:48 --> Model Class Initialized
INFO - 2024-10-24 13:01:48 --> Model Class Initialized
INFO - 2024-10-24 13:01:48 --> Model Class Initialized
INFO - 2024-10-24 13:01:48 --> Model Class Initialized
INFO - 2024-10-24 13:01:48 --> Model Class Initialized
INFO - 2024-10-24 13:01:48 --> Model Class Initialized
DEBUG - 2024-10-24 13:01:48 --> plural called with: company
DEBUG - 2024-10-24 13:01:48 --> is_countable called with!!!!: company
INFO - 2024-10-24 13:01:48 --> Model Class Initialized
INFO - 2024-10-24 13:01:48 --> Model Class Initialized
INFO - 2024-10-24 13:01:48 --> Model Class Initialized
INFO - 2024-10-24 13:01:48 --> Final output sent to browser
DEBUG - 2024-10-24 13:01:48 --> Total execution time: 4.8250
INFO - 2024-10-24 13:01:50 --> Config Class Initialized
INFO - 2024-10-24 13:01:50 --> Hooks Class Initialized
DEBUG - 2024-10-24 13:01:50 --> UTF-8 Support Enabled
INFO - 2024-10-24 13:01:50 --> Utf8 Class Initialized
INFO - 2024-10-24 13:01:50 --> URI Class Initialized
INFO - 2024-10-24 13:01:50 --> Router Class Initialized
INFO - 2024-10-24 13:01:50 --> Output Class Initialized
INFO - 2024-10-24 13:01:50 --> Security Class Initialized
DEBUG - 2024-10-24 13:01:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 13:01:50 --> Input Class Initialized
INFO - 2024-10-24 13:01:50 --> Language Class Initialized
ERROR - 2024-10-24 13:01:50 --> TEST ERROR MESSAGE - 2024-10-24 13:01:50
INFO - 2024-10-24 13:01:50 --> Loader Class Initialized
INFO - 2024-10-24 13:01:50 --> Controller Class Initialized
INFO - 2024-10-24 13:01:50 --> Database Driver Class Initialized
INFO - 2024-10-24 13:01:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 13:01:50 --> Helper loaded: form_helper
INFO - 2024-10-24 13:01:50 --> Helper loaded: url_helper
INFO - 2024-10-24 13:01:50 --> Model Class Initialized
INFO - 2024-10-24 13:01:50 --> Helper loaded: inflector_helper
INFO - 2024-10-24 13:01:50 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 13:01:50 --> Helper loaded: email_helper
INFO - 2024-10-24 13:01:50 --> Model Class Initialized
INFO - 2024-10-24 13:01:50 --> Model Class Initialized
INFO - 2024-10-24 13:01:50 --> Model Class Initialized
INFO - 2024-10-24 13:01:50 --> Model Class Initialized
INFO - 2024-10-24 13:01:50 --> Model Class Initialized
INFO - 2024-10-24 13:01:50 --> Model Class Initialized
INFO - 2024-10-24 13:01:50 --> Model Class Initialized
DEBUG - 2024-10-24 13:01:50 --> plural called with: company
DEBUG - 2024-10-24 13:01:50 --> is_countable called with!!!!: company
INFO - 2024-10-24 13:01:50 --> Model Class Initialized
INFO - 2024-10-24 13:01:50 --> Model Class Initialized
INFO - 2024-10-24 13:01:50 --> Model Class Initialized
ERROR - 2024-10-24 13:01:52 --> Severity: Notice --> Undefined index: freetext /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 13:01:52 --> Severity: Notice --> Undefined index: socialDes /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 13:01:52 --> Severity: Notice --> Undefined index: company /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 13:01:52 --> Severity: Notice --> Undefined index: division /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 13:01:52 --> Severity: Notice --> Undefined index: dataGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 13:01:52 --> Severity: Notice --> Undefined index: finalGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
INFO - 2024-10-24 13:01:52 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 13:01:52 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 13:01:52 --> Final output sent to browser
DEBUG - 2024-10-24 13:01:52 --> Total execution time: 2.3780
INFO - 2024-10-24 13:01:59 --> Config Class Initialized
INFO - 2024-10-24 13:01:59 --> Hooks Class Initialized
DEBUG - 2024-10-24 13:01:59 --> UTF-8 Support Enabled
INFO - 2024-10-24 13:01:59 --> Utf8 Class Initialized
INFO - 2024-10-24 13:01:59 --> URI Class Initialized
INFO - 2024-10-24 13:01:59 --> Router Class Initialized
INFO - 2024-10-24 13:01:59 --> Output Class Initialized
INFO - 2024-10-24 13:01:59 --> Security Class Initialized
DEBUG - 2024-10-24 13:01:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 13:01:59 --> Input Class Initialized
INFO - 2024-10-24 13:01:59 --> Language Class Initialized
ERROR - 2024-10-24 13:01:59 --> TEST ERROR MESSAGE - 2024-10-24 13:01:59
INFO - 2024-10-24 13:01:59 --> Loader Class Initialized
INFO - 2024-10-24 13:01:59 --> Controller Class Initialized
INFO - 2024-10-24 13:01:59 --> Database Driver Class Initialized
INFO - 2024-10-24 13:01:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 13:01:59 --> Helper loaded: form_helper
INFO - 2024-10-24 13:01:59 --> Helper loaded: url_helper
INFO - 2024-10-24 13:01:59 --> Model Class Initialized
INFO - 2024-10-24 13:01:59 --> Helper loaded: inflector_helper
INFO - 2024-10-24 13:01:59 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 13:01:59 --> Helper loaded: email_helper
INFO - 2024-10-24 13:01:59 --> Model Class Initialized
INFO - 2024-10-24 13:01:59 --> Model Class Initialized
INFO - 2024-10-24 13:01:59 --> Model Class Initialized
INFO - 2024-10-24 13:01:59 --> Model Class Initialized
INFO - 2024-10-24 13:01:59 --> Model Class Initialized
INFO - 2024-10-24 13:01:59 --> Model Class Initialized
INFO - 2024-10-24 13:01:59 --> Model Class Initialized
DEBUG - 2024-10-24 13:01:59 --> plural called with: company
DEBUG - 2024-10-24 13:01:59 --> is_countable called with!!!!: company
INFO - 2024-10-24 13:01:59 --> Model Class Initialized
INFO - 2024-10-24 13:01:59 --> Model Class Initialized
INFO - 2024-10-24 13:01:59 --> Model Class Initialized
INFO - 2024-10-24 13:01:59 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 13:01:59 --> Final output sent to browser
DEBUG - 2024-10-24 13:01:59 --> Total execution time: 0.0320
INFO - 2024-10-24 13:08:03 --> Config Class Initialized
INFO - 2024-10-24 13:08:03 --> Hooks Class Initialized
DEBUG - 2024-10-24 13:08:03 --> UTF-8 Support Enabled
INFO - 2024-10-24 13:08:03 --> Utf8 Class Initialized
INFO - 2024-10-24 13:08:03 --> URI Class Initialized
INFO - 2024-10-24 13:08:03 --> Router Class Initialized
INFO - 2024-10-24 13:08:03 --> Output Class Initialized
INFO - 2024-10-24 13:08:03 --> Security Class Initialized
DEBUG - 2024-10-24 13:08:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 13:08:03 --> Input Class Initialized
INFO - 2024-10-24 13:08:03 --> Language Class Initialized
ERROR - 2024-10-24 13:08:03 --> TEST ERROR MESSAGE - 2024-10-24 13:08:03
INFO - 2024-10-24 13:08:03 --> Loader Class Initialized
INFO - 2024-10-24 13:08:03 --> Controller Class Initialized
INFO - 2024-10-24 13:08:03 --> Database Driver Class Initialized
INFO - 2024-10-24 13:08:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 13:08:03 --> Helper loaded: form_helper
INFO - 2024-10-24 13:08:03 --> Helper loaded: url_helper
INFO - 2024-10-24 13:08:03 --> Model Class Initialized
INFO - 2024-10-24 13:08:03 --> Helper loaded: inflector_helper
INFO - 2024-10-24 13:08:03 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 13:08:03 --> Helper loaded: email_helper
INFO - 2024-10-24 13:08:03 --> Model Class Initialized
INFO - 2024-10-24 13:08:03 --> Model Class Initialized
INFO - 2024-10-24 13:08:03 --> Model Class Initialized
INFO - 2024-10-24 13:08:03 --> Model Class Initialized
INFO - 2024-10-24 13:08:03 --> Model Class Initialized
INFO - 2024-10-24 13:08:03 --> Model Class Initialized
INFO - 2024-10-24 13:08:03 --> Model Class Initialized
DEBUG - 2024-10-24 13:08:03 --> plural called with: company
DEBUG - 2024-10-24 13:08:03 --> is_countable called with!!!!: company
INFO - 2024-10-24 13:08:03 --> Model Class Initialized
INFO - 2024-10-24 13:08:03 --> Model Class Initialized
INFO - 2024-10-24 13:08:03 --> Model Class Initialized
INFO - 2024-10-24 13:08:37 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 13:08:37 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 13:08:37 --> Final output sent to browser
DEBUG - 2024-10-24 13:08:37 --> Total execution time: 34.1406
INFO - 2024-10-24 13:09:00 --> Config Class Initialized
INFO - 2024-10-24 13:09:00 --> Hooks Class Initialized
DEBUG - 2024-10-24 13:09:00 --> UTF-8 Support Enabled
INFO - 2024-10-24 13:09:00 --> Utf8 Class Initialized
INFO - 2024-10-24 13:09:00 --> URI Class Initialized
INFO - 2024-10-24 13:09:00 --> Router Class Initialized
INFO - 2024-10-24 13:09:00 --> Output Class Initialized
INFO - 2024-10-24 13:09:00 --> Security Class Initialized
DEBUG - 2024-10-24 13:09:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 13:09:00 --> Input Class Initialized
INFO - 2024-10-24 13:09:00 --> Language Class Initialized
ERROR - 2024-10-24 13:09:00 --> TEST ERROR MESSAGE - 2024-10-24 13:09:00
INFO - 2024-10-24 13:09:00 --> Loader Class Initialized
INFO - 2024-10-24 13:09:00 --> Controller Class Initialized
INFO - 2024-10-24 13:09:00 --> Database Driver Class Initialized
INFO - 2024-10-24 13:09:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 13:09:00 --> Helper loaded: form_helper
INFO - 2024-10-24 13:09:00 --> Helper loaded: url_helper
INFO - 2024-10-24 13:09:00 --> Model Class Initialized
INFO - 2024-10-24 13:09:00 --> Helper loaded: inflector_helper
INFO - 2024-10-24 13:09:00 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 13:09:00 --> Helper loaded: email_helper
INFO - 2024-10-24 13:09:00 --> Model Class Initialized
INFO - 2024-10-24 13:09:00 --> Model Class Initialized
INFO - 2024-10-24 13:09:00 --> Model Class Initialized
INFO - 2024-10-24 13:09:00 --> Model Class Initialized
INFO - 2024-10-24 13:09:00 --> Model Class Initialized
INFO - 2024-10-24 13:09:00 --> Model Class Initialized
INFO - 2024-10-24 13:09:00 --> Model Class Initialized
DEBUG - 2024-10-24 13:09:00 --> plural called with: company
DEBUG - 2024-10-24 13:09:00 --> is_countable called with!!!!: company
INFO - 2024-10-24 13:09:00 --> Model Class Initialized
INFO - 2024-10-24 13:09:00 --> Model Class Initialized
INFO - 2024-10-24 13:09:00 --> Model Class Initialized
INFO - 2024-10-24 13:09:00 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 13:09:00 --> Final output sent to browser
DEBUG - 2024-10-24 13:09:00 --> Total execution time: 0.0240
INFO - 2024-10-24 13:09:21 --> Config Class Initialized
INFO - 2024-10-24 13:09:21 --> Hooks Class Initialized
DEBUG - 2024-10-24 13:09:21 --> UTF-8 Support Enabled
INFO - 2024-10-24 13:09:21 --> Utf8 Class Initialized
INFO - 2024-10-24 13:09:21 --> URI Class Initialized
INFO - 2024-10-24 13:09:21 --> Router Class Initialized
INFO - 2024-10-24 13:09:21 --> Output Class Initialized
INFO - 2024-10-24 13:09:21 --> Security Class Initialized
DEBUG - 2024-10-24 13:09:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 13:09:21 --> Input Class Initialized
INFO - 2024-10-24 13:09:21 --> Language Class Initialized
ERROR - 2024-10-24 13:09:21 --> TEST ERROR MESSAGE - 2024-10-24 13:09:21
INFO - 2024-10-24 13:09:21 --> Loader Class Initialized
INFO - 2024-10-24 13:09:21 --> Controller Class Initialized
INFO - 2024-10-24 13:09:21 --> Database Driver Class Initialized
INFO - 2024-10-24 13:09:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 13:09:21 --> Helper loaded: form_helper
INFO - 2024-10-24 13:09:21 --> Helper loaded: url_helper
INFO - 2024-10-24 13:09:21 --> Model Class Initialized
INFO - 2024-10-24 13:09:21 --> Helper loaded: inflector_helper
INFO - 2024-10-24 13:09:21 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 13:09:21 --> Helper loaded: email_helper
INFO - 2024-10-24 13:09:21 --> Model Class Initialized
INFO - 2024-10-24 13:09:21 --> Model Class Initialized
INFO - 2024-10-24 13:09:21 --> Model Class Initialized
INFO - 2024-10-24 13:09:21 --> Model Class Initialized
INFO - 2024-10-24 13:09:21 --> Model Class Initialized
INFO - 2024-10-24 13:09:21 --> Model Class Initialized
INFO - 2024-10-24 13:09:21 --> Model Class Initialized
DEBUG - 2024-10-24 13:09:21 --> plural called with: company
DEBUG - 2024-10-24 13:09:21 --> is_countable called with!!!!: company
INFO - 2024-10-24 13:09:21 --> Model Class Initialized
INFO - 2024-10-24 13:09:21 --> Model Class Initialized
INFO - 2024-10-24 13:09:21 --> Model Class Initialized
INFO - 2024-10-24 13:09:21 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 13:09:21 --> Final output sent to browser
DEBUG - 2024-10-24 13:09:21 --> Total execution time: 0.0261
INFO - 2024-10-24 13:15:11 --> Config Class Initialized
INFO - 2024-10-24 13:15:11 --> Hooks Class Initialized
DEBUG - 2024-10-24 13:15:11 --> UTF-8 Support Enabled
INFO - 2024-10-24 13:15:11 --> Utf8 Class Initialized
INFO - 2024-10-24 13:15:11 --> URI Class Initialized
INFO - 2024-10-24 13:15:11 --> Router Class Initialized
INFO - 2024-10-24 13:15:11 --> Output Class Initialized
INFO - 2024-10-24 13:15:11 --> Security Class Initialized
DEBUG - 2024-10-24 13:15:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 13:15:11 --> Input Class Initialized
INFO - 2024-10-24 13:15:11 --> Language Class Initialized
ERROR - 2024-10-24 13:15:11 --> TEST ERROR MESSAGE - 2024-10-24 13:15:11
INFO - 2024-10-24 13:15:11 --> Loader Class Initialized
INFO - 2024-10-24 13:15:11 --> Controller Class Initialized
INFO - 2024-10-24 13:15:11 --> Database Driver Class Initialized
INFO - 2024-10-24 13:15:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 13:15:11 --> Helper loaded: form_helper
INFO - 2024-10-24 13:15:11 --> Helper loaded: url_helper
INFO - 2024-10-24 13:15:11 --> Model Class Initialized
INFO - 2024-10-24 13:15:11 --> Helper loaded: inflector_helper
INFO - 2024-10-24 13:15:11 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 13:15:11 --> Helper loaded: email_helper
INFO - 2024-10-24 13:15:11 --> Model Class Initialized
INFO - 2024-10-24 13:15:11 --> Model Class Initialized
INFO - 2024-10-24 13:15:11 --> Model Class Initialized
INFO - 2024-10-24 13:15:11 --> Model Class Initialized
INFO - 2024-10-24 13:15:11 --> Model Class Initialized
INFO - 2024-10-24 13:15:11 --> Model Class Initialized
INFO - 2024-10-24 13:15:11 --> Model Class Initialized
DEBUG - 2024-10-24 13:15:11 --> plural called with: company
DEBUG - 2024-10-24 13:15:11 --> is_countable called with!!!!: company
INFO - 2024-10-24 13:15:11 --> Model Class Initialized
INFO - 2024-10-24 13:15:11 --> Model Class Initialized
INFO - 2024-10-24 13:15:11 --> Model Class Initialized
INFO - 2024-10-24 13:15:11 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 13:15:11 --> Final output sent to browser
DEBUG - 2024-10-24 13:15:11 --> Total execution time: 0.0315
INFO - 2024-10-24 13:21:18 --> Config Class Initialized
INFO - 2024-10-24 13:21:18 --> Hooks Class Initialized
DEBUG - 2024-10-24 13:21:18 --> UTF-8 Support Enabled
INFO - 2024-10-24 13:21:18 --> Utf8 Class Initialized
INFO - 2024-10-24 13:21:18 --> URI Class Initialized
INFO - 2024-10-24 13:21:18 --> Router Class Initialized
INFO - 2024-10-24 13:21:18 --> Output Class Initialized
INFO - 2024-10-24 13:21:18 --> Security Class Initialized
DEBUG - 2024-10-24 13:21:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 13:21:18 --> Input Class Initialized
INFO - 2024-10-24 13:21:18 --> Language Class Initialized
ERROR - 2024-10-24 13:21:18 --> TEST ERROR MESSAGE - 2024-10-24 13:21:18
INFO - 2024-10-24 13:21:18 --> Loader Class Initialized
INFO - 2024-10-24 13:21:18 --> Controller Class Initialized
INFO - 2024-10-24 13:21:18 --> Database Driver Class Initialized
INFO - 2024-10-24 13:21:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 13:21:18 --> Helper loaded: form_helper
INFO - 2024-10-24 13:21:18 --> Helper loaded: url_helper
INFO - 2024-10-24 13:21:18 --> Model Class Initialized
INFO - 2024-10-24 13:21:18 --> Helper loaded: inflector_helper
INFO - 2024-10-24 13:21:18 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 13:21:18 --> Helper loaded: email_helper
INFO - 2024-10-24 13:21:18 --> Model Class Initialized
INFO - 2024-10-24 13:21:18 --> Model Class Initialized
INFO - 2024-10-24 13:21:18 --> Model Class Initialized
INFO - 2024-10-24 13:21:18 --> Model Class Initialized
INFO - 2024-10-24 13:21:18 --> Model Class Initialized
INFO - 2024-10-24 13:21:18 --> Model Class Initialized
INFO - 2024-10-24 13:21:18 --> Model Class Initialized
DEBUG - 2024-10-24 13:21:18 --> plural called with: company
DEBUG - 2024-10-24 13:21:18 --> is_countable called with!!!!: company
INFO - 2024-10-24 13:21:18 --> Model Class Initialized
INFO - 2024-10-24 13:21:18 --> Model Class Initialized
INFO - 2024-10-24 13:21:18 --> Model Class Initialized
INFO - 2024-10-24 13:21:18 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 13:21:18 --> Final output sent to browser
DEBUG - 2024-10-24 13:21:18 --> Total execution time: 0.0256
INFO - 2024-10-24 13:31:25 --> Config Class Initialized
INFO - 2024-10-24 13:31:25 --> Hooks Class Initialized
DEBUG - 2024-10-24 13:31:25 --> UTF-8 Support Enabled
INFO - 2024-10-24 13:31:25 --> Utf8 Class Initialized
INFO - 2024-10-24 13:31:25 --> URI Class Initialized
DEBUG - 2024-10-24 13:31:25 --> No URI present. Default controller set.
INFO - 2024-10-24 13:31:25 --> Router Class Initialized
INFO - 2024-10-24 13:31:25 --> Output Class Initialized
INFO - 2024-10-24 13:31:25 --> Security Class Initialized
DEBUG - 2024-10-24 13:31:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 13:31:25 --> Input Class Initialized
INFO - 2024-10-24 13:31:25 --> Language Class Initialized
ERROR - 2024-10-24 13:31:25 --> TEST ERROR MESSAGE - 2024-10-24 13:31:25
INFO - 2024-10-24 13:31:25 --> Loader Class Initialized
INFO - 2024-10-24 13:31:25 --> Controller Class Initialized
INFO - 2024-10-24 13:31:25 --> Database Driver Class Initialized
INFO - 2024-10-24 13:31:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 13:31:26 --> Helper loaded: form_helper
INFO - 2024-10-24 13:31:26 --> Helper loaded: url_helper
INFO - 2024-10-24 13:31:26 --> Model Class Initialized
INFO - 2024-10-24 13:31:26 --> Helper loaded: inflector_helper
INFO - 2024-10-24 13:31:26 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 13:31:26 --> Helper loaded: email_helper
INFO - 2024-10-24 13:31:26 --> Model Class Initialized
INFO - 2024-10-24 13:31:26 --> Model Class Initialized
INFO - 2024-10-24 13:31:26 --> Model Class Initialized
INFO - 2024-10-24 13:31:26 --> Model Class Initialized
INFO - 2024-10-24 13:31:26 --> Model Class Initialized
INFO - 2024-10-24 13:31:26 --> Model Class Initialized
INFO - 2024-10-24 13:31:26 --> Model Class Initialized
DEBUG - 2024-10-24 13:31:26 --> plural called with: company
DEBUG - 2024-10-24 13:31:26 --> is_countable called with!!!!: company
INFO - 2024-10-24 13:31:26 --> Model Class Initialized
INFO - 2024-10-24 13:31:26 --> Model Class Initialized
INFO - 2024-10-24 13:31:26 --> Model Class Initialized
ERROR - 2024-10-24 13:31:26 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 298
ERROR - 2024-10-24 13:31:26 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 312
ERROR - 2024-10-24 13:31:26 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 317
INFO - 2024-10-24 13:31:26 --> Final output sent to browser
DEBUG - 2024-10-24 13:31:26 --> Total execution time: 0.1222
INFO - 2024-10-24 13:31:50 --> Config Class Initialized
INFO - 2024-10-24 13:31:50 --> Hooks Class Initialized
DEBUG - 2024-10-24 13:31:50 --> UTF-8 Support Enabled
INFO - 2024-10-24 13:31:50 --> Utf8 Class Initialized
INFO - 2024-10-24 13:31:50 --> URI Class Initialized
INFO - 2024-10-24 13:31:50 --> Router Class Initialized
INFO - 2024-10-24 13:31:50 --> Output Class Initialized
INFO - 2024-10-24 13:31:50 --> Security Class Initialized
DEBUG - 2024-10-24 13:31:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 13:31:50 --> Input Class Initialized
INFO - 2024-10-24 13:31:50 --> Language Class Initialized
ERROR - 2024-10-24 13:31:50 --> TEST ERROR MESSAGE - 2024-10-24 13:31:50
INFO - 2024-10-24 13:31:50 --> Loader Class Initialized
INFO - 2024-10-24 13:31:50 --> Controller Class Initialized
INFO - 2024-10-24 13:31:50 --> Database Driver Class Initialized
INFO - 2024-10-24 13:31:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 13:31:50 --> Helper loaded: form_helper
INFO - 2024-10-24 13:31:50 --> Helper loaded: url_helper
INFO - 2024-10-24 13:31:50 --> Model Class Initialized
INFO - 2024-10-24 13:31:50 --> Helper loaded: inflector_helper
INFO - 2024-10-24 13:31:50 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 13:31:50 --> Helper loaded: email_helper
INFO - 2024-10-24 13:31:50 --> Model Class Initialized
INFO - 2024-10-24 13:31:50 --> Model Class Initialized
INFO - 2024-10-24 13:31:50 --> Model Class Initialized
INFO - 2024-10-24 13:31:50 --> Model Class Initialized
INFO - 2024-10-24 13:31:50 --> Model Class Initialized
INFO - 2024-10-24 13:31:50 --> Model Class Initialized
INFO - 2024-10-24 13:31:50 --> Model Class Initialized
DEBUG - 2024-10-24 13:31:50 --> plural called with: company
DEBUG - 2024-10-24 13:31:50 --> is_countable called with!!!!: company
INFO - 2024-10-24 13:31:50 --> Model Class Initialized
INFO - 2024-10-24 13:31:50 --> Model Class Initialized
INFO - 2024-10-24 13:31:50 --> Model Class Initialized
INFO - 2024-10-24 13:32:02 --> Config Class Initialized
INFO - 2024-10-24 13:32:02 --> Hooks Class Initialized
DEBUG - 2024-10-24 13:32:02 --> UTF-8 Support Enabled
INFO - 2024-10-24 13:32:02 --> Utf8 Class Initialized
INFO - 2024-10-24 13:32:02 --> URI Class Initialized
INFO - 2024-10-24 13:32:02 --> Router Class Initialized
INFO - 2024-10-24 13:32:02 --> Output Class Initialized
INFO - 2024-10-24 13:32:02 --> Security Class Initialized
DEBUG - 2024-10-24 13:32:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 13:32:02 --> Input Class Initialized
INFO - 2024-10-24 13:32:02 --> Language Class Initialized
ERROR - 2024-10-24 13:32:02 --> TEST ERROR MESSAGE - 2024-10-24 13:32:02
INFO - 2024-10-24 13:32:02 --> Loader Class Initialized
INFO - 2024-10-24 13:32:02 --> Controller Class Initialized
INFO - 2024-10-24 13:32:02 --> Database Driver Class Initialized
INFO - 2024-10-24 13:32:05 --> Config Class Initialized
INFO - 2024-10-24 13:32:05 --> Hooks Class Initialized
DEBUG - 2024-10-24 13:32:05 --> UTF-8 Support Enabled
INFO - 2024-10-24 13:32:05 --> Utf8 Class Initialized
INFO - 2024-10-24 13:32:05 --> URI Class Initialized
INFO - 2024-10-24 13:32:05 --> Router Class Initialized
INFO - 2024-10-24 13:32:05 --> Output Class Initialized
INFO - 2024-10-24 13:32:05 --> Security Class Initialized
DEBUG - 2024-10-24 13:32:05 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 13:32:05 --> Input Class Initialized
INFO - 2024-10-24 13:32:05 --> Language Class Initialized
ERROR - 2024-10-24 13:32:05 --> TEST ERROR MESSAGE - 2024-10-24 13:32:05
INFO - 2024-10-24 13:32:05 --> Loader Class Initialized
INFO - 2024-10-24 13:32:05 --> Controller Class Initialized
INFO - 2024-10-24 13:32:05 --> Database Driver Class Initialized
INFO - 2024-10-24 13:32:10 --> Config Class Initialized
INFO - 2024-10-24 13:32:10 --> Hooks Class Initialized
DEBUG - 2024-10-24 13:32:10 --> UTF-8 Support Enabled
INFO - 2024-10-24 13:32:10 --> Utf8 Class Initialized
INFO - 2024-10-24 13:32:10 --> URI Class Initialized
INFO - 2024-10-24 13:32:10 --> Router Class Initialized
INFO - 2024-10-24 13:32:10 --> Output Class Initialized
INFO - 2024-10-24 13:32:10 --> Security Class Initialized
DEBUG - 2024-10-24 13:32:10 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 13:32:10 --> Input Class Initialized
INFO - 2024-10-24 13:32:10 --> Language Class Initialized
ERROR - 2024-10-24 13:32:10 --> TEST ERROR MESSAGE - 2024-10-24 13:32:10
INFO - 2024-10-24 13:32:10 --> Loader Class Initialized
INFO - 2024-10-24 13:32:10 --> Controller Class Initialized
INFO - 2024-10-24 13:32:10 --> Database Driver Class Initialized
INFO - 2024-10-24 13:32:20 --> Config Class Initialized
INFO - 2024-10-24 13:32:20 --> Hooks Class Initialized
DEBUG - 2024-10-24 13:32:20 --> UTF-8 Support Enabled
INFO - 2024-10-24 13:32:20 --> Utf8 Class Initialized
INFO - 2024-10-24 13:32:20 --> URI Class Initialized
INFO - 2024-10-24 13:32:20 --> Router Class Initialized
INFO - 2024-10-24 13:32:20 --> Output Class Initialized
INFO - 2024-10-24 13:32:20 --> Security Class Initialized
DEBUG - 2024-10-24 13:32:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 13:32:20 --> Input Class Initialized
INFO - 2024-10-24 13:32:20 --> Language Class Initialized
ERROR - 2024-10-24 13:32:20 --> TEST ERROR MESSAGE - 2024-10-24 13:32:20
INFO - 2024-10-24 13:32:20 --> Loader Class Initialized
INFO - 2024-10-24 13:32:20 --> Controller Class Initialized
INFO - 2024-10-24 13:32:20 --> Database Driver Class Initialized
INFO - 2024-10-24 13:32:26 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 13:32:26 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 13:32:26 --> Final output sent to browser
DEBUG - 2024-10-24 13:32:26 --> Total execution time: 35.5100
INFO - 2024-10-24 13:32:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 13:32:26 --> Helper loaded: form_helper
INFO - 2024-10-24 13:32:26 --> Helper loaded: url_helper
INFO - 2024-10-24 13:32:26 --> Model Class Initialized
INFO - 2024-10-24 13:32:26 --> Helper loaded: inflector_helper
INFO - 2024-10-24 13:32:26 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 13:32:26 --> Helper loaded: email_helper
INFO - 2024-10-24 13:32:26 --> Model Class Initialized
INFO - 2024-10-24 13:32:26 --> Model Class Initialized
INFO - 2024-10-24 13:32:26 --> Model Class Initialized
INFO - 2024-10-24 13:32:26 --> Model Class Initialized
INFO - 2024-10-24 13:32:26 --> Model Class Initialized
INFO - 2024-10-24 13:32:26 --> Model Class Initialized
INFO - 2024-10-24 13:32:26 --> Model Class Initialized
DEBUG - 2024-10-24 13:32:26 --> plural called with: company
DEBUG - 2024-10-24 13:32:26 --> is_countable called with!!!!: company
INFO - 2024-10-24 13:32:26 --> Model Class Initialized
INFO - 2024-10-24 13:32:26 --> Model Class Initialized
INFO - 2024-10-24 13:32:26 --> Model Class Initialized
INFO - 2024-10-24 13:32:31 --> Config Class Initialized
INFO - 2024-10-24 13:32:31 --> Hooks Class Initialized
DEBUG - 2024-10-24 13:32:31 --> UTF-8 Support Enabled
INFO - 2024-10-24 13:32:31 --> Utf8 Class Initialized
INFO - 2024-10-24 13:32:31 --> URI Class Initialized
INFO - 2024-10-24 13:32:31 --> Router Class Initialized
INFO - 2024-10-24 13:32:31 --> Output Class Initialized
INFO - 2024-10-24 13:32:31 --> Security Class Initialized
DEBUG - 2024-10-24 13:32:31 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 13:32:31 --> Input Class Initialized
INFO - 2024-10-24 13:32:31 --> Language Class Initialized
ERROR - 2024-10-24 13:32:31 --> TEST ERROR MESSAGE - 2024-10-24 13:32:31
INFO - 2024-10-24 13:32:31 --> Loader Class Initialized
INFO - 2024-10-24 13:32:31 --> Controller Class Initialized
INFO - 2024-10-24 13:32:31 --> Database Driver Class Initialized
INFO - 2024-10-24 13:32:32 --> Config Class Initialized
INFO - 2024-10-24 13:32:32 --> Hooks Class Initialized
DEBUG - 2024-10-24 13:32:32 --> UTF-8 Support Enabled
INFO - 2024-10-24 13:32:32 --> Utf8 Class Initialized
INFO - 2024-10-24 13:32:32 --> URI Class Initialized
INFO - 2024-10-24 13:32:32 --> Router Class Initialized
INFO - 2024-10-24 13:32:32 --> Output Class Initialized
INFO - 2024-10-24 13:32:32 --> Security Class Initialized
DEBUG - 2024-10-24 13:32:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 13:32:32 --> Input Class Initialized
INFO - 2024-10-24 13:32:32 --> Language Class Initialized
ERROR - 2024-10-24 13:32:32 --> TEST ERROR MESSAGE - 2024-10-24 13:32:32
INFO - 2024-10-24 13:32:32 --> Loader Class Initialized
INFO - 2024-10-24 13:32:32 --> Controller Class Initialized
INFO - 2024-10-24 13:32:32 --> Database Driver Class Initialized
INFO - 2024-10-24 13:32:35 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 13:32:35 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 13:32:35 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 13:32:35 --> Helper loaded: form_helper
INFO - 2024-10-24 13:32:35 --> Helper loaded: url_helper
INFO - 2024-10-24 13:32:35 --> Model Class Initialized
INFO - 2024-10-24 13:32:35 --> Helper loaded: inflector_helper
INFO - 2024-10-24 13:32:35 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 13:32:35 --> Helper loaded: email_helper
INFO - 2024-10-24 13:32:35 --> Model Class Initialized
INFO - 2024-10-24 13:32:35 --> Model Class Initialized
INFO - 2024-10-24 13:32:35 --> Model Class Initialized
INFO - 2024-10-24 13:32:35 --> Model Class Initialized
INFO - 2024-10-24 13:32:35 --> Model Class Initialized
INFO - 2024-10-24 13:32:35 --> Model Class Initialized
INFO - 2024-10-24 13:32:35 --> Model Class Initialized
DEBUG - 2024-10-24 13:32:35 --> plural called with: company
DEBUG - 2024-10-24 13:32:35 --> is_countable called with!!!!: company
INFO - 2024-10-24 13:32:35 --> Model Class Initialized
INFO - 2024-10-24 13:32:35 --> Model Class Initialized
INFO - 2024-10-24 13:32:35 --> Model Class Initialized
INFO - 2024-10-24 13:32:44 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 13:32:44 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 13:32:44 --> Final output sent to browser
DEBUG - 2024-10-24 13:32:44 --> Total execution time: 39.6362
INFO - 2024-10-24 13:32:44 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 13:32:44 --> Helper loaded: form_helper
INFO - 2024-10-24 13:32:44 --> Helper loaded: url_helper
INFO - 2024-10-24 13:32:44 --> Model Class Initialized
INFO - 2024-10-24 13:32:44 --> Helper loaded: inflector_helper
INFO - 2024-10-24 13:32:44 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 13:32:44 --> Helper loaded: email_helper
INFO - 2024-10-24 13:32:44 --> Model Class Initialized
INFO - 2024-10-24 13:32:44 --> Model Class Initialized
INFO - 2024-10-24 13:32:44 --> Model Class Initialized
INFO - 2024-10-24 13:32:44 --> Model Class Initialized
INFO - 2024-10-24 13:32:44 --> Model Class Initialized
INFO - 2024-10-24 13:32:44 --> Model Class Initialized
INFO - 2024-10-24 13:32:44 --> Model Class Initialized
DEBUG - 2024-10-24 13:32:44 --> plural called with: company
DEBUG - 2024-10-24 13:32:44 --> is_countable called with!!!!: company
INFO - 2024-10-24 13:32:44 --> Model Class Initialized
INFO - 2024-10-24 13:32:44 --> Model Class Initialized
INFO - 2024-10-24 13:32:44 --> Model Class Initialized
ERROR - 2024-10-24 13:32:47 --> Severity: Notice --> Undefined index: freetext /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 13:32:47 --> Severity: Notice --> Undefined index: socialDes /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 13:32:47 --> Severity: Notice --> Undefined index: company /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 13:32:47 --> Severity: Notice --> Undefined index: division /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 13:32:47 --> Severity: Notice --> Undefined index: dataGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 13:32:47 --> Severity: Notice --> Undefined index: finalGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
INFO - 2024-10-24 13:32:47 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 13:32:47 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 13:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 13:32:47 --> Helper loaded: form_helper
INFO - 2024-10-24 13:32:47 --> Helper loaded: url_helper
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> Helper loaded: inflector_helper
INFO - 2024-10-24 13:32:47 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 13:32:47 --> Helper loaded: email_helper
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
DEBUG - 2024-10-24 13:32:47 --> plural called with: company
DEBUG - 2024-10-24 13:32:47 --> is_countable called with!!!!: company
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-24 13:32:47 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 13:32:47 --> Final output sent to browser
DEBUG - 2024-10-24 13:32:47 --> Total execution time: 27.0960
INFO - 2024-10-24 13:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 13:32:47 --> Helper loaded: form_helper
INFO - 2024-10-24 13:32:47 --> Helper loaded: url_helper
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> Helper loaded: inflector_helper
INFO - 2024-10-24 13:32:47 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 13:32:47 --> Helper loaded: email_helper
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
DEBUG - 2024-10-24 13:32:47 --> plural called with: company
DEBUG - 2024-10-24 13:32:47 --> is_countable called with!!!!: company
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-24 13:32:47 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 13:32:47 --> Final output sent to browser
DEBUG - 2024-10-24 13:32:47 --> Total execution time: 15.5811
INFO - 2024-10-24 13:32:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 13:32:47 --> Helper loaded: form_helper
INFO - 2024-10-24 13:32:47 --> Helper loaded: url_helper
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> Helper loaded: inflector_helper
INFO - 2024-10-24 13:32:47 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 13:32:47 --> Helper loaded: email_helper
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
DEBUG - 2024-10-24 13:32:47 --> plural called with: company
DEBUG - 2024-10-24 13:32:47 --> is_countable called with!!!!: company
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> Model Class Initialized
INFO - 2024-10-24 13:32:47 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-24 13:32:47 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 13:32:47 --> Final output sent to browser
DEBUG - 2024-10-24 13:32:47 --> Total execution time: 15.3500
INFO - 2024-10-24 13:32:59 --> Config Class Initialized
INFO - 2024-10-24 13:32:59 --> Hooks Class Initialized
DEBUG - 2024-10-24 13:32:59 --> UTF-8 Support Enabled
INFO - 2024-10-24 13:32:59 --> Utf8 Class Initialized
INFO - 2024-10-24 13:32:59 --> URI Class Initialized
INFO - 2024-10-24 13:32:59 --> Router Class Initialized
INFO - 2024-10-24 13:32:59 --> Output Class Initialized
INFO - 2024-10-24 13:32:59 --> Security Class Initialized
DEBUG - 2024-10-24 13:32:59 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 13:32:59 --> Input Class Initialized
INFO - 2024-10-24 13:32:59 --> Language Class Initialized
ERROR - 2024-10-24 13:32:59 --> TEST ERROR MESSAGE - 2024-10-24 13:32:59
INFO - 2024-10-24 13:32:59 --> Loader Class Initialized
INFO - 2024-10-24 13:32:59 --> Controller Class Initialized
INFO - 2024-10-24 13:32:59 --> Database Driver Class Initialized
INFO - 2024-10-24 13:32:59 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 13:32:59 --> Helper loaded: form_helper
INFO - 2024-10-24 13:32:59 --> Helper loaded: url_helper
INFO - 2024-10-24 13:32:59 --> Model Class Initialized
INFO - 2024-10-24 13:32:59 --> Helper loaded: inflector_helper
INFO - 2024-10-24 13:32:59 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 13:32:59 --> Helper loaded: email_helper
INFO - 2024-10-24 13:32:59 --> Model Class Initialized
INFO - 2024-10-24 13:32:59 --> Model Class Initialized
INFO - 2024-10-24 13:32:59 --> Model Class Initialized
INFO - 2024-10-24 13:32:59 --> Model Class Initialized
INFO - 2024-10-24 13:32:59 --> Model Class Initialized
INFO - 2024-10-24 13:32:59 --> Model Class Initialized
INFO - 2024-10-24 13:32:59 --> Model Class Initialized
DEBUG - 2024-10-24 13:32:59 --> plural called with: company
DEBUG - 2024-10-24 13:32:59 --> is_countable called with!!!!: company
INFO - 2024-10-24 13:32:59 --> Model Class Initialized
INFO - 2024-10-24 13:32:59 --> Model Class Initialized
INFO - 2024-10-24 13:32:59 --> Model Class Initialized
INFO - 2024-10-24 13:32:59 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-24 13:32:59 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 13:32:59 --> Final output sent to browser
DEBUG - 2024-10-24 13:32:59 --> Total execution time: 0.0305
INFO - 2024-10-24 13:33:52 --> Config Class Initialized
INFO - 2024-10-24 13:33:52 --> Hooks Class Initialized
DEBUG - 2024-10-24 13:33:52 --> UTF-8 Support Enabled
INFO - 2024-10-24 13:33:52 --> Utf8 Class Initialized
INFO - 2024-10-24 13:33:52 --> URI Class Initialized
INFO - 2024-10-24 13:33:52 --> Router Class Initialized
INFO - 2024-10-24 13:33:52 --> Output Class Initialized
INFO - 2024-10-24 13:33:52 --> Security Class Initialized
DEBUG - 2024-10-24 13:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 13:33:52 --> Input Class Initialized
INFO - 2024-10-24 13:33:52 --> Language Class Initialized
ERROR - 2024-10-24 13:33:52 --> TEST ERROR MESSAGE - 2024-10-24 13:33:52
INFO - 2024-10-24 13:33:52 --> Loader Class Initialized
INFO - 2024-10-24 13:33:52 --> Controller Class Initialized
INFO - 2024-10-24 13:33:52 --> Database Driver Class Initialized
INFO - 2024-10-24 13:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 13:33:52 --> Helper loaded: form_helper
INFO - 2024-10-24 13:33:52 --> Helper loaded: url_helper
INFO - 2024-10-24 13:33:52 --> Model Class Initialized
INFO - 2024-10-24 13:33:52 --> Helper loaded: inflector_helper
INFO - 2024-10-24 13:33:52 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 13:33:52 --> Helper loaded: email_helper
INFO - 2024-10-24 13:33:52 --> Model Class Initialized
INFO - 2024-10-24 13:33:52 --> Model Class Initialized
INFO - 2024-10-24 13:33:52 --> Model Class Initialized
INFO - 2024-10-24 13:33:52 --> Model Class Initialized
INFO - 2024-10-24 13:33:52 --> Model Class Initialized
INFO - 2024-10-24 13:33:52 --> Model Class Initialized
INFO - 2024-10-24 13:33:52 --> Model Class Initialized
DEBUG - 2024-10-24 13:33:52 --> plural called with: company
DEBUG - 2024-10-24 13:33:52 --> is_countable called with!!!!: company
INFO - 2024-10-24 13:33:52 --> Model Class Initialized
INFO - 2024-10-24 13:33:52 --> Model Class Initialized
INFO - 2024-10-24 13:33:52 --> Model Class Initialized
INFO - 2024-10-24 13:33:52 --> Config Class Initialized
INFO - 2024-10-24 13:33:52 --> Hooks Class Initialized
DEBUG - 2024-10-24 13:33:52 --> UTF-8 Support Enabled
INFO - 2024-10-24 13:33:52 --> Utf8 Class Initialized
INFO - 2024-10-24 13:33:52 --> URI Class Initialized
INFO - 2024-10-24 13:33:52 --> Router Class Initialized
INFO - 2024-10-24 13:33:52 --> Output Class Initialized
INFO - 2024-10-24 13:33:52 --> Security Class Initialized
DEBUG - 2024-10-24 13:33:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 13:33:52 --> Input Class Initialized
INFO - 2024-10-24 13:33:52 --> Language Class Initialized
ERROR - 2024-10-24 13:33:52 --> TEST ERROR MESSAGE - 2024-10-24 13:33:52
INFO - 2024-10-24 13:33:52 --> Loader Class Initialized
INFO - 2024-10-24 13:33:52 --> Controller Class Initialized
INFO - 2024-10-24 13:33:52 --> Database Driver Class Initialized
INFO - 2024-10-24 13:33:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 13:33:52 --> Helper loaded: form_helper
INFO - 2024-10-24 13:33:52 --> Helper loaded: url_helper
INFO - 2024-10-24 13:33:52 --> Model Class Initialized
INFO - 2024-10-24 13:33:52 --> Helper loaded: inflector_helper
INFO - 2024-10-24 13:33:52 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 13:33:52 --> Helper loaded: email_helper
INFO - 2024-10-24 13:33:52 --> Model Class Initialized
INFO - 2024-10-24 13:33:52 --> Model Class Initialized
INFO - 2024-10-24 13:33:52 --> Model Class Initialized
INFO - 2024-10-24 13:33:52 --> Model Class Initialized
INFO - 2024-10-24 13:33:52 --> Model Class Initialized
INFO - 2024-10-24 13:33:52 --> Model Class Initialized
INFO - 2024-10-24 13:33:52 --> Model Class Initialized
DEBUG - 2024-10-24 13:33:52 --> plural called with: company
DEBUG - 2024-10-24 13:33:52 --> is_countable called with!!!!: company
INFO - 2024-10-24 13:33:52 --> Model Class Initialized
INFO - 2024-10-24 13:33:52 --> Model Class Initialized
INFO - 2024-10-24 13:33:52 --> Model Class Initialized
ERROR - 2024-10-24 13:33:54 --> Severity: Notice --> Undefined index: freetext /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 13:33:54 --> Severity: Notice --> Undefined index: socialDes /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 13:33:54 --> Severity: Notice --> Undefined index: company /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 13:33:54 --> Severity: Notice --> Undefined index: division /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 13:33:54 --> Severity: Notice --> Undefined index: dataGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 13:33:54 --> Severity: Notice --> Undefined index: finalGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
INFO - 2024-10-24 13:33:54 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 13:33:54 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 13:33:54 --> Final output sent to browser
DEBUG - 2024-10-24 13:33:54 --> Total execution time: 2.5130
INFO - 2024-10-24 13:34:07 --> Config Class Initialized
INFO - 2024-10-24 13:34:07 --> Hooks Class Initialized
DEBUG - 2024-10-24 13:34:07 --> UTF-8 Support Enabled
INFO - 2024-10-24 13:34:07 --> Utf8 Class Initialized
INFO - 2024-10-24 13:34:07 --> URI Class Initialized
INFO - 2024-10-24 13:34:07 --> Router Class Initialized
INFO - 2024-10-24 13:34:07 --> Output Class Initialized
INFO - 2024-10-24 13:34:07 --> Security Class Initialized
DEBUG - 2024-10-24 13:34:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 13:34:07 --> Input Class Initialized
INFO - 2024-10-24 13:34:07 --> Language Class Initialized
ERROR - 2024-10-24 13:34:07 --> TEST ERROR MESSAGE - 2024-10-24 13:34:07
INFO - 2024-10-24 13:34:07 --> Loader Class Initialized
INFO - 2024-10-24 13:34:07 --> Controller Class Initialized
INFO - 2024-10-24 13:34:07 --> Database Driver Class Initialized
INFO - 2024-10-24 13:34:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 13:34:07 --> Helper loaded: form_helper
INFO - 2024-10-24 13:34:07 --> Helper loaded: url_helper
INFO - 2024-10-24 13:34:07 --> Model Class Initialized
INFO - 2024-10-24 13:34:07 --> Helper loaded: inflector_helper
INFO - 2024-10-24 13:34:07 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 13:34:07 --> Helper loaded: email_helper
INFO - 2024-10-24 13:34:07 --> Model Class Initialized
INFO - 2024-10-24 13:34:07 --> Model Class Initialized
INFO - 2024-10-24 13:34:07 --> Model Class Initialized
INFO - 2024-10-24 13:34:07 --> Model Class Initialized
INFO - 2024-10-24 13:34:07 --> Model Class Initialized
INFO - 2024-10-24 13:34:07 --> Model Class Initialized
INFO - 2024-10-24 13:34:07 --> Model Class Initialized
DEBUG - 2024-10-24 13:34:07 --> plural called with: company
DEBUG - 2024-10-24 13:34:07 --> is_countable called with!!!!: company
INFO - 2024-10-24 13:34:07 --> Model Class Initialized
INFO - 2024-10-24 13:34:07 --> Model Class Initialized
INFO - 2024-10-24 13:34:07 --> Model Class Initialized
INFO - 2024-10-24 13:34:07 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 13:34:07 --> Final output sent to browser
DEBUG - 2024-10-24 13:34:07 --> Total execution time: 0.0242
INFO - 2024-10-24 13:35:50 --> Config Class Initialized
INFO - 2024-10-24 13:35:50 --> Hooks Class Initialized
DEBUG - 2024-10-24 13:35:50 --> UTF-8 Support Enabled
INFO - 2024-10-24 13:35:50 --> Utf8 Class Initialized
INFO - 2024-10-24 13:35:50 --> URI Class Initialized
INFO - 2024-10-24 13:35:50 --> Router Class Initialized
INFO - 2024-10-24 13:35:50 --> Output Class Initialized
INFO - 2024-10-24 13:35:50 --> Security Class Initialized
DEBUG - 2024-10-24 13:35:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 13:35:50 --> Input Class Initialized
INFO - 2024-10-24 13:35:50 --> Language Class Initialized
ERROR - 2024-10-24 13:35:50 --> TEST ERROR MESSAGE - 2024-10-24 13:35:50
INFO - 2024-10-24 13:35:50 --> Loader Class Initialized
INFO - 2024-10-24 13:35:50 --> Controller Class Initialized
INFO - 2024-10-24 13:35:50 --> Database Driver Class Initialized
INFO - 2024-10-24 13:35:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 13:35:50 --> Helper loaded: form_helper
INFO - 2024-10-24 13:35:50 --> Helper loaded: url_helper
INFO - 2024-10-24 13:35:50 --> Model Class Initialized
INFO - 2024-10-24 13:35:50 --> Helper loaded: inflector_helper
INFO - 2024-10-24 13:35:50 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 13:35:50 --> Helper loaded: email_helper
INFO - 2024-10-24 13:35:50 --> Model Class Initialized
INFO - 2024-10-24 13:35:50 --> Model Class Initialized
INFO - 2024-10-24 13:35:50 --> Model Class Initialized
INFO - 2024-10-24 13:35:50 --> Model Class Initialized
INFO - 2024-10-24 13:35:50 --> Model Class Initialized
INFO - 2024-10-24 13:35:50 --> Model Class Initialized
INFO - 2024-10-24 13:35:50 --> Model Class Initialized
DEBUG - 2024-10-24 13:35:50 --> plural called with: company
DEBUG - 2024-10-24 13:35:50 --> is_countable called with!!!!: company
INFO - 2024-10-24 13:35:50 --> Model Class Initialized
INFO - 2024-10-24 13:35:50 --> Model Class Initialized
INFO - 2024-10-24 13:35:50 --> Model Class Initialized
INFO - 2024-10-24 13:35:50 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 13:35:50 --> Final output sent to browser
DEBUG - 2024-10-24 13:35:50 --> Total execution time: 0.0240
INFO - 2024-10-24 13:36:02 --> Config Class Initialized
INFO - 2024-10-24 13:36:02 --> Hooks Class Initialized
DEBUG - 2024-10-24 13:36:02 --> UTF-8 Support Enabled
INFO - 2024-10-24 13:36:02 --> Utf8 Class Initialized
INFO - 2024-10-24 13:36:02 --> URI Class Initialized
INFO - 2024-10-24 13:36:02 --> Router Class Initialized
INFO - 2024-10-24 13:36:02 --> Output Class Initialized
INFO - 2024-10-24 13:36:02 --> Security Class Initialized
DEBUG - 2024-10-24 13:36:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 13:36:02 --> Input Class Initialized
INFO - 2024-10-24 13:36:02 --> Language Class Initialized
ERROR - 2024-10-24 13:36:02 --> TEST ERROR MESSAGE - 2024-10-24 13:36:02
INFO - 2024-10-24 13:36:02 --> Loader Class Initialized
INFO - 2024-10-24 13:36:02 --> Controller Class Initialized
INFO - 2024-10-24 13:36:02 --> Database Driver Class Initialized
INFO - 2024-10-24 13:36:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 13:36:02 --> Helper loaded: form_helper
INFO - 2024-10-24 13:36:02 --> Helper loaded: url_helper
INFO - 2024-10-24 13:36:02 --> Model Class Initialized
INFO - 2024-10-24 13:36:02 --> Helper loaded: inflector_helper
INFO - 2024-10-24 13:36:02 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 13:36:02 --> Helper loaded: email_helper
INFO - 2024-10-24 13:36:02 --> Model Class Initialized
INFO - 2024-10-24 13:36:02 --> Model Class Initialized
INFO - 2024-10-24 13:36:02 --> Model Class Initialized
INFO - 2024-10-24 13:36:02 --> Model Class Initialized
INFO - 2024-10-24 13:36:02 --> Model Class Initialized
INFO - 2024-10-24 13:36:02 --> Model Class Initialized
INFO - 2024-10-24 13:36:02 --> Model Class Initialized
DEBUG - 2024-10-24 13:36:02 --> plural called with: company
DEBUG - 2024-10-24 13:36:02 --> is_countable called with!!!!: company
INFO - 2024-10-24 13:36:02 --> Model Class Initialized
INFO - 2024-10-24 13:36:02 --> Model Class Initialized
INFO - 2024-10-24 13:36:02 --> Model Class Initialized
INFO - 2024-10-24 13:36:04 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 13:36:04 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 13:36:04 --> Final output sent to browser
DEBUG - 2024-10-24 13:36:04 --> Total execution time: 1.7966
INFO - 2024-10-24 17:59:34 --> Config Class Initialized
INFO - 2024-10-24 17:59:34 --> Hooks Class Initialized
DEBUG - 2024-10-24 17:59:34 --> UTF-8 Support Enabled
INFO - 2024-10-24 17:59:34 --> Utf8 Class Initialized
INFO - 2024-10-24 17:59:34 --> URI Class Initialized
INFO - 2024-10-24 17:59:34 --> Router Class Initialized
INFO - 2024-10-24 17:59:34 --> Output Class Initialized
INFO - 2024-10-24 17:59:34 --> Security Class Initialized
DEBUG - 2024-10-24 17:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 17:59:34 --> Input Class Initialized
INFO - 2024-10-24 17:59:34 --> Language Class Initialized
ERROR - 2024-10-24 17:59:34 --> TEST ERROR MESSAGE - 2024-10-24 17:59:34
INFO - 2024-10-24 17:59:34 --> Loader Class Initialized
INFO - 2024-10-24 17:59:34 --> Controller Class Initialized
INFO - 2024-10-24 17:59:34 --> Database Driver Class Initialized
INFO - 2024-10-24 17:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 17:59:34 --> Helper loaded: form_helper
INFO - 2024-10-24 17:59:34 --> Helper loaded: url_helper
INFO - 2024-10-24 17:59:34 --> Model Class Initialized
INFO - 2024-10-24 17:59:34 --> Helper loaded: inflector_helper
INFO - 2024-10-24 17:59:34 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 17:59:34 --> Helper loaded: email_helper
INFO - 2024-10-24 17:59:34 --> Model Class Initialized
INFO - 2024-10-24 17:59:34 --> Model Class Initialized
INFO - 2024-10-24 17:59:34 --> Model Class Initialized
INFO - 2024-10-24 17:59:34 --> Model Class Initialized
INFO - 2024-10-24 17:59:34 --> Model Class Initialized
INFO - 2024-10-24 17:59:34 --> Model Class Initialized
INFO - 2024-10-24 17:59:34 --> Model Class Initialized
DEBUG - 2024-10-24 17:59:34 --> plural called with: company
DEBUG - 2024-10-24 17:59:34 --> is_countable called with!!!!: company
INFO - 2024-10-24 17:59:34 --> Model Class Initialized
INFO - 2024-10-24 17:59:34 --> Model Class Initialized
INFO - 2024-10-24 17:59:34 --> Model Class Initialized
INFO - 2024-10-24 17:59:34 --> Config Class Initialized
INFO - 2024-10-24 17:59:34 --> Hooks Class Initialized
DEBUG - 2024-10-24 17:59:34 --> UTF-8 Support Enabled
INFO - 2024-10-24 17:59:34 --> Utf8 Class Initialized
INFO - 2024-10-24 17:59:34 --> URI Class Initialized
INFO - 2024-10-24 17:59:34 --> Router Class Initialized
INFO - 2024-10-24 17:59:34 --> Output Class Initialized
INFO - 2024-10-24 17:59:34 --> Security Class Initialized
DEBUG - 2024-10-24 17:59:34 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 17:59:34 --> Input Class Initialized
INFO - 2024-10-24 17:59:34 --> Language Class Initialized
ERROR - 2024-10-24 17:59:34 --> TEST ERROR MESSAGE - 2024-10-24 17:59:34
INFO - 2024-10-24 17:59:34 --> Loader Class Initialized
INFO - 2024-10-24 17:59:34 --> Controller Class Initialized
INFO - 2024-10-24 17:59:34 --> Database Driver Class Initialized
INFO - 2024-10-24 17:59:34 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 17:59:34 --> Helper loaded: form_helper
INFO - 2024-10-24 17:59:34 --> Helper loaded: url_helper
INFO - 2024-10-24 17:59:34 --> Model Class Initialized
INFO - 2024-10-24 17:59:34 --> Helper loaded: inflector_helper
INFO - 2024-10-24 17:59:34 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 17:59:34 --> Helper loaded: email_helper
INFO - 2024-10-24 17:59:34 --> Model Class Initialized
INFO - 2024-10-24 17:59:34 --> Model Class Initialized
INFO - 2024-10-24 17:59:34 --> Model Class Initialized
INFO - 2024-10-24 17:59:34 --> Model Class Initialized
INFO - 2024-10-24 17:59:34 --> Model Class Initialized
INFO - 2024-10-24 17:59:34 --> Model Class Initialized
INFO - 2024-10-24 17:59:34 --> Model Class Initialized
DEBUG - 2024-10-24 17:59:34 --> plural called with: company
DEBUG - 2024-10-24 17:59:34 --> is_countable called with!!!!: company
INFO - 2024-10-24 17:59:34 --> Model Class Initialized
INFO - 2024-10-24 17:59:34 --> Model Class Initialized
INFO - 2024-10-24 17:59:34 --> Model Class Initialized
INFO - 2024-10-24 17:59:34 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-24 17:59:34 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 17:59:34 --> Final output sent to browser
DEBUG - 2024-10-24 17:59:34 --> Total execution time: 0.0253
INFO - 2024-10-24 17:59:38 --> Config Class Initialized
INFO - 2024-10-24 17:59:38 --> Hooks Class Initialized
DEBUG - 2024-10-24 17:59:38 --> UTF-8 Support Enabled
INFO - 2024-10-24 17:59:38 --> Utf8 Class Initialized
INFO - 2024-10-24 17:59:38 --> URI Class Initialized
INFO - 2024-10-24 17:59:38 --> Router Class Initialized
INFO - 2024-10-24 17:59:38 --> Output Class Initialized
INFO - 2024-10-24 17:59:38 --> Security Class Initialized
DEBUG - 2024-10-24 17:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 17:59:38 --> Input Class Initialized
INFO - 2024-10-24 17:59:38 --> Language Class Initialized
ERROR - 2024-10-24 17:59:38 --> TEST ERROR MESSAGE - 2024-10-24 17:59:38
INFO - 2024-10-24 17:59:38 --> Loader Class Initialized
INFO - 2024-10-24 17:59:38 --> Controller Class Initialized
INFO - 2024-10-24 17:59:38 --> Database Driver Class Initialized
INFO - 2024-10-24 17:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 17:59:38 --> Helper loaded: form_helper
INFO - 2024-10-24 17:59:38 --> Helper loaded: url_helper
INFO - 2024-10-24 17:59:38 --> Model Class Initialized
INFO - 2024-10-24 17:59:38 --> Helper loaded: inflector_helper
INFO - 2024-10-24 17:59:38 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 17:59:38 --> Helper loaded: email_helper
INFO - 2024-10-24 17:59:38 --> Model Class Initialized
INFO - 2024-10-24 17:59:38 --> Model Class Initialized
INFO - 2024-10-24 17:59:38 --> Model Class Initialized
INFO - 2024-10-24 17:59:38 --> Model Class Initialized
INFO - 2024-10-24 17:59:38 --> Model Class Initialized
INFO - 2024-10-24 17:59:38 --> Model Class Initialized
INFO - 2024-10-24 17:59:38 --> Model Class Initialized
DEBUG - 2024-10-24 17:59:38 --> plural called with: company
DEBUG - 2024-10-24 17:59:38 --> is_countable called with!!!!: company
INFO - 2024-10-24 17:59:38 --> Model Class Initialized
INFO - 2024-10-24 17:59:38 --> Model Class Initialized
INFO - 2024-10-24 17:59:38 --> Model Class Initialized
INFO - 2024-10-24 17:59:38 --> Config Class Initialized
INFO - 2024-10-24 17:59:38 --> Hooks Class Initialized
DEBUG - 2024-10-24 17:59:38 --> UTF-8 Support Enabled
INFO - 2024-10-24 17:59:38 --> Utf8 Class Initialized
INFO - 2024-10-24 17:59:38 --> URI Class Initialized
INFO - 2024-10-24 17:59:38 --> Router Class Initialized
INFO - 2024-10-24 17:59:38 --> Output Class Initialized
INFO - 2024-10-24 17:59:38 --> Security Class Initialized
DEBUG - 2024-10-24 17:59:38 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 17:59:38 --> Input Class Initialized
INFO - 2024-10-24 17:59:38 --> Language Class Initialized
ERROR - 2024-10-24 17:59:38 --> TEST ERROR MESSAGE - 2024-10-24 17:59:38
INFO - 2024-10-24 17:59:38 --> Loader Class Initialized
INFO - 2024-10-24 17:59:38 --> Controller Class Initialized
INFO - 2024-10-24 17:59:38 --> Database Driver Class Initialized
INFO - 2024-10-24 17:59:38 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 17:59:38 --> Helper loaded: form_helper
INFO - 2024-10-24 17:59:38 --> Helper loaded: url_helper
INFO - 2024-10-24 17:59:38 --> Model Class Initialized
INFO - 2024-10-24 17:59:38 --> Helper loaded: inflector_helper
INFO - 2024-10-24 17:59:38 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 17:59:38 --> Helper loaded: email_helper
INFO - 2024-10-24 17:59:38 --> Model Class Initialized
INFO - 2024-10-24 17:59:38 --> Model Class Initialized
INFO - 2024-10-24 17:59:38 --> Model Class Initialized
INFO - 2024-10-24 17:59:38 --> Model Class Initialized
INFO - 2024-10-24 17:59:38 --> Model Class Initialized
INFO - 2024-10-24 17:59:38 --> Model Class Initialized
INFO - 2024-10-24 17:59:38 --> Model Class Initialized
DEBUG - 2024-10-24 17:59:38 --> plural called with: company
DEBUG - 2024-10-24 17:59:38 --> is_countable called with!!!!: company
INFO - 2024-10-24 17:59:38 --> Model Class Initialized
INFO - 2024-10-24 17:59:38 --> Model Class Initialized
INFO - 2024-10-24 17:59:38 --> Model Class Initialized
ERROR - 2024-10-24 17:59:40 --> Severity: Notice --> Undefined index: freetext /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 17:59:40 --> Severity: Notice --> Undefined index: socialDes /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 17:59:40 --> Severity: Notice --> Undefined index: company /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 17:59:40 --> Severity: Notice --> Undefined index: division /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 17:59:40 --> Severity: Notice --> Undefined index: dataGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 17:59:40 --> Severity: Notice --> Undefined index: finalGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
INFO - 2024-10-24 17:59:40 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 17:59:40 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 17:59:40 --> Final output sent to browser
DEBUG - 2024-10-24 17:59:40 --> Total execution time: 2.3287
INFO - 2024-10-24 17:59:49 --> Config Class Initialized
INFO - 2024-10-24 17:59:49 --> Hooks Class Initialized
DEBUG - 2024-10-24 17:59:49 --> UTF-8 Support Enabled
INFO - 2024-10-24 17:59:49 --> Utf8 Class Initialized
INFO - 2024-10-24 17:59:49 --> URI Class Initialized
INFO - 2024-10-24 17:59:49 --> Router Class Initialized
INFO - 2024-10-24 17:59:49 --> Output Class Initialized
INFO - 2024-10-24 17:59:49 --> Security Class Initialized
DEBUG - 2024-10-24 17:59:49 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 17:59:49 --> Input Class Initialized
INFO - 2024-10-24 17:59:49 --> Language Class Initialized
ERROR - 2024-10-24 17:59:49 --> TEST ERROR MESSAGE - 2024-10-24 17:59:49
INFO - 2024-10-24 17:59:49 --> Loader Class Initialized
INFO - 2024-10-24 17:59:49 --> Controller Class Initialized
INFO - 2024-10-24 17:59:49 --> Database Driver Class Initialized
INFO - 2024-10-24 17:59:49 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 17:59:49 --> Helper loaded: form_helper
INFO - 2024-10-24 17:59:49 --> Helper loaded: url_helper
INFO - 2024-10-24 17:59:49 --> Model Class Initialized
INFO - 2024-10-24 17:59:49 --> Helper loaded: inflector_helper
INFO - 2024-10-24 17:59:49 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 17:59:49 --> Helper loaded: email_helper
INFO - 2024-10-24 17:59:49 --> Model Class Initialized
INFO - 2024-10-24 17:59:49 --> Model Class Initialized
INFO - 2024-10-24 17:59:49 --> Model Class Initialized
INFO - 2024-10-24 17:59:49 --> Model Class Initialized
INFO - 2024-10-24 17:59:49 --> Model Class Initialized
INFO - 2024-10-24 17:59:49 --> Model Class Initialized
INFO - 2024-10-24 17:59:49 --> Model Class Initialized
DEBUG - 2024-10-24 17:59:49 --> plural called with: company
DEBUG - 2024-10-24 17:59:49 --> is_countable called with!!!!: company
INFO - 2024-10-24 17:59:49 --> Model Class Initialized
INFO - 2024-10-24 17:59:49 --> Model Class Initialized
INFO - 2024-10-24 17:59:49 --> Model Class Initialized
INFO - 2024-10-24 17:59:49 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 17:59:49 --> Final output sent to browser
DEBUG - 2024-10-24 17:59:49 --> Total execution time: 0.0256
INFO - 2024-10-24 18:00:03 --> Config Class Initialized
INFO - 2024-10-24 18:00:03 --> Hooks Class Initialized
DEBUG - 2024-10-24 18:00:03 --> UTF-8 Support Enabled
INFO - 2024-10-24 18:00:03 --> Utf8 Class Initialized
INFO - 2024-10-24 18:00:03 --> URI Class Initialized
INFO - 2024-10-24 18:00:03 --> Router Class Initialized
INFO - 2024-10-24 18:00:03 --> Output Class Initialized
INFO - 2024-10-24 18:00:03 --> Security Class Initialized
DEBUG - 2024-10-24 18:00:03 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 18:00:03 --> Input Class Initialized
INFO - 2024-10-24 18:00:03 --> Language Class Initialized
ERROR - 2024-10-24 18:00:03 --> TEST ERROR MESSAGE - 2024-10-24 18:00:03
INFO - 2024-10-24 18:00:03 --> Loader Class Initialized
INFO - 2024-10-24 18:00:03 --> Controller Class Initialized
INFO - 2024-10-24 18:00:03 --> Database Driver Class Initialized
INFO - 2024-10-24 18:00:03 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 18:00:03 --> Helper loaded: form_helper
INFO - 2024-10-24 18:00:03 --> Helper loaded: url_helper
INFO - 2024-10-24 18:00:03 --> Model Class Initialized
INFO - 2024-10-24 18:00:03 --> Helper loaded: inflector_helper
INFO - 2024-10-24 18:00:03 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 18:00:03 --> Helper loaded: email_helper
INFO - 2024-10-24 18:00:03 --> Model Class Initialized
INFO - 2024-10-24 18:00:03 --> Model Class Initialized
INFO - 2024-10-24 18:00:03 --> Model Class Initialized
INFO - 2024-10-24 18:00:03 --> Model Class Initialized
INFO - 2024-10-24 18:00:03 --> Model Class Initialized
INFO - 2024-10-24 18:00:03 --> Model Class Initialized
INFO - 2024-10-24 18:00:03 --> Model Class Initialized
DEBUG - 2024-10-24 18:00:03 --> plural called with: company
DEBUG - 2024-10-24 18:00:03 --> is_countable called with!!!!: company
INFO - 2024-10-24 18:00:03 --> Model Class Initialized
INFO - 2024-10-24 18:00:03 --> Model Class Initialized
INFO - 2024-10-24 18:00:03 --> Model Class Initialized
INFO - 2024-10-24 18:00:05 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 18:00:05 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 18:00:05 --> Final output sent to browser
DEBUG - 2024-10-24 18:00:05 --> Total execution time: 1.7058
INFO - 2024-10-24 18:00:12 --> Config Class Initialized
INFO - 2024-10-24 18:00:12 --> Hooks Class Initialized
DEBUG - 2024-10-24 18:00:12 --> UTF-8 Support Enabled
INFO - 2024-10-24 18:00:12 --> Utf8 Class Initialized
INFO - 2024-10-24 18:00:12 --> URI Class Initialized
INFO - 2024-10-24 18:00:12 --> Router Class Initialized
INFO - 2024-10-24 18:00:12 --> Output Class Initialized
INFO - 2024-10-24 18:00:12 --> Security Class Initialized
DEBUG - 2024-10-24 18:00:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 18:00:12 --> Input Class Initialized
INFO - 2024-10-24 18:00:12 --> Language Class Initialized
ERROR - 2024-10-24 18:00:12 --> TEST ERROR MESSAGE - 2024-10-24 18:00:12
INFO - 2024-10-24 18:00:12 --> Loader Class Initialized
INFO - 2024-10-24 18:00:12 --> Controller Class Initialized
INFO - 2024-10-24 18:00:12 --> Database Driver Class Initialized
INFO - 2024-10-24 18:00:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 18:00:12 --> Helper loaded: form_helper
INFO - 2024-10-24 18:00:12 --> Helper loaded: url_helper
INFO - 2024-10-24 18:00:12 --> Model Class Initialized
INFO - 2024-10-24 18:00:12 --> Helper loaded: inflector_helper
INFO - 2024-10-24 18:00:12 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 18:00:12 --> Helper loaded: email_helper
INFO - 2024-10-24 18:00:12 --> Model Class Initialized
INFO - 2024-10-24 18:00:12 --> Model Class Initialized
INFO - 2024-10-24 18:00:12 --> Model Class Initialized
INFO - 2024-10-24 18:00:12 --> Model Class Initialized
INFO - 2024-10-24 18:00:12 --> Model Class Initialized
INFO - 2024-10-24 18:00:12 --> Model Class Initialized
INFO - 2024-10-24 18:00:12 --> Model Class Initialized
DEBUG - 2024-10-24 18:00:12 --> plural called with: company
DEBUG - 2024-10-24 18:00:12 --> is_countable called with!!!!: company
INFO - 2024-10-24 18:00:12 --> Model Class Initialized
INFO - 2024-10-24 18:00:12 --> Model Class Initialized
INFO - 2024-10-24 18:00:12 --> Model Class Initialized
INFO - 2024-10-24 18:01:08 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 18:01:08 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 18:01:08 --> Final output sent to browser
DEBUG - 2024-10-24 18:01:08 --> Total execution time: 56.4866
INFO - 2024-10-24 18:01:40 --> Config Class Initialized
INFO - 2024-10-24 18:01:40 --> Hooks Class Initialized
DEBUG - 2024-10-24 18:01:40 --> UTF-8 Support Enabled
INFO - 2024-10-24 18:01:40 --> Utf8 Class Initialized
INFO - 2024-10-24 18:01:40 --> URI Class Initialized
INFO - 2024-10-24 18:01:40 --> Router Class Initialized
INFO - 2024-10-24 18:01:40 --> Output Class Initialized
INFO - 2024-10-24 18:01:40 --> Security Class Initialized
DEBUG - 2024-10-24 18:01:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 18:01:40 --> Input Class Initialized
INFO - 2024-10-24 18:01:40 --> Language Class Initialized
ERROR - 2024-10-24 18:01:40 --> TEST ERROR MESSAGE - 2024-10-24 18:01:40
INFO - 2024-10-24 18:01:40 --> Loader Class Initialized
INFO - 2024-10-24 18:01:40 --> Controller Class Initialized
INFO - 2024-10-24 18:01:40 --> Database Driver Class Initialized
INFO - 2024-10-24 18:01:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 18:01:40 --> Helper loaded: form_helper
INFO - 2024-10-24 18:01:40 --> Helper loaded: url_helper
INFO - 2024-10-24 18:01:40 --> Model Class Initialized
INFO - 2024-10-24 18:01:40 --> Helper loaded: inflector_helper
INFO - 2024-10-24 18:01:40 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 18:01:40 --> Helper loaded: email_helper
INFO - 2024-10-24 18:01:40 --> Model Class Initialized
INFO - 2024-10-24 18:01:40 --> Model Class Initialized
INFO - 2024-10-24 18:01:40 --> Model Class Initialized
INFO - 2024-10-24 18:01:40 --> Model Class Initialized
INFO - 2024-10-24 18:01:40 --> Model Class Initialized
INFO - 2024-10-24 18:01:40 --> Model Class Initialized
INFO - 2024-10-24 18:01:40 --> Model Class Initialized
DEBUG - 2024-10-24 18:01:40 --> plural called with: company
DEBUG - 2024-10-24 18:01:40 --> is_countable called with!!!!: company
INFO - 2024-10-24 18:01:40 --> Model Class Initialized
INFO - 2024-10-24 18:01:40 --> Model Class Initialized
INFO - 2024-10-24 18:01:40 --> Model Class Initialized
INFO - 2024-10-24 18:01:40 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 18:01:40 --> Final output sent to browser
DEBUG - 2024-10-24 18:01:40 --> Total execution time: 0.0252
INFO - 2024-10-24 18:01:58 --> Config Class Initialized
INFO - 2024-10-24 18:01:58 --> Hooks Class Initialized
DEBUG - 2024-10-24 18:01:58 --> UTF-8 Support Enabled
INFO - 2024-10-24 18:01:58 --> Utf8 Class Initialized
INFO - 2024-10-24 18:01:58 --> URI Class Initialized
INFO - 2024-10-24 18:01:58 --> Router Class Initialized
INFO - 2024-10-24 18:01:58 --> Output Class Initialized
INFO - 2024-10-24 18:01:58 --> Security Class Initialized
DEBUG - 2024-10-24 18:01:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 18:01:58 --> Input Class Initialized
INFO - 2024-10-24 18:01:58 --> Language Class Initialized
ERROR - 2024-10-24 18:01:58 --> TEST ERROR MESSAGE - 2024-10-24 18:01:58
INFO - 2024-10-24 18:01:58 --> Loader Class Initialized
INFO - 2024-10-24 18:01:58 --> Controller Class Initialized
INFO - 2024-10-24 18:01:58 --> Database Driver Class Initialized
INFO - 2024-10-24 18:01:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 18:01:58 --> Helper loaded: form_helper
INFO - 2024-10-24 18:01:58 --> Helper loaded: url_helper
INFO - 2024-10-24 18:01:58 --> Model Class Initialized
INFO - 2024-10-24 18:01:58 --> Helper loaded: inflector_helper
INFO - 2024-10-24 18:01:58 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 18:01:58 --> Helper loaded: email_helper
INFO - 2024-10-24 18:01:58 --> Model Class Initialized
INFO - 2024-10-24 18:01:58 --> Model Class Initialized
INFO - 2024-10-24 18:01:58 --> Model Class Initialized
INFO - 2024-10-24 18:01:58 --> Model Class Initialized
INFO - 2024-10-24 18:01:58 --> Model Class Initialized
INFO - 2024-10-24 18:01:58 --> Model Class Initialized
INFO - 2024-10-24 18:01:58 --> Model Class Initialized
DEBUG - 2024-10-24 18:01:58 --> plural called with: company
DEBUG - 2024-10-24 18:01:58 --> is_countable called with!!!!: company
INFO - 2024-10-24 18:01:58 --> Model Class Initialized
INFO - 2024-10-24 18:01:58 --> Model Class Initialized
INFO - 2024-10-24 18:01:58 --> Model Class Initialized
INFO - 2024-10-24 18:01:58 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 18:01:58 --> Final output sent to browser
DEBUG - 2024-10-24 18:01:58 --> Total execution time: 0.0236
INFO - 2024-10-24 18:02:07 --> Config Class Initialized
INFO - 2024-10-24 18:02:07 --> Hooks Class Initialized
DEBUG - 2024-10-24 18:02:07 --> UTF-8 Support Enabled
INFO - 2024-10-24 18:02:07 --> Utf8 Class Initialized
INFO - 2024-10-24 18:02:07 --> URI Class Initialized
INFO - 2024-10-24 18:02:07 --> Router Class Initialized
INFO - 2024-10-24 18:02:07 --> Output Class Initialized
INFO - 2024-10-24 18:02:07 --> Security Class Initialized
DEBUG - 2024-10-24 18:02:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 18:02:07 --> Input Class Initialized
INFO - 2024-10-24 18:02:07 --> Language Class Initialized
ERROR - 2024-10-24 18:02:07 --> TEST ERROR MESSAGE - 2024-10-24 18:02:07
INFO - 2024-10-24 18:02:07 --> Loader Class Initialized
INFO - 2024-10-24 18:02:07 --> Controller Class Initialized
INFO - 2024-10-24 18:02:07 --> Database Driver Class Initialized
INFO - 2024-10-24 18:02:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 18:02:07 --> Helper loaded: form_helper
INFO - 2024-10-24 18:02:07 --> Helper loaded: url_helper
INFO - 2024-10-24 18:02:07 --> Model Class Initialized
INFO - 2024-10-24 18:02:07 --> Helper loaded: inflector_helper
INFO - 2024-10-24 18:02:07 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 18:02:07 --> Helper loaded: email_helper
INFO - 2024-10-24 18:02:07 --> Model Class Initialized
INFO - 2024-10-24 18:02:07 --> Model Class Initialized
INFO - 2024-10-24 18:02:07 --> Model Class Initialized
INFO - 2024-10-24 18:02:07 --> Model Class Initialized
INFO - 2024-10-24 18:02:07 --> Model Class Initialized
INFO - 2024-10-24 18:02:07 --> Model Class Initialized
INFO - 2024-10-24 18:02:07 --> Model Class Initialized
DEBUG - 2024-10-24 18:02:07 --> plural called with: company
DEBUG - 2024-10-24 18:02:07 --> is_countable called with!!!!: company
INFO - 2024-10-24 18:02:07 --> Model Class Initialized
INFO - 2024-10-24 18:02:07 --> Model Class Initialized
INFO - 2024-10-24 18:02:07 --> Model Class Initialized
INFO - 2024-10-24 18:02:07 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 18:02:07 --> Final output sent to browser
DEBUG - 2024-10-24 18:02:07 --> Total execution time: 0.0221
INFO - 2024-10-24 18:02:25 --> Config Class Initialized
INFO - 2024-10-24 18:02:25 --> Hooks Class Initialized
DEBUG - 2024-10-24 18:02:25 --> UTF-8 Support Enabled
INFO - 2024-10-24 18:02:25 --> Utf8 Class Initialized
INFO - 2024-10-24 18:02:25 --> URI Class Initialized
INFO - 2024-10-24 18:02:25 --> Router Class Initialized
INFO - 2024-10-24 18:02:25 --> Output Class Initialized
INFO - 2024-10-24 18:02:25 --> Security Class Initialized
DEBUG - 2024-10-24 18:02:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 18:02:25 --> Input Class Initialized
INFO - 2024-10-24 18:02:25 --> Language Class Initialized
ERROR - 2024-10-24 18:02:25 --> TEST ERROR MESSAGE - 2024-10-24 18:02:25
INFO - 2024-10-24 18:02:25 --> Loader Class Initialized
INFO - 2024-10-24 18:02:25 --> Controller Class Initialized
INFO - 2024-10-24 18:02:25 --> Database Driver Class Initialized
INFO - 2024-10-24 18:02:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 18:02:25 --> Helper loaded: form_helper
INFO - 2024-10-24 18:02:25 --> Helper loaded: url_helper
INFO - 2024-10-24 18:02:25 --> Model Class Initialized
INFO - 2024-10-24 18:02:25 --> Helper loaded: inflector_helper
INFO - 2024-10-24 18:02:25 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 18:02:25 --> Helper loaded: email_helper
INFO - 2024-10-24 18:02:25 --> Model Class Initialized
INFO - 2024-10-24 18:02:25 --> Model Class Initialized
INFO - 2024-10-24 18:02:25 --> Model Class Initialized
INFO - 2024-10-24 18:02:25 --> Model Class Initialized
INFO - 2024-10-24 18:02:25 --> Model Class Initialized
INFO - 2024-10-24 18:02:25 --> Model Class Initialized
INFO - 2024-10-24 18:02:25 --> Model Class Initialized
DEBUG - 2024-10-24 18:02:25 --> plural called with: company
DEBUG - 2024-10-24 18:02:25 --> is_countable called with!!!!: company
INFO - 2024-10-24 18:02:25 --> Model Class Initialized
INFO - 2024-10-24 18:02:25 --> Model Class Initialized
INFO - 2024-10-24 18:02:25 --> Model Class Initialized
INFO - 2024-10-24 18:02:25 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 18:02:25 --> Final output sent to browser
DEBUG - 2024-10-24 18:02:25 --> Total execution time: 0.0245
INFO - 2024-10-24 22:43:42 --> Config Class Initialized
INFO - 2024-10-24 22:43:42 --> Hooks Class Initialized
DEBUG - 2024-10-24 22:43:42 --> UTF-8 Support Enabled
INFO - 2024-10-24 22:43:42 --> Utf8 Class Initialized
INFO - 2024-10-24 22:43:42 --> URI Class Initialized
INFO - 2024-10-24 22:43:42 --> Router Class Initialized
INFO - 2024-10-24 22:43:42 --> Output Class Initialized
INFO - 2024-10-24 22:43:42 --> Security Class Initialized
DEBUG - 2024-10-24 22:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 22:43:42 --> Input Class Initialized
INFO - 2024-10-24 22:43:42 --> Language Class Initialized
ERROR - 2024-10-24 22:43:42 --> TEST ERROR MESSAGE - 2024-10-24 22:43:42
INFO - 2024-10-24 22:43:42 --> Loader Class Initialized
INFO - 2024-10-24 22:43:42 --> Controller Class Initialized
INFO - 2024-10-24 22:43:42 --> Database Driver Class Initialized
INFO - 2024-10-24 22:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 22:43:42 --> Helper loaded: form_helper
INFO - 2024-10-24 22:43:42 --> Helper loaded: url_helper
INFO - 2024-10-24 22:43:42 --> Model Class Initialized
INFO - 2024-10-24 22:43:42 --> Helper loaded: inflector_helper
INFO - 2024-10-24 22:43:42 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 22:43:42 --> Helper loaded: email_helper
INFO - 2024-10-24 22:43:42 --> Model Class Initialized
INFO - 2024-10-24 22:43:42 --> Model Class Initialized
INFO - 2024-10-24 22:43:42 --> Model Class Initialized
INFO - 2024-10-24 22:43:42 --> Model Class Initialized
INFO - 2024-10-24 22:43:42 --> Model Class Initialized
INFO - 2024-10-24 22:43:42 --> Model Class Initialized
INFO - 2024-10-24 22:43:42 --> Model Class Initialized
DEBUG - 2024-10-24 22:43:42 --> plural called with: company
DEBUG - 2024-10-24 22:43:42 --> is_countable called with!!!!: company
INFO - 2024-10-24 22:43:42 --> Model Class Initialized
INFO - 2024-10-24 22:43:42 --> Model Class Initialized
INFO - 2024-10-24 22:43:42 --> Model Class Initialized
INFO - 2024-10-24 22:43:42 --> Config Class Initialized
INFO - 2024-10-24 22:43:42 --> Hooks Class Initialized
DEBUG - 2024-10-24 22:43:42 --> UTF-8 Support Enabled
INFO - 2024-10-24 22:43:42 --> Utf8 Class Initialized
INFO - 2024-10-24 22:43:42 --> URI Class Initialized
INFO - 2024-10-24 22:43:42 --> Router Class Initialized
INFO - 2024-10-24 22:43:42 --> Output Class Initialized
INFO - 2024-10-24 22:43:42 --> Security Class Initialized
DEBUG - 2024-10-24 22:43:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 22:43:42 --> Input Class Initialized
INFO - 2024-10-24 22:43:42 --> Language Class Initialized
ERROR - 2024-10-24 22:43:42 --> TEST ERROR MESSAGE - 2024-10-24 22:43:42
INFO - 2024-10-24 22:43:42 --> Loader Class Initialized
INFO - 2024-10-24 22:43:42 --> Controller Class Initialized
INFO - 2024-10-24 22:43:42 --> Database Driver Class Initialized
INFO - 2024-10-24 22:43:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 22:43:42 --> Helper loaded: form_helper
INFO - 2024-10-24 22:43:42 --> Helper loaded: url_helper
INFO - 2024-10-24 22:43:42 --> Model Class Initialized
INFO - 2024-10-24 22:43:42 --> Helper loaded: inflector_helper
INFO - 2024-10-24 22:43:42 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 22:43:42 --> Helper loaded: email_helper
INFO - 2024-10-24 22:43:42 --> Model Class Initialized
INFO - 2024-10-24 22:43:42 --> Model Class Initialized
INFO - 2024-10-24 22:43:42 --> Model Class Initialized
INFO - 2024-10-24 22:43:42 --> Model Class Initialized
INFO - 2024-10-24 22:43:42 --> Model Class Initialized
INFO - 2024-10-24 22:43:42 --> Model Class Initialized
INFO - 2024-10-24 22:43:42 --> Model Class Initialized
DEBUG - 2024-10-24 22:43:42 --> plural called with: company
DEBUG - 2024-10-24 22:43:42 --> is_countable called with!!!!: company
INFO - 2024-10-24 22:43:42 --> Model Class Initialized
INFO - 2024-10-24 22:43:42 --> Model Class Initialized
INFO - 2024-10-24 22:43:42 --> Model Class Initialized
INFO - 2024-10-24 22:43:42 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-24 22:43:42 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 22:43:42 --> Final output sent to browser
DEBUG - 2024-10-24 22:43:42 --> Total execution time: 0.0220
INFO - 2024-10-24 22:43:47 --> Config Class Initialized
INFO - 2024-10-24 22:43:47 --> Hooks Class Initialized
DEBUG - 2024-10-24 22:43:47 --> UTF-8 Support Enabled
INFO - 2024-10-24 22:43:47 --> Utf8 Class Initialized
INFO - 2024-10-24 22:43:47 --> URI Class Initialized
INFO - 2024-10-24 22:43:47 --> Router Class Initialized
INFO - 2024-10-24 22:43:47 --> Output Class Initialized
INFO - 2024-10-24 22:43:47 --> Security Class Initialized
DEBUG - 2024-10-24 22:43:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 22:43:47 --> Input Class Initialized
INFO - 2024-10-24 22:43:47 --> Language Class Initialized
ERROR - 2024-10-24 22:43:47 --> TEST ERROR MESSAGE - 2024-10-24 22:43:47
INFO - 2024-10-24 22:43:47 --> Loader Class Initialized
INFO - 2024-10-24 22:43:47 --> Controller Class Initialized
INFO - 2024-10-24 22:43:47 --> Database Driver Class Initialized
INFO - 2024-10-24 22:43:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 22:43:47 --> Helper loaded: form_helper
INFO - 2024-10-24 22:43:47 --> Helper loaded: url_helper
INFO - 2024-10-24 22:43:47 --> Model Class Initialized
INFO - 2024-10-24 22:43:47 --> Helper loaded: inflector_helper
INFO - 2024-10-24 22:43:47 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 22:43:47 --> Helper loaded: email_helper
INFO - 2024-10-24 22:43:47 --> Model Class Initialized
INFO - 2024-10-24 22:43:47 --> Model Class Initialized
INFO - 2024-10-24 22:43:47 --> Model Class Initialized
INFO - 2024-10-24 22:43:47 --> Model Class Initialized
INFO - 2024-10-24 22:43:47 --> Model Class Initialized
INFO - 2024-10-24 22:43:47 --> Model Class Initialized
INFO - 2024-10-24 22:43:47 --> Model Class Initialized
DEBUG - 2024-10-24 22:43:47 --> plural called with: company
DEBUG - 2024-10-24 22:43:47 --> is_countable called with!!!!: company
INFO - 2024-10-24 22:43:47 --> Model Class Initialized
INFO - 2024-10-24 22:43:47 --> Model Class Initialized
INFO - 2024-10-24 22:43:47 --> Model Class Initialized
INFO - 2024-10-24 22:43:47 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-24 22:43:47 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 22:43:47 --> Final output sent to browser
DEBUG - 2024-10-24 22:43:47 --> Total execution time: 0.0341
INFO - 2024-10-24 22:43:52 --> Config Class Initialized
INFO - 2024-10-24 22:43:52 --> Hooks Class Initialized
DEBUG - 2024-10-24 22:43:52 --> UTF-8 Support Enabled
INFO - 2024-10-24 22:43:52 --> Utf8 Class Initialized
INFO - 2024-10-24 22:43:52 --> URI Class Initialized
INFO - 2024-10-24 22:43:52 --> Router Class Initialized
INFO - 2024-10-24 22:43:52 --> Output Class Initialized
INFO - 2024-10-24 22:43:52 --> Security Class Initialized
DEBUG - 2024-10-24 22:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 22:43:52 --> Input Class Initialized
INFO - 2024-10-24 22:43:52 --> Language Class Initialized
ERROR - 2024-10-24 22:43:52 --> TEST ERROR MESSAGE - 2024-10-24 22:43:52
INFO - 2024-10-24 22:43:52 --> Loader Class Initialized
INFO - 2024-10-24 22:43:52 --> Controller Class Initialized
INFO - 2024-10-24 22:43:52 --> Database Driver Class Initialized
INFO - 2024-10-24 22:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 22:43:52 --> Helper loaded: form_helper
INFO - 2024-10-24 22:43:52 --> Helper loaded: url_helper
INFO - 2024-10-24 22:43:52 --> Model Class Initialized
INFO - 2024-10-24 22:43:52 --> Helper loaded: inflector_helper
INFO - 2024-10-24 22:43:52 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 22:43:52 --> Helper loaded: email_helper
INFO - 2024-10-24 22:43:52 --> Model Class Initialized
INFO - 2024-10-24 22:43:52 --> Model Class Initialized
INFO - 2024-10-24 22:43:52 --> Model Class Initialized
INFO - 2024-10-24 22:43:52 --> Model Class Initialized
INFO - 2024-10-24 22:43:52 --> Model Class Initialized
INFO - 2024-10-24 22:43:52 --> Model Class Initialized
INFO - 2024-10-24 22:43:52 --> Model Class Initialized
DEBUG - 2024-10-24 22:43:52 --> plural called with: company
DEBUG - 2024-10-24 22:43:52 --> is_countable called with!!!!: company
INFO - 2024-10-24 22:43:52 --> Model Class Initialized
INFO - 2024-10-24 22:43:52 --> Model Class Initialized
INFO - 2024-10-24 22:43:52 --> Model Class Initialized
INFO - 2024-10-24 22:43:52 --> Config Class Initialized
INFO - 2024-10-24 22:43:52 --> Hooks Class Initialized
DEBUG - 2024-10-24 22:43:52 --> UTF-8 Support Enabled
INFO - 2024-10-24 22:43:52 --> Utf8 Class Initialized
INFO - 2024-10-24 22:43:52 --> URI Class Initialized
INFO - 2024-10-24 22:43:52 --> Router Class Initialized
INFO - 2024-10-24 22:43:52 --> Output Class Initialized
INFO - 2024-10-24 22:43:52 --> Security Class Initialized
DEBUG - 2024-10-24 22:43:52 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 22:43:52 --> Input Class Initialized
INFO - 2024-10-24 22:43:52 --> Language Class Initialized
ERROR - 2024-10-24 22:43:52 --> TEST ERROR MESSAGE - 2024-10-24 22:43:52
INFO - 2024-10-24 22:43:52 --> Loader Class Initialized
INFO - 2024-10-24 22:43:52 --> Controller Class Initialized
INFO - 2024-10-24 22:43:52 --> Database Driver Class Initialized
INFO - 2024-10-24 22:43:52 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 22:43:52 --> Helper loaded: form_helper
INFO - 2024-10-24 22:43:52 --> Helper loaded: url_helper
INFO - 2024-10-24 22:43:52 --> Model Class Initialized
INFO - 2024-10-24 22:43:52 --> Helper loaded: inflector_helper
INFO - 2024-10-24 22:43:52 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 22:43:52 --> Helper loaded: email_helper
INFO - 2024-10-24 22:43:52 --> Model Class Initialized
INFO - 2024-10-24 22:43:52 --> Model Class Initialized
INFO - 2024-10-24 22:43:52 --> Model Class Initialized
INFO - 2024-10-24 22:43:52 --> Model Class Initialized
INFO - 2024-10-24 22:43:52 --> Model Class Initialized
INFO - 2024-10-24 22:43:52 --> Model Class Initialized
INFO - 2024-10-24 22:43:52 --> Model Class Initialized
DEBUG - 2024-10-24 22:43:52 --> plural called with: company
DEBUG - 2024-10-24 22:43:52 --> is_countable called with!!!!: company
INFO - 2024-10-24 22:43:52 --> Model Class Initialized
INFO - 2024-10-24 22:43:52 --> Model Class Initialized
INFO - 2024-10-24 22:43:52 --> Model Class Initialized
ERROR - 2024-10-24 22:43:55 --> Severity: Notice --> Undefined index: freetext /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 22:43:55 --> Severity: Notice --> Undefined index: socialDes /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 22:43:55 --> Severity: Notice --> Undefined index: company /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 22:43:55 --> Severity: Notice --> Undefined index: division /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 22:43:55 --> Severity: Notice --> Undefined index: dataGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-24 22:43:55 --> Severity: Notice --> Undefined index: finalGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
INFO - 2024-10-24 22:43:55 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 22:43:55 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 22:43:55 --> Final output sent to browser
DEBUG - 2024-10-24 22:43:55 --> Total execution time: 2.5232
INFO - 2024-10-24 22:44:07 --> Config Class Initialized
INFO - 2024-10-24 22:44:07 --> Hooks Class Initialized
DEBUG - 2024-10-24 22:44:07 --> UTF-8 Support Enabled
INFO - 2024-10-24 22:44:07 --> Utf8 Class Initialized
INFO - 2024-10-24 22:44:07 --> URI Class Initialized
INFO - 2024-10-24 22:44:07 --> Router Class Initialized
INFO - 2024-10-24 22:44:07 --> Output Class Initialized
INFO - 2024-10-24 22:44:07 --> Security Class Initialized
DEBUG - 2024-10-24 22:44:07 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 22:44:07 --> Input Class Initialized
INFO - 2024-10-24 22:44:07 --> Language Class Initialized
ERROR - 2024-10-24 22:44:07 --> TEST ERROR MESSAGE - 2024-10-24 22:44:07
INFO - 2024-10-24 22:44:07 --> Loader Class Initialized
INFO - 2024-10-24 22:44:07 --> Controller Class Initialized
INFO - 2024-10-24 22:44:07 --> Database Driver Class Initialized
INFO - 2024-10-24 22:44:07 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 22:44:07 --> Helper loaded: form_helper
INFO - 2024-10-24 22:44:07 --> Helper loaded: url_helper
INFO - 2024-10-24 22:44:07 --> Model Class Initialized
INFO - 2024-10-24 22:44:07 --> Helper loaded: inflector_helper
INFO - 2024-10-24 22:44:07 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 22:44:07 --> Helper loaded: email_helper
INFO - 2024-10-24 22:44:07 --> Model Class Initialized
INFO - 2024-10-24 22:44:07 --> Model Class Initialized
INFO - 2024-10-24 22:44:07 --> Model Class Initialized
INFO - 2024-10-24 22:44:07 --> Model Class Initialized
INFO - 2024-10-24 22:44:07 --> Model Class Initialized
INFO - 2024-10-24 22:44:07 --> Model Class Initialized
INFO - 2024-10-24 22:44:07 --> Model Class Initialized
DEBUG - 2024-10-24 22:44:07 --> plural called with: company
DEBUG - 2024-10-24 22:44:07 --> is_countable called with!!!!: company
INFO - 2024-10-24 22:44:07 --> Model Class Initialized
INFO - 2024-10-24 22:44:07 --> Model Class Initialized
INFO - 2024-10-24 22:44:07 --> Model Class Initialized
INFO - 2024-10-24 22:44:40 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 22:44:40 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 22:44:40 --> Final output sent to browser
DEBUG - 2024-10-24 22:44:40 --> Total execution time: 33.0940
INFO - 2024-10-24 22:46:00 --> Config Class Initialized
INFO - 2024-10-24 22:46:00 --> Hooks Class Initialized
DEBUG - 2024-10-24 22:46:00 --> UTF-8 Support Enabled
INFO - 2024-10-24 22:46:00 --> Utf8 Class Initialized
INFO - 2024-10-24 22:46:00 --> URI Class Initialized
INFO - 2024-10-24 22:46:00 --> Router Class Initialized
INFO - 2024-10-24 22:46:00 --> Output Class Initialized
INFO - 2024-10-24 22:46:00 --> Security Class Initialized
DEBUG - 2024-10-24 22:46:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 22:46:00 --> Input Class Initialized
INFO - 2024-10-24 22:46:00 --> Language Class Initialized
ERROR - 2024-10-24 22:46:00 --> TEST ERROR MESSAGE - 2024-10-24 22:46:00
INFO - 2024-10-24 22:46:00 --> Loader Class Initialized
INFO - 2024-10-24 22:46:00 --> Controller Class Initialized
INFO - 2024-10-24 22:46:00 --> Database Driver Class Initialized
INFO - 2024-10-24 22:46:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 22:46:00 --> Helper loaded: form_helper
INFO - 2024-10-24 22:46:00 --> Helper loaded: url_helper
INFO - 2024-10-24 22:46:00 --> Model Class Initialized
INFO - 2024-10-24 22:46:00 --> Helper loaded: inflector_helper
INFO - 2024-10-24 22:46:00 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 22:46:00 --> Helper loaded: email_helper
INFO - 2024-10-24 22:46:00 --> Model Class Initialized
INFO - 2024-10-24 22:46:00 --> Model Class Initialized
INFO - 2024-10-24 22:46:00 --> Model Class Initialized
INFO - 2024-10-24 22:46:00 --> Model Class Initialized
INFO - 2024-10-24 22:46:00 --> Model Class Initialized
INFO - 2024-10-24 22:46:00 --> Model Class Initialized
INFO - 2024-10-24 22:46:00 --> Model Class Initialized
DEBUG - 2024-10-24 22:46:00 --> plural called with: company
DEBUG - 2024-10-24 22:46:00 --> is_countable called with!!!!: company
INFO - 2024-10-24 22:46:00 --> Model Class Initialized
INFO - 2024-10-24 22:46:00 --> Model Class Initialized
INFO - 2024-10-24 22:46:00 --> Model Class Initialized
INFO - 2024-10-24 22:46:00 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 22:46:00 --> Final output sent to browser
DEBUG - 2024-10-24 22:46:00 --> Total execution time: 0.0265
INFO - 2024-10-24 22:46:42 --> Config Class Initialized
INFO - 2024-10-24 22:46:42 --> Hooks Class Initialized
DEBUG - 2024-10-24 22:46:42 --> UTF-8 Support Enabled
INFO - 2024-10-24 22:46:42 --> Utf8 Class Initialized
INFO - 2024-10-24 22:46:42 --> URI Class Initialized
INFO - 2024-10-24 22:46:42 --> Router Class Initialized
INFO - 2024-10-24 22:46:42 --> Output Class Initialized
INFO - 2024-10-24 22:46:42 --> Security Class Initialized
DEBUG - 2024-10-24 22:46:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 22:46:42 --> Input Class Initialized
INFO - 2024-10-24 22:46:42 --> Language Class Initialized
ERROR - 2024-10-24 22:46:42 --> TEST ERROR MESSAGE - 2024-10-24 22:46:42
INFO - 2024-10-24 22:46:42 --> Loader Class Initialized
INFO - 2024-10-24 22:46:42 --> Controller Class Initialized
INFO - 2024-10-24 22:46:42 --> Database Driver Class Initialized
INFO - 2024-10-24 22:46:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 22:46:42 --> Helper loaded: form_helper
INFO - 2024-10-24 22:46:42 --> Helper loaded: url_helper
INFO - 2024-10-24 22:46:42 --> Model Class Initialized
INFO - 2024-10-24 22:46:42 --> Helper loaded: inflector_helper
INFO - 2024-10-24 22:46:42 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 22:46:42 --> Helper loaded: email_helper
INFO - 2024-10-24 22:46:42 --> Model Class Initialized
INFO - 2024-10-24 22:46:42 --> Model Class Initialized
INFO - 2024-10-24 22:46:42 --> Model Class Initialized
INFO - 2024-10-24 22:46:42 --> Model Class Initialized
INFO - 2024-10-24 22:46:42 --> Model Class Initialized
INFO - 2024-10-24 22:46:42 --> Model Class Initialized
INFO - 2024-10-24 22:46:42 --> Model Class Initialized
DEBUG - 2024-10-24 22:46:42 --> plural called with: company
DEBUG - 2024-10-24 22:46:42 --> is_countable called with!!!!: company
INFO - 2024-10-24 22:46:42 --> Model Class Initialized
INFO - 2024-10-24 22:46:42 --> Model Class Initialized
INFO - 2024-10-24 22:46:42 --> Model Class Initialized
INFO - 2024-10-24 22:46:42 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 22:46:42 --> Final output sent to browser
DEBUG - 2024-10-24 22:46:42 --> Total execution time: 0.0234
INFO - 2024-10-24 22:47:14 --> Config Class Initialized
INFO - 2024-10-24 22:47:14 --> Hooks Class Initialized
DEBUG - 2024-10-24 22:47:14 --> UTF-8 Support Enabled
INFO - 2024-10-24 22:47:14 --> Utf8 Class Initialized
INFO - 2024-10-24 22:47:14 --> URI Class Initialized
INFO - 2024-10-24 22:47:14 --> Router Class Initialized
INFO - 2024-10-24 22:47:14 --> Output Class Initialized
INFO - 2024-10-24 22:47:14 --> Security Class Initialized
DEBUG - 2024-10-24 22:47:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 22:47:14 --> Input Class Initialized
INFO - 2024-10-24 22:47:14 --> Language Class Initialized
ERROR - 2024-10-24 22:47:14 --> TEST ERROR MESSAGE - 2024-10-24 22:47:14
INFO - 2024-10-24 22:47:14 --> Loader Class Initialized
INFO - 2024-10-24 22:47:14 --> Controller Class Initialized
INFO - 2024-10-24 22:47:14 --> Database Driver Class Initialized
INFO - 2024-10-24 22:47:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 22:47:14 --> Helper loaded: form_helper
INFO - 2024-10-24 22:47:14 --> Helper loaded: url_helper
INFO - 2024-10-24 22:47:14 --> Model Class Initialized
INFO - 2024-10-24 22:47:14 --> Helper loaded: inflector_helper
INFO - 2024-10-24 22:47:14 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 22:47:14 --> Helper loaded: email_helper
INFO - 2024-10-24 22:47:14 --> Model Class Initialized
INFO - 2024-10-24 22:47:14 --> Model Class Initialized
INFO - 2024-10-24 22:47:14 --> Model Class Initialized
INFO - 2024-10-24 22:47:14 --> Model Class Initialized
INFO - 2024-10-24 22:47:14 --> Model Class Initialized
INFO - 2024-10-24 22:47:14 --> Model Class Initialized
INFO - 2024-10-24 22:47:14 --> Model Class Initialized
DEBUG - 2024-10-24 22:47:14 --> plural called with: company
DEBUG - 2024-10-24 22:47:14 --> is_countable called with!!!!: company
INFO - 2024-10-24 22:47:14 --> Model Class Initialized
INFO - 2024-10-24 22:47:14 --> Model Class Initialized
INFO - 2024-10-24 22:47:14 --> Model Class Initialized
INFO - 2024-10-24 22:47:14 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 22:47:14 --> Final output sent to browser
DEBUG - 2024-10-24 22:47:14 --> Total execution time: 0.0254
INFO - 2024-10-24 22:47:53 --> Config Class Initialized
INFO - 2024-10-24 22:47:53 --> Hooks Class Initialized
DEBUG - 2024-10-24 22:47:53 --> UTF-8 Support Enabled
INFO - 2024-10-24 22:47:53 --> Utf8 Class Initialized
INFO - 2024-10-24 22:47:53 --> URI Class Initialized
INFO - 2024-10-24 22:47:53 --> Router Class Initialized
INFO - 2024-10-24 22:47:53 --> Output Class Initialized
INFO - 2024-10-24 22:47:53 --> Security Class Initialized
DEBUG - 2024-10-24 22:47:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 22:47:53 --> Input Class Initialized
INFO - 2024-10-24 22:47:53 --> Language Class Initialized
ERROR - 2024-10-24 22:47:53 --> TEST ERROR MESSAGE - 2024-10-24 22:47:53
INFO - 2024-10-24 22:47:53 --> Loader Class Initialized
INFO - 2024-10-24 22:47:53 --> Controller Class Initialized
INFO - 2024-10-24 22:47:53 --> Database Driver Class Initialized
INFO - 2024-10-24 22:47:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 22:47:53 --> Helper loaded: form_helper
INFO - 2024-10-24 22:47:53 --> Helper loaded: url_helper
INFO - 2024-10-24 22:47:53 --> Model Class Initialized
INFO - 2024-10-24 22:47:53 --> Helper loaded: inflector_helper
INFO - 2024-10-24 22:47:53 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 22:47:53 --> Helper loaded: email_helper
INFO - 2024-10-24 22:47:53 --> Model Class Initialized
INFO - 2024-10-24 22:47:53 --> Model Class Initialized
INFO - 2024-10-24 22:47:53 --> Model Class Initialized
INFO - 2024-10-24 22:47:53 --> Model Class Initialized
INFO - 2024-10-24 22:47:53 --> Model Class Initialized
INFO - 2024-10-24 22:47:53 --> Model Class Initialized
INFO - 2024-10-24 22:47:53 --> Model Class Initialized
DEBUG - 2024-10-24 22:47:53 --> plural called with: company
DEBUG - 2024-10-24 22:47:53 --> is_countable called with!!!!: company
INFO - 2024-10-24 22:47:53 --> Model Class Initialized
INFO - 2024-10-24 22:47:53 --> Model Class Initialized
INFO - 2024-10-24 22:47:53 --> Model Class Initialized
INFO - 2024-10-24 22:47:53 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 22:47:53 --> Final output sent to browser
DEBUG - 2024-10-24 22:47:53 --> Total execution time: 0.0240
INFO - 2024-10-24 22:48:18 --> Config Class Initialized
INFO - 2024-10-24 22:48:18 --> Hooks Class Initialized
DEBUG - 2024-10-24 22:48:18 --> UTF-8 Support Enabled
INFO - 2024-10-24 22:48:18 --> Utf8 Class Initialized
INFO - 2024-10-24 22:48:18 --> URI Class Initialized
INFO - 2024-10-24 22:48:18 --> Router Class Initialized
INFO - 2024-10-24 22:48:18 --> Output Class Initialized
INFO - 2024-10-24 22:48:18 --> Security Class Initialized
DEBUG - 2024-10-24 22:48:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 22:48:18 --> Input Class Initialized
INFO - 2024-10-24 22:48:18 --> Language Class Initialized
ERROR - 2024-10-24 22:48:18 --> TEST ERROR MESSAGE - 2024-10-24 22:48:18
INFO - 2024-10-24 22:48:18 --> Loader Class Initialized
INFO - 2024-10-24 22:48:18 --> Controller Class Initialized
INFO - 2024-10-24 22:48:18 --> Database Driver Class Initialized
INFO - 2024-10-24 22:48:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 22:48:18 --> Helper loaded: form_helper
INFO - 2024-10-24 22:48:18 --> Helper loaded: url_helper
INFO - 2024-10-24 22:48:18 --> Model Class Initialized
INFO - 2024-10-24 22:48:18 --> Helper loaded: inflector_helper
INFO - 2024-10-24 22:48:18 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 22:48:18 --> Helper loaded: email_helper
INFO - 2024-10-24 22:48:18 --> Model Class Initialized
INFO - 2024-10-24 22:48:18 --> Model Class Initialized
INFO - 2024-10-24 22:48:18 --> Model Class Initialized
INFO - 2024-10-24 22:48:18 --> Model Class Initialized
INFO - 2024-10-24 22:48:18 --> Model Class Initialized
INFO - 2024-10-24 22:48:18 --> Model Class Initialized
INFO - 2024-10-24 22:48:18 --> Model Class Initialized
DEBUG - 2024-10-24 22:48:18 --> plural called with: company
DEBUG - 2024-10-24 22:48:18 --> is_countable called with!!!!: company
INFO - 2024-10-24 22:48:18 --> Model Class Initialized
INFO - 2024-10-24 22:48:18 --> Model Class Initialized
INFO - 2024-10-24 22:48:18 --> Model Class Initialized
INFO - 2024-10-24 22:48:18 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 22:48:18 --> Final output sent to browser
DEBUG - 2024-10-24 22:48:18 --> Total execution time: 0.0263
INFO - 2024-10-24 23:07:26 --> Config Class Initialized
INFO - 2024-10-24 23:07:26 --> Hooks Class Initialized
DEBUG - 2024-10-24 23:07:26 --> UTF-8 Support Enabled
INFO - 2024-10-24 23:07:26 --> Utf8 Class Initialized
INFO - 2024-10-24 23:07:26 --> URI Class Initialized
INFO - 2024-10-24 23:07:26 --> Router Class Initialized
INFO - 2024-10-24 23:07:26 --> Output Class Initialized
INFO - 2024-10-24 23:07:26 --> Security Class Initialized
DEBUG - 2024-10-24 23:07:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 23:07:26 --> Input Class Initialized
INFO - 2024-10-24 23:07:26 --> Language Class Initialized
ERROR - 2024-10-24 23:07:26 --> TEST ERROR MESSAGE - 2024-10-24 23:07:26
INFO - 2024-10-24 23:07:26 --> Loader Class Initialized
INFO - 2024-10-24 23:07:26 --> Controller Class Initialized
INFO - 2024-10-24 23:07:26 --> Database Driver Class Initialized
INFO - 2024-10-24 23:07:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 23:07:26 --> Helper loaded: form_helper
INFO - 2024-10-24 23:07:26 --> Helper loaded: url_helper
INFO - 2024-10-24 23:07:26 --> Model Class Initialized
INFO - 2024-10-24 23:07:26 --> Helper loaded: inflector_helper
INFO - 2024-10-24 23:07:26 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 23:07:26 --> Helper loaded: email_helper
INFO - 2024-10-24 23:07:26 --> Model Class Initialized
INFO - 2024-10-24 23:07:26 --> Model Class Initialized
INFO - 2024-10-24 23:07:26 --> Model Class Initialized
INFO - 2024-10-24 23:07:26 --> Model Class Initialized
INFO - 2024-10-24 23:07:26 --> Model Class Initialized
INFO - 2024-10-24 23:07:26 --> Model Class Initialized
INFO - 2024-10-24 23:07:26 --> Model Class Initialized
DEBUG - 2024-10-24 23:07:26 --> plural called with: company
DEBUG - 2024-10-24 23:07:26 --> is_countable called with!!!!: company
INFO - 2024-10-24 23:07:26 --> Model Class Initialized
INFO - 2024-10-24 23:07:26 --> Model Class Initialized
INFO - 2024-10-24 23:07:26 --> Model Class Initialized
ERROR - 2024-10-24 23:07:26 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 298
INFO - 2024-10-24 23:07:26 --> Final output sent to browser
DEBUG - 2024-10-24 23:07:26 --> Total execution time: 0.1043
INFO - 2024-10-24 23:14:53 --> Config Class Initialized
INFO - 2024-10-24 23:14:53 --> Hooks Class Initialized
DEBUG - 2024-10-24 23:14:53 --> UTF-8 Support Enabled
INFO - 2024-10-24 23:14:53 --> Utf8 Class Initialized
INFO - 2024-10-24 23:14:53 --> URI Class Initialized
INFO - 2024-10-24 23:14:53 --> Router Class Initialized
INFO - 2024-10-24 23:14:53 --> Output Class Initialized
INFO - 2024-10-24 23:14:53 --> Security Class Initialized
DEBUG - 2024-10-24 23:14:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 23:14:53 --> Input Class Initialized
INFO - 2024-10-24 23:14:53 --> Language Class Initialized
ERROR - 2024-10-24 23:14:53 --> TEST ERROR MESSAGE - 2024-10-24 23:14:53
INFO - 2024-10-24 23:14:53 --> Loader Class Initialized
INFO - 2024-10-24 23:14:53 --> Controller Class Initialized
INFO - 2024-10-24 23:14:53 --> Database Driver Class Initialized
INFO - 2024-10-24 23:14:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 23:14:53 --> Helper loaded: form_helper
INFO - 2024-10-24 23:14:53 --> Helper loaded: url_helper
INFO - 2024-10-24 23:14:53 --> Model Class Initialized
INFO - 2024-10-24 23:14:53 --> Helper loaded: inflector_helper
INFO - 2024-10-24 23:14:53 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 23:14:53 --> Helper loaded: email_helper
INFO - 2024-10-24 23:14:53 --> Model Class Initialized
INFO - 2024-10-24 23:14:53 --> Model Class Initialized
INFO - 2024-10-24 23:14:53 --> Model Class Initialized
INFO - 2024-10-24 23:14:53 --> Model Class Initialized
INFO - 2024-10-24 23:14:53 --> Model Class Initialized
INFO - 2024-10-24 23:14:53 --> Model Class Initialized
INFO - 2024-10-24 23:14:53 --> Model Class Initialized
DEBUG - 2024-10-24 23:14:53 --> plural called with: company
DEBUG - 2024-10-24 23:14:53 --> is_countable called with!!!!: company
INFO - 2024-10-24 23:14:53 --> Model Class Initialized
INFO - 2024-10-24 23:14:53 --> Model Class Initialized
INFO - 2024-10-24 23:14:53 --> Model Class Initialized
INFO - 2024-10-24 23:15:30 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-24 23:15:30 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-24 23:15:30 --> Final output sent to browser
DEBUG - 2024-10-24 23:15:30 --> Total execution time: 36.6567
INFO - 2024-10-24 23:17:12 --> Config Class Initialized
INFO - 2024-10-24 23:17:12 --> Hooks Class Initialized
DEBUG - 2024-10-24 23:17:12 --> UTF-8 Support Enabled
INFO - 2024-10-24 23:17:12 --> Utf8 Class Initialized
INFO - 2024-10-24 23:17:12 --> URI Class Initialized
INFO - 2024-10-24 23:17:12 --> Router Class Initialized
INFO - 2024-10-24 23:17:12 --> Output Class Initialized
INFO - 2024-10-24 23:17:12 --> Security Class Initialized
DEBUG - 2024-10-24 23:17:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 23:17:12 --> Input Class Initialized
INFO - 2024-10-24 23:17:12 --> Language Class Initialized
ERROR - 2024-10-24 23:17:12 --> TEST ERROR MESSAGE - 2024-10-24 23:17:12
INFO - 2024-10-24 23:17:12 --> Loader Class Initialized
INFO - 2024-10-24 23:17:12 --> Controller Class Initialized
INFO - 2024-10-24 23:17:12 --> Database Driver Class Initialized
INFO - 2024-10-24 23:17:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 23:17:12 --> Helper loaded: form_helper
INFO - 2024-10-24 23:17:12 --> Helper loaded: url_helper
INFO - 2024-10-24 23:17:12 --> Model Class Initialized
INFO - 2024-10-24 23:17:12 --> Helper loaded: inflector_helper
INFO - 2024-10-24 23:17:12 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 23:17:12 --> Helper loaded: email_helper
INFO - 2024-10-24 23:17:12 --> Model Class Initialized
INFO - 2024-10-24 23:17:12 --> Model Class Initialized
INFO - 2024-10-24 23:17:12 --> Model Class Initialized
INFO - 2024-10-24 23:17:12 --> Model Class Initialized
INFO - 2024-10-24 23:17:12 --> Model Class Initialized
INFO - 2024-10-24 23:17:12 --> Model Class Initialized
INFO - 2024-10-24 23:17:12 --> Model Class Initialized
DEBUG - 2024-10-24 23:17:12 --> plural called with: company
DEBUG - 2024-10-24 23:17:12 --> is_countable called with!!!!: company
INFO - 2024-10-24 23:17:12 --> Model Class Initialized
INFO - 2024-10-24 23:17:12 --> Model Class Initialized
INFO - 2024-10-24 23:17:12 --> Model Class Initialized
INFO - 2024-10-24 23:17:12 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 23:17:12 --> Final output sent to browser
DEBUG - 2024-10-24 23:17:12 --> Total execution time: 0.0242
INFO - 2024-10-24 23:17:39 --> Config Class Initialized
INFO - 2024-10-24 23:17:39 --> Hooks Class Initialized
DEBUG - 2024-10-24 23:17:39 --> UTF-8 Support Enabled
INFO - 2024-10-24 23:17:39 --> Utf8 Class Initialized
INFO - 2024-10-24 23:17:39 --> URI Class Initialized
INFO - 2024-10-24 23:17:39 --> Router Class Initialized
INFO - 2024-10-24 23:17:39 --> Output Class Initialized
INFO - 2024-10-24 23:17:39 --> Security Class Initialized
DEBUG - 2024-10-24 23:17:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 23:17:39 --> Input Class Initialized
INFO - 2024-10-24 23:17:39 --> Language Class Initialized
ERROR - 2024-10-24 23:17:39 --> TEST ERROR MESSAGE - 2024-10-24 23:17:39
INFO - 2024-10-24 23:17:39 --> Loader Class Initialized
INFO - 2024-10-24 23:17:39 --> Controller Class Initialized
INFO - 2024-10-24 23:17:39 --> Database Driver Class Initialized
INFO - 2024-10-24 23:17:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 23:17:39 --> Helper loaded: form_helper
INFO - 2024-10-24 23:17:39 --> Helper loaded: url_helper
INFO - 2024-10-24 23:17:39 --> Model Class Initialized
INFO - 2024-10-24 23:17:39 --> Helper loaded: inflector_helper
INFO - 2024-10-24 23:17:39 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 23:17:39 --> Helper loaded: email_helper
INFO - 2024-10-24 23:17:39 --> Model Class Initialized
INFO - 2024-10-24 23:17:39 --> Model Class Initialized
INFO - 2024-10-24 23:17:39 --> Model Class Initialized
INFO - 2024-10-24 23:17:39 --> Model Class Initialized
INFO - 2024-10-24 23:17:39 --> Model Class Initialized
INFO - 2024-10-24 23:17:39 --> Model Class Initialized
INFO - 2024-10-24 23:17:39 --> Model Class Initialized
DEBUG - 2024-10-24 23:17:39 --> plural called with: company
DEBUG - 2024-10-24 23:17:39 --> is_countable called with!!!!: company
INFO - 2024-10-24 23:17:39 --> Model Class Initialized
INFO - 2024-10-24 23:17:39 --> Model Class Initialized
INFO - 2024-10-24 23:17:39 --> Model Class Initialized
INFO - 2024-10-24 23:17:39 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 23:17:39 --> Final output sent to browser
DEBUG - 2024-10-24 23:17:39 --> Total execution time: 0.0353
INFO - 2024-10-24 23:18:09 --> Config Class Initialized
INFO - 2024-10-24 23:18:09 --> Hooks Class Initialized
DEBUG - 2024-10-24 23:18:09 --> UTF-8 Support Enabled
INFO - 2024-10-24 23:18:09 --> Utf8 Class Initialized
INFO - 2024-10-24 23:18:09 --> URI Class Initialized
INFO - 2024-10-24 23:18:09 --> Router Class Initialized
INFO - 2024-10-24 23:18:09 --> Output Class Initialized
INFO - 2024-10-24 23:18:09 --> Security Class Initialized
DEBUG - 2024-10-24 23:18:09 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-24 23:18:09 --> Input Class Initialized
INFO - 2024-10-24 23:18:09 --> Language Class Initialized
ERROR - 2024-10-24 23:18:09 --> TEST ERROR MESSAGE - 2024-10-24 23:18:09
INFO - 2024-10-24 23:18:09 --> Loader Class Initialized
INFO - 2024-10-24 23:18:09 --> Controller Class Initialized
INFO - 2024-10-24 23:18:09 --> Database Driver Class Initialized
INFO - 2024-10-24 23:18:09 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-24 23:18:09 --> Helper loaded: form_helper
INFO - 2024-10-24 23:18:09 --> Helper loaded: url_helper
INFO - 2024-10-24 23:18:09 --> Model Class Initialized
INFO - 2024-10-24 23:18:09 --> Helper loaded: inflector_helper
INFO - 2024-10-24 23:18:09 --> Helper loaded: mezoo_helper
INFO - 2024-10-24 23:18:09 --> Helper loaded: email_helper
INFO - 2024-10-24 23:18:09 --> Model Class Initialized
INFO - 2024-10-24 23:18:09 --> Model Class Initialized
INFO - 2024-10-24 23:18:09 --> Model Class Initialized
INFO - 2024-10-24 23:18:09 --> Model Class Initialized
INFO - 2024-10-24 23:18:09 --> Model Class Initialized
INFO - 2024-10-24 23:18:09 --> Model Class Initialized
INFO - 2024-10-24 23:18:09 --> Model Class Initialized
DEBUG - 2024-10-24 23:18:09 --> plural called with: company
DEBUG - 2024-10-24 23:18:09 --> is_countable called with!!!!: company
INFO - 2024-10-24 23:18:09 --> Model Class Initialized
INFO - 2024-10-24 23:18:09 --> Model Class Initialized
INFO - 2024-10-24 23:18:09 --> Model Class Initialized
INFO - 2024-10-24 23:18:09 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-24 23:18:09 --> Final output sent to browser
DEBUG - 2024-10-24 23:18:09 --> Total execution time: 0.0239

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-10-16 02:26:53 --> Query error: Table 'tillmezo_a.company' doesn't exist - Invalid query: SELECT *
FROM `company`
WHERE `login` = 'admin2'
AND `password` = 'til794613'
ERROR - 2024-10-16 02:26:53 --> Severity: error --> Exception: Call to a member function row_array() on bool /home/tillmezo/domains/till.mezoo.co.il/public_html/application/core/MY_Model.php 146
ERROR - 2024-10-16 02:28:17 --> Query error: Table 'tillmezo_a.company' doesn't exist - Invalid query: SELECT *
FROM `company`
WHERE `login` = 'admin2'
AND `password` = 'til794613'
ERROR - 2024-10-16 02:28:17 --> Severity: error --> Exception: Call to a member function row_array() on bool /home/tillmezo/domains/till.mezoo.co.il/public_html/application/core/MY_Model.php 146
ERROR - 2024-10-16 02:28:28 --> Query error: Table 'tillmezo_a.company' doesn't exist - Invalid query: SELECT *
FROM `company`
WHERE `login` = 'admin2'
AND `password` = 'til794613'
ERROR - 2024-10-16 02:28:28 --> Severity: error --> Exception: Call to a member function row_array() on bool /home/tillmezo/domains/till.mezoo.co.il/public_html/application/core/MY_Model.php 146
ERROR - 2024-10-16 02:33:41 --> Query error: Table 'tillmezo_a.company' doesn't exist - Invalid query: SELECT *
FROM `company`
WHERE `login` = 'admin2'
AND `password` = 'til794613'
ERROR - 2024-10-16 02:33:41 --> Severity: error --> Exception: Call to a member function row_array() on bool /home/tillmezo/domains/till.mezoo.co.il/public_html/application/core/MY_Model.php 146
ERROR - 2024-10-16 02:34:31 --> Query error: Table 'tillmezo_a.company' doesn't exist - Invalid query: SELECT *
FROM `company`
WHERE `login` = 'admin2'
AND `password` = 'til794613'
ERROR - 2024-10-16 02:34:31 --> Severity: error --> Exception: Call to a member function row_array() on bool /home/tillmezo/domains/till.mezoo.co.il/public_html/application/core/MY_Model.php 146
ERROR - 2024-10-16 03:04:52 --> Query error: Table 'tillmezo_a.log' doesn't exist - Invalid query: INSERT INTO `log` (`username`, `created`, `result`) VALUES ('admin2', '2024-10-16 03:04:52', 'Yes')
ERROR - 2024-10-16 03:05:07 --> Query error: Table 'tillmezo_a.log' doesn't exist - Invalid query: INSERT INTO `log` (`username`, `created`, `result`) VALUES ('admin2', '2024-10-16 03:05:07', 'Yes')
ERROR - 2024-10-16 03:08:30 --> Query error: Table 'tillmezo_a.log' doesn't exist - Invalid query: INSERT INTO `log` (`username`, `created`, `result`) VALUES ('admin2', '2024-10-16 03:08:30', 'Yes')
ERROR - 2024-10-16 03:43:05 --> Query error: Table 'tillmezo_a.responderextradata' doesn't exist - Invalid query: SELECT *
FROM `responderextradata`
WHERE `paramName` = 'PD_IDNumber'
AND `val` = '23'
ERROR - 2024-10-16 03:43:05 --> Severity: error --> Exception: Call to a member function row_array() on bool /home/tillmezo/domains/till.mezoo.co.il/public_html/application/core/MY_Model.php 146
ERROR - 2024-10-16 03:43:16 --> Query error: Table 'tillmezo_a.responderextradata' doesn't exist - Invalid query: SELECT *
FROM `responderextradata`
WHERE `paramName` = 'PD_IDNumber'
AND `val` = '23'
ERROR - 2024-10-16 03:43:16 --> Severity: error --> Exception: Call to a member function row_array() on bool /home/tillmezo/domains/till.mezoo.co.il/public_html/application/core/MY_Model.php 146
ERROR - 2024-10-16 03:57:38 --> Query error: Table 'tillmezo_a.responderextradata' doesn't exist - Invalid query: SELECT *
FROM `responderextradata`
WHERE `paramName` = 'PD_IDNumber'
AND `val` = '23'
ERROR - 2024-10-16 03:57:38 --> Severity: error --> Exception: Call to a member function row_array() on bool /home/tillmezo/domains/till.mezoo.co.il/public_html/application/core/MY_Model.php 146

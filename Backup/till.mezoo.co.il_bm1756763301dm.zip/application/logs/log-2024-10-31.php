<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-10-31 18:21:37 --> Severity: Warning --> Division by zero /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 216
ERROR - 2024-10-31 18:21:37 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: INSERT INTO `feedbackdims` (`feedbackId`, `dimId`, `result`) VALUES (16413, NULL, NAN)
ERROR - 2024-10-31 18:21:37 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: INSERT INTO `feedbackdims` (`feedbackId`, `dimId`, `result`) VALUES (16413, NULL, NAN)
ERROR - 2024-10-31 18:22:42 --> Severity: Warning --> Cannot use a scalar value as an array /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 448

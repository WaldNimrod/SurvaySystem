<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2025-03-07 07:32:53 --> Severity: error --> Exception: Too few arguments to function Welcome::setRemarks(), 0 passed in /home/tillmezo/domains/till.mezoo.co.il/public_html/system/core/CodeIgniter.php on line 529 and exactly 1 expected /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 624

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

INFO - 2024-10-28 03:03:21 --> Config Class Initialized
INFO - 2024-10-28 03:03:21 --> Hooks Class Initialized
DEBUG - 2024-10-28 03:03:21 --> UTF-8 Support Enabled
INFO - 2024-10-28 03:03:21 --> Utf8 Class Initialized
INFO - 2024-10-28 03:03:21 --> URI Class Initialized
DEBUG - 2024-10-28 03:03:21 --> No URI present. Default controller set.
INFO - 2024-10-28 03:03:21 --> Router Class Initialized
INFO - 2024-10-28 03:03:21 --> Output Class Initialized
INFO - 2024-10-28 03:03:21 --> Security Class Initialized
DEBUG - 2024-10-28 03:03:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 03:03:21 --> Input Class Initialized
INFO - 2024-10-28 03:03:21 --> Language Class Initialized
ERROR - 2024-10-28 03:03:21 --> TEST ERROR MESSAGE - 2024-10-28 03:03:21
INFO - 2024-10-28 03:03:21 --> Loader Class Initialized
INFO - 2024-10-28 03:03:21 --> Controller Class Initialized
INFO - 2024-10-28 03:03:22 --> Database Driver Class Initialized
INFO - 2024-10-28 03:03:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 03:03:22 --> Helper loaded: form_helper
INFO - 2024-10-28 03:03:22 --> Helper loaded: url_helper
INFO - 2024-10-28 03:03:22 --> Model Class Initialized
INFO - 2024-10-28 03:03:22 --> Helper loaded: inflector_helper
INFO - 2024-10-28 03:03:22 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 03:03:22 --> Helper loaded: email_helper
INFO - 2024-10-28 03:03:22 --> Model Class Initialized
INFO - 2024-10-28 03:03:22 --> Model Class Initialized
INFO - 2024-10-28 03:03:22 --> Model Class Initialized
INFO - 2024-10-28 03:03:22 --> Model Class Initialized
INFO - 2024-10-28 03:03:22 --> Model Class Initialized
INFO - 2024-10-28 03:03:22 --> Model Class Initialized
INFO - 2024-10-28 03:03:22 --> Model Class Initialized
DEBUG - 2024-10-28 03:03:22 --> plural called with: company
DEBUG - 2024-10-28 03:03:22 --> is_countable called with!!!!: company
INFO - 2024-10-28 03:03:22 --> Model Class Initialized
INFO - 2024-10-28 03:03:22 --> Model Class Initialized
INFO - 2024-10-28 03:03:22 --> Model Class Initialized
INFO - 2024-10-28 03:03:22 --> Final output sent to browser
DEBUG - 2024-10-28 03:03:22 --> Total execution time: 0.0925
INFO - 2024-10-28 03:57:27 --> Config Class Initialized
INFO - 2024-10-28 03:57:27 --> Hooks Class Initialized
DEBUG - 2024-10-28 03:57:27 --> UTF-8 Support Enabled
INFO - 2024-10-28 03:57:27 --> Utf8 Class Initialized
INFO - 2024-10-28 03:57:27 --> URI Class Initialized
DEBUG - 2024-10-28 03:57:27 --> No URI present. Default controller set.
INFO - 2024-10-28 03:57:27 --> Router Class Initialized
INFO - 2024-10-28 03:57:27 --> Output Class Initialized
INFO - 2024-10-28 03:57:27 --> Security Class Initialized
DEBUG - 2024-10-28 03:57:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 03:57:27 --> Input Class Initialized
INFO - 2024-10-28 03:57:27 --> Language Class Initialized
ERROR - 2024-10-28 03:57:27 --> TEST ERROR MESSAGE - 2024-10-28 03:57:27
INFO - 2024-10-28 03:57:27 --> Loader Class Initialized
INFO - 2024-10-28 03:57:27 --> Controller Class Initialized
INFO - 2024-10-28 03:57:27 --> Database Driver Class Initialized
INFO - 2024-10-28 03:57:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 03:57:27 --> Helper loaded: form_helper
INFO - 2024-10-28 03:57:27 --> Helper loaded: url_helper
INFO - 2024-10-28 03:57:27 --> Model Class Initialized
INFO - 2024-10-28 03:57:27 --> Helper loaded: inflector_helper
INFO - 2024-10-28 03:57:27 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 03:57:27 --> Helper loaded: email_helper
INFO - 2024-10-28 03:57:27 --> Model Class Initialized
INFO - 2024-10-28 03:57:27 --> Model Class Initialized
INFO - 2024-10-28 03:57:27 --> Model Class Initialized
INFO - 2024-10-28 03:57:27 --> Model Class Initialized
INFO - 2024-10-28 03:57:27 --> Model Class Initialized
INFO - 2024-10-28 03:57:27 --> Model Class Initialized
INFO - 2024-10-28 03:57:27 --> Model Class Initialized
DEBUG - 2024-10-28 03:57:27 --> plural called with: company
DEBUG - 2024-10-28 03:57:27 --> is_countable called with!!!!: company
INFO - 2024-10-28 03:57:27 --> Model Class Initialized
INFO - 2024-10-28 03:57:27 --> Model Class Initialized
INFO - 2024-10-28 03:57:27 --> Model Class Initialized
INFO - 2024-10-28 03:57:27 --> Final output sent to browser
DEBUG - 2024-10-28 03:57:27 --> Total execution time: 0.0255
INFO - 2024-10-28 06:59:42 --> Config Class Initialized
INFO - 2024-10-28 06:59:42 --> Hooks Class Initialized
DEBUG - 2024-10-28 06:59:42 --> UTF-8 Support Enabled
INFO - 2024-10-28 06:59:42 --> Utf8 Class Initialized
INFO - 2024-10-28 06:59:42 --> URI Class Initialized
INFO - 2024-10-28 06:59:42 --> Router Class Initialized
INFO - 2024-10-28 06:59:42 --> Output Class Initialized
INFO - 2024-10-28 06:59:42 --> Security Class Initialized
DEBUG - 2024-10-28 06:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 06:59:42 --> Input Class Initialized
INFO - 2024-10-28 06:59:42 --> Language Class Initialized
ERROR - 2024-10-28 06:59:42 --> TEST ERROR MESSAGE - 2024-10-28 06:59:42
INFO - 2024-10-28 06:59:42 --> Loader Class Initialized
INFO - 2024-10-28 06:59:42 --> Controller Class Initialized
INFO - 2024-10-28 06:59:42 --> Database Driver Class Initialized
INFO - 2024-10-28 06:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 06:59:42 --> Helper loaded: form_helper
INFO - 2024-10-28 06:59:42 --> Helper loaded: url_helper
INFO - 2024-10-28 06:59:42 --> Model Class Initialized
INFO - 2024-10-28 06:59:42 --> Helper loaded: inflector_helper
INFO - 2024-10-28 06:59:42 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 06:59:42 --> Helper loaded: email_helper
INFO - 2024-10-28 06:59:42 --> Model Class Initialized
INFO - 2024-10-28 06:59:42 --> Model Class Initialized
INFO - 2024-10-28 06:59:42 --> Model Class Initialized
INFO - 2024-10-28 06:59:42 --> Model Class Initialized
INFO - 2024-10-28 06:59:42 --> Model Class Initialized
INFO - 2024-10-28 06:59:42 --> Model Class Initialized
INFO - 2024-10-28 06:59:42 --> Model Class Initialized
DEBUG - 2024-10-28 06:59:42 --> plural called with: company
DEBUG - 2024-10-28 06:59:42 --> is_countable called with!!!!: company
INFO - 2024-10-28 06:59:42 --> Model Class Initialized
INFO - 2024-10-28 06:59:42 --> Model Class Initialized
INFO - 2024-10-28 06:59:42 --> Model Class Initialized
INFO - 2024-10-28 06:59:42 --> Config Class Initialized
INFO - 2024-10-28 06:59:42 --> Hooks Class Initialized
DEBUG - 2024-10-28 06:59:42 --> UTF-8 Support Enabled
INFO - 2024-10-28 06:59:42 --> Utf8 Class Initialized
INFO - 2024-10-28 06:59:42 --> URI Class Initialized
INFO - 2024-10-28 06:59:42 --> Router Class Initialized
INFO - 2024-10-28 06:59:42 --> Output Class Initialized
INFO - 2024-10-28 06:59:42 --> Security Class Initialized
DEBUG - 2024-10-28 06:59:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 06:59:42 --> Input Class Initialized
INFO - 2024-10-28 06:59:42 --> Language Class Initialized
ERROR - 2024-10-28 06:59:42 --> TEST ERROR MESSAGE - 2024-10-28 06:59:42
INFO - 2024-10-28 06:59:42 --> Loader Class Initialized
INFO - 2024-10-28 06:59:42 --> Controller Class Initialized
INFO - 2024-10-28 06:59:42 --> Database Driver Class Initialized
INFO - 2024-10-28 06:59:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 06:59:42 --> Helper loaded: form_helper
INFO - 2024-10-28 06:59:42 --> Helper loaded: url_helper
INFO - 2024-10-28 06:59:42 --> Model Class Initialized
INFO - 2024-10-28 06:59:42 --> Helper loaded: inflector_helper
INFO - 2024-10-28 06:59:42 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 06:59:42 --> Helper loaded: email_helper
INFO - 2024-10-28 06:59:42 --> Model Class Initialized
INFO - 2024-10-28 06:59:42 --> Model Class Initialized
INFO - 2024-10-28 06:59:42 --> Model Class Initialized
INFO - 2024-10-28 06:59:42 --> Model Class Initialized
INFO - 2024-10-28 06:59:42 --> Model Class Initialized
INFO - 2024-10-28 06:59:42 --> Model Class Initialized
INFO - 2024-10-28 06:59:42 --> Model Class Initialized
DEBUG - 2024-10-28 06:59:42 --> plural called with: company
DEBUG - 2024-10-28 06:59:42 --> is_countable called with!!!!: company
INFO - 2024-10-28 06:59:42 --> Model Class Initialized
INFO - 2024-10-28 06:59:42 --> Model Class Initialized
INFO - 2024-10-28 06:59:42 --> Model Class Initialized
INFO - 2024-10-28 06:59:42 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-28 06:59:42 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-28 06:59:42 --> Final output sent to browser
DEBUG - 2024-10-28 06:59:42 --> Total execution time: 0.0275
INFO - 2024-10-28 06:59:46 --> Config Class Initialized
INFO - 2024-10-28 06:59:46 --> Hooks Class Initialized
DEBUG - 2024-10-28 06:59:46 --> UTF-8 Support Enabled
INFO - 2024-10-28 06:59:46 --> Utf8 Class Initialized
INFO - 2024-10-28 06:59:46 --> URI Class Initialized
INFO - 2024-10-28 06:59:46 --> Router Class Initialized
INFO - 2024-10-28 06:59:46 --> Output Class Initialized
INFO - 2024-10-28 06:59:46 --> Security Class Initialized
DEBUG - 2024-10-28 06:59:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 06:59:46 --> Input Class Initialized
INFO - 2024-10-28 06:59:46 --> Language Class Initialized
ERROR - 2024-10-28 06:59:46 --> TEST ERROR MESSAGE - 2024-10-28 06:59:46
INFO - 2024-10-28 06:59:47 --> Loader Class Initialized
INFO - 2024-10-28 06:59:47 --> Controller Class Initialized
INFO - 2024-10-28 06:59:47 --> Database Driver Class Initialized
INFO - 2024-10-28 06:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 06:59:47 --> Helper loaded: form_helper
INFO - 2024-10-28 06:59:47 --> Helper loaded: url_helper
INFO - 2024-10-28 06:59:47 --> Model Class Initialized
INFO - 2024-10-28 06:59:47 --> Helper loaded: inflector_helper
INFO - 2024-10-28 06:59:47 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 06:59:47 --> Helper loaded: email_helper
INFO - 2024-10-28 06:59:47 --> Model Class Initialized
INFO - 2024-10-28 06:59:47 --> Model Class Initialized
INFO - 2024-10-28 06:59:47 --> Model Class Initialized
INFO - 2024-10-28 06:59:47 --> Model Class Initialized
INFO - 2024-10-28 06:59:47 --> Model Class Initialized
INFO - 2024-10-28 06:59:47 --> Model Class Initialized
INFO - 2024-10-28 06:59:47 --> Model Class Initialized
DEBUG - 2024-10-28 06:59:47 --> plural called with: company
DEBUG - 2024-10-28 06:59:47 --> is_countable called with!!!!: company
INFO - 2024-10-28 06:59:47 --> Model Class Initialized
INFO - 2024-10-28 06:59:47 --> Model Class Initialized
INFO - 2024-10-28 06:59:47 --> Model Class Initialized
INFO - 2024-10-28 06:59:47 --> Config Class Initialized
INFO - 2024-10-28 06:59:47 --> Hooks Class Initialized
DEBUG - 2024-10-28 06:59:47 --> UTF-8 Support Enabled
INFO - 2024-10-28 06:59:47 --> Utf8 Class Initialized
INFO - 2024-10-28 06:59:47 --> URI Class Initialized
INFO - 2024-10-28 06:59:47 --> Router Class Initialized
INFO - 2024-10-28 06:59:47 --> Output Class Initialized
INFO - 2024-10-28 06:59:47 --> Security Class Initialized
DEBUG - 2024-10-28 06:59:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 06:59:47 --> Input Class Initialized
INFO - 2024-10-28 06:59:47 --> Language Class Initialized
ERROR - 2024-10-28 06:59:47 --> TEST ERROR MESSAGE - 2024-10-28 06:59:47
INFO - 2024-10-28 06:59:47 --> Loader Class Initialized
INFO - 2024-10-28 06:59:47 --> Controller Class Initialized
INFO - 2024-10-28 06:59:47 --> Database Driver Class Initialized
INFO - 2024-10-28 06:59:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 06:59:47 --> Helper loaded: form_helper
INFO - 2024-10-28 06:59:47 --> Helper loaded: url_helper
INFO - 2024-10-28 06:59:47 --> Model Class Initialized
INFO - 2024-10-28 06:59:47 --> Helper loaded: inflector_helper
INFO - 2024-10-28 06:59:47 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 06:59:47 --> Helper loaded: email_helper
INFO - 2024-10-28 06:59:47 --> Model Class Initialized
INFO - 2024-10-28 06:59:47 --> Model Class Initialized
INFO - 2024-10-28 06:59:47 --> Model Class Initialized
INFO - 2024-10-28 06:59:47 --> Model Class Initialized
INFO - 2024-10-28 06:59:47 --> Model Class Initialized
INFO - 2024-10-28 06:59:47 --> Model Class Initialized
INFO - 2024-10-28 06:59:47 --> Model Class Initialized
DEBUG - 2024-10-28 06:59:47 --> plural called with: company
DEBUG - 2024-10-28 06:59:47 --> is_countable called with!!!!: company
INFO - 2024-10-28 06:59:47 --> Model Class Initialized
INFO - 2024-10-28 06:59:47 --> Model Class Initialized
INFO - 2024-10-28 06:59:47 --> Model Class Initialized
ERROR - 2024-10-28 06:59:47 --> Severity: Notice --> Undefined index: freetext /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 06:59:47 --> Severity: Notice --> Undefined index: socialDes /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 06:59:47 --> Severity: Notice --> Undefined index: company /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 06:59:47 --> Severity: Notice --> Undefined index: division /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 06:59:47 --> Severity: Notice --> Undefined index: dataGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 06:59:47 --> Severity: Notice --> Undefined index: finalGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
INFO - 2024-10-28 06:59:47 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-28 06:59:47 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-28 06:59:47 --> Final output sent to browser
DEBUG - 2024-10-28 06:59:47 --> Total execution time: 0.8059
INFO - 2024-10-28 08:01:19 --> Config Class Initialized
INFO - 2024-10-28 08:01:19 --> Hooks Class Initialized
DEBUG - 2024-10-28 08:01:19 --> UTF-8 Support Enabled
INFO - 2024-10-28 08:01:19 --> Utf8 Class Initialized
INFO - 2024-10-28 08:01:19 --> URI Class Initialized
INFO - 2024-10-28 08:01:19 --> Router Class Initialized
INFO - 2024-10-28 08:01:19 --> Output Class Initialized
INFO - 2024-10-28 08:01:19 --> Security Class Initialized
DEBUG - 2024-10-28 08:01:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 08:01:19 --> Input Class Initialized
INFO - 2024-10-28 08:01:19 --> Language Class Initialized
ERROR - 2024-10-28 08:01:19 --> TEST ERROR MESSAGE - 2024-10-28 08:01:19
INFO - 2024-10-28 08:01:19 --> Loader Class Initialized
INFO - 2024-10-28 08:01:19 --> Controller Class Initialized
INFO - 2024-10-28 08:01:19 --> Database Driver Class Initialized
INFO - 2024-10-28 08:01:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 08:01:19 --> Helper loaded: form_helper
INFO - 2024-10-28 08:01:19 --> Helper loaded: url_helper
INFO - 2024-10-28 08:01:19 --> Model Class Initialized
INFO - 2024-10-28 08:01:19 --> Helper loaded: inflector_helper
INFO - 2024-10-28 08:01:19 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 08:01:19 --> Helper loaded: email_helper
INFO - 2024-10-28 08:01:19 --> Model Class Initialized
INFO - 2024-10-28 08:01:19 --> Model Class Initialized
INFO - 2024-10-28 08:01:19 --> Model Class Initialized
INFO - 2024-10-28 08:01:19 --> Model Class Initialized
INFO - 2024-10-28 08:01:19 --> Model Class Initialized
INFO - 2024-10-28 08:01:19 --> Model Class Initialized
INFO - 2024-10-28 08:01:19 --> Model Class Initialized
DEBUG - 2024-10-28 08:01:19 --> plural called with: company
DEBUG - 2024-10-28 08:01:19 --> is_countable called with!!!!: company
INFO - 2024-10-28 08:01:19 --> Model Class Initialized
INFO - 2024-10-28 08:01:19 --> Model Class Initialized
INFO - 2024-10-28 08:01:19 --> Model Class Initialized
ERROR - 2024-10-28 08:01:20 --> Severity: Notice --> Undefined index: freetext /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 08:01:20 --> Severity: Notice --> Undefined index: socialDes /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 08:01:20 --> Severity: Notice --> Undefined index: company /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 08:01:20 --> Severity: Notice --> Undefined index: division /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 08:01:20 --> Severity: Notice --> Undefined index: dataGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 08:01:20 --> Severity: Notice --> Undefined index: finalGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
INFO - 2024-10-28 08:01:20 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-28 08:01:20 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-28 08:01:20 --> Final output sent to browser
DEBUG - 2024-10-28 08:01:20 --> Total execution time: 0.6943
INFO - 2024-10-28 10:20:33 --> Config Class Initialized
INFO - 2024-10-28 10:20:33 --> Hooks Class Initialized
DEBUG - 2024-10-28 10:20:33 --> UTF-8 Support Enabled
INFO - 2024-10-28 10:20:33 --> Utf8 Class Initialized
INFO - 2024-10-28 10:20:33 --> URI Class Initialized
INFO - 2024-10-28 10:20:33 --> Router Class Initialized
INFO - 2024-10-28 10:20:33 --> Output Class Initialized
INFO - 2024-10-28 10:20:33 --> Security Class Initialized
DEBUG - 2024-10-28 10:20:33 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 10:20:33 --> Input Class Initialized
INFO - 2024-10-28 10:20:33 --> Language Class Initialized
ERROR - 2024-10-28 10:20:33 --> TEST ERROR MESSAGE - 2024-10-28 10:20:33
INFO - 2024-10-28 10:20:33 --> Loader Class Initialized
INFO - 2024-10-28 10:20:33 --> Controller Class Initialized
INFO - 2024-10-28 10:20:33 --> Database Driver Class Initialized
INFO - 2024-10-28 10:20:33 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 10:20:33 --> Helper loaded: form_helper
INFO - 2024-10-28 10:20:33 --> Helper loaded: url_helper
INFO - 2024-10-28 10:20:33 --> Model Class Initialized
INFO - 2024-10-28 10:20:33 --> Helper loaded: inflector_helper
INFO - 2024-10-28 10:20:33 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 10:20:33 --> Helper loaded: email_helper
INFO - 2024-10-28 10:20:33 --> Model Class Initialized
INFO - 2024-10-28 10:20:33 --> Model Class Initialized
INFO - 2024-10-28 10:20:33 --> Model Class Initialized
INFO - 2024-10-28 10:20:33 --> Model Class Initialized
INFO - 2024-10-28 10:20:33 --> Model Class Initialized
INFO - 2024-10-28 10:20:33 --> Model Class Initialized
INFO - 2024-10-28 10:20:33 --> Model Class Initialized
DEBUG - 2024-10-28 10:20:33 --> plural called with: company
DEBUG - 2024-10-28 10:20:33 --> is_countable called with!!!!: company
INFO - 2024-10-28 10:20:33 --> Model Class Initialized
INFO - 2024-10-28 10:20:33 --> Model Class Initialized
INFO - 2024-10-28 10:20:33 --> Model Class Initialized
ERROR - 2024-10-28 10:20:33 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 298
ERROR - 2024-10-28 10:20:33 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 312
ERROR - 2024-10-28 10:20:33 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 317
INFO - 2024-10-28 10:20:33 --> Final output sent to browser
DEBUG - 2024-10-28 10:20:33 --> Total execution time: 0.1292
INFO - 2024-10-28 11:38:06 --> Config Class Initialized
INFO - 2024-10-28 11:38:06 --> Hooks Class Initialized
DEBUG - 2024-10-28 11:38:06 --> UTF-8 Support Enabled
INFO - 2024-10-28 11:38:06 --> Utf8 Class Initialized
INFO - 2024-10-28 11:38:06 --> URI Class Initialized
DEBUG - 2024-10-28 11:38:06 --> No URI present. Default controller set.
INFO - 2024-10-28 11:38:06 --> Router Class Initialized
INFO - 2024-10-28 11:38:06 --> Output Class Initialized
INFO - 2024-10-28 11:38:06 --> Security Class Initialized
DEBUG - 2024-10-28 11:38:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 11:38:06 --> Input Class Initialized
INFO - 2024-10-28 11:38:06 --> Language Class Initialized
ERROR - 2024-10-28 11:38:06 --> TEST ERROR MESSAGE - 2024-10-28 11:38:06
INFO - 2024-10-28 11:38:06 --> Loader Class Initialized
INFO - 2024-10-28 11:38:06 --> Controller Class Initialized
INFO - 2024-10-28 11:38:06 --> Database Driver Class Initialized
INFO - 2024-10-28 11:38:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 11:38:06 --> Helper loaded: form_helper
INFO - 2024-10-28 11:38:06 --> Helper loaded: url_helper
INFO - 2024-10-28 11:38:06 --> Model Class Initialized
INFO - 2024-10-28 11:38:06 --> Helper loaded: inflector_helper
INFO - 2024-10-28 11:38:06 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 11:38:06 --> Helper loaded: email_helper
INFO - 2024-10-28 11:38:06 --> Model Class Initialized
INFO - 2024-10-28 11:38:06 --> Model Class Initialized
INFO - 2024-10-28 11:38:06 --> Model Class Initialized
INFO - 2024-10-28 11:38:06 --> Model Class Initialized
INFO - 2024-10-28 11:38:06 --> Model Class Initialized
INFO - 2024-10-28 11:38:06 --> Model Class Initialized
INFO - 2024-10-28 11:38:06 --> Model Class Initialized
DEBUG - 2024-10-28 11:38:06 --> plural called with: company
DEBUG - 2024-10-28 11:38:06 --> is_countable called with!!!!: company
INFO - 2024-10-28 11:38:06 --> Model Class Initialized
INFO - 2024-10-28 11:38:06 --> Model Class Initialized
INFO - 2024-10-28 11:38:06 --> Model Class Initialized
INFO - 2024-10-28 11:38:06 --> Final output sent to browser
DEBUG - 2024-10-28 11:38:06 --> Total execution time: 0.0248
INFO - 2024-10-28 11:38:11 --> Config Class Initialized
INFO - 2024-10-28 11:38:11 --> Hooks Class Initialized
DEBUG - 2024-10-28 11:38:11 --> UTF-8 Support Enabled
INFO - 2024-10-28 11:38:11 --> Utf8 Class Initialized
INFO - 2024-10-28 11:38:11 --> URI Class Initialized
DEBUG - 2024-10-28 11:38:11 --> No URI present. Default controller set.
INFO - 2024-10-28 11:38:11 --> Router Class Initialized
INFO - 2024-10-28 11:38:11 --> Output Class Initialized
INFO - 2024-10-28 11:38:11 --> Security Class Initialized
DEBUG - 2024-10-28 11:38:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 11:38:11 --> Input Class Initialized
INFO - 2024-10-28 11:38:11 --> Language Class Initialized
ERROR - 2024-10-28 11:38:11 --> TEST ERROR MESSAGE - 2024-10-28 11:38:11
INFO - 2024-10-28 11:38:11 --> Loader Class Initialized
INFO - 2024-10-28 11:38:11 --> Controller Class Initialized
INFO - 2024-10-28 11:38:11 --> Database Driver Class Initialized
INFO - 2024-10-28 11:38:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 11:38:11 --> Helper loaded: form_helper
INFO - 2024-10-28 11:38:11 --> Helper loaded: url_helper
INFO - 2024-10-28 11:38:11 --> Model Class Initialized
INFO - 2024-10-28 11:38:11 --> Helper loaded: inflector_helper
INFO - 2024-10-28 11:38:11 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 11:38:11 --> Helper loaded: email_helper
INFO - 2024-10-28 11:38:11 --> Model Class Initialized
INFO - 2024-10-28 11:38:11 --> Model Class Initialized
INFO - 2024-10-28 11:38:11 --> Model Class Initialized
INFO - 2024-10-28 11:38:11 --> Model Class Initialized
INFO - 2024-10-28 11:38:11 --> Model Class Initialized
INFO - 2024-10-28 11:38:11 --> Model Class Initialized
INFO - 2024-10-28 11:38:11 --> Model Class Initialized
DEBUG - 2024-10-28 11:38:11 --> plural called with: company
DEBUG - 2024-10-28 11:38:11 --> is_countable called with!!!!: company
INFO - 2024-10-28 11:38:11 --> Model Class Initialized
INFO - 2024-10-28 11:38:11 --> Model Class Initialized
INFO - 2024-10-28 11:38:11 --> Model Class Initialized
INFO - 2024-10-28 11:38:11 --> Final output sent to browser
DEBUG - 2024-10-28 11:38:11 --> Total execution time: 0.0274
INFO - 2024-10-28 11:38:14 --> Config Class Initialized
INFO - 2024-10-28 11:38:14 --> Hooks Class Initialized
DEBUG - 2024-10-28 11:38:14 --> UTF-8 Support Enabled
INFO - 2024-10-28 11:38:14 --> Utf8 Class Initialized
INFO - 2024-10-28 11:38:14 --> URI Class Initialized
DEBUG - 2024-10-28 11:38:14 --> No URI present. Default controller set.
INFO - 2024-10-28 11:38:14 --> Router Class Initialized
INFO - 2024-10-28 11:38:14 --> Output Class Initialized
INFO - 2024-10-28 11:38:14 --> Security Class Initialized
DEBUG - 2024-10-28 11:38:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 11:38:14 --> Input Class Initialized
INFO - 2024-10-28 11:38:14 --> Language Class Initialized
ERROR - 2024-10-28 11:38:14 --> TEST ERROR MESSAGE - 2024-10-28 11:38:14
INFO - 2024-10-28 11:38:14 --> Loader Class Initialized
INFO - 2024-10-28 11:38:14 --> Controller Class Initialized
INFO - 2024-10-28 11:38:14 --> Database Driver Class Initialized
INFO - 2024-10-28 11:38:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 11:38:14 --> Helper loaded: form_helper
INFO - 2024-10-28 11:38:14 --> Helper loaded: url_helper
INFO - 2024-10-28 11:38:14 --> Model Class Initialized
INFO - 2024-10-28 11:38:14 --> Helper loaded: inflector_helper
INFO - 2024-10-28 11:38:14 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 11:38:14 --> Helper loaded: email_helper
INFO - 2024-10-28 11:38:14 --> Model Class Initialized
INFO - 2024-10-28 11:38:14 --> Model Class Initialized
INFO - 2024-10-28 11:38:14 --> Model Class Initialized
INFO - 2024-10-28 11:38:14 --> Model Class Initialized
INFO - 2024-10-28 11:38:14 --> Model Class Initialized
INFO - 2024-10-28 11:38:14 --> Model Class Initialized
INFO - 2024-10-28 11:38:14 --> Model Class Initialized
DEBUG - 2024-10-28 11:38:14 --> plural called with: company
DEBUG - 2024-10-28 11:38:14 --> is_countable called with!!!!: company
INFO - 2024-10-28 11:38:14 --> Model Class Initialized
INFO - 2024-10-28 11:38:14 --> Model Class Initialized
INFO - 2024-10-28 11:38:14 --> Model Class Initialized
INFO - 2024-10-28 11:38:14 --> Final output sent to browser
DEBUG - 2024-10-28 11:38:14 --> Total execution time: 0.0223
INFO - 2024-10-28 11:38:15 --> Config Class Initialized
INFO - 2024-10-28 11:38:15 --> Hooks Class Initialized
DEBUG - 2024-10-28 11:38:15 --> UTF-8 Support Enabled
INFO - 2024-10-28 11:38:15 --> Utf8 Class Initialized
INFO - 2024-10-28 11:38:15 --> URI Class Initialized
DEBUG - 2024-10-28 11:38:15 --> No URI present. Default controller set.
INFO - 2024-10-28 11:38:15 --> Router Class Initialized
INFO - 2024-10-28 11:38:15 --> Output Class Initialized
INFO - 2024-10-28 11:38:15 --> Security Class Initialized
DEBUG - 2024-10-28 11:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 11:38:15 --> Input Class Initialized
INFO - 2024-10-28 11:38:15 --> Language Class Initialized
ERROR - 2024-10-28 11:38:15 --> TEST ERROR MESSAGE - 2024-10-28 11:38:15
INFO - 2024-10-28 11:38:15 --> Loader Class Initialized
INFO - 2024-10-28 11:38:15 --> Controller Class Initialized
INFO - 2024-10-28 11:38:15 --> Database Driver Class Initialized
INFO - 2024-10-28 11:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 11:38:15 --> Helper loaded: form_helper
INFO - 2024-10-28 11:38:15 --> Helper loaded: url_helper
INFO - 2024-10-28 11:38:15 --> Model Class Initialized
INFO - 2024-10-28 11:38:15 --> Helper loaded: inflector_helper
INFO - 2024-10-28 11:38:15 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 11:38:15 --> Helper loaded: email_helper
INFO - 2024-10-28 11:38:15 --> Model Class Initialized
INFO - 2024-10-28 11:38:15 --> Model Class Initialized
INFO - 2024-10-28 11:38:15 --> Model Class Initialized
INFO - 2024-10-28 11:38:15 --> Model Class Initialized
INFO - 2024-10-28 11:38:15 --> Model Class Initialized
INFO - 2024-10-28 11:38:15 --> Model Class Initialized
INFO - 2024-10-28 11:38:15 --> Model Class Initialized
DEBUG - 2024-10-28 11:38:15 --> plural called with: company
DEBUG - 2024-10-28 11:38:15 --> is_countable called with!!!!: company
INFO - 2024-10-28 11:38:15 --> Model Class Initialized
INFO - 2024-10-28 11:38:15 --> Model Class Initialized
INFO - 2024-10-28 11:38:15 --> Model Class Initialized
INFO - 2024-10-28 11:38:15 --> Final output sent to browser
DEBUG - 2024-10-28 11:38:15 --> Total execution time: 0.0199
INFO - 2024-10-28 11:38:15 --> Config Class Initialized
INFO - 2024-10-28 11:38:15 --> Hooks Class Initialized
DEBUG - 2024-10-28 11:38:15 --> UTF-8 Support Enabled
INFO - 2024-10-28 11:38:15 --> Utf8 Class Initialized
INFO - 2024-10-28 11:38:15 --> URI Class Initialized
DEBUG - 2024-10-28 11:38:15 --> No URI present. Default controller set.
INFO - 2024-10-28 11:38:15 --> Router Class Initialized
INFO - 2024-10-28 11:38:15 --> Output Class Initialized
INFO - 2024-10-28 11:38:15 --> Security Class Initialized
DEBUG - 2024-10-28 11:38:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 11:38:15 --> Input Class Initialized
INFO - 2024-10-28 11:38:15 --> Language Class Initialized
ERROR - 2024-10-28 11:38:15 --> TEST ERROR MESSAGE - 2024-10-28 11:38:15
INFO - 2024-10-28 11:38:15 --> Loader Class Initialized
INFO - 2024-10-28 11:38:15 --> Controller Class Initialized
INFO - 2024-10-28 11:38:15 --> Database Driver Class Initialized
INFO - 2024-10-28 11:38:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 11:38:15 --> Helper loaded: form_helper
INFO - 2024-10-28 11:38:15 --> Helper loaded: url_helper
INFO - 2024-10-28 11:38:15 --> Model Class Initialized
INFO - 2024-10-28 11:38:15 --> Helper loaded: inflector_helper
INFO - 2024-10-28 11:38:15 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 11:38:15 --> Helper loaded: email_helper
INFO - 2024-10-28 11:38:15 --> Model Class Initialized
INFO - 2024-10-28 11:38:15 --> Model Class Initialized
INFO - 2024-10-28 11:38:15 --> Model Class Initialized
INFO - 2024-10-28 11:38:15 --> Model Class Initialized
INFO - 2024-10-28 11:38:15 --> Model Class Initialized
INFO - 2024-10-28 11:38:15 --> Model Class Initialized
INFO - 2024-10-28 11:38:15 --> Model Class Initialized
DEBUG - 2024-10-28 11:38:15 --> plural called with: company
DEBUG - 2024-10-28 11:38:15 --> is_countable called with!!!!: company
INFO - 2024-10-28 11:38:15 --> Model Class Initialized
INFO - 2024-10-28 11:38:15 --> Model Class Initialized
INFO - 2024-10-28 11:38:15 --> Model Class Initialized
INFO - 2024-10-28 11:38:15 --> Final output sent to browser
DEBUG - 2024-10-28 11:38:15 --> Total execution time: 0.0261
INFO - 2024-10-28 11:38:24 --> Config Class Initialized
INFO - 2024-10-28 11:38:24 --> Hooks Class Initialized
DEBUG - 2024-10-28 11:38:24 --> UTF-8 Support Enabled
INFO - 2024-10-28 11:38:24 --> Utf8 Class Initialized
INFO - 2024-10-28 11:38:24 --> URI Class Initialized
DEBUG - 2024-10-28 11:38:24 --> No URI present. Default controller set.
INFO - 2024-10-28 11:38:24 --> Router Class Initialized
INFO - 2024-10-28 11:38:24 --> Output Class Initialized
INFO - 2024-10-28 11:38:24 --> Security Class Initialized
DEBUG - 2024-10-28 11:38:24 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 11:38:24 --> Input Class Initialized
INFO - 2024-10-28 11:38:24 --> Language Class Initialized
ERROR - 2024-10-28 11:38:24 --> TEST ERROR MESSAGE - 2024-10-28 11:38:24
INFO - 2024-10-28 11:38:24 --> Loader Class Initialized
INFO - 2024-10-28 11:38:24 --> Controller Class Initialized
INFO - 2024-10-28 11:38:24 --> Database Driver Class Initialized
INFO - 2024-10-28 11:38:24 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 11:38:24 --> Helper loaded: form_helper
INFO - 2024-10-28 11:38:24 --> Helper loaded: url_helper
INFO - 2024-10-28 11:38:24 --> Model Class Initialized
INFO - 2024-10-28 11:38:24 --> Helper loaded: inflector_helper
INFO - 2024-10-28 11:38:24 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 11:38:24 --> Helper loaded: email_helper
INFO - 2024-10-28 11:38:24 --> Model Class Initialized
INFO - 2024-10-28 11:38:24 --> Model Class Initialized
INFO - 2024-10-28 11:38:24 --> Model Class Initialized
INFO - 2024-10-28 11:38:24 --> Model Class Initialized
INFO - 2024-10-28 11:38:24 --> Model Class Initialized
INFO - 2024-10-28 11:38:24 --> Model Class Initialized
INFO - 2024-10-28 11:38:24 --> Model Class Initialized
DEBUG - 2024-10-28 11:38:24 --> plural called with: company
DEBUG - 2024-10-28 11:38:24 --> is_countable called with!!!!: company
INFO - 2024-10-28 11:38:24 --> Model Class Initialized
INFO - 2024-10-28 11:38:24 --> Model Class Initialized
INFO - 2024-10-28 11:38:24 --> Model Class Initialized
INFO - 2024-10-28 11:38:24 --> Final output sent to browser
DEBUG - 2024-10-28 11:38:24 --> Total execution time: 0.0201
INFO - 2024-10-28 11:38:32 --> Config Class Initialized
INFO - 2024-10-28 11:38:32 --> Hooks Class Initialized
DEBUG - 2024-10-28 11:38:32 --> UTF-8 Support Enabled
INFO - 2024-10-28 11:38:32 --> Utf8 Class Initialized
INFO - 2024-10-28 11:38:32 --> URI Class Initialized
DEBUG - 2024-10-28 11:38:32 --> No URI present. Default controller set.
INFO - 2024-10-28 11:38:32 --> Router Class Initialized
INFO - 2024-10-28 11:38:32 --> Output Class Initialized
INFO - 2024-10-28 11:38:32 --> Security Class Initialized
DEBUG - 2024-10-28 11:38:32 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 11:38:32 --> Input Class Initialized
INFO - 2024-10-28 11:38:32 --> Language Class Initialized
ERROR - 2024-10-28 11:38:32 --> TEST ERROR MESSAGE - 2024-10-28 11:38:32
INFO - 2024-10-28 11:38:32 --> Loader Class Initialized
INFO - 2024-10-28 11:38:32 --> Controller Class Initialized
INFO - 2024-10-28 11:38:32 --> Database Driver Class Initialized
INFO - 2024-10-28 11:38:32 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 11:38:32 --> Helper loaded: form_helper
INFO - 2024-10-28 11:38:32 --> Helper loaded: url_helper
INFO - 2024-10-28 11:38:32 --> Model Class Initialized
INFO - 2024-10-28 11:38:32 --> Helper loaded: inflector_helper
INFO - 2024-10-28 11:38:32 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 11:38:32 --> Helper loaded: email_helper
INFO - 2024-10-28 11:38:32 --> Model Class Initialized
INFO - 2024-10-28 11:38:32 --> Model Class Initialized
INFO - 2024-10-28 11:38:32 --> Model Class Initialized
INFO - 2024-10-28 11:38:32 --> Model Class Initialized
INFO - 2024-10-28 11:38:32 --> Model Class Initialized
INFO - 2024-10-28 11:38:32 --> Model Class Initialized
INFO - 2024-10-28 11:38:32 --> Model Class Initialized
DEBUG - 2024-10-28 11:38:32 --> plural called with: company
DEBUG - 2024-10-28 11:38:32 --> is_countable called with!!!!: company
INFO - 2024-10-28 11:38:32 --> Model Class Initialized
INFO - 2024-10-28 11:38:32 --> Model Class Initialized
INFO - 2024-10-28 11:38:32 --> Model Class Initialized
INFO - 2024-10-28 11:38:32 --> Final output sent to browser
DEBUG - 2024-10-28 11:38:32 --> Total execution time: 0.0367
INFO - 2024-10-28 11:38:57 --> Config Class Initialized
INFO - 2024-10-28 11:38:57 --> Hooks Class Initialized
DEBUG - 2024-10-28 11:38:57 --> UTF-8 Support Enabled
INFO - 2024-10-28 11:38:57 --> Utf8 Class Initialized
INFO - 2024-10-28 11:38:57 --> URI Class Initialized
DEBUG - 2024-10-28 11:38:57 --> No URI present. Default controller set.
INFO - 2024-10-28 11:38:57 --> Router Class Initialized
INFO - 2024-10-28 11:38:57 --> Output Class Initialized
INFO - 2024-10-28 11:38:57 --> Security Class Initialized
DEBUG - 2024-10-28 11:38:57 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 11:38:57 --> Input Class Initialized
INFO - 2024-10-28 11:38:57 --> Language Class Initialized
ERROR - 2024-10-28 11:38:57 --> TEST ERROR MESSAGE - 2024-10-28 11:38:57
INFO - 2024-10-28 11:38:57 --> Loader Class Initialized
INFO - 2024-10-28 11:38:57 --> Controller Class Initialized
INFO - 2024-10-28 11:38:57 --> Database Driver Class Initialized
INFO - 2024-10-28 11:38:57 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 11:38:57 --> Helper loaded: form_helper
INFO - 2024-10-28 11:38:57 --> Helper loaded: url_helper
INFO - 2024-10-28 11:38:57 --> Model Class Initialized
INFO - 2024-10-28 11:38:57 --> Helper loaded: inflector_helper
INFO - 2024-10-28 11:38:57 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 11:38:57 --> Helper loaded: email_helper
INFO - 2024-10-28 11:38:57 --> Model Class Initialized
INFO - 2024-10-28 11:38:57 --> Model Class Initialized
INFO - 2024-10-28 11:38:57 --> Model Class Initialized
INFO - 2024-10-28 11:38:57 --> Model Class Initialized
INFO - 2024-10-28 11:38:57 --> Model Class Initialized
INFO - 2024-10-28 11:38:57 --> Model Class Initialized
INFO - 2024-10-28 11:38:57 --> Model Class Initialized
DEBUG - 2024-10-28 11:38:57 --> plural called with: company
DEBUG - 2024-10-28 11:38:57 --> is_countable called with!!!!: company
INFO - 2024-10-28 11:38:57 --> Model Class Initialized
INFO - 2024-10-28 11:38:57 --> Model Class Initialized
INFO - 2024-10-28 11:38:57 --> Model Class Initialized
INFO - 2024-10-28 11:38:57 --> Final output sent to browser
DEBUG - 2024-10-28 11:38:57 --> Total execution time: 0.0223
INFO - 2024-10-28 12:04:53 --> Config Class Initialized
INFO - 2024-10-28 12:04:53 --> Hooks Class Initialized
DEBUG - 2024-10-28 12:04:53 --> UTF-8 Support Enabled
INFO - 2024-10-28 12:04:53 --> Utf8 Class Initialized
INFO - 2024-10-28 12:04:53 --> URI Class Initialized
INFO - 2024-10-28 12:04:53 --> Router Class Initialized
INFO - 2024-10-28 12:04:53 --> Output Class Initialized
INFO - 2024-10-28 12:04:53 --> Security Class Initialized
DEBUG - 2024-10-28 12:04:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 12:04:53 --> Input Class Initialized
INFO - 2024-10-28 12:04:53 --> Language Class Initialized
ERROR - 2024-10-28 12:04:53 --> TEST ERROR MESSAGE - 2024-10-28 12:04:53
INFO - 2024-10-28 12:04:53 --> Loader Class Initialized
INFO - 2024-10-28 12:04:53 --> Controller Class Initialized
INFO - 2024-10-28 12:04:53 --> Database Driver Class Initialized
INFO - 2024-10-28 12:04:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 12:04:53 --> Helper loaded: form_helper
INFO - 2024-10-28 12:04:53 --> Helper loaded: url_helper
INFO - 2024-10-28 12:04:53 --> Model Class Initialized
INFO - 2024-10-28 12:04:53 --> Helper loaded: inflector_helper
INFO - 2024-10-28 12:04:53 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 12:04:53 --> Helper loaded: email_helper
INFO - 2024-10-28 12:04:53 --> Model Class Initialized
INFO - 2024-10-28 12:04:53 --> Model Class Initialized
INFO - 2024-10-28 12:04:53 --> Model Class Initialized
INFO - 2024-10-28 12:04:53 --> Model Class Initialized
INFO - 2024-10-28 12:04:53 --> Model Class Initialized
INFO - 2024-10-28 12:04:53 --> Model Class Initialized
INFO - 2024-10-28 12:04:53 --> Model Class Initialized
DEBUG - 2024-10-28 12:04:53 --> plural called with: company
DEBUG - 2024-10-28 12:04:53 --> is_countable called with!!!!: company
INFO - 2024-10-28 12:04:53 --> Model Class Initialized
INFO - 2024-10-28 12:04:53 --> Model Class Initialized
INFO - 2024-10-28 12:04:53 --> Model Class Initialized
ERROR - 2024-10-28 12:04:53 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 298
INFO - 2024-10-28 12:04:53 --> Final output sent to browser
DEBUG - 2024-10-28 12:04:53 --> Total execution time: 0.1686
INFO - 2024-10-28 13:16:17 --> Config Class Initialized
INFO - 2024-10-28 13:16:17 --> Hooks Class Initialized
DEBUG - 2024-10-28 13:16:17 --> UTF-8 Support Enabled
INFO - 2024-10-28 13:16:17 --> Utf8 Class Initialized
INFO - 2024-10-28 13:16:17 --> URI Class Initialized
INFO - 2024-10-28 13:16:17 --> Router Class Initialized
INFO - 2024-10-28 13:16:17 --> Output Class Initialized
INFO - 2024-10-28 13:16:17 --> Security Class Initialized
DEBUG - 2024-10-28 13:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 13:16:17 --> Input Class Initialized
INFO - 2024-10-28 13:16:17 --> Language Class Initialized
ERROR - 2024-10-28 13:16:17 --> TEST ERROR MESSAGE - 2024-10-28 13:16:17
INFO - 2024-10-28 13:16:17 --> Loader Class Initialized
INFO - 2024-10-28 13:16:17 --> Controller Class Initialized
INFO - 2024-10-28 13:16:17 --> Database Driver Class Initialized
INFO - 2024-10-28 13:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 13:16:17 --> Helper loaded: form_helper
INFO - 2024-10-28 13:16:17 --> Helper loaded: url_helper
INFO - 2024-10-28 13:16:17 --> Model Class Initialized
INFO - 2024-10-28 13:16:17 --> Helper loaded: inflector_helper
INFO - 2024-10-28 13:16:17 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 13:16:17 --> Helper loaded: email_helper
INFO - 2024-10-28 13:16:17 --> Model Class Initialized
INFO - 2024-10-28 13:16:17 --> Model Class Initialized
INFO - 2024-10-28 13:16:17 --> Model Class Initialized
INFO - 2024-10-28 13:16:17 --> Model Class Initialized
INFO - 2024-10-28 13:16:17 --> Model Class Initialized
INFO - 2024-10-28 13:16:17 --> Model Class Initialized
INFO - 2024-10-28 13:16:17 --> Model Class Initialized
DEBUG - 2024-10-28 13:16:17 --> plural called with: company
DEBUG - 2024-10-28 13:16:17 --> is_countable called with!!!!: company
INFO - 2024-10-28 13:16:17 --> Model Class Initialized
INFO - 2024-10-28 13:16:17 --> Model Class Initialized
INFO - 2024-10-28 13:16:17 --> Model Class Initialized
INFO - 2024-10-28 13:16:17 --> Config Class Initialized
INFO - 2024-10-28 13:16:17 --> Hooks Class Initialized
DEBUG - 2024-10-28 13:16:17 --> UTF-8 Support Enabled
INFO - 2024-10-28 13:16:17 --> Utf8 Class Initialized
INFO - 2024-10-28 13:16:17 --> URI Class Initialized
INFO - 2024-10-28 13:16:17 --> Router Class Initialized
INFO - 2024-10-28 13:16:17 --> Output Class Initialized
INFO - 2024-10-28 13:16:17 --> Security Class Initialized
DEBUG - 2024-10-28 13:16:17 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 13:16:17 --> Input Class Initialized
INFO - 2024-10-28 13:16:17 --> Language Class Initialized
ERROR - 2024-10-28 13:16:17 --> TEST ERROR MESSAGE - 2024-10-28 13:16:17
INFO - 2024-10-28 13:16:17 --> Loader Class Initialized
INFO - 2024-10-28 13:16:17 --> Controller Class Initialized
INFO - 2024-10-28 13:16:17 --> Database Driver Class Initialized
INFO - 2024-10-28 13:16:17 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 13:16:17 --> Helper loaded: form_helper
INFO - 2024-10-28 13:16:17 --> Helper loaded: url_helper
INFO - 2024-10-28 13:16:17 --> Model Class Initialized
INFO - 2024-10-28 13:16:17 --> Helper loaded: inflector_helper
INFO - 2024-10-28 13:16:17 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 13:16:17 --> Helper loaded: email_helper
INFO - 2024-10-28 13:16:17 --> Model Class Initialized
INFO - 2024-10-28 13:16:17 --> Model Class Initialized
INFO - 2024-10-28 13:16:17 --> Model Class Initialized
INFO - 2024-10-28 13:16:17 --> Model Class Initialized
INFO - 2024-10-28 13:16:17 --> Model Class Initialized
INFO - 2024-10-28 13:16:17 --> Model Class Initialized
INFO - 2024-10-28 13:16:17 --> Model Class Initialized
DEBUG - 2024-10-28 13:16:17 --> plural called with: company
DEBUG - 2024-10-28 13:16:17 --> is_countable called with!!!!: company
INFO - 2024-10-28 13:16:17 --> Model Class Initialized
INFO - 2024-10-28 13:16:17 --> Model Class Initialized
INFO - 2024-10-28 13:16:17 --> Model Class Initialized
INFO - 2024-10-28 13:16:17 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-28 13:16:17 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-28 13:16:17 --> Final output sent to browser
DEBUG - 2024-10-28 13:16:17 --> Total execution time: 0.0250
INFO - 2024-10-28 13:16:22 --> Config Class Initialized
INFO - 2024-10-28 13:16:22 --> Hooks Class Initialized
DEBUG - 2024-10-28 13:16:22 --> UTF-8 Support Enabled
INFO - 2024-10-28 13:16:22 --> Utf8 Class Initialized
INFO - 2024-10-28 13:16:22 --> URI Class Initialized
INFO - 2024-10-28 13:16:22 --> Router Class Initialized
INFO - 2024-10-28 13:16:22 --> Output Class Initialized
INFO - 2024-10-28 13:16:22 --> Security Class Initialized
DEBUG - 2024-10-28 13:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 13:16:22 --> Input Class Initialized
INFO - 2024-10-28 13:16:22 --> Language Class Initialized
ERROR - 2024-10-28 13:16:22 --> TEST ERROR MESSAGE - 2024-10-28 13:16:22
INFO - 2024-10-28 13:16:22 --> Loader Class Initialized
INFO - 2024-10-28 13:16:22 --> Controller Class Initialized
INFO - 2024-10-28 13:16:22 --> Database Driver Class Initialized
INFO - 2024-10-28 13:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 13:16:22 --> Helper loaded: form_helper
INFO - 2024-10-28 13:16:22 --> Helper loaded: url_helper
INFO - 2024-10-28 13:16:22 --> Model Class Initialized
INFO - 2024-10-28 13:16:22 --> Helper loaded: inflector_helper
INFO - 2024-10-28 13:16:22 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 13:16:22 --> Helper loaded: email_helper
INFO - 2024-10-28 13:16:22 --> Model Class Initialized
INFO - 2024-10-28 13:16:22 --> Model Class Initialized
INFO - 2024-10-28 13:16:22 --> Model Class Initialized
INFO - 2024-10-28 13:16:22 --> Model Class Initialized
INFO - 2024-10-28 13:16:22 --> Model Class Initialized
INFO - 2024-10-28 13:16:22 --> Model Class Initialized
INFO - 2024-10-28 13:16:22 --> Model Class Initialized
DEBUG - 2024-10-28 13:16:22 --> plural called with: company
DEBUG - 2024-10-28 13:16:22 --> is_countable called with!!!!: company
INFO - 2024-10-28 13:16:22 --> Model Class Initialized
INFO - 2024-10-28 13:16:22 --> Model Class Initialized
INFO - 2024-10-28 13:16:22 --> Model Class Initialized
INFO - 2024-10-28 13:16:22 --> Config Class Initialized
INFO - 2024-10-28 13:16:22 --> Hooks Class Initialized
DEBUG - 2024-10-28 13:16:22 --> UTF-8 Support Enabled
INFO - 2024-10-28 13:16:22 --> Utf8 Class Initialized
INFO - 2024-10-28 13:16:22 --> URI Class Initialized
INFO - 2024-10-28 13:16:22 --> Router Class Initialized
INFO - 2024-10-28 13:16:22 --> Output Class Initialized
INFO - 2024-10-28 13:16:22 --> Security Class Initialized
DEBUG - 2024-10-28 13:16:22 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 13:16:22 --> Input Class Initialized
INFO - 2024-10-28 13:16:22 --> Language Class Initialized
ERROR - 2024-10-28 13:16:22 --> TEST ERROR MESSAGE - 2024-10-28 13:16:22
INFO - 2024-10-28 13:16:22 --> Loader Class Initialized
INFO - 2024-10-28 13:16:22 --> Controller Class Initialized
INFO - 2024-10-28 13:16:22 --> Database Driver Class Initialized
INFO - 2024-10-28 13:16:22 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 13:16:22 --> Helper loaded: form_helper
INFO - 2024-10-28 13:16:22 --> Helper loaded: url_helper
INFO - 2024-10-28 13:16:22 --> Model Class Initialized
INFO - 2024-10-28 13:16:22 --> Helper loaded: inflector_helper
INFO - 2024-10-28 13:16:22 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 13:16:22 --> Helper loaded: email_helper
INFO - 2024-10-28 13:16:22 --> Model Class Initialized
INFO - 2024-10-28 13:16:22 --> Model Class Initialized
INFO - 2024-10-28 13:16:22 --> Model Class Initialized
INFO - 2024-10-28 13:16:22 --> Model Class Initialized
INFO - 2024-10-28 13:16:22 --> Model Class Initialized
INFO - 2024-10-28 13:16:22 --> Model Class Initialized
INFO - 2024-10-28 13:16:22 --> Model Class Initialized
DEBUG - 2024-10-28 13:16:22 --> plural called with: company
DEBUG - 2024-10-28 13:16:22 --> is_countable called with!!!!: company
INFO - 2024-10-28 13:16:22 --> Model Class Initialized
INFO - 2024-10-28 13:16:22 --> Model Class Initialized
INFO - 2024-10-28 13:16:22 --> Model Class Initialized
ERROR - 2024-10-28 13:16:23 --> Severity: Notice --> Undefined index: freetext /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 13:16:23 --> Severity: Notice --> Undefined index: socialDes /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 13:16:23 --> Severity: Notice --> Undefined index: company /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 13:16:23 --> Severity: Notice --> Undefined index: division /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 13:16:23 --> Severity: Notice --> Undefined index: dataGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 13:16:23 --> Severity: Notice --> Undefined index: finalGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
INFO - 2024-10-28 13:16:23 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-28 13:16:23 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-28 13:16:23 --> Final output sent to browser
DEBUG - 2024-10-28 13:16:23 --> Total execution time: 0.7127
INFO - 2024-10-28 13:16:36 --> Config Class Initialized
INFO - 2024-10-28 13:16:36 --> Hooks Class Initialized
DEBUG - 2024-10-28 13:16:36 --> UTF-8 Support Enabled
INFO - 2024-10-28 13:16:36 --> Utf8 Class Initialized
INFO - 2024-10-28 13:16:36 --> URI Class Initialized
INFO - 2024-10-28 13:16:36 --> Router Class Initialized
INFO - 2024-10-28 13:16:36 --> Output Class Initialized
INFO - 2024-10-28 13:16:36 --> Security Class Initialized
DEBUG - 2024-10-28 13:16:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 13:16:36 --> Input Class Initialized
INFO - 2024-10-28 13:16:36 --> Language Class Initialized
ERROR - 2024-10-28 13:16:36 --> TEST ERROR MESSAGE - 2024-10-28 13:16:36
INFO - 2024-10-28 13:16:36 --> Loader Class Initialized
INFO - 2024-10-28 13:16:36 --> Controller Class Initialized
INFO - 2024-10-28 13:16:36 --> Database Driver Class Initialized
INFO - 2024-10-28 13:16:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 13:16:36 --> Helper loaded: form_helper
INFO - 2024-10-28 13:16:36 --> Helper loaded: url_helper
INFO - 2024-10-28 13:16:36 --> Model Class Initialized
INFO - 2024-10-28 13:16:36 --> Helper loaded: inflector_helper
INFO - 2024-10-28 13:16:36 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 13:16:36 --> Helper loaded: email_helper
INFO - 2024-10-28 13:16:36 --> Model Class Initialized
INFO - 2024-10-28 13:16:36 --> Model Class Initialized
INFO - 2024-10-28 13:16:36 --> Model Class Initialized
INFO - 2024-10-28 13:16:36 --> Model Class Initialized
INFO - 2024-10-28 13:16:36 --> Model Class Initialized
INFO - 2024-10-28 13:16:36 --> Model Class Initialized
INFO - 2024-10-28 13:16:36 --> Model Class Initialized
DEBUG - 2024-10-28 13:16:36 --> plural called with: company
DEBUG - 2024-10-28 13:16:36 --> is_countable called with!!!!: company
INFO - 2024-10-28 13:16:36 --> Model Class Initialized
INFO - 2024-10-28 13:16:36 --> Model Class Initialized
INFO - 2024-10-28 13:16:36 --> Model Class Initialized
INFO - 2024-10-28 13:16:37 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-28 13:16:37 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-28 13:16:37 --> Final output sent to browser
DEBUG - 2024-10-28 13:16:37 --> Total execution time: 0.5377
INFO - 2024-10-28 13:16:40 --> Config Class Initialized
INFO - 2024-10-28 13:16:40 --> Hooks Class Initialized
DEBUG - 2024-10-28 13:16:40 --> UTF-8 Support Enabled
INFO - 2024-10-28 13:16:40 --> Utf8 Class Initialized
INFO - 2024-10-28 13:16:40 --> URI Class Initialized
INFO - 2024-10-28 13:16:40 --> Router Class Initialized
INFO - 2024-10-28 13:16:40 --> Output Class Initialized
INFO - 2024-10-28 13:16:40 --> Security Class Initialized
DEBUG - 2024-10-28 13:16:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 13:16:40 --> Input Class Initialized
INFO - 2024-10-28 13:16:40 --> Language Class Initialized
ERROR - 2024-10-28 13:16:40 --> TEST ERROR MESSAGE - 2024-10-28 13:16:40
INFO - 2024-10-28 13:16:40 --> Loader Class Initialized
INFO - 2024-10-28 13:16:40 --> Controller Class Initialized
INFO - 2024-10-28 13:16:40 --> Database Driver Class Initialized
INFO - 2024-10-28 13:16:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 13:16:40 --> Helper loaded: form_helper
INFO - 2024-10-28 13:16:40 --> Helper loaded: url_helper
INFO - 2024-10-28 13:16:40 --> Model Class Initialized
INFO - 2024-10-28 13:16:40 --> Helper loaded: inflector_helper
INFO - 2024-10-28 13:16:40 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 13:16:40 --> Helper loaded: email_helper
INFO - 2024-10-28 13:16:40 --> Model Class Initialized
INFO - 2024-10-28 13:16:40 --> Model Class Initialized
INFO - 2024-10-28 13:16:40 --> Model Class Initialized
INFO - 2024-10-28 13:16:40 --> Model Class Initialized
INFO - 2024-10-28 13:16:40 --> Model Class Initialized
INFO - 2024-10-28 13:16:40 --> Model Class Initialized
INFO - 2024-10-28 13:16:40 --> Model Class Initialized
DEBUG - 2024-10-28 13:16:40 --> plural called with: company
DEBUG - 2024-10-28 13:16:40 --> is_countable called with!!!!: company
INFO - 2024-10-28 13:16:40 --> Model Class Initialized
INFO - 2024-10-28 13:16:40 --> Model Class Initialized
INFO - 2024-10-28 13:16:40 --> Model Class Initialized
INFO - 2024-10-28 13:16:44 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-28 13:16:44 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-28 13:16:44 --> Final output sent to browser
DEBUG - 2024-10-28 13:16:44 --> Total execution time: 3.2744
INFO - 2024-10-28 13:17:23 --> Config Class Initialized
INFO - 2024-10-28 13:17:23 --> Hooks Class Initialized
DEBUG - 2024-10-28 13:17:23 --> UTF-8 Support Enabled
INFO - 2024-10-28 13:17:23 --> Utf8 Class Initialized
INFO - 2024-10-28 13:17:23 --> URI Class Initialized
INFO - 2024-10-28 13:17:23 --> Router Class Initialized
INFO - 2024-10-28 13:17:23 --> Output Class Initialized
INFO - 2024-10-28 13:17:23 --> Security Class Initialized
DEBUG - 2024-10-28 13:17:23 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 13:17:23 --> Input Class Initialized
INFO - 2024-10-28 13:17:23 --> Language Class Initialized
ERROR - 2024-10-28 13:17:23 --> TEST ERROR MESSAGE - 2024-10-28 13:17:23
INFO - 2024-10-28 13:17:23 --> Loader Class Initialized
INFO - 2024-10-28 13:17:23 --> Controller Class Initialized
INFO - 2024-10-28 13:17:23 --> Database Driver Class Initialized
INFO - 2024-10-28 13:17:23 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 13:17:23 --> Helper loaded: form_helper
INFO - 2024-10-28 13:17:23 --> Helper loaded: url_helper
INFO - 2024-10-28 13:17:23 --> Model Class Initialized
INFO - 2024-10-28 13:17:23 --> Helper loaded: inflector_helper
INFO - 2024-10-28 13:17:23 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 13:17:23 --> Helper loaded: email_helper
INFO - 2024-10-28 13:17:23 --> Model Class Initialized
INFO - 2024-10-28 13:17:23 --> Model Class Initialized
INFO - 2024-10-28 13:17:23 --> Model Class Initialized
INFO - 2024-10-28 13:17:23 --> Model Class Initialized
INFO - 2024-10-28 13:17:23 --> Model Class Initialized
INFO - 2024-10-28 13:17:23 --> Model Class Initialized
INFO - 2024-10-28 13:17:23 --> Model Class Initialized
DEBUG - 2024-10-28 13:17:23 --> plural called with: company
DEBUG - 2024-10-28 13:17:23 --> is_countable called with!!!!: company
INFO - 2024-10-28 13:17:23 --> Model Class Initialized
INFO - 2024-10-28 13:17:23 --> Model Class Initialized
INFO - 2024-10-28 13:17:23 --> Model Class Initialized
INFO - 2024-10-28 13:17:23 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-28 13:17:23 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-28 13:17:23 --> Final output sent to browser
DEBUG - 2024-10-28 13:17:23 --> Total execution time: 0.2895
INFO - 2024-10-28 13:17:25 --> Config Class Initialized
INFO - 2024-10-28 13:17:25 --> Hooks Class Initialized
DEBUG - 2024-10-28 13:17:25 --> UTF-8 Support Enabled
INFO - 2024-10-28 13:17:25 --> Utf8 Class Initialized
INFO - 2024-10-28 13:17:25 --> URI Class Initialized
INFO - 2024-10-28 13:17:25 --> Router Class Initialized
INFO - 2024-10-28 13:17:25 --> Output Class Initialized
INFO - 2024-10-28 13:17:25 --> Security Class Initialized
DEBUG - 2024-10-28 13:17:25 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 13:17:25 --> Input Class Initialized
INFO - 2024-10-28 13:17:25 --> Language Class Initialized
ERROR - 2024-10-28 13:17:25 --> TEST ERROR MESSAGE - 2024-10-28 13:17:25
INFO - 2024-10-28 13:17:25 --> Loader Class Initialized
INFO - 2024-10-28 13:17:25 --> Controller Class Initialized
INFO - 2024-10-28 13:17:25 --> Database Driver Class Initialized
INFO - 2024-10-28 13:17:25 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 13:17:25 --> Helper loaded: form_helper
INFO - 2024-10-28 13:17:25 --> Helper loaded: url_helper
INFO - 2024-10-28 13:17:25 --> Model Class Initialized
INFO - 2024-10-28 13:17:25 --> Helper loaded: inflector_helper
INFO - 2024-10-28 13:17:25 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 13:17:25 --> Helper loaded: email_helper
INFO - 2024-10-28 13:17:25 --> Model Class Initialized
INFO - 2024-10-28 13:17:25 --> Model Class Initialized
INFO - 2024-10-28 13:17:25 --> Model Class Initialized
INFO - 2024-10-28 13:17:25 --> Model Class Initialized
INFO - 2024-10-28 13:17:25 --> Model Class Initialized
INFO - 2024-10-28 13:17:25 --> Model Class Initialized
INFO - 2024-10-28 13:17:25 --> Model Class Initialized
DEBUG - 2024-10-28 13:17:25 --> plural called with: company
DEBUG - 2024-10-28 13:17:25 --> is_countable called with!!!!: company
INFO - 2024-10-28 13:17:25 --> Model Class Initialized
INFO - 2024-10-28 13:17:25 --> Model Class Initialized
INFO - 2024-10-28 13:17:25 --> Model Class Initialized
INFO - 2024-10-28 13:17:25 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-28 13:17:25 --> Final output sent to browser
DEBUG - 2024-10-28 13:17:25 --> Total execution time: 0.0256
INFO - 2024-10-28 13:17:50 --> Config Class Initialized
INFO - 2024-10-28 13:17:50 --> Hooks Class Initialized
DEBUG - 2024-10-28 13:17:50 --> UTF-8 Support Enabled
INFO - 2024-10-28 13:17:50 --> Utf8 Class Initialized
INFO - 2024-10-28 13:17:50 --> URI Class Initialized
INFO - 2024-10-28 13:17:50 --> Router Class Initialized
INFO - 2024-10-28 13:17:50 --> Output Class Initialized
INFO - 2024-10-28 13:17:50 --> Security Class Initialized
DEBUG - 2024-10-28 13:17:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 13:17:50 --> Input Class Initialized
INFO - 2024-10-28 13:17:50 --> Language Class Initialized
ERROR - 2024-10-28 13:17:50 --> TEST ERROR MESSAGE - 2024-10-28 13:17:50
INFO - 2024-10-28 13:17:50 --> Loader Class Initialized
INFO - 2024-10-28 13:17:50 --> Controller Class Initialized
INFO - 2024-10-28 13:17:50 --> Database Driver Class Initialized
INFO - 2024-10-28 13:17:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 13:17:50 --> Helper loaded: form_helper
INFO - 2024-10-28 13:17:50 --> Helper loaded: url_helper
INFO - 2024-10-28 13:17:50 --> Model Class Initialized
INFO - 2024-10-28 13:17:50 --> Helper loaded: inflector_helper
INFO - 2024-10-28 13:17:50 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 13:17:50 --> Helper loaded: email_helper
INFO - 2024-10-28 13:17:50 --> Model Class Initialized
INFO - 2024-10-28 13:17:50 --> Model Class Initialized
INFO - 2024-10-28 13:17:50 --> Model Class Initialized
INFO - 2024-10-28 13:17:50 --> Model Class Initialized
INFO - 2024-10-28 13:17:50 --> Model Class Initialized
INFO - 2024-10-28 13:17:50 --> Model Class Initialized
INFO - 2024-10-28 13:17:50 --> Model Class Initialized
DEBUG - 2024-10-28 13:17:50 --> plural called with: company
DEBUG - 2024-10-28 13:17:50 --> is_countable called with!!!!: company
INFO - 2024-10-28 13:17:50 --> Model Class Initialized
INFO - 2024-10-28 13:17:50 --> Model Class Initialized
INFO - 2024-10-28 13:17:50 --> Model Class Initialized
INFO - 2024-10-28 13:17:50 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-28 13:17:50 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-28 13:17:50 --> Final output sent to browser
DEBUG - 2024-10-28 13:17:50 --> Total execution time: 0.1539
INFO - 2024-10-28 13:17:53 --> Config Class Initialized
INFO - 2024-10-28 13:17:53 --> Hooks Class Initialized
DEBUG - 2024-10-28 13:17:53 --> UTF-8 Support Enabled
INFO - 2024-10-28 13:17:53 --> Utf8 Class Initialized
INFO - 2024-10-28 13:17:53 --> URI Class Initialized
INFO - 2024-10-28 13:17:53 --> Router Class Initialized
INFO - 2024-10-28 13:17:53 --> Output Class Initialized
INFO - 2024-10-28 13:17:53 --> Security Class Initialized
DEBUG - 2024-10-28 13:17:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 13:17:53 --> Input Class Initialized
INFO - 2024-10-28 13:17:53 --> Language Class Initialized
ERROR - 2024-10-28 13:17:53 --> TEST ERROR MESSAGE - 2024-10-28 13:17:53
INFO - 2024-10-28 13:17:53 --> Loader Class Initialized
INFO - 2024-10-28 13:17:53 --> Controller Class Initialized
INFO - 2024-10-28 13:17:53 --> Database Driver Class Initialized
INFO - 2024-10-28 13:17:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 13:17:53 --> Helper loaded: form_helper
INFO - 2024-10-28 13:17:53 --> Helper loaded: url_helper
INFO - 2024-10-28 13:17:53 --> Model Class Initialized
INFO - 2024-10-28 13:17:53 --> Helper loaded: inflector_helper
INFO - 2024-10-28 13:17:53 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 13:17:53 --> Helper loaded: email_helper
INFO - 2024-10-28 13:17:53 --> Model Class Initialized
INFO - 2024-10-28 13:17:53 --> Model Class Initialized
INFO - 2024-10-28 13:17:53 --> Model Class Initialized
INFO - 2024-10-28 13:17:53 --> Model Class Initialized
INFO - 2024-10-28 13:17:53 --> Model Class Initialized
INFO - 2024-10-28 13:17:53 --> Model Class Initialized
INFO - 2024-10-28 13:17:53 --> Model Class Initialized
DEBUG - 2024-10-28 13:17:53 --> plural called with: company
DEBUG - 2024-10-28 13:17:53 --> is_countable called with!!!!: company
INFO - 2024-10-28 13:17:53 --> Model Class Initialized
INFO - 2024-10-28 13:17:53 --> Model Class Initialized
INFO - 2024-10-28 13:17:53 --> Model Class Initialized
INFO - 2024-10-28 13:17:53 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-28 13:17:53 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-28 13:17:53 --> Final output sent to browser
DEBUG - 2024-10-28 13:17:53 --> Total execution time: 0.5901
INFO - 2024-10-28 13:18:15 --> Config Class Initialized
INFO - 2024-10-28 13:18:15 --> Hooks Class Initialized
DEBUG - 2024-10-28 13:18:15 --> UTF-8 Support Enabled
INFO - 2024-10-28 13:18:15 --> Utf8 Class Initialized
INFO - 2024-10-28 13:18:15 --> URI Class Initialized
INFO - 2024-10-28 13:18:15 --> Router Class Initialized
INFO - 2024-10-28 13:18:15 --> Output Class Initialized
INFO - 2024-10-28 13:18:15 --> Security Class Initialized
DEBUG - 2024-10-28 13:18:15 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 13:18:15 --> Input Class Initialized
INFO - 2024-10-28 13:18:15 --> Language Class Initialized
ERROR - 2024-10-28 13:18:15 --> TEST ERROR MESSAGE - 2024-10-28 13:18:15
INFO - 2024-10-28 13:18:15 --> Loader Class Initialized
INFO - 2024-10-28 13:18:15 --> Controller Class Initialized
INFO - 2024-10-28 13:18:15 --> Database Driver Class Initialized
INFO - 2024-10-28 13:18:15 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 13:18:15 --> Helper loaded: form_helper
INFO - 2024-10-28 13:18:15 --> Helper loaded: url_helper
INFO - 2024-10-28 13:18:15 --> Model Class Initialized
INFO - 2024-10-28 13:18:15 --> Helper loaded: inflector_helper
INFO - 2024-10-28 13:18:15 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 13:18:15 --> Helper loaded: email_helper
INFO - 2024-10-28 13:18:15 --> Model Class Initialized
INFO - 2024-10-28 13:18:15 --> Model Class Initialized
INFO - 2024-10-28 13:18:15 --> Model Class Initialized
INFO - 2024-10-28 13:18:15 --> Model Class Initialized
INFO - 2024-10-28 13:18:15 --> Model Class Initialized
INFO - 2024-10-28 13:18:15 --> Model Class Initialized
INFO - 2024-10-28 13:18:15 --> Model Class Initialized
DEBUG - 2024-10-28 13:18:15 --> plural called with: company
DEBUG - 2024-10-28 13:18:15 --> is_countable called with!!!!: company
INFO - 2024-10-28 13:18:15 --> Model Class Initialized
INFO - 2024-10-28 13:18:15 --> Model Class Initialized
INFO - 2024-10-28 13:18:15 --> Model Class Initialized
INFO - 2024-10-28 13:18:15 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-28 13:18:15 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-28 13:18:15 --> Final output sent to browser
DEBUG - 2024-10-28 13:18:15 --> Total execution time: 0.1922
INFO - 2024-10-28 13:18:16 --> Config Class Initialized
INFO - 2024-10-28 13:18:16 --> Hooks Class Initialized
DEBUG - 2024-10-28 13:18:16 --> UTF-8 Support Enabled
INFO - 2024-10-28 13:18:16 --> Utf8 Class Initialized
INFO - 2024-10-28 13:18:16 --> URI Class Initialized
INFO - 2024-10-28 13:18:16 --> Router Class Initialized
INFO - 2024-10-28 13:18:16 --> Output Class Initialized
INFO - 2024-10-28 13:18:16 --> Security Class Initialized
DEBUG - 2024-10-28 13:18:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 13:18:16 --> Input Class Initialized
INFO - 2024-10-28 13:18:16 --> Language Class Initialized
ERROR - 2024-10-28 13:18:16 --> TEST ERROR MESSAGE - 2024-10-28 13:18:16
INFO - 2024-10-28 13:18:16 --> Loader Class Initialized
INFO - 2024-10-28 13:18:16 --> Controller Class Initialized
INFO - 2024-10-28 13:18:16 --> Database Driver Class Initialized
INFO - 2024-10-28 13:18:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 13:18:16 --> Helper loaded: form_helper
INFO - 2024-10-28 13:18:16 --> Helper loaded: url_helper
INFO - 2024-10-28 13:18:16 --> Model Class Initialized
INFO - 2024-10-28 13:18:16 --> Helper loaded: inflector_helper
INFO - 2024-10-28 13:18:16 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 13:18:16 --> Helper loaded: email_helper
INFO - 2024-10-28 13:18:16 --> Model Class Initialized
INFO - 2024-10-28 13:18:16 --> Model Class Initialized
INFO - 2024-10-28 13:18:16 --> Model Class Initialized
INFO - 2024-10-28 13:18:16 --> Model Class Initialized
INFO - 2024-10-28 13:18:16 --> Model Class Initialized
INFO - 2024-10-28 13:18:16 --> Model Class Initialized
INFO - 2024-10-28 13:18:16 --> Model Class Initialized
DEBUG - 2024-10-28 13:18:16 --> plural called with: company
DEBUG - 2024-10-28 13:18:16 --> is_countable called with!!!!: company
INFO - 2024-10-28 13:18:16 --> Model Class Initialized
INFO - 2024-10-28 13:18:16 --> Model Class Initialized
INFO - 2024-10-28 13:18:16 --> Model Class Initialized
INFO - 2024-10-28 13:18:16 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-28 13:18:16 --> Final output sent to browser
DEBUG - 2024-10-28 13:18:16 --> Total execution time: 0.0389
INFO - 2024-10-28 13:18:39 --> Config Class Initialized
INFO - 2024-10-28 13:18:39 --> Hooks Class Initialized
DEBUG - 2024-10-28 13:18:39 --> UTF-8 Support Enabled
INFO - 2024-10-28 13:18:39 --> Utf8 Class Initialized
INFO - 2024-10-28 13:18:39 --> URI Class Initialized
INFO - 2024-10-28 13:18:39 --> Router Class Initialized
INFO - 2024-10-28 13:18:39 --> Output Class Initialized
INFO - 2024-10-28 13:18:39 --> Security Class Initialized
DEBUG - 2024-10-28 13:18:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 13:18:39 --> Input Class Initialized
INFO - 2024-10-28 13:18:39 --> Language Class Initialized
ERROR - 2024-10-28 13:18:39 --> TEST ERROR MESSAGE - 2024-10-28 13:18:39
INFO - 2024-10-28 13:18:39 --> Loader Class Initialized
INFO - 2024-10-28 13:18:39 --> Controller Class Initialized
INFO - 2024-10-28 13:18:39 --> Database Driver Class Initialized
INFO - 2024-10-28 13:18:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 13:18:39 --> Helper loaded: form_helper
INFO - 2024-10-28 13:18:39 --> Helper loaded: url_helper
INFO - 2024-10-28 13:18:39 --> Model Class Initialized
INFO - 2024-10-28 13:18:39 --> Helper loaded: inflector_helper
INFO - 2024-10-28 13:18:39 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 13:18:39 --> Helper loaded: email_helper
INFO - 2024-10-28 13:18:39 --> Model Class Initialized
INFO - 2024-10-28 13:18:39 --> Model Class Initialized
INFO - 2024-10-28 13:18:39 --> Model Class Initialized
INFO - 2024-10-28 13:18:39 --> Model Class Initialized
INFO - 2024-10-28 13:18:39 --> Model Class Initialized
INFO - 2024-10-28 13:18:39 --> Model Class Initialized
INFO - 2024-10-28 13:18:39 --> Model Class Initialized
DEBUG - 2024-10-28 13:18:39 --> plural called with: company
DEBUG - 2024-10-28 13:18:39 --> is_countable called with!!!!: company
INFO - 2024-10-28 13:18:39 --> Model Class Initialized
INFO - 2024-10-28 13:18:39 --> Model Class Initialized
INFO - 2024-10-28 13:18:39 --> Model Class Initialized
INFO - 2024-10-28 13:18:39 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-28 13:18:39 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-28 13:18:39 --> Final output sent to browser
DEBUG - 2024-10-28 13:18:39 --> Total execution time: 0.1267
INFO - 2024-10-28 13:18:40 --> Config Class Initialized
INFO - 2024-10-28 13:18:40 --> Hooks Class Initialized
DEBUG - 2024-10-28 13:18:40 --> UTF-8 Support Enabled
INFO - 2024-10-28 13:18:40 --> Utf8 Class Initialized
INFO - 2024-10-28 13:18:40 --> URI Class Initialized
INFO - 2024-10-28 13:18:40 --> Router Class Initialized
INFO - 2024-10-28 13:18:40 --> Output Class Initialized
INFO - 2024-10-28 13:18:40 --> Security Class Initialized
DEBUG - 2024-10-28 13:18:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 13:18:40 --> Input Class Initialized
INFO - 2024-10-28 13:18:40 --> Language Class Initialized
ERROR - 2024-10-28 13:18:40 --> TEST ERROR MESSAGE - 2024-10-28 13:18:40
INFO - 2024-10-28 13:18:40 --> Loader Class Initialized
INFO - 2024-10-28 13:18:40 --> Controller Class Initialized
INFO - 2024-10-28 13:18:40 --> Database Driver Class Initialized
INFO - 2024-10-28 13:18:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 13:18:40 --> Helper loaded: form_helper
INFO - 2024-10-28 13:18:40 --> Helper loaded: url_helper
INFO - 2024-10-28 13:18:40 --> Model Class Initialized
INFO - 2024-10-28 13:18:40 --> Helper loaded: inflector_helper
INFO - 2024-10-28 13:18:40 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 13:18:40 --> Helper loaded: email_helper
INFO - 2024-10-28 13:18:40 --> Model Class Initialized
INFO - 2024-10-28 13:18:40 --> Model Class Initialized
INFO - 2024-10-28 13:18:40 --> Model Class Initialized
INFO - 2024-10-28 13:18:40 --> Model Class Initialized
INFO - 2024-10-28 13:18:40 --> Model Class Initialized
INFO - 2024-10-28 13:18:40 --> Model Class Initialized
INFO - 2024-10-28 13:18:40 --> Model Class Initialized
DEBUG - 2024-10-28 13:18:40 --> plural called with: company
DEBUG - 2024-10-28 13:18:40 --> is_countable called with!!!!: company
INFO - 2024-10-28 13:18:40 --> Model Class Initialized
INFO - 2024-10-28 13:18:40 --> Model Class Initialized
INFO - 2024-10-28 13:18:40 --> Model Class Initialized
INFO - 2024-10-28 13:18:40 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-28 13:18:40 --> Final output sent to browser
DEBUG - 2024-10-28 13:18:40 --> Total execution time: 0.0232
INFO - 2024-10-28 13:19:11 --> Config Class Initialized
INFO - 2024-10-28 13:19:11 --> Hooks Class Initialized
DEBUG - 2024-10-28 13:19:11 --> UTF-8 Support Enabled
INFO - 2024-10-28 13:19:11 --> Utf8 Class Initialized
INFO - 2024-10-28 13:19:11 --> URI Class Initialized
INFO - 2024-10-28 13:19:11 --> Router Class Initialized
INFO - 2024-10-28 13:19:11 --> Output Class Initialized
INFO - 2024-10-28 13:19:11 --> Security Class Initialized
DEBUG - 2024-10-28 13:19:11 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 13:19:11 --> Input Class Initialized
INFO - 2024-10-28 13:19:11 --> Language Class Initialized
ERROR - 2024-10-28 13:19:11 --> TEST ERROR MESSAGE - 2024-10-28 13:19:11
INFO - 2024-10-28 13:19:11 --> Loader Class Initialized
INFO - 2024-10-28 13:19:11 --> Controller Class Initialized
INFO - 2024-10-28 13:19:11 --> Database Driver Class Initialized
INFO - 2024-10-28 13:19:11 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 13:19:11 --> Helper loaded: form_helper
INFO - 2024-10-28 13:19:11 --> Helper loaded: url_helper
INFO - 2024-10-28 13:19:11 --> Model Class Initialized
INFO - 2024-10-28 13:19:11 --> Helper loaded: inflector_helper
INFO - 2024-10-28 13:19:11 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 13:19:11 --> Helper loaded: email_helper
INFO - 2024-10-28 13:19:11 --> Model Class Initialized
INFO - 2024-10-28 13:19:11 --> Model Class Initialized
INFO - 2024-10-28 13:19:11 --> Model Class Initialized
INFO - 2024-10-28 13:19:11 --> Model Class Initialized
INFO - 2024-10-28 13:19:11 --> Model Class Initialized
INFO - 2024-10-28 13:19:11 --> Model Class Initialized
INFO - 2024-10-28 13:19:11 --> Model Class Initialized
DEBUG - 2024-10-28 13:19:11 --> plural called with: company
DEBUG - 2024-10-28 13:19:11 --> is_countable called with!!!!: company
INFO - 2024-10-28 13:19:11 --> Model Class Initialized
INFO - 2024-10-28 13:19:11 --> Model Class Initialized
INFO - 2024-10-28 13:19:11 --> Model Class Initialized
INFO - 2024-10-28 13:19:11 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-28 13:19:11 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-28 13:19:11 --> Final output sent to browser
DEBUG - 2024-10-28 13:19:11 --> Total execution time: 0.2703
INFO - 2024-10-28 13:19:12 --> Config Class Initialized
INFO - 2024-10-28 13:19:12 --> Hooks Class Initialized
DEBUG - 2024-10-28 13:19:12 --> UTF-8 Support Enabled
INFO - 2024-10-28 13:19:12 --> Utf8 Class Initialized
INFO - 2024-10-28 13:19:12 --> URI Class Initialized
INFO - 2024-10-28 13:19:12 --> Router Class Initialized
INFO - 2024-10-28 13:19:12 --> Output Class Initialized
INFO - 2024-10-28 13:19:12 --> Security Class Initialized
DEBUG - 2024-10-28 13:19:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 13:19:12 --> Input Class Initialized
INFO - 2024-10-28 13:19:12 --> Language Class Initialized
ERROR - 2024-10-28 13:19:12 --> TEST ERROR MESSAGE - 2024-10-28 13:19:12
INFO - 2024-10-28 13:19:12 --> Loader Class Initialized
INFO - 2024-10-28 13:19:12 --> Controller Class Initialized
INFO - 2024-10-28 13:19:12 --> Database Driver Class Initialized
INFO - 2024-10-28 13:19:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 13:19:12 --> Helper loaded: form_helper
INFO - 2024-10-28 13:19:12 --> Helper loaded: url_helper
INFO - 2024-10-28 13:19:12 --> Model Class Initialized
INFO - 2024-10-28 13:19:12 --> Helper loaded: inflector_helper
INFO - 2024-10-28 13:19:12 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 13:19:12 --> Helper loaded: email_helper
INFO - 2024-10-28 13:19:12 --> Model Class Initialized
INFO - 2024-10-28 13:19:12 --> Model Class Initialized
INFO - 2024-10-28 13:19:12 --> Model Class Initialized
INFO - 2024-10-28 13:19:12 --> Model Class Initialized
INFO - 2024-10-28 13:19:12 --> Model Class Initialized
INFO - 2024-10-28 13:19:12 --> Model Class Initialized
INFO - 2024-10-28 13:19:12 --> Model Class Initialized
DEBUG - 2024-10-28 13:19:12 --> plural called with: company
DEBUG - 2024-10-28 13:19:12 --> is_countable called with!!!!: company
INFO - 2024-10-28 13:19:12 --> Model Class Initialized
INFO - 2024-10-28 13:19:12 --> Model Class Initialized
INFO - 2024-10-28 13:19:12 --> Model Class Initialized
INFO - 2024-10-28 13:19:12 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-28 13:19:12 --> Final output sent to browser
DEBUG - 2024-10-28 13:19:12 --> Total execution time: 0.0204
INFO - 2024-10-28 13:24:18 --> Config Class Initialized
INFO - 2024-10-28 13:24:18 --> Hooks Class Initialized
DEBUG - 2024-10-28 13:24:18 --> UTF-8 Support Enabled
INFO - 2024-10-28 13:24:18 --> Utf8 Class Initialized
INFO - 2024-10-28 13:24:18 --> URI Class Initialized
DEBUG - 2024-10-28 13:24:18 --> No URI present. Default controller set.
INFO - 2024-10-28 13:24:18 --> Router Class Initialized
INFO - 2024-10-28 13:24:18 --> Output Class Initialized
INFO - 2024-10-28 13:24:18 --> Security Class Initialized
DEBUG - 2024-10-28 13:24:18 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 13:24:18 --> Input Class Initialized
INFO - 2024-10-28 13:24:18 --> Language Class Initialized
ERROR - 2024-10-28 13:24:18 --> TEST ERROR MESSAGE - 2024-10-28 13:24:18
INFO - 2024-10-28 13:24:18 --> Loader Class Initialized
INFO - 2024-10-28 13:24:18 --> Controller Class Initialized
INFO - 2024-10-28 13:24:18 --> Database Driver Class Initialized
INFO - 2024-10-28 13:24:18 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 13:24:18 --> Helper loaded: form_helper
INFO - 2024-10-28 13:24:18 --> Helper loaded: url_helper
INFO - 2024-10-28 13:24:18 --> Model Class Initialized
INFO - 2024-10-28 13:24:18 --> Helper loaded: inflector_helper
INFO - 2024-10-28 13:24:18 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 13:24:18 --> Helper loaded: email_helper
INFO - 2024-10-28 13:24:18 --> Model Class Initialized
INFO - 2024-10-28 13:24:18 --> Model Class Initialized
INFO - 2024-10-28 13:24:18 --> Model Class Initialized
INFO - 2024-10-28 13:24:18 --> Model Class Initialized
INFO - 2024-10-28 13:24:18 --> Model Class Initialized
INFO - 2024-10-28 13:24:18 --> Model Class Initialized
INFO - 2024-10-28 13:24:18 --> Model Class Initialized
DEBUG - 2024-10-28 13:24:18 --> plural called with: company
DEBUG - 2024-10-28 13:24:18 --> is_countable called with!!!!: company
INFO - 2024-10-28 13:24:18 --> Model Class Initialized
INFO - 2024-10-28 13:24:18 --> Model Class Initialized
INFO - 2024-10-28 13:24:18 --> Model Class Initialized
INFO - 2024-10-28 13:24:18 --> Final output sent to browser
DEBUG - 2024-10-28 13:24:18 --> Total execution time: 0.0219
INFO - 2024-10-28 13:24:19 --> Config Class Initialized
INFO - 2024-10-28 13:24:19 --> Hooks Class Initialized
DEBUG - 2024-10-28 13:24:19 --> UTF-8 Support Enabled
INFO - 2024-10-28 13:24:19 --> Utf8 Class Initialized
INFO - 2024-10-28 13:24:19 --> URI Class Initialized
DEBUG - 2024-10-28 13:24:19 --> No URI present. Default controller set.
INFO - 2024-10-28 13:24:19 --> Router Class Initialized
INFO - 2024-10-28 13:24:19 --> Output Class Initialized
INFO - 2024-10-28 13:24:19 --> Security Class Initialized
DEBUG - 2024-10-28 13:24:19 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 13:24:19 --> Input Class Initialized
INFO - 2024-10-28 13:24:19 --> Language Class Initialized
ERROR - 2024-10-28 13:24:19 --> TEST ERROR MESSAGE - 2024-10-28 13:24:19
INFO - 2024-10-28 13:24:19 --> Loader Class Initialized
INFO - 2024-10-28 13:24:19 --> Controller Class Initialized
INFO - 2024-10-28 13:24:19 --> Database Driver Class Initialized
INFO - 2024-10-28 13:24:19 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 13:24:19 --> Helper loaded: form_helper
INFO - 2024-10-28 13:24:19 --> Helper loaded: url_helper
INFO - 2024-10-28 13:24:19 --> Model Class Initialized
INFO - 2024-10-28 13:24:19 --> Helper loaded: inflector_helper
INFO - 2024-10-28 13:24:19 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 13:24:19 --> Helper loaded: email_helper
INFO - 2024-10-28 13:24:19 --> Model Class Initialized
INFO - 2024-10-28 13:24:19 --> Model Class Initialized
INFO - 2024-10-28 13:24:19 --> Model Class Initialized
INFO - 2024-10-28 13:24:19 --> Model Class Initialized
INFO - 2024-10-28 13:24:19 --> Model Class Initialized
INFO - 2024-10-28 13:24:19 --> Model Class Initialized
INFO - 2024-10-28 13:24:19 --> Model Class Initialized
DEBUG - 2024-10-28 13:24:19 --> plural called with: company
DEBUG - 2024-10-28 13:24:19 --> is_countable called with!!!!: company
INFO - 2024-10-28 13:24:19 --> Model Class Initialized
INFO - 2024-10-28 13:24:19 --> Model Class Initialized
INFO - 2024-10-28 13:24:19 --> Model Class Initialized
INFO - 2024-10-28 13:24:19 --> Final output sent to browser
DEBUG - 2024-10-28 13:24:19 --> Total execution time: 0.0307
INFO - 2024-10-28 13:24:40 --> Config Class Initialized
INFO - 2024-10-28 13:24:40 --> Hooks Class Initialized
DEBUG - 2024-10-28 13:24:40 --> UTF-8 Support Enabled
INFO - 2024-10-28 13:24:40 --> Utf8 Class Initialized
INFO - 2024-10-28 13:24:40 --> URI Class Initialized
DEBUG - 2024-10-28 13:24:40 --> No URI present. Default controller set.
INFO - 2024-10-28 13:24:40 --> Router Class Initialized
INFO - 2024-10-28 13:24:40 --> Output Class Initialized
INFO - 2024-10-28 13:24:40 --> Security Class Initialized
DEBUG - 2024-10-28 13:24:40 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 13:24:40 --> Input Class Initialized
INFO - 2024-10-28 13:24:40 --> Language Class Initialized
ERROR - 2024-10-28 13:24:40 --> TEST ERROR MESSAGE - 2024-10-28 13:24:40
INFO - 2024-10-28 13:24:40 --> Loader Class Initialized
INFO - 2024-10-28 13:24:40 --> Controller Class Initialized
INFO - 2024-10-28 13:24:40 --> Database Driver Class Initialized
INFO - 2024-10-28 13:24:40 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 13:24:40 --> Helper loaded: form_helper
INFO - 2024-10-28 13:24:40 --> Helper loaded: url_helper
INFO - 2024-10-28 13:24:40 --> Model Class Initialized
INFO - 2024-10-28 13:24:40 --> Helper loaded: inflector_helper
INFO - 2024-10-28 13:24:40 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 13:24:40 --> Helper loaded: email_helper
INFO - 2024-10-28 13:24:40 --> Model Class Initialized
INFO - 2024-10-28 13:24:40 --> Model Class Initialized
INFO - 2024-10-28 13:24:40 --> Model Class Initialized
INFO - 2024-10-28 13:24:40 --> Model Class Initialized
INFO - 2024-10-28 13:24:40 --> Model Class Initialized
INFO - 2024-10-28 13:24:40 --> Model Class Initialized
INFO - 2024-10-28 13:24:40 --> Model Class Initialized
DEBUG - 2024-10-28 13:24:40 --> plural called with: company
DEBUG - 2024-10-28 13:24:40 --> is_countable called with!!!!: company
INFO - 2024-10-28 13:24:40 --> Model Class Initialized
INFO - 2024-10-28 13:24:40 --> Model Class Initialized
INFO - 2024-10-28 13:24:40 --> Model Class Initialized
INFO - 2024-10-28 13:24:40 --> Final output sent to browser
DEBUG - 2024-10-28 13:24:40 --> Total execution time: 0.0277
INFO - 2024-10-28 13:24:43 --> Config Class Initialized
INFO - 2024-10-28 13:24:43 --> Hooks Class Initialized
DEBUG - 2024-10-28 13:24:43 --> UTF-8 Support Enabled
INFO - 2024-10-28 13:24:43 --> Utf8 Class Initialized
INFO - 2024-10-28 13:24:43 --> URI Class Initialized
DEBUG - 2024-10-28 13:24:43 --> No URI present. Default controller set.
INFO - 2024-10-28 13:24:43 --> Router Class Initialized
INFO - 2024-10-28 13:24:43 --> Output Class Initialized
INFO - 2024-10-28 13:24:43 --> Security Class Initialized
DEBUG - 2024-10-28 13:24:43 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 13:24:43 --> Input Class Initialized
INFO - 2024-10-28 13:24:43 --> Language Class Initialized
ERROR - 2024-10-28 13:24:43 --> TEST ERROR MESSAGE - 2024-10-28 13:24:43
INFO - 2024-10-28 13:24:43 --> Loader Class Initialized
INFO - 2024-10-28 13:24:43 --> Controller Class Initialized
INFO - 2024-10-28 13:24:43 --> Database Driver Class Initialized
INFO - 2024-10-28 13:24:43 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 13:24:43 --> Helper loaded: form_helper
INFO - 2024-10-28 13:24:43 --> Helper loaded: url_helper
INFO - 2024-10-28 13:24:43 --> Model Class Initialized
INFO - 2024-10-28 13:24:43 --> Helper loaded: inflector_helper
INFO - 2024-10-28 13:24:43 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 13:24:43 --> Helper loaded: email_helper
INFO - 2024-10-28 13:24:43 --> Model Class Initialized
INFO - 2024-10-28 13:24:43 --> Model Class Initialized
INFO - 2024-10-28 13:24:43 --> Model Class Initialized
INFO - 2024-10-28 13:24:43 --> Model Class Initialized
INFO - 2024-10-28 13:24:43 --> Model Class Initialized
INFO - 2024-10-28 13:24:43 --> Model Class Initialized
INFO - 2024-10-28 13:24:43 --> Model Class Initialized
DEBUG - 2024-10-28 13:24:43 --> plural called with: company
DEBUG - 2024-10-28 13:24:43 --> is_countable called with!!!!: company
INFO - 2024-10-28 13:24:43 --> Model Class Initialized
INFO - 2024-10-28 13:24:43 --> Model Class Initialized
INFO - 2024-10-28 13:24:43 --> Model Class Initialized
INFO - 2024-10-28 13:24:43 --> Final output sent to browser
DEBUG - 2024-10-28 13:24:43 --> Total execution time: 0.0215
INFO - 2024-10-28 13:59:50 --> Config Class Initialized
INFO - 2024-10-28 13:59:50 --> Hooks Class Initialized
DEBUG - 2024-10-28 13:59:50 --> UTF-8 Support Enabled
INFO - 2024-10-28 13:59:50 --> Utf8 Class Initialized
INFO - 2024-10-28 13:59:50 --> URI Class Initialized
INFO - 2024-10-28 13:59:50 --> Router Class Initialized
INFO - 2024-10-28 13:59:50 --> Output Class Initialized
INFO - 2024-10-28 13:59:50 --> Security Class Initialized
DEBUG - 2024-10-28 13:59:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 13:59:50 --> Input Class Initialized
INFO - 2024-10-28 13:59:50 --> Language Class Initialized
ERROR - 2024-10-28 13:59:50 --> TEST ERROR MESSAGE - 2024-10-28 13:59:50
INFO - 2024-10-28 13:59:50 --> Loader Class Initialized
INFO - 2024-10-28 13:59:50 --> Controller Class Initialized
INFO - 2024-10-28 13:59:50 --> Database Driver Class Initialized
INFO - 2024-10-28 13:59:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 13:59:50 --> Helper loaded: form_helper
INFO - 2024-10-28 13:59:50 --> Helper loaded: url_helper
INFO - 2024-10-28 13:59:50 --> Model Class Initialized
INFO - 2024-10-28 13:59:50 --> Helper loaded: inflector_helper
INFO - 2024-10-28 13:59:50 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 13:59:50 --> Helper loaded: email_helper
INFO - 2024-10-28 13:59:50 --> Model Class Initialized
INFO - 2024-10-28 13:59:50 --> Model Class Initialized
INFO - 2024-10-28 13:59:50 --> Model Class Initialized
INFO - 2024-10-28 13:59:50 --> Model Class Initialized
INFO - 2024-10-28 13:59:50 --> Model Class Initialized
INFO - 2024-10-28 13:59:50 --> Model Class Initialized
INFO - 2024-10-28 13:59:50 --> Model Class Initialized
DEBUG - 2024-10-28 13:59:50 --> plural called with: company
DEBUG - 2024-10-28 13:59:50 --> is_countable called with!!!!: company
INFO - 2024-10-28 13:59:50 --> Model Class Initialized
INFO - 2024-10-28 13:59:50 --> Model Class Initialized
INFO - 2024-10-28 13:59:50 --> Model Class Initialized
INFO - 2024-10-28 13:59:51 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-28 13:59:51 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-28 13:59:51 --> Final output sent to browser
DEBUG - 2024-10-28 13:59:51 --> Total execution time: 0.1849
INFO - 2024-10-28 13:59:53 --> Config Class Initialized
INFO - 2024-10-28 13:59:53 --> Hooks Class Initialized
DEBUG - 2024-10-28 13:59:53 --> UTF-8 Support Enabled
INFO - 2024-10-28 13:59:53 --> Utf8 Class Initialized
INFO - 2024-10-28 13:59:53 --> URI Class Initialized
INFO - 2024-10-28 13:59:53 --> Router Class Initialized
INFO - 2024-10-28 13:59:53 --> Output Class Initialized
INFO - 2024-10-28 13:59:53 --> Security Class Initialized
DEBUG - 2024-10-28 13:59:53 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 13:59:53 --> Input Class Initialized
INFO - 2024-10-28 13:59:53 --> Language Class Initialized
ERROR - 2024-10-28 13:59:53 --> TEST ERROR MESSAGE - 2024-10-28 13:59:53
INFO - 2024-10-28 13:59:53 --> Loader Class Initialized
INFO - 2024-10-28 13:59:53 --> Controller Class Initialized
INFO - 2024-10-28 13:59:53 --> Database Driver Class Initialized
INFO - 2024-10-28 13:59:53 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 13:59:53 --> Helper loaded: form_helper
INFO - 2024-10-28 13:59:53 --> Helper loaded: url_helper
INFO - 2024-10-28 13:59:53 --> Model Class Initialized
INFO - 2024-10-28 13:59:53 --> Helper loaded: inflector_helper
INFO - 2024-10-28 13:59:53 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 13:59:53 --> Helper loaded: email_helper
INFO - 2024-10-28 13:59:53 --> Model Class Initialized
INFO - 2024-10-28 13:59:53 --> Model Class Initialized
INFO - 2024-10-28 13:59:53 --> Model Class Initialized
INFO - 2024-10-28 13:59:53 --> Model Class Initialized
INFO - 2024-10-28 13:59:53 --> Model Class Initialized
INFO - 2024-10-28 13:59:53 --> Model Class Initialized
INFO - 2024-10-28 13:59:53 --> Model Class Initialized
DEBUG - 2024-10-28 13:59:53 --> plural called with: company
DEBUG - 2024-10-28 13:59:53 --> is_countable called with!!!!: company
INFO - 2024-10-28 13:59:53 --> Model Class Initialized
INFO - 2024-10-28 13:59:53 --> Model Class Initialized
INFO - 2024-10-28 13:59:53 --> Model Class Initialized
INFO - 2024-10-28 13:59:53 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-28 13:59:53 --> Final output sent to browser
DEBUG - 2024-10-28 13:59:53 --> Total execution time: 0.0263
INFO - 2024-10-28 14:05:37 --> Config Class Initialized
INFO - 2024-10-28 14:05:37 --> Hooks Class Initialized
DEBUG - 2024-10-28 14:05:37 --> UTF-8 Support Enabled
INFO - 2024-10-28 14:05:37 --> Utf8 Class Initialized
INFO - 2024-10-28 14:05:37 --> URI Class Initialized
INFO - 2024-10-28 14:05:37 --> Router Class Initialized
INFO - 2024-10-28 14:05:37 --> Output Class Initialized
INFO - 2024-10-28 14:05:37 --> Security Class Initialized
DEBUG - 2024-10-28 14:05:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 14:05:37 --> Input Class Initialized
INFO - 2024-10-28 14:05:37 --> Language Class Initialized
ERROR - 2024-10-28 14:05:37 --> TEST ERROR MESSAGE - 2024-10-28 14:05:37
INFO - 2024-10-28 14:05:37 --> Loader Class Initialized
INFO - 2024-10-28 14:05:37 --> Controller Class Initialized
INFO - 2024-10-28 14:05:37 --> Database Driver Class Initialized
INFO - 2024-10-28 14:05:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 14:05:37 --> Helper loaded: form_helper
INFO - 2024-10-28 14:05:37 --> Helper loaded: url_helper
INFO - 2024-10-28 14:05:37 --> Model Class Initialized
INFO - 2024-10-28 14:05:37 --> Helper loaded: inflector_helper
INFO - 2024-10-28 14:05:37 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 14:05:37 --> Helper loaded: email_helper
INFO - 2024-10-28 14:05:37 --> Model Class Initialized
INFO - 2024-10-28 14:05:37 --> Model Class Initialized
INFO - 2024-10-28 14:05:37 --> Model Class Initialized
INFO - 2024-10-28 14:05:37 --> Model Class Initialized
INFO - 2024-10-28 14:05:37 --> Model Class Initialized
INFO - 2024-10-28 14:05:37 --> Model Class Initialized
INFO - 2024-10-28 14:05:37 --> Model Class Initialized
DEBUG - 2024-10-28 14:05:37 --> plural called with: company
DEBUG - 2024-10-28 14:05:37 --> is_countable called with!!!!: company
INFO - 2024-10-28 14:05:37 --> Model Class Initialized
INFO - 2024-10-28 14:05:37 --> Model Class Initialized
INFO - 2024-10-28 14:05:37 --> Model Class Initialized
ERROR - 2024-10-28 14:05:37 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 298
INFO - 2024-10-28 14:05:37 --> Final output sent to browser
DEBUG - 2024-10-28 14:05:37 --> Total execution time: 0.0929
INFO - 2024-10-28 14:36:54 --> Config Class Initialized
INFO - 2024-10-28 14:36:54 --> Hooks Class Initialized
DEBUG - 2024-10-28 14:36:54 --> UTF-8 Support Enabled
INFO - 2024-10-28 14:36:54 --> Utf8 Class Initialized
INFO - 2024-10-28 14:36:54 --> URI Class Initialized
INFO - 2024-10-28 14:36:54 --> Router Class Initialized
INFO - 2024-10-28 14:36:54 --> Output Class Initialized
INFO - 2024-10-28 14:36:54 --> Security Class Initialized
DEBUG - 2024-10-28 14:36:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 14:36:54 --> Input Class Initialized
INFO - 2024-10-28 14:36:54 --> Language Class Initialized
ERROR - 2024-10-28 14:36:54 --> TEST ERROR MESSAGE - 2024-10-28 14:36:54
INFO - 2024-10-28 14:36:54 --> Loader Class Initialized
INFO - 2024-10-28 14:36:54 --> Controller Class Initialized
INFO - 2024-10-28 14:36:54 --> Database Driver Class Initialized
INFO - 2024-10-28 14:36:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 14:36:54 --> Helper loaded: form_helper
INFO - 2024-10-28 14:36:54 --> Helper loaded: url_helper
INFO - 2024-10-28 14:36:54 --> Model Class Initialized
INFO - 2024-10-28 14:36:54 --> Helper loaded: inflector_helper
INFO - 2024-10-28 14:36:54 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 14:36:54 --> Helper loaded: email_helper
INFO - 2024-10-28 14:36:54 --> Model Class Initialized
INFO - 2024-10-28 14:36:54 --> Model Class Initialized
INFO - 2024-10-28 14:36:54 --> Model Class Initialized
INFO - 2024-10-28 14:36:54 --> Model Class Initialized
INFO - 2024-10-28 14:36:54 --> Model Class Initialized
INFO - 2024-10-28 14:36:54 --> Model Class Initialized
INFO - 2024-10-28 14:36:54 --> Model Class Initialized
DEBUG - 2024-10-28 14:36:54 --> plural called with: company
DEBUG - 2024-10-28 14:36:54 --> is_countable called with!!!!: company
INFO - 2024-10-28 14:36:54 --> Model Class Initialized
INFO - 2024-10-28 14:36:54 --> Model Class Initialized
INFO - 2024-10-28 14:36:54 --> Model Class Initialized
ERROR - 2024-10-28 14:36:54 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 298
INFO - 2024-10-28 14:36:54 --> Final output sent to browser
DEBUG - 2024-10-28 14:36:54 --> Total execution time: 0.1296
INFO - 2024-10-28 14:47:58 --> Config Class Initialized
INFO - 2024-10-28 14:47:58 --> Hooks Class Initialized
DEBUG - 2024-10-28 14:47:58 --> UTF-8 Support Enabled
INFO - 2024-10-28 14:47:58 --> Utf8 Class Initialized
INFO - 2024-10-28 14:47:58 --> URI Class Initialized
INFO - 2024-10-28 14:47:58 --> Router Class Initialized
INFO - 2024-10-28 14:47:58 --> Output Class Initialized
INFO - 2024-10-28 14:47:58 --> Security Class Initialized
DEBUG - 2024-10-28 14:47:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 14:47:58 --> Input Class Initialized
INFO - 2024-10-28 14:47:58 --> Language Class Initialized
ERROR - 2024-10-28 14:47:58 --> TEST ERROR MESSAGE - 2024-10-28 14:47:58
INFO - 2024-10-28 14:47:58 --> Loader Class Initialized
INFO - 2024-10-28 14:47:58 --> Controller Class Initialized
INFO - 2024-10-28 14:47:58 --> Database Driver Class Initialized
INFO - 2024-10-28 14:47:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 14:47:58 --> Helper loaded: form_helper
INFO - 2024-10-28 14:47:58 --> Helper loaded: url_helper
INFO - 2024-10-28 14:47:58 --> Model Class Initialized
INFO - 2024-10-28 14:47:58 --> Helper loaded: inflector_helper
INFO - 2024-10-28 14:47:58 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 14:47:58 --> Helper loaded: email_helper
INFO - 2024-10-28 14:47:58 --> Model Class Initialized
INFO - 2024-10-28 14:47:58 --> Model Class Initialized
INFO - 2024-10-28 14:47:58 --> Model Class Initialized
INFO - 2024-10-28 14:47:58 --> Model Class Initialized
INFO - 2024-10-28 14:47:58 --> Model Class Initialized
INFO - 2024-10-28 14:47:58 --> Model Class Initialized
INFO - 2024-10-28 14:47:58 --> Model Class Initialized
DEBUG - 2024-10-28 14:47:58 --> plural called with: company
DEBUG - 2024-10-28 14:47:58 --> is_countable called with!!!!: company
INFO - 2024-10-28 14:47:58 --> Model Class Initialized
INFO - 2024-10-28 14:47:58 --> Model Class Initialized
INFO - 2024-10-28 14:47:58 --> Model Class Initialized
INFO - 2024-10-28 14:47:58 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-28 14:47:58 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-28 14:47:58 --> Final output sent to browser
DEBUG - 2024-10-28 14:47:58 --> Total execution time: 0.2372
INFO - 2024-10-28 14:48:02 --> Config Class Initialized
INFO - 2024-10-28 14:48:02 --> Hooks Class Initialized
DEBUG - 2024-10-28 14:48:02 --> UTF-8 Support Enabled
INFO - 2024-10-28 14:48:02 --> Utf8 Class Initialized
INFO - 2024-10-28 14:48:02 --> URI Class Initialized
INFO - 2024-10-28 14:48:02 --> Router Class Initialized
INFO - 2024-10-28 14:48:02 --> Output Class Initialized
INFO - 2024-10-28 14:48:02 --> Security Class Initialized
DEBUG - 2024-10-28 14:48:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 14:48:02 --> Input Class Initialized
INFO - 2024-10-28 14:48:02 --> Language Class Initialized
ERROR - 2024-10-28 14:48:02 --> TEST ERROR MESSAGE - 2024-10-28 14:48:02
INFO - 2024-10-28 14:48:02 --> Loader Class Initialized
INFO - 2024-10-28 14:48:02 --> Controller Class Initialized
INFO - 2024-10-28 14:48:02 --> Database Driver Class Initialized
INFO - 2024-10-28 14:48:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 14:48:02 --> Helper loaded: form_helper
INFO - 2024-10-28 14:48:02 --> Helper loaded: url_helper
INFO - 2024-10-28 14:48:02 --> Model Class Initialized
INFO - 2024-10-28 14:48:02 --> Helper loaded: inflector_helper
INFO - 2024-10-28 14:48:02 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 14:48:02 --> Helper loaded: email_helper
INFO - 2024-10-28 14:48:02 --> Model Class Initialized
INFO - 2024-10-28 14:48:02 --> Model Class Initialized
INFO - 2024-10-28 14:48:02 --> Model Class Initialized
INFO - 2024-10-28 14:48:02 --> Model Class Initialized
INFO - 2024-10-28 14:48:02 --> Model Class Initialized
INFO - 2024-10-28 14:48:02 --> Model Class Initialized
INFO - 2024-10-28 14:48:02 --> Model Class Initialized
DEBUG - 2024-10-28 14:48:02 --> plural called with: company
DEBUG - 2024-10-28 14:48:02 --> is_countable called with!!!!: company
INFO - 2024-10-28 14:48:02 --> Model Class Initialized
INFO - 2024-10-28 14:48:02 --> Model Class Initialized
INFO - 2024-10-28 14:48:02 --> Model Class Initialized
INFO - 2024-10-28 14:48:02 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-28 14:48:02 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-28 14:48:02 --> Final output sent to browser
DEBUG - 2024-10-28 14:48:02 --> Total execution time: 0.1652
INFO - 2024-10-28 14:48:04 --> Config Class Initialized
INFO - 2024-10-28 14:48:04 --> Hooks Class Initialized
DEBUG - 2024-10-28 14:48:04 --> UTF-8 Support Enabled
INFO - 2024-10-28 14:48:04 --> Utf8 Class Initialized
INFO - 2024-10-28 14:48:04 --> URI Class Initialized
INFO - 2024-10-28 14:48:04 --> Router Class Initialized
INFO - 2024-10-28 14:48:04 --> Output Class Initialized
INFO - 2024-10-28 14:48:04 --> Security Class Initialized
DEBUG - 2024-10-28 14:48:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 14:48:04 --> Input Class Initialized
INFO - 2024-10-28 14:48:04 --> Language Class Initialized
ERROR - 2024-10-28 14:48:04 --> TEST ERROR MESSAGE - 2024-10-28 14:48:04
INFO - 2024-10-28 14:48:04 --> Loader Class Initialized
INFO - 2024-10-28 14:48:04 --> Controller Class Initialized
INFO - 2024-10-28 14:48:04 --> Database Driver Class Initialized
INFO - 2024-10-28 14:48:04 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 14:48:04 --> Helper loaded: form_helper
INFO - 2024-10-28 14:48:04 --> Helper loaded: url_helper
INFO - 2024-10-28 14:48:04 --> Model Class Initialized
INFO - 2024-10-28 14:48:04 --> Helper loaded: inflector_helper
INFO - 2024-10-28 14:48:04 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 14:48:04 --> Helper loaded: email_helper
INFO - 2024-10-28 14:48:04 --> Model Class Initialized
INFO - 2024-10-28 14:48:04 --> Model Class Initialized
INFO - 2024-10-28 14:48:04 --> Model Class Initialized
INFO - 2024-10-28 14:48:04 --> Model Class Initialized
INFO - 2024-10-28 14:48:04 --> Model Class Initialized
INFO - 2024-10-28 14:48:04 --> Model Class Initialized
INFO - 2024-10-28 14:48:04 --> Model Class Initialized
DEBUG - 2024-10-28 14:48:04 --> plural called with: company
DEBUG - 2024-10-28 14:48:04 --> is_countable called with!!!!: company
INFO - 2024-10-28 14:48:04 --> Model Class Initialized
INFO - 2024-10-28 14:48:04 --> Model Class Initialized
INFO - 2024-10-28 14:48:04 --> Model Class Initialized
INFO - 2024-10-28 14:48:04 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-28 14:48:04 --> Final output sent to browser
DEBUG - 2024-10-28 14:48:04 --> Total execution time: 0.0264
INFO - 2024-10-28 14:48:47 --> Config Class Initialized
INFO - 2024-10-28 14:48:47 --> Hooks Class Initialized
DEBUG - 2024-10-28 14:48:47 --> UTF-8 Support Enabled
INFO - 2024-10-28 14:48:47 --> Utf8 Class Initialized
INFO - 2024-10-28 14:48:47 --> URI Class Initialized
INFO - 2024-10-28 14:48:47 --> Router Class Initialized
INFO - 2024-10-28 14:48:47 --> Output Class Initialized
INFO - 2024-10-28 14:48:47 --> Security Class Initialized
DEBUG - 2024-10-28 14:48:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 14:48:47 --> Input Class Initialized
INFO - 2024-10-28 14:48:47 --> Language Class Initialized
ERROR - 2024-10-28 14:48:47 --> TEST ERROR MESSAGE - 2024-10-28 14:48:47
INFO - 2024-10-28 14:48:47 --> Loader Class Initialized
INFO - 2024-10-28 14:48:47 --> Controller Class Initialized
INFO - 2024-10-28 14:48:47 --> Database Driver Class Initialized
INFO - 2024-10-28 14:48:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 14:48:47 --> Helper loaded: form_helper
INFO - 2024-10-28 14:48:47 --> Helper loaded: url_helper
INFO - 2024-10-28 14:48:47 --> Model Class Initialized
INFO - 2024-10-28 14:48:47 --> Helper loaded: inflector_helper
INFO - 2024-10-28 14:48:47 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 14:48:47 --> Helper loaded: email_helper
INFO - 2024-10-28 14:48:47 --> Model Class Initialized
INFO - 2024-10-28 14:48:47 --> Model Class Initialized
INFO - 2024-10-28 14:48:47 --> Model Class Initialized
INFO - 2024-10-28 14:48:47 --> Model Class Initialized
INFO - 2024-10-28 14:48:47 --> Model Class Initialized
INFO - 2024-10-28 14:48:47 --> Model Class Initialized
INFO - 2024-10-28 14:48:47 --> Model Class Initialized
DEBUG - 2024-10-28 14:48:47 --> plural called with: company
DEBUG - 2024-10-28 14:48:47 --> is_countable called with!!!!: company
INFO - 2024-10-28 14:48:47 --> Model Class Initialized
INFO - 2024-10-28 14:48:47 --> Model Class Initialized
INFO - 2024-10-28 14:48:47 --> Model Class Initialized
INFO - 2024-10-28 14:48:47 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-28 14:48:47 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-28 14:48:47 --> Final output sent to browser
DEBUG - 2024-10-28 14:48:47 --> Total execution time: 0.0404
INFO - 2024-10-28 14:49:00 --> Config Class Initialized
INFO - 2024-10-28 14:49:00 --> Hooks Class Initialized
DEBUG - 2024-10-28 14:49:00 --> UTF-8 Support Enabled
INFO - 2024-10-28 14:49:00 --> Utf8 Class Initialized
INFO - 2024-10-28 14:49:00 --> URI Class Initialized
INFO - 2024-10-28 14:49:00 --> Router Class Initialized
INFO - 2024-10-28 14:49:00 --> Output Class Initialized
INFO - 2024-10-28 14:49:00 --> Security Class Initialized
DEBUG - 2024-10-28 14:49:00 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 14:49:00 --> Input Class Initialized
INFO - 2024-10-28 14:49:00 --> Language Class Initialized
ERROR - 2024-10-28 14:49:00 --> TEST ERROR MESSAGE - 2024-10-28 14:49:00
INFO - 2024-10-28 14:49:00 --> Loader Class Initialized
INFO - 2024-10-28 14:49:00 --> Controller Class Initialized
INFO - 2024-10-28 14:49:00 --> Database Driver Class Initialized
INFO - 2024-10-28 14:49:00 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 14:49:00 --> Helper loaded: form_helper
INFO - 2024-10-28 14:49:00 --> Helper loaded: url_helper
INFO - 2024-10-28 14:49:00 --> Model Class Initialized
INFO - 2024-10-28 14:49:00 --> Helper loaded: inflector_helper
INFO - 2024-10-28 14:49:00 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 14:49:00 --> Helper loaded: email_helper
INFO - 2024-10-28 14:49:00 --> Model Class Initialized
INFO - 2024-10-28 14:49:00 --> Model Class Initialized
INFO - 2024-10-28 14:49:00 --> Model Class Initialized
INFO - 2024-10-28 14:49:00 --> Model Class Initialized
INFO - 2024-10-28 14:49:00 --> Model Class Initialized
INFO - 2024-10-28 14:49:00 --> Model Class Initialized
INFO - 2024-10-28 14:49:00 --> Model Class Initialized
DEBUG - 2024-10-28 14:49:00 --> plural called with: company
DEBUG - 2024-10-28 14:49:00 --> is_countable called with!!!!: company
INFO - 2024-10-28 14:49:00 --> Model Class Initialized
INFO - 2024-10-28 14:49:00 --> Model Class Initialized
INFO - 2024-10-28 14:49:00 --> Model Class Initialized
ERROR - 2024-10-28 14:49:00 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 298
ERROR - 2024-10-28 14:49:00 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 312
ERROR - 2024-10-28 14:49:00 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 317
INFO - 2024-10-28 14:49:00 --> Final output sent to browser
DEBUG - 2024-10-28 14:49:00 --> Total execution time: 0.1303
INFO - 2024-10-28 14:49:02 --> Config Class Initialized
INFO - 2024-10-28 14:49:02 --> Hooks Class Initialized
DEBUG - 2024-10-28 14:49:02 --> UTF-8 Support Enabled
INFO - 2024-10-28 14:49:02 --> Utf8 Class Initialized
INFO - 2024-10-28 14:49:02 --> URI Class Initialized
INFO - 2024-10-28 14:49:02 --> Router Class Initialized
INFO - 2024-10-28 14:49:02 --> Output Class Initialized
INFO - 2024-10-28 14:49:02 --> Security Class Initialized
DEBUG - 2024-10-28 14:49:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 14:49:02 --> Input Class Initialized
INFO - 2024-10-28 14:49:02 --> Language Class Initialized
ERROR - 2024-10-28 14:49:02 --> TEST ERROR MESSAGE - 2024-10-28 14:49:02
INFO - 2024-10-28 14:49:02 --> Loader Class Initialized
INFO - 2024-10-28 14:49:02 --> Controller Class Initialized
INFO - 2024-10-28 14:49:02 --> Database Driver Class Initialized
INFO - 2024-10-28 14:49:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 14:49:02 --> Helper loaded: form_helper
INFO - 2024-10-28 14:49:02 --> Helper loaded: url_helper
INFO - 2024-10-28 14:49:02 --> Model Class Initialized
INFO - 2024-10-28 14:49:02 --> Helper loaded: inflector_helper
INFO - 2024-10-28 14:49:02 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 14:49:02 --> Helper loaded: email_helper
INFO - 2024-10-28 14:49:02 --> Model Class Initialized
INFO - 2024-10-28 14:49:02 --> Model Class Initialized
INFO - 2024-10-28 14:49:02 --> Model Class Initialized
INFO - 2024-10-28 14:49:02 --> Model Class Initialized
INFO - 2024-10-28 14:49:02 --> Model Class Initialized
INFO - 2024-10-28 14:49:02 --> Model Class Initialized
INFO - 2024-10-28 14:49:02 --> Model Class Initialized
DEBUG - 2024-10-28 14:49:02 --> plural called with: company
DEBUG - 2024-10-28 14:49:02 --> is_countable called with!!!!: company
INFO - 2024-10-28 14:49:02 --> Model Class Initialized
INFO - 2024-10-28 14:49:02 --> Model Class Initialized
INFO - 2024-10-28 14:49:02 --> Model Class Initialized
INFO - 2024-10-28 14:49:02 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-28 14:49:02 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-28 14:49:02 --> Final output sent to browser
DEBUG - 2024-10-28 14:49:02 --> Total execution time: 0.0623
INFO - 2024-10-28 14:49:04 --> Config Class Initialized
INFO - 2024-10-28 14:49:04 --> Hooks Class Initialized
DEBUG - 2024-10-28 14:49:04 --> UTF-8 Support Enabled
INFO - 2024-10-28 14:49:04 --> Utf8 Class Initialized
INFO - 2024-10-28 14:49:04 --> URI Class Initialized
INFO - 2024-10-28 14:49:04 --> Router Class Initialized
INFO - 2024-10-28 14:49:04 --> Output Class Initialized
INFO - 2024-10-28 14:49:04 --> Security Class Initialized
DEBUG - 2024-10-28 14:49:04 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 14:49:04 --> Input Class Initialized
INFO - 2024-10-28 14:49:05 --> Language Class Initialized
ERROR - 2024-10-28 14:49:05 --> TEST ERROR MESSAGE - 2024-10-28 14:49:05
INFO - 2024-10-28 14:49:05 --> Loader Class Initialized
INFO - 2024-10-28 14:49:05 --> Controller Class Initialized
INFO - 2024-10-28 14:49:05 --> Database Driver Class Initialized
INFO - 2024-10-28 14:49:05 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 14:49:05 --> Helper loaded: form_helper
INFO - 2024-10-28 14:49:05 --> Helper loaded: url_helper
INFO - 2024-10-28 14:49:05 --> Model Class Initialized
INFO - 2024-10-28 14:49:05 --> Helper loaded: inflector_helper
INFO - 2024-10-28 14:49:05 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 14:49:05 --> Helper loaded: email_helper
INFO - 2024-10-28 14:49:05 --> Model Class Initialized
INFO - 2024-10-28 14:49:05 --> Model Class Initialized
INFO - 2024-10-28 14:49:05 --> Model Class Initialized
INFO - 2024-10-28 14:49:05 --> Model Class Initialized
INFO - 2024-10-28 14:49:05 --> Model Class Initialized
INFO - 2024-10-28 14:49:05 --> Model Class Initialized
INFO - 2024-10-28 14:49:05 --> Model Class Initialized
DEBUG - 2024-10-28 14:49:05 --> plural called with: company
DEBUG - 2024-10-28 14:49:05 --> is_countable called with!!!!: company
INFO - 2024-10-28 14:49:05 --> Model Class Initialized
INFO - 2024-10-28 14:49:05 --> Model Class Initialized
INFO - 2024-10-28 14:49:05 --> Model Class Initialized
INFO - 2024-10-28 14:49:05 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-28 14:49:05 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-28 14:49:05 --> Final output sent to browser
DEBUG - 2024-10-28 14:49:05 --> Total execution time: 0.2416
INFO - 2024-10-28 14:49:06 --> Config Class Initialized
INFO - 2024-10-28 14:49:06 --> Hooks Class Initialized
DEBUG - 2024-10-28 14:49:06 --> UTF-8 Support Enabled
INFO - 2024-10-28 14:49:06 --> Utf8 Class Initialized
INFO - 2024-10-28 14:49:06 --> URI Class Initialized
INFO - 2024-10-28 14:49:06 --> Router Class Initialized
INFO - 2024-10-28 14:49:06 --> Output Class Initialized
INFO - 2024-10-28 14:49:06 --> Security Class Initialized
DEBUG - 2024-10-28 14:49:06 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 14:49:06 --> Input Class Initialized
INFO - 2024-10-28 14:49:06 --> Language Class Initialized
ERROR - 2024-10-28 14:49:06 --> TEST ERROR MESSAGE - 2024-10-28 14:49:06
INFO - 2024-10-28 14:49:06 --> Loader Class Initialized
INFO - 2024-10-28 14:49:06 --> Controller Class Initialized
INFO - 2024-10-28 14:49:06 --> Database Driver Class Initialized
INFO - 2024-10-28 14:49:06 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 14:49:06 --> Helper loaded: form_helper
INFO - 2024-10-28 14:49:06 --> Helper loaded: url_helper
INFO - 2024-10-28 14:49:06 --> Model Class Initialized
INFO - 2024-10-28 14:49:06 --> Helper loaded: inflector_helper
INFO - 2024-10-28 14:49:06 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 14:49:06 --> Helper loaded: email_helper
INFO - 2024-10-28 14:49:06 --> Model Class Initialized
INFO - 2024-10-28 14:49:06 --> Model Class Initialized
INFO - 2024-10-28 14:49:06 --> Model Class Initialized
INFO - 2024-10-28 14:49:06 --> Model Class Initialized
INFO - 2024-10-28 14:49:06 --> Model Class Initialized
INFO - 2024-10-28 14:49:06 --> Model Class Initialized
INFO - 2024-10-28 14:49:06 --> Model Class Initialized
DEBUG - 2024-10-28 14:49:06 --> plural called with: company
DEBUG - 2024-10-28 14:49:06 --> is_countable called with!!!!: company
INFO - 2024-10-28 14:49:06 --> Model Class Initialized
INFO - 2024-10-28 14:49:06 --> Model Class Initialized
INFO - 2024-10-28 14:49:06 --> Model Class Initialized
INFO - 2024-10-28 14:49:06 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-28 14:49:06 --> Final output sent to browser
DEBUG - 2024-10-28 14:49:06 --> Total execution time: 0.0210
INFO - 2024-10-28 14:49:37 --> Config Class Initialized
INFO - 2024-10-28 14:49:37 --> Hooks Class Initialized
DEBUG - 2024-10-28 14:49:37 --> UTF-8 Support Enabled
INFO - 2024-10-28 14:49:37 --> Utf8 Class Initialized
INFO - 2024-10-28 14:49:37 --> URI Class Initialized
INFO - 2024-10-28 14:49:37 --> Router Class Initialized
INFO - 2024-10-28 14:49:37 --> Output Class Initialized
INFO - 2024-10-28 14:49:37 --> Security Class Initialized
DEBUG - 2024-10-28 14:49:37 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 14:49:37 --> Input Class Initialized
INFO - 2024-10-28 14:49:37 --> Language Class Initialized
ERROR - 2024-10-28 14:49:37 --> TEST ERROR MESSAGE - 2024-10-28 14:49:37
INFO - 2024-10-28 14:49:37 --> Loader Class Initialized
INFO - 2024-10-28 14:49:37 --> Controller Class Initialized
INFO - 2024-10-28 14:49:37 --> Database Driver Class Initialized
INFO - 2024-10-28 14:49:37 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 14:49:37 --> Helper loaded: form_helper
INFO - 2024-10-28 14:49:37 --> Helper loaded: url_helper
INFO - 2024-10-28 14:49:37 --> Model Class Initialized
INFO - 2024-10-28 14:49:37 --> Helper loaded: inflector_helper
INFO - 2024-10-28 14:49:37 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 14:49:37 --> Helper loaded: email_helper
INFO - 2024-10-28 14:49:37 --> Model Class Initialized
INFO - 2024-10-28 14:49:37 --> Model Class Initialized
INFO - 2024-10-28 14:49:37 --> Model Class Initialized
INFO - 2024-10-28 14:49:37 --> Model Class Initialized
INFO - 2024-10-28 14:49:37 --> Model Class Initialized
INFO - 2024-10-28 14:49:37 --> Model Class Initialized
INFO - 2024-10-28 14:49:37 --> Model Class Initialized
DEBUG - 2024-10-28 14:49:37 --> plural called with: company
DEBUG - 2024-10-28 14:49:37 --> is_countable called with!!!!: company
INFO - 2024-10-28 14:49:37 --> Model Class Initialized
INFO - 2024-10-28 14:49:37 --> Model Class Initialized
INFO - 2024-10-28 14:49:37 --> Model Class Initialized
INFO - 2024-10-28 14:49:37 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-28 14:49:37 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-28 14:49:37 --> Final output sent to browser
DEBUG - 2024-10-28 14:49:37 --> Total execution time: 0.0494
INFO - 2024-10-28 14:49:42 --> Config Class Initialized
INFO - 2024-10-28 14:49:42 --> Hooks Class Initialized
DEBUG - 2024-10-28 14:49:42 --> UTF-8 Support Enabled
INFO - 2024-10-28 14:49:42 --> Utf8 Class Initialized
INFO - 2024-10-28 14:49:42 --> URI Class Initialized
INFO - 2024-10-28 14:49:42 --> Router Class Initialized
INFO - 2024-10-28 14:49:42 --> Output Class Initialized
INFO - 2024-10-28 14:49:42 --> Security Class Initialized
DEBUG - 2024-10-28 14:49:42 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 14:49:42 --> Input Class Initialized
INFO - 2024-10-28 14:49:42 --> Language Class Initialized
ERROR - 2024-10-28 14:49:42 --> TEST ERROR MESSAGE - 2024-10-28 14:49:42
INFO - 2024-10-28 14:49:42 --> Loader Class Initialized
INFO - 2024-10-28 14:49:42 --> Controller Class Initialized
INFO - 2024-10-28 14:49:42 --> Database Driver Class Initialized
INFO - 2024-10-28 14:49:42 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 14:49:42 --> Helper loaded: form_helper
INFO - 2024-10-28 14:49:42 --> Helper loaded: url_helper
INFO - 2024-10-28 14:49:42 --> Model Class Initialized
INFO - 2024-10-28 14:49:42 --> Helper loaded: inflector_helper
INFO - 2024-10-28 14:49:42 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 14:49:42 --> Helper loaded: email_helper
INFO - 2024-10-28 14:49:42 --> Model Class Initialized
INFO - 2024-10-28 14:49:42 --> Model Class Initialized
INFO - 2024-10-28 14:49:42 --> Model Class Initialized
INFO - 2024-10-28 14:49:42 --> Model Class Initialized
INFO - 2024-10-28 14:49:42 --> Model Class Initialized
INFO - 2024-10-28 14:49:42 --> Model Class Initialized
INFO - 2024-10-28 14:49:42 --> Model Class Initialized
DEBUG - 2024-10-28 14:49:42 --> plural called with: company
DEBUG - 2024-10-28 14:49:42 --> is_countable called with!!!!: company
INFO - 2024-10-28 14:49:42 --> Model Class Initialized
INFO - 2024-10-28 14:49:42 --> Model Class Initialized
INFO - 2024-10-28 14:49:42 --> Model Class Initialized
ERROR - 2024-10-28 14:49:43 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 298
INFO - 2024-10-28 14:49:43 --> Final output sent to browser
DEBUG - 2024-10-28 14:49:43 --> Total execution time: 0.1413
INFO - 2024-10-28 14:49:46 --> Config Class Initialized
INFO - 2024-10-28 14:49:46 --> Hooks Class Initialized
DEBUG - 2024-10-28 14:49:46 --> UTF-8 Support Enabled
INFO - 2024-10-28 14:49:46 --> Utf8 Class Initialized
INFO - 2024-10-28 14:49:46 --> URI Class Initialized
INFO - 2024-10-28 14:49:46 --> Router Class Initialized
INFO - 2024-10-28 14:49:46 --> Output Class Initialized
INFO - 2024-10-28 14:49:46 --> Security Class Initialized
DEBUG - 2024-10-28 14:49:46 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 14:49:46 --> Input Class Initialized
INFO - 2024-10-28 14:49:46 --> Language Class Initialized
ERROR - 2024-10-28 14:49:46 --> TEST ERROR MESSAGE - 2024-10-28 14:49:46
INFO - 2024-10-28 14:49:46 --> Loader Class Initialized
INFO - 2024-10-28 14:49:46 --> Controller Class Initialized
INFO - 2024-10-28 14:49:46 --> Database Driver Class Initialized
INFO - 2024-10-28 14:49:46 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 14:49:46 --> Helper loaded: form_helper
INFO - 2024-10-28 14:49:46 --> Helper loaded: url_helper
INFO - 2024-10-28 14:49:46 --> Model Class Initialized
INFO - 2024-10-28 14:49:46 --> Helper loaded: inflector_helper
INFO - 2024-10-28 14:49:46 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 14:49:46 --> Helper loaded: email_helper
INFO - 2024-10-28 14:49:46 --> Model Class Initialized
INFO - 2024-10-28 14:49:46 --> Model Class Initialized
INFO - 2024-10-28 14:49:46 --> Model Class Initialized
INFO - 2024-10-28 14:49:46 --> Model Class Initialized
INFO - 2024-10-28 14:49:46 --> Model Class Initialized
INFO - 2024-10-28 14:49:46 --> Model Class Initialized
INFO - 2024-10-28 14:49:46 --> Model Class Initialized
DEBUG - 2024-10-28 14:49:46 --> plural called with: company
DEBUG - 2024-10-28 14:49:46 --> is_countable called with!!!!: company
INFO - 2024-10-28 14:49:46 --> Model Class Initialized
INFO - 2024-10-28 14:49:46 --> Model Class Initialized
INFO - 2024-10-28 14:49:46 --> Model Class Initialized
INFO - 2024-10-28 14:49:46 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-28 14:49:46 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-28 14:49:46 --> Final output sent to browser
DEBUG - 2024-10-28 14:49:46 --> Total execution time: 0.2332
INFO - 2024-10-28 14:49:47 --> Config Class Initialized
INFO - 2024-10-28 14:49:47 --> Hooks Class Initialized
DEBUG - 2024-10-28 14:49:47 --> UTF-8 Support Enabled
INFO - 2024-10-28 14:49:47 --> Utf8 Class Initialized
INFO - 2024-10-28 14:49:47 --> URI Class Initialized
INFO - 2024-10-28 14:49:47 --> Router Class Initialized
INFO - 2024-10-28 14:49:47 --> Output Class Initialized
INFO - 2024-10-28 14:49:47 --> Security Class Initialized
DEBUG - 2024-10-28 14:49:47 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 14:49:47 --> Input Class Initialized
INFO - 2024-10-28 14:49:47 --> Language Class Initialized
ERROR - 2024-10-28 14:49:47 --> TEST ERROR MESSAGE - 2024-10-28 14:49:47
INFO - 2024-10-28 14:49:47 --> Loader Class Initialized
INFO - 2024-10-28 14:49:47 --> Controller Class Initialized
INFO - 2024-10-28 14:49:47 --> Database Driver Class Initialized
INFO - 2024-10-28 14:49:47 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 14:49:47 --> Helper loaded: form_helper
INFO - 2024-10-28 14:49:47 --> Helper loaded: url_helper
INFO - 2024-10-28 14:49:47 --> Model Class Initialized
INFO - 2024-10-28 14:49:47 --> Helper loaded: inflector_helper
INFO - 2024-10-28 14:49:47 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 14:49:47 --> Helper loaded: email_helper
INFO - 2024-10-28 14:49:47 --> Model Class Initialized
INFO - 2024-10-28 14:49:47 --> Model Class Initialized
INFO - 2024-10-28 14:49:47 --> Model Class Initialized
INFO - 2024-10-28 14:49:47 --> Model Class Initialized
INFO - 2024-10-28 14:49:47 --> Model Class Initialized
INFO - 2024-10-28 14:49:47 --> Model Class Initialized
INFO - 2024-10-28 14:49:47 --> Model Class Initialized
DEBUG - 2024-10-28 14:49:47 --> plural called with: company
DEBUG - 2024-10-28 14:49:47 --> is_countable called with!!!!: company
INFO - 2024-10-28 14:49:47 --> Model Class Initialized
INFO - 2024-10-28 14:49:47 --> Model Class Initialized
INFO - 2024-10-28 14:49:47 --> Model Class Initialized
INFO - 2024-10-28 14:49:47 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-28 14:49:47 --> Final output sent to browser
DEBUG - 2024-10-28 14:49:47 --> Total execution time: 0.0205
INFO - 2024-10-28 14:50:21 --> Config Class Initialized
INFO - 2024-10-28 14:50:21 --> Hooks Class Initialized
DEBUG - 2024-10-28 14:50:21 --> UTF-8 Support Enabled
INFO - 2024-10-28 14:50:21 --> Utf8 Class Initialized
INFO - 2024-10-28 14:50:21 --> URI Class Initialized
INFO - 2024-10-28 14:50:21 --> Router Class Initialized
INFO - 2024-10-28 14:50:21 --> Output Class Initialized
INFO - 2024-10-28 14:50:21 --> Security Class Initialized
DEBUG - 2024-10-28 14:50:21 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 14:50:21 --> Input Class Initialized
INFO - 2024-10-28 14:50:21 --> Language Class Initialized
ERROR - 2024-10-28 14:50:21 --> TEST ERROR MESSAGE - 2024-10-28 14:50:21
INFO - 2024-10-28 14:50:21 --> Loader Class Initialized
INFO - 2024-10-28 14:50:21 --> Controller Class Initialized
INFO - 2024-10-28 14:50:21 --> Database Driver Class Initialized
INFO - 2024-10-28 14:50:21 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 14:50:21 --> Helper loaded: form_helper
INFO - 2024-10-28 14:50:21 --> Helper loaded: url_helper
INFO - 2024-10-28 14:50:21 --> Model Class Initialized
INFO - 2024-10-28 14:50:21 --> Helper loaded: inflector_helper
INFO - 2024-10-28 14:50:21 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 14:50:21 --> Helper loaded: email_helper
INFO - 2024-10-28 14:50:21 --> Model Class Initialized
INFO - 2024-10-28 14:50:21 --> Model Class Initialized
INFO - 2024-10-28 14:50:21 --> Model Class Initialized
INFO - 2024-10-28 14:50:21 --> Model Class Initialized
INFO - 2024-10-28 14:50:21 --> Model Class Initialized
INFO - 2024-10-28 14:50:21 --> Model Class Initialized
INFO - 2024-10-28 14:50:21 --> Model Class Initialized
DEBUG - 2024-10-28 14:50:21 --> plural called with: company
DEBUG - 2024-10-28 14:50:21 --> is_countable called with!!!!: company
INFO - 2024-10-28 14:50:21 --> Model Class Initialized
INFO - 2024-10-28 14:50:21 --> Model Class Initialized
INFO - 2024-10-28 14:50:21 --> Model Class Initialized
INFO - 2024-10-28 14:50:21 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-28 14:50:21 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-28 14:50:21 --> Final output sent to browser
DEBUG - 2024-10-28 14:50:21 --> Total execution time: 0.0380
INFO - 2024-10-28 14:50:26 --> Config Class Initialized
INFO - 2024-10-28 14:50:26 --> Hooks Class Initialized
DEBUG - 2024-10-28 14:50:26 --> UTF-8 Support Enabled
INFO - 2024-10-28 14:50:26 --> Utf8 Class Initialized
INFO - 2024-10-28 14:50:26 --> URI Class Initialized
INFO - 2024-10-28 14:50:26 --> Router Class Initialized
INFO - 2024-10-28 14:50:26 --> Output Class Initialized
INFO - 2024-10-28 14:50:26 --> Security Class Initialized
DEBUG - 2024-10-28 14:50:26 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 14:50:26 --> Input Class Initialized
INFO - 2024-10-28 14:50:26 --> Language Class Initialized
ERROR - 2024-10-28 14:50:26 --> TEST ERROR MESSAGE - 2024-10-28 14:50:26
INFO - 2024-10-28 14:50:26 --> Loader Class Initialized
INFO - 2024-10-28 14:50:26 --> Controller Class Initialized
INFO - 2024-10-28 14:50:26 --> Database Driver Class Initialized
INFO - 2024-10-28 14:50:26 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 14:50:26 --> Helper loaded: form_helper
INFO - 2024-10-28 14:50:26 --> Helper loaded: url_helper
INFO - 2024-10-28 14:50:26 --> Model Class Initialized
INFO - 2024-10-28 14:50:26 --> Helper loaded: inflector_helper
INFO - 2024-10-28 14:50:26 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 14:50:26 --> Helper loaded: email_helper
INFO - 2024-10-28 14:50:26 --> Model Class Initialized
INFO - 2024-10-28 14:50:26 --> Model Class Initialized
INFO - 2024-10-28 14:50:26 --> Model Class Initialized
INFO - 2024-10-28 14:50:26 --> Model Class Initialized
INFO - 2024-10-28 14:50:26 --> Model Class Initialized
INFO - 2024-10-28 14:50:26 --> Model Class Initialized
INFO - 2024-10-28 14:50:26 --> Model Class Initialized
DEBUG - 2024-10-28 14:50:26 --> plural called with: company
DEBUG - 2024-10-28 14:50:26 --> is_countable called with!!!!: company
INFO - 2024-10-28 14:50:26 --> Model Class Initialized
INFO - 2024-10-28 14:50:26 --> Model Class Initialized
INFO - 2024-10-28 14:50:26 --> Model Class Initialized
ERROR - 2024-10-28 14:50:26 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 298
INFO - 2024-10-28 14:50:26 --> Final output sent to browser
DEBUG - 2024-10-28 14:50:26 --> Total execution time: 0.0881
INFO - 2024-10-28 14:50:29 --> Config Class Initialized
INFO - 2024-10-28 14:50:29 --> Hooks Class Initialized
DEBUG - 2024-10-28 14:50:29 --> UTF-8 Support Enabled
INFO - 2024-10-28 14:50:29 --> Utf8 Class Initialized
INFO - 2024-10-28 14:50:29 --> URI Class Initialized
INFO - 2024-10-28 14:50:29 --> Router Class Initialized
INFO - 2024-10-28 14:50:29 --> Output Class Initialized
INFO - 2024-10-28 14:50:29 --> Security Class Initialized
DEBUG - 2024-10-28 14:50:29 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 14:50:29 --> Input Class Initialized
INFO - 2024-10-28 14:50:29 --> Language Class Initialized
ERROR - 2024-10-28 14:50:29 --> TEST ERROR MESSAGE - 2024-10-28 14:50:29
INFO - 2024-10-28 14:50:29 --> Loader Class Initialized
INFO - 2024-10-28 14:50:29 --> Controller Class Initialized
INFO - 2024-10-28 14:50:29 --> Database Driver Class Initialized
INFO - 2024-10-28 14:50:29 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 14:50:29 --> Helper loaded: form_helper
INFO - 2024-10-28 14:50:29 --> Helper loaded: url_helper
INFO - 2024-10-28 14:50:29 --> Model Class Initialized
INFO - 2024-10-28 14:50:29 --> Helper loaded: inflector_helper
INFO - 2024-10-28 14:50:29 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 14:50:29 --> Helper loaded: email_helper
INFO - 2024-10-28 14:50:29 --> Model Class Initialized
INFO - 2024-10-28 14:50:29 --> Model Class Initialized
INFO - 2024-10-28 14:50:29 --> Model Class Initialized
INFO - 2024-10-28 14:50:29 --> Model Class Initialized
INFO - 2024-10-28 14:50:29 --> Model Class Initialized
INFO - 2024-10-28 14:50:29 --> Model Class Initialized
INFO - 2024-10-28 14:50:29 --> Model Class Initialized
DEBUG - 2024-10-28 14:50:29 --> plural called with: company
DEBUG - 2024-10-28 14:50:29 --> is_countable called with!!!!: company
INFO - 2024-10-28 14:50:29 --> Model Class Initialized
INFO - 2024-10-28 14:50:29 --> Model Class Initialized
INFO - 2024-10-28 14:50:29 --> Model Class Initialized
INFO - 2024-10-28 14:50:29 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-28 14:50:29 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-28 14:50:29 --> Final output sent to browser
DEBUG - 2024-10-28 14:50:29 --> Total execution time: 0.1929
INFO - 2024-10-28 14:50:30 --> Config Class Initialized
INFO - 2024-10-28 14:50:30 --> Hooks Class Initialized
DEBUG - 2024-10-28 14:50:30 --> UTF-8 Support Enabled
INFO - 2024-10-28 14:50:30 --> Utf8 Class Initialized
INFO - 2024-10-28 14:50:30 --> URI Class Initialized
INFO - 2024-10-28 14:50:30 --> Router Class Initialized
INFO - 2024-10-28 14:50:30 --> Output Class Initialized
INFO - 2024-10-28 14:50:30 --> Security Class Initialized
DEBUG - 2024-10-28 14:50:30 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 14:50:30 --> Input Class Initialized
INFO - 2024-10-28 14:50:30 --> Language Class Initialized
ERROR - 2024-10-28 14:50:30 --> TEST ERROR MESSAGE - 2024-10-28 14:50:30
INFO - 2024-10-28 14:50:30 --> Loader Class Initialized
INFO - 2024-10-28 14:50:30 --> Controller Class Initialized
INFO - 2024-10-28 14:50:30 --> Database Driver Class Initialized
INFO - 2024-10-28 14:50:30 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 14:50:30 --> Helper loaded: form_helper
INFO - 2024-10-28 14:50:30 --> Helper loaded: url_helper
INFO - 2024-10-28 14:50:30 --> Model Class Initialized
INFO - 2024-10-28 14:50:30 --> Helper loaded: inflector_helper
INFO - 2024-10-28 14:50:30 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 14:50:30 --> Helper loaded: email_helper
INFO - 2024-10-28 14:50:30 --> Model Class Initialized
INFO - 2024-10-28 14:50:30 --> Model Class Initialized
INFO - 2024-10-28 14:50:30 --> Model Class Initialized
INFO - 2024-10-28 14:50:30 --> Model Class Initialized
INFO - 2024-10-28 14:50:30 --> Model Class Initialized
INFO - 2024-10-28 14:50:30 --> Model Class Initialized
INFO - 2024-10-28 14:50:30 --> Model Class Initialized
DEBUG - 2024-10-28 14:50:30 --> plural called with: company
DEBUG - 2024-10-28 14:50:30 --> is_countable called with!!!!: company
INFO - 2024-10-28 14:50:30 --> Model Class Initialized
INFO - 2024-10-28 14:50:30 --> Model Class Initialized
INFO - 2024-10-28 14:50:30 --> Model Class Initialized
INFO - 2024-10-28 14:50:30 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-28 14:50:30 --> Final output sent to browser
DEBUG - 2024-10-28 14:50:30 --> Total execution time: 0.0287
INFO - 2024-10-28 14:55:20 --> Config Class Initialized
INFO - 2024-10-28 14:55:20 --> Hooks Class Initialized
DEBUG - 2024-10-28 14:55:20 --> UTF-8 Support Enabled
INFO - 2024-10-28 14:55:20 --> Utf8 Class Initialized
INFO - 2024-10-28 14:55:20 --> URI Class Initialized
DEBUG - 2024-10-28 14:55:20 --> No URI present. Default controller set.
INFO - 2024-10-28 14:55:20 --> Router Class Initialized
INFO - 2024-10-28 14:55:20 --> Output Class Initialized
INFO - 2024-10-28 14:55:20 --> Security Class Initialized
DEBUG - 2024-10-28 14:55:20 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 14:55:20 --> Input Class Initialized
INFO - 2024-10-28 14:55:20 --> Language Class Initialized
ERROR - 2024-10-28 14:55:20 --> TEST ERROR MESSAGE - 2024-10-28 14:55:20
INFO - 2024-10-28 14:55:20 --> Loader Class Initialized
INFO - 2024-10-28 14:55:20 --> Controller Class Initialized
INFO - 2024-10-28 14:55:20 --> Database Driver Class Initialized
INFO - 2024-10-28 14:55:20 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 14:55:20 --> Helper loaded: form_helper
INFO - 2024-10-28 14:55:20 --> Helper loaded: url_helper
INFO - 2024-10-28 14:55:20 --> Model Class Initialized
INFO - 2024-10-28 14:55:20 --> Helper loaded: inflector_helper
INFO - 2024-10-28 14:55:20 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 14:55:20 --> Helper loaded: email_helper
INFO - 2024-10-28 14:55:20 --> Model Class Initialized
INFO - 2024-10-28 14:55:20 --> Model Class Initialized
INFO - 2024-10-28 14:55:20 --> Model Class Initialized
INFO - 2024-10-28 14:55:20 --> Model Class Initialized
INFO - 2024-10-28 14:55:20 --> Model Class Initialized
INFO - 2024-10-28 14:55:20 --> Model Class Initialized
INFO - 2024-10-28 14:55:20 --> Model Class Initialized
DEBUG - 2024-10-28 14:55:20 --> plural called with: company
DEBUG - 2024-10-28 14:55:20 --> is_countable called with!!!!: company
INFO - 2024-10-28 14:55:20 --> Model Class Initialized
INFO - 2024-10-28 14:55:20 --> Model Class Initialized
INFO - 2024-10-28 14:55:20 --> Model Class Initialized
INFO - 2024-10-28 14:55:20 --> Final output sent to browser
DEBUG - 2024-10-28 14:55:20 --> Total execution time: 0.0203
INFO - 2024-10-28 14:58:02 --> Config Class Initialized
INFO - 2024-10-28 14:58:02 --> Hooks Class Initialized
DEBUG - 2024-10-28 14:58:02 --> UTF-8 Support Enabled
INFO - 2024-10-28 14:58:02 --> Utf8 Class Initialized
INFO - 2024-10-28 14:58:02 --> URI Class Initialized
DEBUG - 2024-10-28 14:58:02 --> No URI present. Default controller set.
INFO - 2024-10-28 14:58:02 --> Router Class Initialized
INFO - 2024-10-28 14:58:02 --> Output Class Initialized
INFO - 2024-10-28 14:58:02 --> Security Class Initialized
DEBUG - 2024-10-28 14:58:02 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 14:58:02 --> Input Class Initialized
INFO - 2024-10-28 14:58:02 --> Language Class Initialized
ERROR - 2024-10-28 14:58:02 --> TEST ERROR MESSAGE - 2024-10-28 14:58:02
INFO - 2024-10-28 14:58:02 --> Loader Class Initialized
INFO - 2024-10-28 14:58:02 --> Controller Class Initialized
INFO - 2024-10-28 14:58:02 --> Database Driver Class Initialized
INFO - 2024-10-28 14:58:02 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 14:58:02 --> Helper loaded: form_helper
INFO - 2024-10-28 14:58:02 --> Helper loaded: url_helper
INFO - 2024-10-28 14:58:02 --> Model Class Initialized
INFO - 2024-10-28 14:58:02 --> Helper loaded: inflector_helper
INFO - 2024-10-28 14:58:02 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 14:58:02 --> Helper loaded: email_helper
INFO - 2024-10-28 14:58:02 --> Model Class Initialized
INFO - 2024-10-28 14:58:02 --> Model Class Initialized
INFO - 2024-10-28 14:58:02 --> Model Class Initialized
INFO - 2024-10-28 14:58:02 --> Model Class Initialized
INFO - 2024-10-28 14:58:02 --> Model Class Initialized
INFO - 2024-10-28 14:58:02 --> Model Class Initialized
INFO - 2024-10-28 14:58:02 --> Model Class Initialized
DEBUG - 2024-10-28 14:58:02 --> plural called with: company
DEBUG - 2024-10-28 14:58:02 --> is_countable called with!!!!: company
INFO - 2024-10-28 14:58:02 --> Model Class Initialized
INFO - 2024-10-28 14:58:02 --> Model Class Initialized
INFO - 2024-10-28 14:58:02 --> Model Class Initialized
INFO - 2024-10-28 14:58:02 --> Final output sent to browser
DEBUG - 2024-10-28 14:58:02 --> Total execution time: 0.0217
INFO - 2024-10-28 15:11:51 --> Config Class Initialized
INFO - 2024-10-28 15:11:51 --> Hooks Class Initialized
DEBUG - 2024-10-28 15:11:51 --> UTF-8 Support Enabled
INFO - 2024-10-28 15:11:51 --> Utf8 Class Initialized
INFO - 2024-10-28 15:11:51 --> URI Class Initialized
INFO - 2024-10-28 15:11:51 --> Router Class Initialized
INFO - 2024-10-28 15:11:51 --> Output Class Initialized
INFO - 2024-10-28 15:11:51 --> Security Class Initialized
DEBUG - 2024-10-28 15:11:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 15:11:51 --> Input Class Initialized
INFO - 2024-10-28 15:11:51 --> Language Class Initialized
ERROR - 2024-10-28 15:11:51 --> TEST ERROR MESSAGE - 2024-10-28 15:11:51
INFO - 2024-10-28 15:11:51 --> Loader Class Initialized
INFO - 2024-10-28 15:11:51 --> Controller Class Initialized
INFO - 2024-10-28 15:11:51 --> Database Driver Class Initialized
INFO - 2024-10-28 15:11:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 15:11:51 --> Helper loaded: form_helper
INFO - 2024-10-28 15:11:51 --> Helper loaded: url_helper
INFO - 2024-10-28 15:11:51 --> Model Class Initialized
INFO - 2024-10-28 15:11:51 --> Helper loaded: inflector_helper
INFO - 2024-10-28 15:11:51 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 15:11:51 --> Helper loaded: email_helper
INFO - 2024-10-28 15:11:51 --> Model Class Initialized
INFO - 2024-10-28 15:11:51 --> Model Class Initialized
INFO - 2024-10-28 15:11:51 --> Model Class Initialized
INFO - 2024-10-28 15:11:51 --> Model Class Initialized
INFO - 2024-10-28 15:11:51 --> Model Class Initialized
INFO - 2024-10-28 15:11:51 --> Model Class Initialized
INFO - 2024-10-28 15:11:51 --> Model Class Initialized
DEBUG - 2024-10-28 15:11:51 --> plural called with: company
DEBUG - 2024-10-28 15:11:51 --> is_countable called with!!!!: company
INFO - 2024-10-28 15:11:51 --> Model Class Initialized
INFO - 2024-10-28 15:11:51 --> Model Class Initialized
INFO - 2024-10-28 15:11:51 --> Model Class Initialized
INFO - 2024-10-28 15:11:52 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-28 15:11:52 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-28 15:11:52 --> Final output sent to browser
DEBUG - 2024-10-28 15:11:52 --> Total execution time: 0.6456
INFO - 2024-10-28 15:11:58 --> Config Class Initialized
INFO - 2024-10-28 15:11:58 --> Hooks Class Initialized
DEBUG - 2024-10-28 15:11:58 --> UTF-8 Support Enabled
INFO - 2024-10-28 15:11:58 --> Utf8 Class Initialized
INFO - 2024-10-28 15:11:58 --> URI Class Initialized
INFO - 2024-10-28 15:11:58 --> Router Class Initialized
INFO - 2024-10-28 15:11:58 --> Output Class Initialized
INFO - 2024-10-28 15:11:58 --> Security Class Initialized
DEBUG - 2024-10-28 15:11:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 15:11:58 --> Input Class Initialized
INFO - 2024-10-28 15:11:58 --> Language Class Initialized
ERROR - 2024-10-28 15:11:58 --> TEST ERROR MESSAGE - 2024-10-28 15:11:58
INFO - 2024-10-28 15:11:58 --> Loader Class Initialized
INFO - 2024-10-28 15:11:58 --> Controller Class Initialized
INFO - 2024-10-28 15:11:58 --> Database Driver Class Initialized
INFO - 2024-10-28 15:11:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 15:11:58 --> Helper loaded: form_helper
INFO - 2024-10-28 15:11:58 --> Helper loaded: url_helper
INFO - 2024-10-28 15:11:58 --> Model Class Initialized
INFO - 2024-10-28 15:11:58 --> Helper loaded: inflector_helper
INFO - 2024-10-28 15:11:58 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 15:11:58 --> Helper loaded: email_helper
INFO - 2024-10-28 15:11:58 --> Model Class Initialized
INFO - 2024-10-28 15:11:58 --> Model Class Initialized
INFO - 2024-10-28 15:11:58 --> Model Class Initialized
INFO - 2024-10-28 15:11:58 --> Model Class Initialized
INFO - 2024-10-28 15:11:58 --> Model Class Initialized
INFO - 2024-10-28 15:11:58 --> Model Class Initialized
INFO - 2024-10-28 15:11:58 --> Model Class Initialized
DEBUG - 2024-10-28 15:11:58 --> plural called with: company
DEBUG - 2024-10-28 15:11:58 --> is_countable called with!!!!: company
INFO - 2024-10-28 15:11:58 --> Model Class Initialized
INFO - 2024-10-28 15:11:58 --> Model Class Initialized
INFO - 2024-10-28 15:11:58 --> Model Class Initialized
INFO - 2024-10-28 15:11:58 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-28 15:11:58 --> Final output sent to browser
DEBUG - 2024-10-28 15:11:58 --> Total execution time: 0.0209
INFO - 2024-10-28 15:29:13 --> Config Class Initialized
INFO - 2024-10-28 15:29:13 --> Hooks Class Initialized
DEBUG - 2024-10-28 15:29:13 --> UTF-8 Support Enabled
INFO - 2024-10-28 15:29:13 --> Utf8 Class Initialized
INFO - 2024-10-28 15:29:13 --> URI Class Initialized
DEBUG - 2024-10-28 15:29:13 --> No URI present. Default controller set.
INFO - 2024-10-28 15:29:13 --> Router Class Initialized
INFO - 2024-10-28 15:29:13 --> Output Class Initialized
INFO - 2024-10-28 15:29:13 --> Security Class Initialized
DEBUG - 2024-10-28 15:29:13 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 15:29:13 --> Input Class Initialized
INFO - 2024-10-28 15:29:13 --> Language Class Initialized
ERROR - 2024-10-28 15:29:13 --> TEST ERROR MESSAGE - 2024-10-28 15:29:13
INFO - 2024-10-28 15:29:13 --> Loader Class Initialized
INFO - 2024-10-28 15:29:13 --> Controller Class Initialized
INFO - 2024-10-28 15:29:13 --> Database Driver Class Initialized
INFO - 2024-10-28 15:29:13 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 15:29:13 --> Helper loaded: form_helper
INFO - 2024-10-28 15:29:13 --> Helper loaded: url_helper
INFO - 2024-10-28 15:29:13 --> Model Class Initialized
INFO - 2024-10-28 15:29:13 --> Helper loaded: inflector_helper
INFO - 2024-10-28 15:29:13 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 15:29:13 --> Helper loaded: email_helper
INFO - 2024-10-28 15:29:13 --> Model Class Initialized
INFO - 2024-10-28 15:29:13 --> Model Class Initialized
INFO - 2024-10-28 15:29:13 --> Model Class Initialized
INFO - 2024-10-28 15:29:13 --> Model Class Initialized
INFO - 2024-10-28 15:29:13 --> Model Class Initialized
INFO - 2024-10-28 15:29:13 --> Model Class Initialized
INFO - 2024-10-28 15:29:13 --> Model Class Initialized
DEBUG - 2024-10-28 15:29:13 --> plural called with: company
DEBUG - 2024-10-28 15:29:13 --> is_countable called with!!!!: company
INFO - 2024-10-28 15:29:13 --> Model Class Initialized
INFO - 2024-10-28 15:29:13 --> Model Class Initialized
INFO - 2024-10-28 15:29:13 --> Model Class Initialized
INFO - 2024-10-28 15:29:13 --> Final output sent to browser
DEBUG - 2024-10-28 15:29:13 --> Total execution time: 0.0227
INFO - 2024-10-28 15:29:14 --> Config Class Initialized
INFO - 2024-10-28 15:29:14 --> Hooks Class Initialized
DEBUG - 2024-10-28 15:29:14 --> UTF-8 Support Enabled
INFO - 2024-10-28 15:29:14 --> Utf8 Class Initialized
INFO - 2024-10-28 15:29:14 --> URI Class Initialized
DEBUG - 2024-10-28 15:29:14 --> No URI present. Default controller set.
INFO - 2024-10-28 15:29:14 --> Router Class Initialized
INFO - 2024-10-28 15:29:14 --> Output Class Initialized
INFO - 2024-10-28 15:29:14 --> Security Class Initialized
DEBUG - 2024-10-28 15:29:14 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 15:29:14 --> Input Class Initialized
INFO - 2024-10-28 15:29:14 --> Language Class Initialized
ERROR - 2024-10-28 15:29:14 --> TEST ERROR MESSAGE - 2024-10-28 15:29:14
INFO - 2024-10-28 15:29:14 --> Loader Class Initialized
INFO - 2024-10-28 15:29:14 --> Controller Class Initialized
INFO - 2024-10-28 15:29:14 --> Database Driver Class Initialized
INFO - 2024-10-28 15:29:14 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 15:29:14 --> Helper loaded: form_helper
INFO - 2024-10-28 15:29:14 --> Helper loaded: url_helper
INFO - 2024-10-28 15:29:14 --> Model Class Initialized
INFO - 2024-10-28 15:29:14 --> Helper loaded: inflector_helper
INFO - 2024-10-28 15:29:14 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 15:29:14 --> Helper loaded: email_helper
INFO - 2024-10-28 15:29:14 --> Model Class Initialized
INFO - 2024-10-28 15:29:14 --> Model Class Initialized
INFO - 2024-10-28 15:29:14 --> Model Class Initialized
INFO - 2024-10-28 15:29:14 --> Model Class Initialized
INFO - 2024-10-28 15:29:14 --> Model Class Initialized
INFO - 2024-10-28 15:29:14 --> Model Class Initialized
INFO - 2024-10-28 15:29:14 --> Model Class Initialized
DEBUG - 2024-10-28 15:29:14 --> plural called with: company
DEBUG - 2024-10-28 15:29:14 --> is_countable called with!!!!: company
INFO - 2024-10-28 15:29:14 --> Model Class Initialized
INFO - 2024-10-28 15:29:14 --> Model Class Initialized
INFO - 2024-10-28 15:29:14 --> Model Class Initialized
INFO - 2024-10-28 15:29:14 --> Final output sent to browser
DEBUG - 2024-10-28 15:29:14 --> Total execution time: 0.0315
INFO - 2024-10-28 17:28:12 --> Config Class Initialized
INFO - 2024-10-28 17:28:12 --> Hooks Class Initialized
DEBUG - 2024-10-28 17:28:12 --> UTF-8 Support Enabled
INFO - 2024-10-28 17:28:12 --> Utf8 Class Initialized
INFO - 2024-10-28 17:28:12 --> URI Class Initialized
INFO - 2024-10-28 17:28:12 --> Router Class Initialized
INFO - 2024-10-28 17:28:12 --> Output Class Initialized
INFO - 2024-10-28 17:28:12 --> Security Class Initialized
DEBUG - 2024-10-28 17:28:12 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 17:28:12 --> Input Class Initialized
INFO - 2024-10-28 17:28:12 --> Language Class Initialized
ERROR - 2024-10-28 17:28:12 --> TEST ERROR MESSAGE - 2024-10-28 17:28:12
INFO - 2024-10-28 17:28:12 --> Loader Class Initialized
INFO - 2024-10-28 17:28:12 --> Controller Class Initialized
INFO - 2024-10-28 17:28:12 --> Database Driver Class Initialized
INFO - 2024-10-28 17:28:12 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 17:28:12 --> Helper loaded: form_helper
INFO - 2024-10-28 17:28:12 --> Helper loaded: url_helper
INFO - 2024-10-28 17:28:12 --> Model Class Initialized
INFO - 2024-10-28 17:28:12 --> Helper loaded: inflector_helper
INFO - 2024-10-28 17:28:12 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 17:28:12 --> Helper loaded: email_helper
INFO - 2024-10-28 17:28:12 --> Model Class Initialized
INFO - 2024-10-28 17:28:12 --> Model Class Initialized
INFO - 2024-10-28 17:28:12 --> Model Class Initialized
INFO - 2024-10-28 17:28:12 --> Model Class Initialized
INFO - 2024-10-28 17:28:12 --> Model Class Initialized
INFO - 2024-10-28 17:28:12 --> Model Class Initialized
INFO - 2024-10-28 17:28:12 --> Model Class Initialized
DEBUG - 2024-10-28 17:28:12 --> plural called with: company
DEBUG - 2024-10-28 17:28:12 --> is_countable called with!!!!: company
INFO - 2024-10-28 17:28:12 --> Model Class Initialized
INFO - 2024-10-28 17:28:12 --> Model Class Initialized
INFO - 2024-10-28 17:28:12 --> Model Class Initialized
ERROR - 2024-10-28 17:28:12 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 298
ERROR - 2024-10-28 17:28:12 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 312
ERROR - 2024-10-28 17:28:12 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 317
INFO - 2024-10-28 17:28:12 --> Final output sent to browser
DEBUG - 2024-10-28 17:28:12 --> Total execution time: 0.1206
INFO - 2024-10-28 17:32:27 --> Config Class Initialized
INFO - 2024-10-28 17:32:27 --> Hooks Class Initialized
DEBUG - 2024-10-28 17:32:27 --> UTF-8 Support Enabled
INFO - 2024-10-28 17:32:27 --> Utf8 Class Initialized
INFO - 2024-10-28 17:32:27 --> URI Class Initialized
INFO - 2024-10-28 17:32:27 --> Router Class Initialized
INFO - 2024-10-28 17:32:27 --> Output Class Initialized
INFO - 2024-10-28 17:32:27 --> Security Class Initialized
DEBUG - 2024-10-28 17:32:27 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 17:32:27 --> Input Class Initialized
INFO - 2024-10-28 17:32:27 --> Language Class Initialized
ERROR - 2024-10-28 17:32:27 --> TEST ERROR MESSAGE - 2024-10-28 17:32:27
INFO - 2024-10-28 17:32:27 --> Loader Class Initialized
INFO - 2024-10-28 17:32:27 --> Controller Class Initialized
INFO - 2024-10-28 17:32:27 --> Database Driver Class Initialized
INFO - 2024-10-28 17:32:27 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 17:32:27 --> Helper loaded: form_helper
INFO - 2024-10-28 17:32:27 --> Helper loaded: url_helper
INFO - 2024-10-28 17:32:27 --> Model Class Initialized
INFO - 2024-10-28 17:32:27 --> Helper loaded: inflector_helper
INFO - 2024-10-28 17:32:27 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 17:32:27 --> Helper loaded: email_helper
INFO - 2024-10-28 17:32:27 --> Model Class Initialized
INFO - 2024-10-28 17:32:27 --> Model Class Initialized
INFO - 2024-10-28 17:32:27 --> Model Class Initialized
INFO - 2024-10-28 17:32:27 --> Model Class Initialized
INFO - 2024-10-28 17:32:27 --> Model Class Initialized
INFO - 2024-10-28 17:32:27 --> Model Class Initialized
INFO - 2024-10-28 17:32:27 --> Model Class Initialized
DEBUG - 2024-10-28 17:32:27 --> plural called with: company
DEBUG - 2024-10-28 17:32:27 --> is_countable called with!!!!: company
INFO - 2024-10-28 17:32:27 --> Model Class Initialized
INFO - 2024-10-28 17:32:27 --> Model Class Initialized
INFO - 2024-10-28 17:32:27 --> Model Class Initialized
ERROR - 2024-10-28 17:32:27 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 298
ERROR - 2024-10-28 17:32:27 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 312
ERROR - 2024-10-28 17:32:27 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 317
INFO - 2024-10-28 17:32:27 --> Final output sent to browser
DEBUG - 2024-10-28 17:32:27 --> Total execution time: 0.0743
INFO - 2024-10-28 17:32:58 --> Config Class Initialized
INFO - 2024-10-28 17:32:58 --> Hooks Class Initialized
DEBUG - 2024-10-28 17:32:58 --> UTF-8 Support Enabled
INFO - 2024-10-28 17:32:58 --> Utf8 Class Initialized
INFO - 2024-10-28 17:32:58 --> URI Class Initialized
DEBUG - 2024-10-28 17:32:58 --> No URI present. Default controller set.
INFO - 2024-10-28 17:32:58 --> Router Class Initialized
INFO - 2024-10-28 17:32:58 --> Output Class Initialized
INFO - 2024-10-28 17:32:58 --> Security Class Initialized
DEBUG - 2024-10-28 17:32:58 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 17:32:58 --> Input Class Initialized
INFO - 2024-10-28 17:32:58 --> Language Class Initialized
ERROR - 2024-10-28 17:32:58 --> TEST ERROR MESSAGE - 2024-10-28 17:32:58
INFO - 2024-10-28 17:32:58 --> Loader Class Initialized
INFO - 2024-10-28 17:32:58 --> Controller Class Initialized
INFO - 2024-10-28 17:32:58 --> Database Driver Class Initialized
INFO - 2024-10-28 17:32:58 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 17:32:58 --> Helper loaded: form_helper
INFO - 2024-10-28 17:32:58 --> Helper loaded: url_helper
INFO - 2024-10-28 17:32:58 --> Model Class Initialized
INFO - 2024-10-28 17:32:58 --> Helper loaded: inflector_helper
INFO - 2024-10-28 17:32:58 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 17:32:58 --> Helper loaded: email_helper
INFO - 2024-10-28 17:32:58 --> Model Class Initialized
INFO - 2024-10-28 17:32:58 --> Model Class Initialized
INFO - 2024-10-28 17:32:58 --> Model Class Initialized
INFO - 2024-10-28 17:32:58 --> Model Class Initialized
INFO - 2024-10-28 17:32:58 --> Model Class Initialized
INFO - 2024-10-28 17:32:58 --> Model Class Initialized
INFO - 2024-10-28 17:32:58 --> Model Class Initialized
DEBUG - 2024-10-28 17:32:58 --> plural called with: company
DEBUG - 2024-10-28 17:32:58 --> is_countable called with!!!!: company
INFO - 2024-10-28 17:32:58 --> Model Class Initialized
INFO - 2024-10-28 17:32:58 --> Model Class Initialized
INFO - 2024-10-28 17:32:58 --> Model Class Initialized
ERROR - 2024-10-28 17:32:58 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 298
ERROR - 2024-10-28 17:32:58 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 312
ERROR - 2024-10-28 17:32:58 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 317
INFO - 2024-10-28 17:32:59 --> Final output sent to browser
DEBUG - 2024-10-28 17:32:59 --> Total execution time: 0.0862
INFO - 2024-10-28 17:37:54 --> Config Class Initialized
INFO - 2024-10-28 17:37:54 --> Hooks Class Initialized
DEBUG - 2024-10-28 17:37:54 --> UTF-8 Support Enabled
INFO - 2024-10-28 17:37:54 --> Utf8 Class Initialized
INFO - 2024-10-28 17:37:54 --> URI Class Initialized
INFO - 2024-10-28 17:37:54 --> Router Class Initialized
INFO - 2024-10-28 17:37:54 --> Output Class Initialized
INFO - 2024-10-28 17:37:54 --> Security Class Initialized
DEBUG - 2024-10-28 17:37:54 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 17:37:54 --> Input Class Initialized
INFO - 2024-10-28 17:37:54 --> Language Class Initialized
ERROR - 2024-10-28 17:37:54 --> TEST ERROR MESSAGE - 2024-10-28 17:37:54
INFO - 2024-10-28 17:37:54 --> Loader Class Initialized
INFO - 2024-10-28 17:37:54 --> Controller Class Initialized
INFO - 2024-10-28 17:37:54 --> Database Driver Class Initialized
INFO - 2024-10-28 17:37:54 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 17:37:54 --> Helper loaded: form_helper
INFO - 2024-10-28 17:37:54 --> Helper loaded: url_helper
INFO - 2024-10-28 17:37:54 --> Model Class Initialized
INFO - 2024-10-28 17:37:54 --> Helper loaded: inflector_helper
INFO - 2024-10-28 17:37:54 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 17:37:54 --> Helper loaded: email_helper
INFO - 2024-10-28 17:37:54 --> Model Class Initialized
INFO - 2024-10-28 17:37:54 --> Model Class Initialized
INFO - 2024-10-28 17:37:54 --> Model Class Initialized
INFO - 2024-10-28 17:37:54 --> Model Class Initialized
INFO - 2024-10-28 17:37:54 --> Model Class Initialized
INFO - 2024-10-28 17:37:54 --> Model Class Initialized
INFO - 2024-10-28 17:37:54 --> Model Class Initialized
DEBUG - 2024-10-28 17:37:54 --> plural called with: company
DEBUG - 2024-10-28 17:37:54 --> is_countable called with!!!!: company
INFO - 2024-10-28 17:37:54 --> Model Class Initialized
INFO - 2024-10-28 17:37:54 --> Model Class Initialized
INFO - 2024-10-28 17:37:54 --> Model Class Initialized
ERROR - 2024-10-28 17:37:54 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 298
ERROR - 2024-10-28 17:37:54 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 312
ERROR - 2024-10-28 17:37:54 --> Severity: Notice --> Trying to access array offset on value of type null /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 317
INFO - 2024-10-28 17:37:54 --> Final output sent to browser
DEBUG - 2024-10-28 17:37:54 --> Total execution time: 0.0967
INFO - 2024-10-28 17:43:50 --> Config Class Initialized
INFO - 2024-10-28 17:43:50 --> Hooks Class Initialized
DEBUG - 2024-10-28 17:43:50 --> UTF-8 Support Enabled
INFO - 2024-10-28 17:43:50 --> Utf8 Class Initialized
INFO - 2024-10-28 17:43:50 --> URI Class Initialized
INFO - 2024-10-28 17:43:50 --> Router Class Initialized
INFO - 2024-10-28 17:43:50 --> Output Class Initialized
INFO - 2024-10-28 17:43:50 --> Security Class Initialized
DEBUG - 2024-10-28 17:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 17:43:50 --> Input Class Initialized
INFO - 2024-10-28 17:43:50 --> Language Class Initialized
ERROR - 2024-10-28 17:43:50 --> TEST ERROR MESSAGE - 2024-10-28 17:43:50
INFO - 2024-10-28 17:43:50 --> Loader Class Initialized
INFO - 2024-10-28 17:43:50 --> Controller Class Initialized
INFO - 2024-10-28 17:43:50 --> Database Driver Class Initialized
INFO - 2024-10-28 17:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 17:43:50 --> Helper loaded: form_helper
INFO - 2024-10-28 17:43:50 --> Helper loaded: url_helper
INFO - 2024-10-28 17:43:50 --> Model Class Initialized
INFO - 2024-10-28 17:43:50 --> Helper loaded: inflector_helper
INFO - 2024-10-28 17:43:50 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 17:43:50 --> Helper loaded: email_helper
INFO - 2024-10-28 17:43:50 --> Model Class Initialized
INFO - 2024-10-28 17:43:50 --> Model Class Initialized
INFO - 2024-10-28 17:43:50 --> Model Class Initialized
INFO - 2024-10-28 17:43:50 --> Model Class Initialized
INFO - 2024-10-28 17:43:50 --> Model Class Initialized
INFO - 2024-10-28 17:43:50 --> Model Class Initialized
INFO - 2024-10-28 17:43:50 --> Model Class Initialized
DEBUG - 2024-10-28 17:43:50 --> plural called with: company
DEBUG - 2024-10-28 17:43:50 --> is_countable called with!!!!: company
INFO - 2024-10-28 17:43:50 --> Model Class Initialized
INFO - 2024-10-28 17:43:50 --> Model Class Initialized
INFO - 2024-10-28 17:43:50 --> Model Class Initialized
INFO - 2024-10-28 17:43:50 --> Config Class Initialized
INFO - 2024-10-28 17:43:50 --> Hooks Class Initialized
DEBUG - 2024-10-28 17:43:50 --> UTF-8 Support Enabled
INFO - 2024-10-28 17:43:50 --> Utf8 Class Initialized
INFO - 2024-10-28 17:43:50 --> URI Class Initialized
INFO - 2024-10-28 17:43:50 --> Router Class Initialized
INFO - 2024-10-28 17:43:50 --> Output Class Initialized
INFO - 2024-10-28 17:43:50 --> Security Class Initialized
DEBUG - 2024-10-28 17:43:50 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 17:43:50 --> Input Class Initialized
INFO - 2024-10-28 17:43:50 --> Language Class Initialized
ERROR - 2024-10-28 17:43:50 --> TEST ERROR MESSAGE - 2024-10-28 17:43:50
INFO - 2024-10-28 17:43:50 --> Loader Class Initialized
INFO - 2024-10-28 17:43:50 --> Controller Class Initialized
INFO - 2024-10-28 17:43:50 --> Database Driver Class Initialized
INFO - 2024-10-28 17:43:50 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 17:43:50 --> Helper loaded: form_helper
INFO - 2024-10-28 17:43:50 --> Helper loaded: url_helper
INFO - 2024-10-28 17:43:50 --> Model Class Initialized
INFO - 2024-10-28 17:43:50 --> Helper loaded: inflector_helper
INFO - 2024-10-28 17:43:50 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 17:43:50 --> Helper loaded: email_helper
INFO - 2024-10-28 17:43:50 --> Model Class Initialized
INFO - 2024-10-28 17:43:50 --> Model Class Initialized
INFO - 2024-10-28 17:43:50 --> Model Class Initialized
INFO - 2024-10-28 17:43:50 --> Model Class Initialized
INFO - 2024-10-28 17:43:50 --> Model Class Initialized
INFO - 2024-10-28 17:43:50 --> Model Class Initialized
INFO - 2024-10-28 17:43:50 --> Model Class Initialized
DEBUG - 2024-10-28 17:43:50 --> plural called with: company
DEBUG - 2024-10-28 17:43:50 --> is_countable called with!!!!: company
INFO - 2024-10-28 17:43:50 --> Model Class Initialized
INFO - 2024-10-28 17:43:50 --> Model Class Initialized
INFO - 2024-10-28 17:43:50 --> Model Class Initialized
INFO - 2024-10-28 17:43:50 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/login.php
INFO - 2024-10-28 17:43:50 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-28 17:43:50 --> Final output sent to browser
DEBUG - 2024-10-28 17:43:50 --> Total execution time: 0.0195
INFO - 2024-10-28 17:44:16 --> Config Class Initialized
INFO - 2024-10-28 17:44:16 --> Hooks Class Initialized
DEBUG - 2024-10-28 17:44:16 --> UTF-8 Support Enabled
INFO - 2024-10-28 17:44:16 --> Utf8 Class Initialized
INFO - 2024-10-28 17:44:16 --> URI Class Initialized
INFO - 2024-10-28 17:44:16 --> Router Class Initialized
INFO - 2024-10-28 17:44:16 --> Output Class Initialized
INFO - 2024-10-28 17:44:16 --> Security Class Initialized
DEBUG - 2024-10-28 17:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 17:44:16 --> Input Class Initialized
INFO - 2024-10-28 17:44:16 --> Language Class Initialized
ERROR - 2024-10-28 17:44:16 --> TEST ERROR MESSAGE - 2024-10-28 17:44:16
INFO - 2024-10-28 17:44:16 --> Loader Class Initialized
INFO - 2024-10-28 17:44:16 --> Controller Class Initialized
INFO - 2024-10-28 17:44:16 --> Database Driver Class Initialized
INFO - 2024-10-28 17:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 17:44:16 --> Helper loaded: form_helper
INFO - 2024-10-28 17:44:16 --> Helper loaded: url_helper
INFO - 2024-10-28 17:44:16 --> Model Class Initialized
INFO - 2024-10-28 17:44:16 --> Helper loaded: inflector_helper
INFO - 2024-10-28 17:44:16 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 17:44:16 --> Helper loaded: email_helper
INFO - 2024-10-28 17:44:16 --> Model Class Initialized
INFO - 2024-10-28 17:44:16 --> Model Class Initialized
INFO - 2024-10-28 17:44:16 --> Model Class Initialized
INFO - 2024-10-28 17:44:16 --> Model Class Initialized
INFO - 2024-10-28 17:44:16 --> Model Class Initialized
INFO - 2024-10-28 17:44:16 --> Model Class Initialized
INFO - 2024-10-28 17:44:16 --> Model Class Initialized
DEBUG - 2024-10-28 17:44:16 --> plural called with: company
DEBUG - 2024-10-28 17:44:16 --> is_countable called with!!!!: company
INFO - 2024-10-28 17:44:16 --> Model Class Initialized
INFO - 2024-10-28 17:44:16 --> Model Class Initialized
INFO - 2024-10-28 17:44:16 --> Model Class Initialized
INFO - 2024-10-28 17:44:16 --> Config Class Initialized
INFO - 2024-10-28 17:44:16 --> Hooks Class Initialized
DEBUG - 2024-10-28 17:44:16 --> UTF-8 Support Enabled
INFO - 2024-10-28 17:44:16 --> Utf8 Class Initialized
INFO - 2024-10-28 17:44:16 --> URI Class Initialized
INFO - 2024-10-28 17:44:16 --> Router Class Initialized
INFO - 2024-10-28 17:44:16 --> Output Class Initialized
INFO - 2024-10-28 17:44:16 --> Security Class Initialized
DEBUG - 2024-10-28 17:44:16 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 17:44:16 --> Input Class Initialized
INFO - 2024-10-28 17:44:16 --> Language Class Initialized
ERROR - 2024-10-28 17:44:16 --> TEST ERROR MESSAGE - 2024-10-28 17:44:16
INFO - 2024-10-28 17:44:16 --> Loader Class Initialized
INFO - 2024-10-28 17:44:16 --> Controller Class Initialized
INFO - 2024-10-28 17:44:16 --> Database Driver Class Initialized
INFO - 2024-10-28 17:44:16 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 17:44:16 --> Helper loaded: form_helper
INFO - 2024-10-28 17:44:16 --> Helper loaded: url_helper
INFO - 2024-10-28 17:44:16 --> Model Class Initialized
INFO - 2024-10-28 17:44:16 --> Helper loaded: inflector_helper
INFO - 2024-10-28 17:44:16 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 17:44:16 --> Helper loaded: email_helper
INFO - 2024-10-28 17:44:16 --> Model Class Initialized
INFO - 2024-10-28 17:44:16 --> Model Class Initialized
INFO - 2024-10-28 17:44:16 --> Model Class Initialized
INFO - 2024-10-28 17:44:16 --> Model Class Initialized
INFO - 2024-10-28 17:44:16 --> Model Class Initialized
INFO - 2024-10-28 17:44:16 --> Model Class Initialized
INFO - 2024-10-28 17:44:16 --> Model Class Initialized
DEBUG - 2024-10-28 17:44:16 --> plural called with: company
DEBUG - 2024-10-28 17:44:16 --> is_countable called with!!!!: company
INFO - 2024-10-28 17:44:16 --> Model Class Initialized
INFO - 2024-10-28 17:44:16 --> Model Class Initialized
INFO - 2024-10-28 17:44:16 --> Model Class Initialized
ERROR - 2024-10-28 17:44:17 --> Severity: Notice --> Undefined index: freetext /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 17:44:17 --> Severity: Notice --> Undefined index: socialDes /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 17:44:17 --> Severity: Notice --> Undefined index: company /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 17:44:17 --> Severity: Notice --> Undefined index: division /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 17:44:17 --> Severity: Notice --> Undefined index: dataGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 17:44:17 --> Severity: Notice --> Undefined index: finalGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
INFO - 2024-10-28 17:44:17 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-28 17:44:17 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-28 17:44:17 --> Final output sent to browser
DEBUG - 2024-10-28 17:44:17 --> Total execution time: 0.9597
INFO - 2024-10-28 17:44:39 --> Config Class Initialized
INFO - 2024-10-28 17:44:39 --> Hooks Class Initialized
DEBUG - 2024-10-28 17:44:39 --> UTF-8 Support Enabled
INFO - 2024-10-28 17:44:39 --> Utf8 Class Initialized
INFO - 2024-10-28 17:44:39 --> URI Class Initialized
INFO - 2024-10-28 17:44:39 --> Router Class Initialized
INFO - 2024-10-28 17:44:39 --> Output Class Initialized
INFO - 2024-10-28 17:44:39 --> Security Class Initialized
DEBUG - 2024-10-28 17:44:39 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 17:44:39 --> Input Class Initialized
INFO - 2024-10-28 17:44:39 --> Language Class Initialized
ERROR - 2024-10-28 17:44:39 --> TEST ERROR MESSAGE - 2024-10-28 17:44:39
INFO - 2024-10-28 17:44:39 --> Loader Class Initialized
INFO - 2024-10-28 17:44:39 --> Controller Class Initialized
INFO - 2024-10-28 17:44:39 --> Database Driver Class Initialized
INFO - 2024-10-28 17:44:39 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 17:44:39 --> Helper loaded: form_helper
INFO - 2024-10-28 17:44:39 --> Helper loaded: url_helper
INFO - 2024-10-28 17:44:39 --> Model Class Initialized
INFO - 2024-10-28 17:44:39 --> Helper loaded: inflector_helper
INFO - 2024-10-28 17:44:39 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 17:44:39 --> Helper loaded: email_helper
INFO - 2024-10-28 17:44:39 --> Model Class Initialized
INFO - 2024-10-28 17:44:39 --> Model Class Initialized
INFO - 2024-10-28 17:44:39 --> Model Class Initialized
INFO - 2024-10-28 17:44:39 --> Model Class Initialized
INFO - 2024-10-28 17:44:39 --> Model Class Initialized
INFO - 2024-10-28 17:44:39 --> Model Class Initialized
INFO - 2024-10-28 17:44:39 --> Model Class Initialized
DEBUG - 2024-10-28 17:44:39 --> plural called with: company
DEBUG - 2024-10-28 17:44:39 --> is_countable called with!!!!: company
INFO - 2024-10-28 17:44:39 --> Model Class Initialized
INFO - 2024-10-28 17:44:39 --> Model Class Initialized
INFO - 2024-10-28 17:44:39 --> Model Class Initialized
INFO - 2024-10-28 17:44:40 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php
INFO - 2024-10-28 17:44:40 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin_template.php
INFO - 2024-10-28 17:44:40 --> Final output sent to browser
DEBUG - 2024-10-28 17:44:40 --> Total execution time: 0.7196
INFO - 2024-10-28 17:44:51 --> Config Class Initialized
INFO - 2024-10-28 17:44:51 --> Hooks Class Initialized
DEBUG - 2024-10-28 17:44:51 --> UTF-8 Support Enabled
INFO - 2024-10-28 17:44:51 --> Utf8 Class Initialized
INFO - 2024-10-28 17:44:51 --> URI Class Initialized
INFO - 2024-10-28 17:44:51 --> Router Class Initialized
INFO - 2024-10-28 17:44:51 --> Output Class Initialized
INFO - 2024-10-28 17:44:51 --> Security Class Initialized
DEBUG - 2024-10-28 17:44:51 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 17:44:51 --> Input Class Initialized
INFO - 2024-10-28 17:44:51 --> Language Class Initialized
ERROR - 2024-10-28 17:44:51 --> TEST ERROR MESSAGE - 2024-10-28 17:44:51
INFO - 2024-10-28 17:44:51 --> Loader Class Initialized
INFO - 2024-10-28 17:44:51 --> Controller Class Initialized
INFO - 2024-10-28 17:44:51 --> Database Driver Class Initialized
INFO - 2024-10-28 17:44:51 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 17:44:51 --> Helper loaded: form_helper
INFO - 2024-10-28 17:44:51 --> Helper loaded: url_helper
INFO - 2024-10-28 17:44:51 --> Model Class Initialized
INFO - 2024-10-28 17:44:51 --> Helper loaded: inflector_helper
INFO - 2024-10-28 17:44:51 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 17:44:51 --> Helper loaded: email_helper
INFO - 2024-10-28 17:44:51 --> Model Class Initialized
INFO - 2024-10-28 17:44:51 --> Model Class Initialized
INFO - 2024-10-28 17:44:51 --> Model Class Initialized
INFO - 2024-10-28 17:44:51 --> Model Class Initialized
INFO - 2024-10-28 17:44:51 --> Model Class Initialized
INFO - 2024-10-28 17:44:51 --> Model Class Initialized
INFO - 2024-10-28 17:44:51 --> Model Class Initialized
DEBUG - 2024-10-28 17:44:51 --> plural called with: company
DEBUG - 2024-10-28 17:44:51 --> is_countable called with!!!!: company
INFO - 2024-10-28 17:44:51 --> Model Class Initialized
INFO - 2024-10-28 17:44:51 --> Model Class Initialized
INFO - 2024-10-28 17:44:51 --> Model Class Initialized
INFO - 2024-10-28 17:44:51 --> File loaded: /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/report.php
INFO - 2024-10-28 17:44:51 --> Final output sent to browser
DEBUG - 2024-10-28 17:44:51 --> Total execution time: 0.0231
INFO - 2024-10-28 18:29:36 --> Config Class Initialized
INFO - 2024-10-28 18:29:36 --> Hooks Class Initialized
DEBUG - 2024-10-28 18:29:36 --> UTF-8 Support Enabled
INFO - 2024-10-28 18:29:36 --> Utf8 Class Initialized
INFO - 2024-10-28 18:29:36 --> URI Class Initialized
INFO - 2024-10-28 18:29:36 --> Router Class Initialized
INFO - 2024-10-28 18:29:36 --> Output Class Initialized
INFO - 2024-10-28 18:29:36 --> Security Class Initialized
DEBUG - 2024-10-28 18:29:36 --> Global POST, GET and COOKIE data sanitized
INFO - 2024-10-28 18:29:36 --> Input Class Initialized
INFO - 2024-10-28 18:29:36 --> Language Class Initialized
ERROR - 2024-10-28 18:29:36 --> TEST ERROR MESSAGE - 2024-10-28 18:29:36
INFO - 2024-10-28 18:29:36 --> Loader Class Initialized
INFO - 2024-10-28 18:29:36 --> Controller Class Initialized
INFO - 2024-10-28 18:29:36 --> Database Driver Class Initialized
INFO - 2024-10-28 18:29:36 --> Session: Class initialized using 'files' driver.
INFO - 2024-10-28 18:29:36 --> Helper loaded: form_helper
INFO - 2024-10-28 18:29:36 --> Helper loaded: url_helper
INFO - 2024-10-28 18:29:36 --> Model Class Initialized
INFO - 2024-10-28 18:29:36 --> Helper loaded: inflector_helper
INFO - 2024-10-28 18:29:36 --> Helper loaded: mezoo_helper
INFO - 2024-10-28 18:29:36 --> Helper loaded: email_helper
INFO - 2024-10-28 18:29:36 --> Model Class Initialized
INFO - 2024-10-28 18:29:36 --> Model Class Initialized
INFO - 2024-10-28 18:29:36 --> Model Class Initialized
INFO - 2024-10-28 18:29:36 --> Model Class Initialized
INFO - 2024-10-28 18:29:36 --> Model Class Initialized
INFO - 2024-10-28 18:29:36 --> Model Class Initialized
INFO - 2024-10-28 18:29:36 --> Model Class Initialized
DEBUG - 2024-10-28 18:29:36 --> plural called with: company
DEBUG - 2024-10-28 18:29:36 --> is_countable called with!!!!: company
INFO - 2024-10-28 18:29:36 --> Model Class Initialized
INFO - 2024-10-28 18:29:36 --> Model Class Initialized
INFO - 2024-10-28 18:29:36 --> Model Class Initialized
INFO - 2024-10-28 18:29:36 --> Final output sent to browser
DEBUG - 2024-10-28 18:29:36 --> Total execution time: 0.0812
ERROR - 2024-10-28 21:43:30 --> TEST ERROR MESSAGE - 2024-10-28 21:43:30
ERROR - 2024-10-28 21:44:04 --> TEST ERROR MESSAGE - 2024-10-28 21:44:04
ERROR - 2024-10-28 21:44:04 --> TEST ERROR MESSAGE - 2024-10-28 21:44:04
ERROR - 2024-10-28 21:44:04 --> Severity: Notice --> Undefined index: freetext /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 21:44:04 --> Severity: Notice --> Undefined index: socialDes /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 21:44:04 --> Severity: Notice --> Undefined index: company /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 21:44:04 --> Severity: Notice --> Undefined index: division /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 21:44:04 --> Severity: Notice --> Undefined index: dataGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 21:44:04 --> Severity: Notice --> Undefined index: finalGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 21:44:59 --> TEST ERROR MESSAGE - 2024-10-28 21:44:59
ERROR - 2024-10-28 21:45:00 --> Severity: Notice --> Undefined index: freetext /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 21:45:00 --> Severity: Notice --> Undefined index: socialDes /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 21:45:00 --> Severity: Notice --> Undefined index: company /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 21:45:00 --> Severity: Notice --> Undefined index: division /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 21:45:00 --> Severity: Notice --> Undefined index: dataGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 21:45:00 --> Severity: Notice --> Undefined index: finalGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 21:47:37 --> TEST ERROR MESSAGE - 2024-10-28 21:47:37
ERROR - 2024-10-28 22:03:05 --> Severity: Notice --> Undefined index: freetext /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 22:03:05 --> Severity: Notice --> Undefined index: socialDes /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 22:03:05 --> Severity: Notice --> Undefined index: company /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 22:03:05 --> Severity: Notice --> Undefined index: division /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 22:03:05 --> Severity: Notice --> Undefined index: dataGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 22:03:05 --> Severity: Notice --> Undefined index: finalGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 22:03:06 --> Severity: Notice --> Undefined index: freetext /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 22:03:06 --> Severity: Notice --> Undefined index: socialDes /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 22:03:06 --> Severity: Notice --> Undefined index: company /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 22:03:06 --> Severity: Notice --> Undefined index: division /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 22:03:06 --> Severity: Notice --> Undefined index: dataGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 22:03:06 --> Severity: Notice --> Undefined index: finalGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 22:03:17 --> Severity: Notice --> Undefined index: freetext /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 22:03:17 --> Severity: Notice --> Undefined index: socialDes /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 22:03:17 --> Severity: Notice --> Undefined index: company /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 22:03:17 --> Severity: Notice --> Undefined index: division /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 22:03:17 --> Severity: Notice --> Undefined index: dataGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 22:03:17 --> Severity: Notice --> Undefined index: finalGroup /home/tillmezo/domains/till.mezoo.co.il/public_html/application/views/admin/admin.php 97
ERROR - 2024-10-28 23:45:36 --> Severity: Warning --> Division by zero /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 214
ERROR - 2024-10-28 23:45:36 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: INSERT INTO `feedbackdims` (`feedbackId`, `dimId`, `result`) VALUES (16384, NULL, NAN)
ERROR - 2024-10-28 23:45:36 --> Query error: Unknown column 'NAN' in 'field list' - Invalid query: INSERT INTO `feedbackdims` (`feedbackId`, `dimId`, `result`) VALUES (16384, NULL, NAN)
ERROR - 2024-10-28 23:46:15 --> Severity: Warning --> Cannot use a scalar value as an array /home/tillmezo/domains/till.mezoo.co.il/public_html/application/controllers/Welcome.php 435

<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>

ERROR - 2024-12-23 13:27:32 --> Severity: Warning --> mysqli::real_connect(): (HY000/1045): Access denied for user '_a'@'localhost' (using password: YES) /home/tillmezo/domains/till.mezoo.co.il/public_html/system/database/drivers/mysqli/mysqli_driver.php 201
ERROR - 2024-12-23 13:27:32 --> Unable to connect to the database

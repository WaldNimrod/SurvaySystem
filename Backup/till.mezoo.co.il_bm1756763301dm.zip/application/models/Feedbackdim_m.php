<?php

class Feedbackdim_m extends MY_Model
{

}
<?php

class Feedback_m extends MY_Model
{

}
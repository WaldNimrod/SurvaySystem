<?php

class Responder_m extends MY_Model
{

}
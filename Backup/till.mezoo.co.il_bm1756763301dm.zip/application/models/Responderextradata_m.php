<?php

class Responderextradata_m extends MY_Model
{

}
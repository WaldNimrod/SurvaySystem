<?php

class Dimensiondata_m extends MY_Model
{

}
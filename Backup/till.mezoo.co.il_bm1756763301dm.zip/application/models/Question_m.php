<?php

class Question_m extends MY_Model
{

}
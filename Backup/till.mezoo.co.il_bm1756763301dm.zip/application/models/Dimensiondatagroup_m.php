<?php

class Dimensiondatagroup_m extends MY_Model
{

}
<?php

class Log_m extends MY_Model
{

}
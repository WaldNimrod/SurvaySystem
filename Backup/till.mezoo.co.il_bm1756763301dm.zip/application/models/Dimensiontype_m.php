<?php

class Dimensiontype_m extends MY_Model
{

}
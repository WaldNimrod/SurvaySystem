<?php

class Company_m extends MY_Model
{

}
<?php

class Division_m extends MY_Model
{

}